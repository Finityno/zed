from pathlib import Path
import gzip,hashlib,io,json,platform,tarfile
root=Path(__file__).parent;owner=root.parent;work=Path('/workspace/zed-idle-effects');output=work/'performance-evidence/window-idle-effects-held-20261009';output.mkdir(parents=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((root/'decision.json').read_text());p=json.loads((root/'policy.json').read_text());assert not d['qualified'] and len(d['failures'])==18
for index in ['frozen-inputs.json','pre-candidate-frozen-method.json']:
 for name,expected in json.loads((root/index).read_text()).items():assert sha(root/name)==expected,name
runtime=json.loads((root/'runtime-identities.json').read_text());assert runtime['uname']==platform.uname()._asdict()
for collection in ['dynamic_libraries','compiler_shared_libraries']:
 for path,expected in runtime[collection].items():assert sha(Path(path))==expected['sha256']
assert sha(Path(runtime['compiler']))==runtime['compiler_sha256']
for dep in json.loads((root/'external-dependencies.json').read_text()):assert sha(Path(dep['path']))==dep['sha256']
for lane in ['baseline','candidate']:
 for path,expected in json.loads((root/(lane+'-source-inputs.json')).read_text())['files'].items():assert sha(root/(lane+'-workspace')/path)==expected,path
 for identity in json.loads((root/'binary-identities.json').read_text())[lane].values():assert sha(Path(identity['path']))==identity['sha256']
builds=json.loads((root/'build-order-receipt.json').read_text())['receipts'];phases=json.loads((root/'valid-cohort-order-receipt.json').read_text())['receipts'];assert len(builds)==4 and len(phases)==2
assert phases[0]['started_unix']>=builds[-1]['started_unix']+builds[-1]['elapsed_seconds'];assert phases[1]['started_unix']>=phases[0]['started_unix']+phases[0]['elapsed_seconds']
for kind,count in [('bare',1476),('census',820)]:
 samples=json.loads((root/(kind+'-samples.json')).read_text());assert len(samples)==count
 for row in samples:assert row['exit_code']==0 and sha(Path(row['log']))==row['log_sha256']
assert len(json.loads((root/'contracts-summary.json').read_text()))==36
assert len(json.loads((root/'functional-preflight-summary.json').read_text()))==96
assert all(d['summary'][kind][case][metric]['baseline_median']>d['summary'][kind][case][metric]['candidate_median'] for case in p['primary_cases'] for kind,metric in [('bare','current_rss_kib'),('census','held_bytes'),('census','owner_bytes')])
files={}
for base,prefix in [(root,'comparison'),(owner,'attribution')]:
 for path in base.rglob('*'):
  relative=path.relative_to(base)
  if base==owner and relative.parts[0]=='comparison':continue
  if any(part.endswith('-workspace') or part.endswith('-artifacts') for part in relative.parts):continue
  if path.is_file() and path.suffix in {'.py','.json','.log','.diff','.rs','.c','.md','.txt'}:files[prefix+'/'+str(relative)]=path
for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','LICENSE-APACHE','LICENSE-GPL']:files['native-root/'+name]=root/'candidate-workspace'/name
for lane in ['baseline','candidate']:
 for name in ['app.rs','window.rs','gpui.rs','perf_count.rs','app/effects_profile.rs','window/view_retention/splice_profile.rs','window/view_retention/transcript_profile.rs']:files[lane+'/'+name]=root/(lane+'-workspace')/'crates/gpui/src'/name
manifest={name:{'bytes':path.stat().st_size,'sha256':sha(path)} for name,path in sorted(files.items())};archive=output/'receipts.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=6,mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
 for name,data in [('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())]+[(name,path.read_bytes()) for name,path in sorted(files.items())]:
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 for name,expected in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
evidence={'status':'HELD/unmerged; never unchanged rerun or weaker gates','qualified':False,'baseline':p['baseline'],'source':'c7cbdd4e365c121e476d04db576dee6eeb304c57','fincode_main_at_freeze':p['fincode_main'],'fincode_gpui':p['fincode_pin'],'component_pin':p['component_pin'],'valid_children':2296,'workloads':82,'failures':d['failures'],'all_eight_primary_memory_targets_pass':True,'observed_primary_changes':{case:{metric:d['summary'][kind][case][metric] for kind,metric in [('census','held_bytes'),('census','owner_bytes'),('bare','current_rss_kib')]} for case in p['primary_cases']},'important_gain_not_qualified':'58.74–75.66% lesscompleteApp heldheap,87.5–93.75% lessqueueowner,21.39–33.41%lowernativecurrentRSS.18failedcontrols:5CPU/elapsed/wholechildfields,4censusRSS,8primaryallocation-callfields,1activebackgroundrequestedbytes. Allgainsthreshold/exceedbothranges; controlsdisqualify.','mechanism':'ExistingWindowidlecallback checksalleveryWindowquiet30s andlargeemptyAppqueue>32768; reserve8192Effects. NoApp/Windowfields/queue-enqueuehooks/independentAppTask. At2s usesexistingcallbackrearm towaitremaining30s, costing19extraalloccalls perWindow inclresize against8budget. Backgroundlargebursts withoutdraw canrefaultafterreclaim:active requested+18.29MB exceeds3.28MB frozenbudget.','correctness':'36nativecontract invocations pass expectedbaseline4red/4pass andcandidate8pass inbothbare/census. NativeallWindowquiet/earlyactivity/no-redraw/ordinaryreserve/cancel-on-close/alreadyquiet/refill/callbackownership pass; existingScene/App/Subscriber/cursor/read/nested/idle/retainedoracle16seeds50steps/wheel/dependency/panel/layout/atomic preserved.96fourlanefunctionalchecks andall2296pairedoutputs/state/owner match; App/Windowsizeof unchanged.','protocol':'Foursequentialbuilds51.05/47.22/47.82/50.86s;1476alternatingbarechildren252.02s,then820countingchildren42.77s. Same59immutableexterns/compiler/System/source/runtime/binary/frozen19methodinputs reverified. Effectquiet periods pollat3s thenthe remainder so2s callback/rearm costsincluded, frozenbeforecandidate. No cohortrepeat.','attribution':'Ten currentnativecompleteApp/Window deferred-order ownerchildren retain9437184queuebytes after3s withallclosures released, bothretentionmodes. Existingownedlargeclosedheapranks8.4MBsampledestimate; notRSS.','adverse_setup':'Originalbaselineownerbuild duplicatecountingallocator error preserved; existingtest-only splicefixture changedtocorrectcommoncounter. Prematureattribution afterfailedbuild ranzerochildren andfailedmissingbinary, fullypreserved. Correctedownerbuild/10childrenpass beforecandidate. Beforefreeze preparationscriptfixture-only-copy assertion preserved whereavailable; no candidate/performance samples atthatpoint.','not_run':'OwningstrictClippy/guards/PR/merge/consumeradoption withheld onfailedperformancegates.','limits':p['limits'],'policy_sha256':sha(root/'policy.json'),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(manifest)+1}
(output/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(output/'README.md').write_text('''# Held window-owned effects reclamation

The one frozen 2,296-child comparison across 82 complete App/Window workloads
passes all eight memory targets but fails 18 other fields. Complete-App held
heap falls 58.74–75.66%, queue ownership falls 87.5–93.75%, and native current
RSS falls 21.39–33.41%. Five CPU/elapsed/whole-child controls, four census RSS
controls, eight primary allocation-call budgets and one active background
requested-byte budget fail. Preserve this design unmerged; never repeat it
unchanged or weaken its gates. No PR or adoption is qualified.

The existing window callback waits for every window to be quiet for 30 seconds
before shrinking an empty oversized queue to an 8,192-effect reserve. App and
Window sizes are unchanged, with no enqueue hooks or independent App task.
Rearming still adds 19 calls per window including the resize, against eight
budgeted calls. Active background bursts that do not draw add 18.29 MB of
requested refill bytes, above the declared 3.28 MB allowance. These costs are
included, not hidden by skipping the intermediate two-second callback.

Thirty-six native contract invocations pass, with four real lifecycle regressions
red on baseline and all eight green on candidate in bare and census lanes.
Ninety-six functional checks and all 2,296 paired callback, scene, hitbox,
state and owner outputs match. Every source/compiler/runtime/common 59 native
extern/binary identity and all frozen inputs are reverified after the sequential
build, bare and census phases. All raw samples and original setup failures
are archived and every member hash verified. Exact binaries remain durable.

The ten current-main ownership children confirm a drained 9 MiB effects queue
with no retained closures. Linux fake-platform/System measurements are not
Fincode app, physical GPU, macOS/Windows or shipped-allocator percentages.
No-window, already-quiet-before-burst and last-window-close reclamation are
outside this window-scoped design. Continue with the measured task-rearming
allocation overhead as a distinct candidate; preserve this failed cohort.
''')
(root/'archive-verification.json').write_text(json.dumps({key:evidence[key] for key in ['archive_sha256','archive_bytes','members','valid_children','qualified']},indent=2)+'\n');print((root/'archive-verification.json').read_text())
