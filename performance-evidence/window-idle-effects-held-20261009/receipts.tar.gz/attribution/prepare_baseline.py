from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).parent;source=Path('/workspace/zed-idle-effects');work=root/'baseline-workspace';work.mkdir()
crates=json.loads(Path('/workspace/scratch/gpui-layer-replay-loop/diagnostic-source-inputs.json').read_text())['crates']
for name in crates:shutil.copytree(source/'crates'/name,work/'crates'/name,symlinks=True)
for name in ['Cargo.toml','Cargo.lock','AGENTS.md','README.md','rust-toolchain.toml','LICENSE-APACHE','LICENSE-GPL']:shutil.copy2(source/name,work/name)
shutil.copytree(source/'.cargo',work/'.cargo',symlinks=True)
for name in ['ibm-plex-sans','lilex']:shutil.copytree(source/'assets/fonts'/name,work/'assets/fonts'/name,symlinks=True)
shutil.copy2(root/'perf-count.rs',work/'crates/gpui/src/perf_count.rs')
shutil.copy2(root/'comparison-fixture.rs',work/'crates/gpui/src/window/view_retention/splice_profile.rs')
p=work/'crates/gpui/src/gpui.rs';p.write_text(p.read_text()+'\n#[cfg(all(test, gpui_layout_sets_census))]\n#[path = "perf_count.rs"]\npub(crate) mod perf_count;\n')
old=Path('/workspace/scratch/gpui-effect-capacity-loop')
shutil.copy2(root/'owner-attribution-fixture.rs',work/'crates/gpui/src/app/effects_profile.rs')
p=work/'crates/gpui/src/app.rs';p.write_text(p.read_text()+'\n#[cfg(all(test, target_os = "linux"))]\n#[path = "app/effects_profile.rs"]\nmod effects_profile;\n')
files={str(p.relative_to(work)):hashlib.sha256(p.read_bytes()).hexdigest() for p in work.rglob('*') if p.is_file()}
(root/'baseline-source-inputs.json').write_text(json.dumps({'baseline':'df6e7d05b529313ad142f397a4e4ea428c2c01ae','candidate':None,'crates':crates,'files':files,'scope':'Exact current24owningcrate snapshot, completeApp/Window deferred-callback owner and3second quietfixture. No candidate. Shared counting System, immutable59 nativeexterns.'},indent=2)+'\n')
shutil.copy2(old/'run_attribution.py',root/'run_attribution.py')
print(json.dumps({'files':len(files),'candidate':None}))
