from pathlib import Path
import json,shutil,hashlib
root=Path(__file__).parent;prior=Path('/workspace/scratch/gpui-effect-capacity-loop/comparison')
shutil.copy2(root/'effects-fixture.rs',root/'owner-attribution-fixture.rs')
shutil.copy2(prior/'effects-fixture.rs',root/'effects-fixture.rs')
p=root/'effects-fixture.rs';s=p.read_text();needle='    let progress = Rc::new(Cell::new((0usize, 0u64)));\n    let started ='
insert='''    let second_window = if matches!(scenario, "two_quiet" | "one_busy") {
        let window = cx.add_window({
            let draws = draws.clone();
            move |_, _| EffectProfileView(draws)
        });
        for _ in 0..4 {
            cx.update_window(window.into(), |_, window, cx| window.draw(cx).clear(cx)).expect("second warmup");
        }
        cx.update_window(window.into(), |_, window, _| window.reset_frame_work_stats(false)).expect("disable second clocks");
        Some(window)
    } else { None };
    if scenario == "already_quiet" { effect_quiet(&mut cx, 31, &draws); }
    let progress = Rc::new(Cell::new((0usize, 0u64)));
    let started ='''
assert needle in s;s=s.replace(needle,insert)
needle='    if scenario != "active" && scenario != "long_refault" {'
insert='''    if scenario == "one_busy" {
        for _ in 0..4 {
            effect_quiet(&mut cx, 10, &draws);
            cx.update_window(second_window.expect("second window").into(), |_, window, cx| window.draw(cx).clear(cx)).expect("active window draw");
        }
    }
    if scenario != "active" && scenario != "long_refault" && scenario != "one_busy" {'''
assert needle in s;s=s.replace(needle,insert)
s=s.replace('\\"draws\\":{}}}", draws.get());','\\"app_size_bytes\\":{},\\"window_size_bytes\\":{},\\"draws\\":{}}}", std::mem::size_of::<App>(), std::mem::size_of::<Window>(), draws.get());')
assert 'app_size_bytes' in s;p.write_text(s)
policy=json.loads((prior/'policy.json').read_text());extras=['effect-two_quiet-'+mode+'-'+str(count) for mode in ['off','on'] for count in [65536,131072]]+['effect-one_busy-on-131072','effect-already_quiet-off-131072','effect-already_quiet-on-131072']
policy['controls']+=extras;policy['effect_cases']+=extras;policy['primary_cases']+=extras[:4]
policy.update(goal='Release emptyoversized effectsqueue through existingWindowidlecallback afterallwindowsquiet30s, preserving8192reserve. NoaddedAppfields/independenttimer/noqueue-enqueue hotpath changes; completeApp memory/RSSgain, strictCPU andboundedcoldrefill controls.',baseline='df6e7d05b529313ad142f397a4e4ea428c2c01ae',fincode_main='37ec31483e85fea4c366317dec717897abd5e282',primary_gain_gate='Alleight single/twoWindow idleprimaries completeAppcensus heldbytes reduce>=20%, emptyqueue ownerbytes>=85%, barecurrentnativeRSS>=10%, absolute gains exceedBOTHfull lane ranges. New8192reserve retains87.5/93.75%lessowner; deliberatecoldrefill tradeoff fromfailed256reserve mechanism, frozenBEFOREcandidate. Noapp/GPUclaim.',normal_memory_controls='ZeroaddedApp/Windowfields. All82 censuspeak medianincreases<=0; all58ordinary andempty/below/boundary andalreadyquiet/noWindow controls: held/requested/calls increases<=0. Largeeffectmemorycontrols useexplicitcoldrefill budgets; nootherfixedcache allowance.',cold_memory_tradeoff='ReusesexistingperWindowTask field/weakWindowcallback: at2s usualperFrame shrink, ifemptyqueuecapacity>32768 waitremainderof30s sinceeveryWindow lastdraw, then shrinkemptyqueue to8192reserve. Noextratimer forsmallqueues/noWindow/alreadyquiet-aftercallback. Addedrearm/task+ringresize budget perlargecycle andWindow:655360requestedbytes and8calls,0peak increase. Long31s refills:atmostceil(log2(count/8192))growthcalls percycle andgeometricadditionalrequestedbytes<=2*count*72*(cycles-1). Short3s gaps preservequeue untilfull30s quiet. CPU/RSScontrols remainstrictfullbaselinevariation. Recordallcosts. PriorfailedApptimer256reserve cohort heldunchanged.',basis='Ten completecurrent-main nativeApp/Window ownerchildren andowned8.4MBsampledheaprank. Actual131072Effectqueue keeps9437184bytes after3s quietinbothretentionmodes; allorderedclosures released. EarlierindependentAppTask/256reserve failed35controls. NewexistingWindow ownership/nofields/noenqueuehooks/8192reserve.',fixed_app_budget=0,retained_task_budget=0,timer_requested_budget_per_cycle=655360,timer_call_budget_per_cycle=8,effect_reserve=8192,owner_reduction_target=.85)
policy['effect_windows']={case:2 if case in extras[:5] else 0 if 'no_window' in case or 'close_window' in case else 1 for case in policy['effect_cases']}
for case in extras:policy['effect_cycles'][case]=1
policy['correctness']='Nativefull30s-windowquiet before-red/after-green; everyWindowquiet/noearlydraw/activitybackoff/smallreserve/close/cancel/noAppsize/no-redraw/callbackorder; existingScene/App/Subscriber/cursor/read/nested/idle/retainedoracle/wheel/dependency/panel/layout/atomic contracts. All2296pairedscene/hitbox/state/owner outputs match.'
policy['limits']+=['Window-scoped idle reuse: noWindow/already-quiet-beforeburst/lastWindowclose andlargeburstwithoutsubsequentdraw canretainoldqueue; no claimofunconditionalApp idlecleanup.','A largequeue reclaim requires one coldresize of8192*72bytes and may require bounded refill growth after30s. Allcosts included and predeclared; no ordinaryCPU/RSS exemption.','Prior35-control failedApptimer design unchanged/unmerged; this source changes Windowidle ownership, reserve and callback architecture, not codeplacement tofitnoise.']
(root/'policy.json').write_text(json.dumps(policy,indent=2)+'\n')
shutil.copy2(prior/'check_effect_preflight.py',root/'check_effect_preflight.py')
s=(prior/'qualify_effects.py').read_text().replace("math.log2(count / 256)","math.log2(count / policy['effect_reserve'])").replace("('owner_bytes', 0.99)","('owner_bytes', policy['owner_reduction_target'])")
s=s.replace("ordinary = '-empty-' in case or '-below-' in case", "ordinary = any(marker in case for marker in ['-empty-', '-below-', '-boundary-', '-already_quiet-', '-no_window-', '-close_window-'])")
s=s.replace("cycles * policy['timer_requested_budget_per_cycle']", "cycles * policy['effect_windows'][case] * policy['timer_requested_budget_per_cycle']").replace("cycles * policy['timer_call_budget_per_cycle']", "cycles * policy['effect_windows'][case] * policy['timer_call_budget_per_cycle']")
s=s.replace("if metric == 'held_bytes' and '-active-' in case:","if metric == 'held_bytes' and ('-active-' in case or '-one_busy-' in case):")
s=s.replace("effect = case in policy['effect_cases']", "effect = case in policy['effect_cases']\n        if effect:\n            assert all(old['app_size_bytes'] == new['app_size_bytes'] and old['window_size_bytes'] == new['window_size_bytes'] for old, new in zip(baseline, candidate))")
(root/'qualify.py').write_text(s)
print(json.dumps({'cases':len(policy['controls']),'primary':len(policy['primary_cases']),'children':len(policy['controls'])*28,'source_candidate':None,'policy_sha256':hashlib.sha256((root/'policy.json').read_bytes()).hexdigest()}))
