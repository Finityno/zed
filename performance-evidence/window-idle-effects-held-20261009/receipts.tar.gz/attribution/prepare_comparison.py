from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path(__file__).parent;source=Path('/workspace/zed-idle-effects');baseline='df6e7d05b529313ad142f397a4e4ea428c2c01ae';env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
candidate=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],env=env,text=True).strip()
crates=json.loads((root.parent/'baseline-source-inputs.json').read_text())['crates']
for lane in ['baseline','candidate']:
 work=root/(lane+'-workspace');work.mkdir()
 for name in crates:shutil.copytree(source/'crates'/name,work/'crates'/name,symlinks=True)
 for name in ['Cargo.toml','Cargo.lock','AGENTS.md','README.md','rust-toolchain.toml','LICENSE-APACHE','LICENSE-GPL']:shutil.copy2(source/name,work/name)
 shutil.copytree(source/'.cargo',work/'.cargo',symlinks=True)
 for name in ['ibm-plex-sans','lilex']:shutil.copytree(source/'assets/fonts'/name,work/'assets/fonts'/name,symlinks=True)
 if lane=='baseline':
  for name in ['app.rs','window.rs']:
   data=subprocess.check_output(['git','-C',str(source),'show',baseline+':crates/gpui/src/'+name],env=env)
   if name=='app.rs':data+=(root/'window-effect-regression.rs').read_bytes()
   (work/'crates/gpui/src'/name).write_bytes(data)
 shutil.copy2(root/'perf-count.rs',work/'crates/gpui/src/perf_count.rs')
 p=work/'crates/gpui/src/gpui.rs';p.write_text(p.read_text()+'\n#[cfg(all(test, gpui_layout_sets_census))]\n#[path = "perf_count.rs"]\npub(crate) mod perf_count;\n')
 p=work/'crates/gpui/src/app.rs';p.write_text(p.read_text()+'\n#[cfg(all(test, target_os = "linux"))]\n#[path = "app/effects_profile.rs"]\nmod effects_profile;\n')
 shutil.copy2(root/'effects-fixture.rs',work/'crates/gpui/src/app/effects_profile.rs')
 for src,dest in [('comparison-fixture.rs','splice_profile.rs'),('transcript-fixture.rs','transcript_profile.rs')]:shutil.copy2(root/src,work/'crates/gpui/src/window/view_retention'/dest)
 p=work/'crates/gpui/src/window/view_retention/tests.rs';p.write_text(p.read_text()+'\n#[cfg(target_os = "linux")]\n#[path = "transcript_profile.rs"]\nmod transcript_profile;\n')
 files={str(p.relative_to(work)):hashlib.sha256(p.read_bytes()).hexdigest() for p in work.rglob('*') if p.is_file()}
 (root/(lane+'-source-inputs.json')).write_text(json.dumps({'baseline':baseline,'candidate':candidate,'lane':lane,'crates':crates,'files':files,'description':'Exactcurrent24owningcrates/root/lock/fonts/licenses. Common82completeApp/Window fixtures/countingSystem,8realWindow lifecyclecontracts. OnlyAppemptyqueue existingWindowidle30s reserve8192 productiondiff.'},indent=2)+'\n')
left=json.loads((root/'baseline-source-inputs.json').read_text())['files'];right=json.loads((root/'candidate-source-inputs.json').read_text())['files'];changed=[p for p in left if left[p]!=right[p]]
assert sorted(changed)==['crates/gpui/src/app.rs','crates/gpui/src/window.rs']
for name,expected in json.loads((root/'pre-candidate-frozen-method.json').read_text()).items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
(root/'candidate-source.diff').write_bytes(subprocess.check_output(['git','-C',str(source),'diff',baseline,candidate],env=env))
(root/'comparison-source-receipt.json').write_text(json.dumps({'baseline':baseline,'candidate':candidate,'changed_source':changed,'files_each':len(left),'policy_sha256':hashlib.sha256((root/'policy.json').read_bytes()).hexdigest()},indent=2)+'\n')
print(json.dumps({'baseline':baseline,'candidate':candidate,'changed':changed,'files':len(left)}))
