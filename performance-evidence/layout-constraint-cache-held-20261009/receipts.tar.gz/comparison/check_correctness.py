from pathlib import Path
import subprocess,os,json,hashlib
r=Path(__file__).parent;policy=json.loads((r/'policy.json').read_text());rows=json.loads((r/'correctness-receipts.json').read_text()) if (r/'correctness-receipts.json').exists() else [];out=r/'correctness';out.mkdir(exist_ok=True);bins={lane:str(r/f'{lane}-bare-artifacts/gpui-ada3fb4d7b1cfe56') for lane in ['baseline','candidate']}
patterns=['taffy::','window::layout_retention_tests::','window::view_retention::tests::','window::view_retention::dependencies::','window::layout_keys::','text_system::','scene::tests::','window::glyph_painting::tests::','app::tests::','arena::tests::','elements::div::tests::','elements::list::test::','elements::uniform_list::test::','elements::text::tests::','elements::deferred::tests::','window::text_glyph_cache_tests::','window::tests::','subscription::tests::']
for lane,binary in bins.items():
 for i,pattern in enumerate(patterns):
  if any(row.get('lane')==lane and row.get('pattern')==pattern for row in rows):continue
  command=[binary,pattern,'--nocapture','--test-threads=1'];p=out/f'{lane}-{i:02}.log'
  with p.open('w') as f:result=subprocess.run(command,env=os.environ,stdout=f,stderr=subprocess.STDOUT,timeout=180)
  rows.append({'lane':lane,'pattern':pattern,'command':command,'exit_code':result.returncode,'log':str(p),'log_sha256':hashlib.sha256(p.read_bytes()).hexdigest()});(r/'correctness-receipts.json').write_text(json.dumps(rows,indent=2)+'\n')
  assert result.returncode==0,p.read_text()
for case in policy['controls']:
 audits=[]
 for lane,binary in bins.items():
  pattern='profile_owned_layout_cache' if case in policy['layout_cases'] else 'profile_transcript_paint' if case in policy['transcript_cases'] else 'profile_layout_key_sets'
  if any(row.get('lane')==lane and row.get('pattern')==pattern for row in rows):continue
  command=[binary,pattern,'--ignored','--nocapture','--test-threads=1'];env=os.environ|{'LAYOUT_OWNER_CASE':case,'LAYOUT_OWNER_ITERATIONS':'32','TRANSCRIPT_PROFILE_CASE':case,'TRANSCRIPT_PROFILE_ITERATIONS':'32','LAYOUT_SETS_PROFILE_CASE':case,'LAYOUT_SETS_PROFILE_ITERATIONS':'32','LAYOUT_AUDIT_FRAMES':'1'};p=out/f'frames-{case}-{lane}.log'
  prior=next((row for row in rows if row.get('case')==case and row.get('lane')==lane),None)
  if prior:
   assert hashlib.sha256(p.read_bytes()).hexdigest()==prior['log_sha256'];code=prior['exit_code']
  else:
   with p.open('w') as f:result=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=60)
   code=result.returncode
  row={'case':case,'lane':lane,'command':command,'exit_code':code,'log':str(p),'log_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
  for line in p.read_text().splitlines():
   if 'FRAME_AUDIT ' in line:row['frame_audit']=int(line.split('FRAME_AUDIT ',1)[1])
   for marker in ['LAYOUT_OWNER ','TRANSCRIPT_PROFILE ','LAYOUT_SETS_PROFILE ']:
    if marker in line:row.update(json.loads(line.split(marker,1)[1]))
  if prior:rows.remove(prior)
  rows.append(row);(r/'correctness-receipts.json').write_text(json.dumps(rows,indent=2)+'\n');assert code==0 and 'frame_audit' in row,p.read_text();audits.append(row)
 for field in ['frame_audit','signature','frame_hash','state_count','state_box_bytes','frames','nodes']:
  if field in audits[0] or field in audits[1]:assert audits[0][field]==audits[1][field],(case,field,audits[0].get(field),audits[1].get(field))
print(json.dumps({'children':len(rows),'all_pass':True,'per_frame_audit_cases':len(policy['controls'])}))
