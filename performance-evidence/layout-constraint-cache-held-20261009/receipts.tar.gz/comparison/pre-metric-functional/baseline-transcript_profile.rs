use super::*;
use std::{hash::{Hash, Hasher}, hint::black_box};

#[test]
#[ignore]
fn profile_transcript_paint() {
    let case = std::env::var("TRANSCRIPT_PROFILE_CASE").expect("TRANSCRIPT_PROFILE_CASE");
    let iterations: usize = std::env::var("TRANSCRIPT_PROFILE_ITERATIONS")
        .expect("TRANSCRIPT_PROFILE_ITERATIONS").parse().expect("iterations");
    let parts: Vec<_> = case.split('-').collect();
    let scenario = parts[0];
    let retained = parts[1] == "on";
    let count: usize = parts[2].parse().expect("rows");
    assert!(count >= 32 && iterations > 0 && iterations.is_multiple_of(2));
    #[cfg(gpui_layout_sets_census)]
    super::splice_profile::census::start();
    let mut cx = super::super::super::layout_retention_tests::text_system_context(0);
    cx.update(|cx| cx.set_view_retention(retained));
    let window = cx.add_window(|_, cx| {
        let rows: Vec<_> = (0..count)
            .map(|ix| {
                let badge = cx.new(|_| TranscriptBadge { count: 0 });
                cx.new(|_| TranscriptRow { ix, lines: 1 + ix % 4, tail: 0, badge })
            })
            .collect();
        Transcript { list_state: ListState::new(rows.len(), ListAlignment::Bottom, px(200.)), rows }
    });
    cx.simulate_window_resize(window.into(), size(px(900.), px(1200.)));
    let (rows, list_state) = window.read_with(&cx, |transcript, _| {
        (transcript.rows.clone(), transcript.list_state.clone())
    }).expect("window");
    if scenario == "scroll" {
        list_state.scroll_to(ListOffset { item_ix: count.saturating_sub(50), offset_in_item: px(0.) });
    }
    let frame = |cx: &mut TestAppContext| {
        cx.update_window(window.into(), |_, window, cx| window.draw(cx).clear(cx)).expect("frame");
    };
    for _ in 0..4 { frame(&mut cx); }
    cx.update_window(window.into(), |_, window, _| window.reset_frame_work_stats(false)).expect("disable diagnostic clocks");
    let audit_frames = std::env::var_os("LAYOUT_AUDIT_FRAMES").is_some(); let mut audit = Vec::with_capacity(if audit_frames { iterations } else { 0 });
    let started = Instant::now();
    let cpu_started = super::splice_profile::thread_cpu_ns();
    for index in 0..iterations {
        match scenario {
            "scroll" => {
                list_state.scroll_by(px(if (index / 60) % 2 == 0 { 6. } else { -6. }));
                window.update(&mut cx, |_, _, cx| cx.notify()).expect("notify");
            }
            "stream" => rows[count - 1].update(&mut cx, |row, cx| {
                row.tail += 1;
                if index % 8 == 7 { row.lines += 1; }
                cx.notify();
            }),
            "tick" => {
                let badge = rows[count - 10].read_with(&cx, |row, _| row.badge.clone());
                badge.update(&mut cx, |badge, cx| { badge.count += 1; cx.notify(); });
            }
            "redraw" => window.update(&mut cx, |_, _, cx| cx.notify()).expect("notify"),
            "rebuild" => window.update(&mut cx, |_, window, _| window.refresh()).expect("refresh"),
            _ => panic!("unknown scenario"),
        }
        frame(&mut cx);
        if audit_frames { audit.push(cx.update_window(window.into(), |_, window, _| describe_frame(window)).expect("frame audit")); }
        black_box(&cx);
    }
    let cpu_ns = super::splice_profile::thread_cpu_ns() - cpu_started;
    let elapsed_ns = started.elapsed().as_nanos();
    #[cfg(gpui_layout_sets_census)]
    let (held_bytes, peak_bytes, requested_bytes, allocation_calls) = super::splice_profile::census::finish();
    #[cfg(not(gpui_layout_sets_census))]
    let (held_bytes, peak_bytes, requested_bytes, allocation_calls) = (-1, -1, 0, 0);
    let (nodes, frames) = cx.update_window(window.into(), |_, window, _| (window.layout_engine.as_ref().expect("engine").layout_owner_node_counts(),window.frame_work_stats().frames)).expect("owner counts");
    let (state_count, state_box_bytes, signature) = cx.update_window(window.into(), |_, window, _| {
        let state_count = window.rendered_frame.element_states.len();
        let state_box_bytes: usize = window.rendered_frame.element_states.values()
            .map(|state| std::mem::size_of_val(state.inner.as_ref())).sum();
        let mut hasher = std::collections::hash_map::DefaultHasher::new();
        describe_frame(window).hash(&mut hasher);
        (state_count, state_box_bytes, hasher.finish())
    }).expect("audit");
    if audit_frames { use std::hash::{Hash, Hasher}; let mut hasher = std::collections::hash_map::DefaultHasher::new(); audit.hash(&mut hasher); println!("FRAME_AUDIT {}", hasher.finish()); }
    println!("TRANSCRIPT_PROFILE {{\"case\":\"{case}\",\"iterations\":{iterations},\"nodes\":{nodes},\"frames\":{frames},\"cpu_ns\":{cpu_ns},\"elapsed_ns\":{elapsed_ns},\"signature\":{signature},\"state_count\":{state_count},\"state_box_bytes\":{state_box_bytes},\"held_bytes\":{held_bytes},\"peak_bytes\":{peak_bytes},\"requested_bytes\":{requested_bytes},\"allocation_calls\":{allocation_calls}}}");
}
