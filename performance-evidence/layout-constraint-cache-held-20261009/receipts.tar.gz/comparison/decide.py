from pathlib import Path
import json,statistics,math,hashlib
r=Path(__file__).parent;p=json.loads((r/'policy.json').read_text());assert hashlib.sha256((r/'policy.json').read_bytes()).hexdigest()==(r/'policy.sha256').read_text().strip();summary=[];failures=[]
for kind,n in [('bare',p['timing_pairs']),('census',p['memory_pairs'])]:
 rows=json.loads((r/(kind+'-samples.json')).read_text());assert len(rows)==len(p['controls'])*n*2
 for case in p['controls']:
  lanes={lane:[v for v in rows if v['case']==case and v['lane']==lane] for lane in ['baseline','candidate']};assert all(len(v)==n and all(vv['exit_code']==0 for vv in v) for v in lanes.values())
  for pair in range(n):
   b=next(v for v in lanes['baseline'] if v['pair']==pair);c=next(v for v in lanes['candidate'] if v['pair']==pair)
   for field in ['signature','frame_hash','state_count','state_box_bytes','frames','nodes','node_high_water']:
    if field in b or field in c:assert b[field]==c[field],(kind,case,pair,field,b.get(field),c.get(field))
  high=max(v['node_high_water'] for lane in lanes.values() for v in lane);capacity=1<<max(0,high).bit_length();heap_budget=96*capacity;byte_budget=heap_budget*(max(v['frames'] for lane in lanes.values() for v in lane)+4);rss_budget=math.ceil(heap_budget/1024)
  fields=['cpu_ns','elapsed_ns','child_cpu_ns','current_rss_kib','peak_rss_kib'] if kind=='bare' else ['held_bytes','peak_bytes','requested_bytes','allocation_calls','current_rss_kib','peak_rss_kib']
  entry={'kind':kind,'case':case,'node_high_water':high,'heap_budget':heap_budget,'requested_byte_budget':byte_budget,'rss_fixed_budget_kib':rss_budget,'fields':{}}
  for field in fields:
   base=[v[field] for v in lanes['baseline']];cand=[v[field] for v in lanes['candidate']];bm=statistics.median(base);cm=statistics.median(cand);br=max(base)-min(base);cr=max(cand)-min(cand);delta=cm-bm;gain=-delta/bm if bm else 0
   if kind=='bare' and case in p['primary'] and field in ['cpu_ns','elapsed_ns']:budget=None;passed=gain>=p['primary_gain_fraction'] and -delta>max(br,cr);gate='primary>=15%gainandbothranges'
   else:
    budget=br+rss_budget if field in ['current_rss_kib','peak_rss_kib'] else heap_budget if field in ['held_bytes','peak_bytes'] else byte_budget if field=='requested_bytes' else 0 if field=='allocation_calls' else br;passed=delta<=budget;gate='control'
   metric={'baseline_median':bm,'candidate_median':cm,'delta':delta,'fraction_gain':gain,'baseline_range':br,'candidate_range':cr,'budget':budget,'gate':gate,'pass':passed};entry['fields'][field]=metric
   if not passed:failures.append({'kind':kind,'case':case,'field':field,**metric})
  summary.append(entry)
pre=json.loads((r.parent/'cache-owner-preflight.json').read_text())['rows']
for count in [0,16,80,133,141,645,671,1024,10000]:
 b=next(v for v in pre if v['version']=='0.13.0' and v['nodes']==count);c=next(v for v in pre if v['version']=='0.14.0' and v['nodes']==count);assert c['held']-b['held']==40*(count+1) and c['bytes']-b['bytes']==40*(count+1) and c['peak']-b['peak']==40*(count+1) and c['calls']==b['calls'] and b['after_drop']==c['after_drop']==0
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');decision={'qualified':not failures,'status':'PERFORMANCE_GATES_PASS_PENDING_OWNING_CHECKS_REVIEW' if not failures else 'HELD_UNMERGED','failures':failures,'controls':len(p['controls']),'native_children':len(p['controls'])*(p['timing_pairs']+p['memory_pairs'])*2,'primary':[v for v in summary if v['kind']=='bare' and v['case'] in p['primary']],'policy_sha256':hashlib.sha256((r/'policy.json').read_bytes()).hexdigest(),'no_unchanged_resampling':True,'no_app_GPU_platform_gain':True,'fixed_Taffy_memory_cost':'+40bytes per puretree node-slot; +16Cache,+8Style,+8Layout(times2). No memory gain.'};(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n');print(json.dumps({'qualified':not failures,'children':decision['native_children'],'failed_fields':len(failures),'primary':[(v['case'],v['fields']['cpu_ns']['fraction_gain'],v['fields']['elapsed_ns']['fraction_gain']) for v in decision['primary']],'failure_list':[(f['kind'],f['case'],f['field'],f['delta'],f['budget']) for f in failures]}))
