from pathlib import Path
import json,shutil,hashlib
r=Path(__file__).parent;v1=r/'pre-metric-functional';v1.mkdir()
for lane in ['baseline','candidate']:
 for name in [lane+'-bare-artifacts',lane+'-bare-build.log',lane+'-bare-build-receipt.json','build-current-'+lane+'-bare.log','build-current-'+lane+'-bare-receipt.json',lane+'-source-inputs.json']:shutil.move(r/name,v1/name)
 w=r/(lane+'-workspace');src=w/'crates/gpui/src';p=src/'taffy.rs';shutil.copy2(p,v1/(lane+'-taffy.rs'));s=p.read_text();s=s.replace('    pub(crate) fn layout_owner_node_counts(&self) -> usize { self.taffy.total_node_count() }','    pub(crate) fn layout_owner_node_counts(&self) -> usize { self.taffy.total_node_count() }\n    pub(crate) fn layout_owner_node_high_water(&self) -> usize { self.node_high_water() }');p.write_text(s)
 for relative,handle in [('window/view_retention/layout_owner_profile.rs','view'),('window/view_retention/transcript_profile.rs','window'),('window/view_retention/splice_profile.rs','window')]:
  p=src/relative;shutil.copy2(p,v1/(lane+'-'+p.name));s=p.read_text();marker='    if audit_frames { use std::hash';i=s.index(marker);s=s[:i]+'''    let node_high_water = cx.update_window('''+handle+'''.into(), |_, window, _| window.layout_engine.as_ref().expect("engine").layout_owner_node_high_water()).expect("node high water");
    let current_rss_kib = crate::perf_count::native_current_rss_kib();
'''+s[i:];s=s.replace(r'\"nodes\":{nodes},',r'\"nodes\":{nodes},\"node_high_water\":{node_high_water},\"current_rss_kib\":{current_rss_kib},');p.write_text(s)
 p=src/'perf_count.rs';shutil.copy2(p,v1/(lane+'-perf-count.rs'));s=p.read_text()+'''
pub(crate) fn native_current_rss_kib() -> usize {
    let status = std::fs::read_to_string("/proc/self/status").expect("native Linux status");
    status.lines().find_map(|line| line.strip_prefix("VmRSS:").and_then(|value| value.split_whitespace().next()).and_then(|value| value.parse().ok())).expect("native RSS")
}
''';p.write_text(s)
 (r/(lane+'-source-inputs.json')).write_text(json.dumps({'baseline':'08d5555709d7afab3936c7afcd9f7f0ff9ecbd65','private_harness_only':True,'files':{str(p.relative_to(w)):hashlib.sha256(p.read_bytes()).hexdigest() for p in w.rglob('*') if p.is_file()}},indent=2)+'\n')
(v1/'scope.json').write_text(json.dumps({'scope':'All188 successful native functional children, originalsource/build/binaries retained. Initialparserfailure reparsed without rerunning those21children. Add private actual maximum logical nodeowner count for frozen fixedcapacity bound and nativecurrentRSS read AFTER componenttimer/census snapshot/finish. No production or frozenpolicychange, no pairedperformance samples before/after. Final four metricbinaries and own functional contract qualification pending.'},indent=2)+'\n')
shutil.copy2(r/'correctness-receipts.json',v1/'correctness-receipts.json');shutil.copytree(r/'correctness',v1/'correctness');shutil.move(r/'correctness-receipts.json',v1/'correctness-legacy-receipts.json');shutil.move(r/'correctness',v1/'correctness-legacy')
p=r/'check_correctness.py';s=p.read_text().replace("rows=json.loads((r/'correctness-receipts.json').read_text());","rows=json.loads((r/'correctness-receipts.json').read_text()) if (r/'correctness-receipts.json').exists() else [];");s=s.replace("'text_system::tests::'","'text_system::'").replace("'window::view_retention::dependencies::tests::'","'window::view_retention::dependencies::'").replace("'arena::tests::']","'arena::tests::','elements::div::tests::','elements::list::test::','elements::uniform_list::test::','elements::text::tests::','elements::deferred::tests::','window::text_glyph_cache_tests::','window::tests::','subscription::tests::']");p.write_text(s)
print('Private maxowner/currentRSS metrics added; all first188 functional raw/source/build/binaries preserved. Frozenpolicy/sourcecandidate untouched.')
