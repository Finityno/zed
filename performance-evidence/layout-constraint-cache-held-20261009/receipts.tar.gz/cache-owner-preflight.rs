#[path = "perf-count.rs"] mod perf_count;
use std::hint::black_box;
fn main() {
    let nodes: usize = std::env::args().nth(1).expect("nodes").parse().expect("node count");
    perf_count::census::start();
    let mut tree = taffy::TaffyTree::<()>::with_capacity(nodes);
    for _ in 0..nodes { black_box(tree.new_leaf(taffy::Style::default()).expect("leaf")); }
    let (held, peak, bytes, calls) = perf_count::census::snapshot();
    drop(tree);
    let (released, _, _, _) = perf_count::census::finish();
    assert_eq!(released, 0);
    println!("{{\"nodes\":{nodes},\"cache_size\":{},\"style_size\":{},\"layout_size\":{},\"tree_size\":{},\"held\":{held},\"peak\":{peak},\"bytes\":{bytes},\"calls\":{calls},\"after_drop\":{released}}}", std::mem::size_of::<taffy::Cache>(),std::mem::size_of::<taffy::Style>(), std::mem::size_of::<taffy::Layout>(),std::mem::size_of::<taffy::TaffyTree<()>>());
}
