use super::*;
use std::hint::black_box;

struct LayoutOwnerRow { index: usize, value: bool, accent: bool }
impl Render for LayoutOwnerRow {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        let label: SharedString = format!("Setting {}", self.index).into();
        let description: SharedString = format!("Setting {} controls the transcript and editor panel. Text wraps as the sidebar takes space.", self.index).into();
        div().id(("layout-owner-row", self.index)).w_full().flex().flex_row().gap_3().py_1()
            .text_color(if self.accent { hsla(0.6, 0.7, 0.5, 1.) } else { hsla(0., 0., 0.1, 1.) })
            .child(div().flex_1().min_w_0().flex().flex_col().gap_1().child(label).child(div().text_size(px(12.)).child(description)))
            .child(div().w(px(160.)).flex().flex_col().child(if self.value { "Enabled for this workspace" } else { "Disabled" }).child("Ctrl+Shift+P"))
    }
}
struct LayoutOwnerPanel { rows: Vec<Entity<LayoutOwnerRow>>, header: bool }
impl Render for LayoutOwnerPanel {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        div().id("layout-owner-panel").size_full().flex().flex_col().text_size(px(14.))
            .child(div().h(px(40.)).child(if self.header { "Workspace settings updated" } else { "Workspace settings" }))
            .child(div().id("layout-owner-scroll").flex_1().w_full().min_h_0().overflow_y_scroll()
                .child(div().w_full().flex().flex_col().children(self.rows.iter().cloned())))
    }
}

#[test]
#[ignore]
fn profile_owned_layout_cache() {
    let case = std::env::var("LAYOUT_OWNER_CASE").expect("case");
    let parts: Vec<_> = case.split('-').collect();
    let scenario = parts[0]; let retained = parts[1] == "on";
    let count: usize = parts[2].parse().expect("rows");
    let timed = parts[3] == "clock";
    let iterations: usize = std::env::var("LAYOUT_OWNER_ITERATIONS").expect("iterations").parse().expect("iterations");
    #[cfg(gpui_layout_sets_census)] crate::perf_count::census::start();
    let mut cx = super::super::super::layout_retention_tests::text_system_context(0);
    cx.update(|cx| cx.set_view_retention(retained));
    let view = cx.add_window(|_, cx| LayoutOwnerPanel { rows: (0..count).map(|index| cx.new(|_| LayoutOwnerRow {index,value:false,accent:false})).collect(),header:false });
    cx.simulate_window_resize(view.into(),size(px(900.),px(1100.)));
    for _ in 0..4 { cx.update_window(view.into(),|_,window,cx| {window.refresh();window.draw(cx).clear(cx);}).expect("warm"); }
    let rows = view.update(&mut cx, |view,_,_| view.rows.clone()).expect("rows");
    cx.update_window(view.into(), |_,window,_| window.reset_frame_work_stats(timed)).expect("clock");
    let start = Instant::now(); let cpu_start = super::splice_profile::thread_cpu_ns();
    for index in 0..iterations {
        if scenario == "value" || scenario == "color" {
            rows[0].update(&mut cx,|row,cx| { if scenario=="value" {row.value=index%2==0;}else{row.accent=index%2==0;} cx.notify(); });
        } else if scenario == "header" {
            view.update(&mut cx,|view,_,cx| {view.header=index%2==0;cx.notify();}).expect("header");
        } else if scenario == "resize" {
            cx.simulate_window_resize(view.into(),size(px(if index%2==0 {720.} else {900.}),px(1100.)));
        } else { assert_eq!(scenario,"redraw"); }
        cx.update_window(view.into(),|_,window,cx| {window.draw(cx).clear(cx);}).expect("draw");
    }
    let cpu_ns=super::splice_profile::thread_cpu_ns()-cpu_start;let elapsed_ns=start.elapsed().as_nanos();
    #[cfg(gpui_layout_sets_census)] let (held_bytes,peak_bytes,requested_bytes,allocation_calls)=crate::perf_count::census::snapshot();
    #[cfg(not(gpui_layout_sets_census))] let (held_bytes,peak_bytes,requested_bytes,allocation_calls)=(-1,-1,0,0);
    let (stats,nodes,cache_size,node_capacity)=cx.update_window(view.into(),|_,window,_| {
        let engine=window.layout_engine.as_ref().expect("layout engine");
        (window.frame_work_stats(),engine.layout_owner_node_counts(),std::mem::size_of::<taffy::Cache>(),0usize)
    }).expect("stats");
    use std::hash::{Hash,Hasher};let mut signature=std::collections::hash_map::DefaultHasher::new();
    cx.update_window(view.into(),|_,window,_| describe_frame(window).hash(&mut signature)).expect("scene");
    #[cfg(gpui_layout_sets_census)] crate::perf_count::census::finish();
    black_box(&cx);
    println!("LAYOUT_OWNER {{\"case\":\"{case}\",\"iterations\":{iterations},\"cpu_ns\":{cpu_ns},\"elapsed_ns\":{elapsed_ns},\"held_bytes\":{held_bytes},\"peak_bytes\":{peak_bytes},\"requested_bytes\":{requested_bytes},\"allocation_calls\":{allocation_calls},\"signature\":{},\"nodes\":{nodes},\"cache_size\":{cache_size},\"node_capacity\":{node_capacity},\"frames\":{},\"views_rendered\":{},\"views_reused\":{},\"compute_layout_calls\":{},\"measure_calls\":{},\"replay_measure_calls\":{},\"measurements_carried\":{},\"measured_nodes_dirtied\":{},\"layout_nodes_created\":{},\"layout_nodes_reused\":{},\"compute_layout_ns\":{},\"measure_ns\":{},\"build_ns\":{},\"prepaint_ns\":{},\"paint_ns\":{},\"shape_ns\":{}}}",signature.finish(),stats.frames,stats.views_rendered,stats.views_reused,stats.compute_layout_calls,stats.measure_calls,stats.replay_measure_calls,stats.measurements_carried,stats.measured_nodes_dirtied,stats.layout_nodes_created,stats.layout_nodes_reused,stats.compute_layout_time.as_nanos(),stats.measure_time.as_nanos(),stats.build_time.as_nanos(),stats.prepaint_time.as_nanos(),stats.paint_time.as_nanos(),stats.shape_time.as_nanos());
}
