from pathlib import Path
import json,hashlib,subprocess,os
r=Path(__file__).parent;binary=r/'baseline-bare-artifacts/gpui-ada3fb4d7b1cfe56';identity={'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'bytes':binary.stat().st_size};(r/'owner-binary-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
for dep in json.loads((r/'external-dependencies.json').read_text()):assert hashlib.sha256(Path(dep['path']).read_bytes()).hexdigest()==dep['sha256']
for path,expected in json.loads((r/'baseline-source-inputs.json').read_text())['files'].items():assert hashlib.sha256((r/'baseline-workspace'/path).read_bytes()).hexdigest()==expected
out=r/'owner-receipts';out.mkdir();rows=[];cases=[f'{scenario}-{mode}-{count}-{clock}' for scenario in ['value','header','color','resize','redraw'] for mode in ['off','on'] for count in [16,80] for clock in ['bare','clock']]
(r/'owner-method.json').write_text(json.dumps({'cases':cases,'iterations':64,'baseline':'b3136c6e2e6a8b2ac871ba1f59a0e2a6600db467','purpose':'Current0.13 completeApp/Window baseline CPU/phase/measure attribution before newcandidate. Clock variants are diagnostic overhead, not performance gain evidence. node_capacity is0placeholder/unmeasured; logicalnodes+actual publicCache sizeof measured. No wholeApp/GPU gain.'},indent=2)+'\n')
for case in cases:
 log=out/(case+'.log');command=[str(r/'native-run'),'taskset','-c','2',str(binary),'profile_owned_layout_cache','--ignored','--nocapture','--test-threads=1']
 with log.open('w') as stream:result=subprocess.run(command,env=os.environ|{'LAYOUT_OWNER_CASE':case,'LAYOUT_OWNER_ITERATIONS':'64'},stdout=stream,stderr=subprocess.STDOUT,timeout=60)
 row={'case':case,'command':command,'binary_sha256':identity['sha256'],'exit_code':result.returncode,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 for line in log.read_text().splitlines():
  if 'LAYOUT_OWNER ' in line:row.update(json.loads(line.split('LAYOUT_OWNER ',1)[1]))
  if line.startswith('NATIVE_RECEIPT '):row['native']=json.loads(line.split(' ',1)[1])
 rows.append(row);(r/'owner-samples.json').write_text(json.dumps(rows,indent=2)+'\n');assert result.returncode==0 and 'cpu_ns' in row,log.read_text()
print(json.dumps({'children':len(rows),'all_exit_zero':True,'production_candidate':None}))
