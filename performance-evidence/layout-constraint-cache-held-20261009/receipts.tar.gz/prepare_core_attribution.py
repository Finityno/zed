from pathlib import Path
import json,hashlib,shutil
r=Path(__file__).parent;w=r/'layout-clock-workspace';shutil.copytree(r/'baseline-workspace',w,symlinks=True);src=w/'crates/gpui/src'
helper='''
#[cfg(test)]
thread_local! {
    static LAYOUT_OWNER_CORE: std::cell::Cell<(u64, u64)> = const { std::cell::Cell::new((0, 0)) };
}
#[cfg(test)]
pub(crate) fn layout_owner_core_reset() { LAYOUT_OWNER_CORE.with(|counts| counts.set((0, 0))); }
#[cfg(test)]
pub(crate) fn layout_owner_core_snapshot() -> (u64, u64) { LAYOUT_OWNER_CORE.with(std::cell::Cell::get) }
'''
p=src/'taffy.rs';s=p.read_text();start=s.index('    fn run_layout(');begin=s.index('        let scale_factor = window.scale_factor();',start);s=s[:begin]+'        let layout_owner_started = std::time::Instant::now();\n'+s[begin:];end=s.index('            .expect(EXPECT_MESSAGE);',begin)+len('            .expect(EXPECT_MESSAGE);');s=s[:end]+'''\n        let elapsed = layout_owner_started.elapsed().as_nanos() as u64;
        LAYOUT_OWNER_CORE.with(|counts| { let (calls, nanos) = counts.get(); counts.set((calls + 1, nanos + elapsed)); });'''+s[end:];p.write_text(s+helper)
p=src/'window/view_retention/layout_owner_profile.rs';s=p.read_text().replace('struct LayoutOwnerRow { index: usize, value: bool, accent: bool }','struct LayoutOwnerRow { index: usize, value: bool, accent: bool, nested: bool }').replace('rows: Vec<Entity<LayoutOwnerRow>>, header: bool','rows: Vec<Entity<LayoutOwnerRow>>, header: bool, nested: bool')
s=s.replace('.w_full().flex().flex_row().gap_3().py_1()', '.when(!self.nested, |this| this.w_full()).flex().flex_row().justify_between().items_center().gap_3().py_1()').replace('div().flex_1().min_w_0().flex().flex_col()', 'div().when(!self.nested, |this| this.flex_1().min_w_0()).flex().flex_col()')
s=s.replace('        div().id("layout-owner-panel")', '''        if self.nested {
            return div().id("layout-owner-workspace").size_full().flex().flex_col().text_size(px(14.))
                .child(div().h(px(36.)).child(if self.header {"Updated settings"} else {"Settings"}))
                .child(div().flex().flex_row().flex_1().min_h_0()
                    .child(div().w(px(200.)).child("Editor and workspace"))
                    .child(div().flex_1().flex().flex_col().gap_3().p_3().overflow_hidden()
                        .children(self.rows.chunks(10).map(|rows| div().flex().flex_col().border_1().rounded_md()
                            .child(div().h(px(30.)).child("Workspace options"))
                            .children(rows.iter().cloned()))))).into_any_element();
        }
        div().id("layout-owner-panel")''').replace('.children(self.rows.iter().cloned())))','.children(self.rows.iter().cloned()))).into_any_element()')
s=s.replace('    let timed = parts[3] == "clock";', '    let timed = parts[3] == "clock"; let nested = parts.get(4) == Some(&"nested");').replace('index,value:false,accent:false','index,value:false,accent:false,nested').replace('collect(),header:false','collect(),header:false,nested')
s=s.replace('    let start = Instant::now();', '    crate::taffy::layout_owner_core_reset();\n    let start = Instant::now();')
s=s.replace('    let (stats,nodes,cache_size,node_capacity)', '    let (stats,nodes,cache_size)').replace(',std::mem::size_of::<taffy::Cache>(),0usize)', ',std::mem::size_of::<taffy::Cache>())')
s=s.replace('    use std::hash::{Hash,Hasher};', '    let (core_calls, core_ns) = crate::taffy::layout_owner_core_snapshot();\n    use std::hash::{Hash,Hasher};')
s=s.replace(r'\"node_capacity\":{node_capacity},', r'\"core_calls\":{core_calls},\"core_ns\":{core_ns},')
p.write_text(s);(r/'layout-core-fixture.rs').write_bytes(p.read_bytes())
(r/'layout-core-source-inputs.json').write_text(json.dumps({'baseline':'b3136c6e2e6a8b2ac871ba1f59a0e2a6600db467','purpose':'Private baseline-only all direct/indirectTaffy.run_layout clock + nested auto-width settings components; initial40child diagnostics unchanged/preserved. No production source/candidate, no gain classification. Existing public Window phase clock excludes direct engine calls such as lay_out_at_size; do not infer retained total layout share from that partial field.','files':{str(p.relative_to(w)):hashlib.sha256(p.read_bytes()).hexdigest() for p in w.rglob('*') if p.is_file()}},indent=2)+'\n');print({'layout_core_instrumented':True,'original_baseline_and_all40_samples_preserved':True})
