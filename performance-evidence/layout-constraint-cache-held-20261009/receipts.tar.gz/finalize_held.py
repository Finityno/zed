from pathlib import Path
import json,hashlib,tarfile,io,collections,subprocess,os,stat
r=Path(__file__).parent;c=r/'comparison';decision=json.loads((c/'decision.json').read_text());assert not decision['qualified'];assert decision['native_children']==2352
repo=Path('/workspace/zed-layout-cache');dest=repo/'performance-evidence/layout-constraint-cache-held-20261009';dest.mkdir(parents=True);failtypes=collections.Counter(v['field'] for v in decision['failures']);timing=json.loads((c/'bare-alternation-receipt.json').read_text());census=json.loads((c/'census-alternation-receipt.json').read_text());assert timing['exit_code']==census['exit_code']==0 and timing['started_unix']+timing['elapsed_seconds']<census['started_unix']
inputs=[];seen={};archive=dest/'receipts.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for path in sorted(r.rglob('*')):
  if not path.is_file() and not path.is_symlink():continue
  relative=path.relative_to(r)
  if any(part.endswith('-artifacts') for part in relative.parts) or 'registry-preflight' in relative.parts or path.name.startswith('cache-owner-0.') or path.name=='native-run':continue
  if path.is_symlink():tar.add(path,arcname=str(relative),recursive=False);inputs.append({'path':str(relative),'symlink':os.readlink(path)});continue
  data=path.read_bytes();sha=hashlib.sha256(data).hexdigest();info=tar.gettarinfo(str(path),arcname=str(relative));key=(sha,info.mode,info.size)
  if key in seen:info.type=tarfile.LNKTYPE;info.linkname=seen[key];info.size=0;tar.addfile(info)
  else:tar.addfile(info,io.BytesIO(data));seen[key]=str(relative)
  inputs.append({'path':str(relative),'bytes':len(data),'sha256':sha})
 manifest={'inputs':inputs,'scope':'All method/source/failedsetup/parser-repair/rawnative results/buildprocess receipts and CPU/memory/RSS decisions. Exact whole435file source snapshots included with dedup hardlinks. Compiledartifact binaries/protected59 remain intact at hash-identified localpaths; runtime/compiler identities recorded. Dependency original0.14crate included, sourcechecksum/source revision recorded. No builds/hashing/compression overlapped pairedtiming.'};data=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('archive-inputs.json');info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
sha=hashlib.sha256(archive.read_bytes()).hexdigest();evidence={'status':'HELD_UNMERGED','source':'93ae3a430c6cc7388e54706b05f9e630fcb03214','baseline':'08d5555709d7afab3936c7afcd9f7f0ff9ecbd65','fincode_main':'21bf6201a8bbcdb7192ccca01a0d4f0b9e963b7e','fincode_pin':'6b18c87dd5f2d1ccbee1ee641054295f2a78390b','component_pin':'031f54b627333272a8c157cbe4ca1cf591d16172','policy_sha256':decision['policy_sha256'],'controls':84,'children':2352,'bare_children':1512,'census_children':840,'bare_seconds':timing['elapsed_seconds'],'census_seconds':census['elapsed_seconds'],'failed_fields':len(decision['failures']),'failure_types':dict(failtypes),'primary_cpu_gains':[{'case':v['case'],'fraction':v['fields']['cpu_ns']['fraction_gain'],'elapsed_fraction':v['fields']['elapsed_ns']['fraction_gain']} for v in decision['primary']],'full_decision':decision,'memory_ownership_preflight':'+16Cache,+8Style,+8Layoutstoredtwice =>40B/node; noextracalls/allpuretreebytesrelease. Frozen96B/geometric node-reserve fullAppbudget. Despiteheldcontrols pass,53memory/RSS/CPUcontrols fail (see exact55 fields).','correctness':'Final620testpasses in36nativeinvocations (twozerotestpatterns explicitlynotcoverage),168per-frame audit children across84cases; all2352 paired terminalscenes/state/node counts identical. Initial254testpasses+168functional children preserved. Parserprefixfailure21validchildren reparsed without rerun; twoprivateharness buildcfg/scopeerrors preserved/corrected before pairedsampling.','provenance':'Owned source comparison update412191f0124236f6b98480cadb90d746931e492e motivated cache investigation; all gain evidence owncompleteApp/Window component. No exactsourceversionbaseinvented. Registry0.14source77f385683c1d698c91a23a259f87fdddf26925fb, packagechecksum639627c87f43b9181c811f40a6296409e093a17bc761214cba3c15df74f86b99; runtime3transitiveobjects same,58otherexterns identical,59protected objects unchanged, nativecompiler1.99/System.','lock':'ActualisolatedCargoregeneration validatesnewtaffyrecord,1828unrelatedrecords preserved. FullowninglockedCargo/strictClippy/guards notrun after failedgates.','archive_sha256':sha,'archive_bytes':archive.stat().st_size,'archive_members':len(inputs)+1,'qualified':False,'merged':False,'pr_created':False,'unchanged_resampling_allowed':False,'coverage':'Native Linux fakeplatform/text/System completeApp/Window, notFincodeapp/GPU/nativeplatformgain. Memorytradeofffrozen; alladverse results kept. Nextdesignmustdistinct; no weaker controls.'}
evidence['memory_ownership_preflight']=evidence['memory_ownership_preflight'].replace('53memory/RSS/CPUcontrols','55memory/RSS/CPUcontrols');(dest/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(dest/'README.md').write_text('''# Held layout constraint cache upgrade

The complete nested-settings update uses 34.83–37.54% less native thread CPU
and 34.83–37.54% less elapsed time across four 16/80-row retention-on/off
workloads. Each gain clears the frozen 15% target and both full lane ranges.
The design remains held because 55 frozen controls fail. Do not repeat it
unchanged or weaken the controls; no PR, merge or application adoption occurs.

The failed fields include current native RSS, resize peak requested heap,
peak native RSS and one retained 80-row flat-header CPU/elapsed/whole-child
workload. The largest current RSS changes exceed the explicit node-cache
budget by more than one MiB. Controlled pure-tree ownership costs 40 bytes
per node slot with no extra allocations and releases all bytes on drop;
that preflight did not predict these complete component RSS/peak costs.

2352 alternating native children cover 84 workloads: 1512 bare children in
231.30 seconds, followed by 840 separate census children in 65.85 seconds.
620 final native test passes and 168 per-frame audit children pass; all paired
terminal scenes, state owners and node counts match. Two zero-test patterns
are recorded as no coverage. The original 80 CPU attribution children and
all earlier functional/setup/parser results are retained in the archive.
The public Window layout clock misses direct engine calls; a distinct private
all-engine diagnostic identified the nested layout bottleneck. That clocked
attribution is separate from the final bare timing.

Both lanes use compiler 1.99 and identical 58 other native externs and three
Taffy transitive objects. The intended dependency changes from 0.13 to 0.14,
including its new default balanced-flex feature and leaf-layout API adapter.
Exact source, flags, runtime, allocator and package identities are recorded.
Actual isolated Cargo regeneration validates the seeded dependency record;
1828 other lock records remain identical. Owning locked Cargo, strict Clippy,
source guards and adoption qualification were not run after failed gates.

The evidence is native Linux GPUI with a fake platform/text system and System
allocator. It establishes no whole-application, physical-GPU, macOS, Windows
or shipped-allocator gain. Preserve the independent arena, frame-demand,
atlas and glyph-replay changes. Continue with a distinct layout-owner design
that retains the existing dependency, followed by separate consumer checks
only when a candidate qualifies.
''')
p=repo/'PERFORMANCE_GOAL.md';p.write_text(p.read_text()+'''\nTaffy constraint-cache upgrade at `93ae3a430c6cc7388e54706b05f9e630fcb03214`
remains held. Its 2352 native children across 84 workloads lower four nested
panel CPU/elapsed targets by 34.83–37.54%, above the frozen 15% goal and both
lane ranges, but 55 frozen CPU, peak-heap and native RSS fields fail. The
predeclared fixed cache/style/layout overhead does not cover the measured
component RSS/resize peaks. All final native functional scenes and owner
contracts pass. No merge or Fincode adoption occurs; never repeat unchanged
or weaken gates. Source and raw evidence remain on
`perf/layout-constraint-cache-20261009` under
`performance-evidence/layout-constraint-cache-held-20261009`. Continue with
a distinct layout-owner design while preserving the current dependency and
independent arena/frame-demand/atlas/text work.
''')
(r/'held-summary.json').write_text(json.dumps(evidence,indent=2)+'\n');print(json.dumps({'archive_sha256':sha,'bytes':archive.stat().st_size,'members':len(inputs)+1,'failures':dict(failtypes),'source':evidence['source']}))
