from pathlib import Path
import subprocess,json,os,hashlib
r=Path(__file__).parent;c=json.loads(Path('/workspace/scratch/gpui-splice-state-loop/baseline-rustc-command.json').read_text());env=os.environ|c['environment'];base='/workspace/scratch/gpui-splice-state-loop/baseline-workspace/target/debug/deps';rows=[];commands=[]
for version,artifact in [('0.13.0',base+'/libtaffy-7edc9eea8d7e7c2d.rlib'),('0.14.0',str(r/'taffy14-artifacts/libtaffy-layout014.rlib'))]:
 binary=r/('cache-owner-'+version);args=[c['args'][0],'--edition=2021',str(r/'cache-owner-preflight.rs'),'-C','opt-level=3','-C','codegen-units=16','-C','embed-bitcode=no','-C','debug-assertions=on','--cfg','gpui_layout_sets_census','--extern','taffy='+artifact,'-L','dependency='+base,'-o',str(binary)];subprocess.run(args,env=env,check=True,timeout=60);commands.append(args)
 for count in [0,16,80,133,141,645,671,1024,10000]:
  result=subprocess.run([str(binary),str(count)],env=env,check=True,capture_output=True,text=True,timeout=10);row=json.loads(result.stdout);row|={'version':version,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()};rows.append(row)
(r/'cache-owner-preflight.json').write_text(json.dumps({'rows':rows,'commands':commands,'scope':'Untimed public cache/tree/Style/Layout sizeof and controlled pure-tree requested allocation census; API/ownership preflight before performance candidate/policy. No performance gain.'},indent=2)+'\n');print(json.dumps(rows))
