from pathlib import Path
import json,statistics
root=Path(__file__).parent;p=json.loads((root/'policy.json').read_text())
results={};failures=[]
for kind in ['bare','census']:
 samples=json.loads((root/(kind+'-samples.json')).read_text());summaries={}
 for case in p['controls']:
  lanes={lane: sorted([r for r in samples if r['case']==case and r['lane']==lane],key=lambda r:r['pair']) for lane in ['baseline','candidate']}
  a,b=lanes['baseline'],lanes['candidate'];assert len(a)==len(b)==(p['timing_pairs'] if kind=='bare' else p['memory_pairs'])
  assert all(x['signature']==y['signature'] for x,y in zip(a,b));summary={}
  metrics=['cpu_ns','elapsed_ns','peak_rss_kib'] if kind=='bare' else ['held_bytes','peak_bytes','requested_bytes','allocation_calls','peak_rss_kib']
  for metric in metrics:
   old=[r[metric] for r in a];new=[r[metric] for r in b];baseline=statistics.median(old);candidate=statistics.median(new);spread=max(old)-min(old);increase=candidate-baseline
   allowed=spread if kind=='bare' or metric=='peak_rss_kib' else 0
   passed=increase<=allowed
   if not passed:failures.append([kind,case,metric,increase,allowed])
   summary[metric]={'baseline_median':baseline,'candidate_median':candidate,'change_percent':(candidate/baseline-1)*100 if baseline else None,'baseline_range':spread,'allowed_increase':allowed,'pass':passed}
  if kind=='census' and case in p['primary_cases']:
   for metric in ['held_bytes','peak_bytes']:
    primary=summary[metric]['candidate_median']<=summary[metric]['baseline_median']*.60
    if not primary:failures.append([kind,case,metric,'primary memory target failed'])
  summaries[case]=summary
 results[kind]=summaries
result={'qualified':not failures,'failures':failures,'summary':results}
(root/'decision.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
