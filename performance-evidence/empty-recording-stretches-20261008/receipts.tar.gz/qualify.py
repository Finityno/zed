from pathlib import Path
import json,statistics
r=Path(__file__).parent;p=json.loads((r/'policy.json').read_text());results={};failures=[]
for kind in ['bare','census']:
 samples=json.loads((r/(kind+'-samples.json')).read_text());summaries={}
 for case in p['controls']:
  lanes={lane:sorted([s for s in samples if s['case']==case and s['lane']==lane],key=lambda s:s['pair']) for lane in ['baseline','candidate']}
  a,b=lanes['baseline'],lanes['candidate'];assert len(a)==len(b)==(p['timing_pairs'] if kind=='bare' else p['memory_pairs']);assert all(x['signature']==y['signature'] and x['exit_code']==y['exit_code']==0 for x,y in zip(a,b));summary={}
  metrics=['cpu_ns','elapsed_ns','child_cpu_ns','peak_rss_kib'] if kind=='bare' else ['held_bytes','peak_bytes','requested_bytes','allocation_calls','peak_rss_kib']
  for metric in metrics:
   old=[x[metric] for x in a];new=[x[metric] for x in b];baseline=statistics.median(old);candidate=statistics.median(new);spread=max(old)-min(old);new_spread=max(new)-min(new);increase=candidate-baseline;allowed=spread if kind=='bare' or metric=='peak_rss_kib' else 0;passed=increase<=allowed
   if not passed:failures.append([kind,case,metric,'control',increase,allowed])
   summary[metric]={'baseline_median':baseline,'candidate_median':candidate,'baseline_min':min(old),'baseline_max':max(old),'candidate_min':min(new),'candidate_max':max(new),'change_percent':(candidate/baseline-1)*100 if baseline else None,'baseline_range':spread,'candidate_range':new_spread,'allowed_increase':allowed,'pass':passed}
   if kind=='census' and case in p['primary_cases'] and metric!='peak_rss_kib':
    minimum=.4 if metric in ['held_bytes','peak_bytes'] else .2
    gain=baseline-candidate
    if baseline<=0 or candidate>baseline*(1-minimum) or gain<=max(spread,new_spread):failures.append([kind,case,metric,'primary gain/variation',gain,minimum,spread,new_spread])
  summaries[case]=summary
 results[kind]=summaries
d={'qualified':not failures,'failures':failures,'summary':results};(r/'decision.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'qualified':d['qualified'],'failures':failures,'primary':{case:results['census'][case] for case in p['primary_cases']}}))
