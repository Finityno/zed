from pathlib import Path
import gzip,hashlib,io,json,platform,tarfile
root=Path(__file__).parent;owner=root.parent;work=Path('/workspace/zed-layer-replay')
output=work/'performance-evidence/stationary-layer-replay-held-20261009';output.mkdir(parents=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
decision=json.loads((root/'decision.json').read_text());policy=json.loads((root/'policy.json').read_text())
assert not decision['qualified'] and len(decision['failures'])==14
for name,expected in json.loads((root/'frozen-inputs.json').read_text()).items():assert sha(root/name)==expected,name
runtime=json.loads((root/'runtime-identities.json').read_text());assert runtime['uname']==platform.uname()._asdict()
for collection in ['dynamic_libraries','compiler_shared_libraries']:
 for path,expected in runtime[collection].items():assert sha(Path(path))==expected['sha256']
assert sha(Path(runtime['compiler']))==runtime['compiler_sha256']
for dependency in json.loads((root/'external-dependencies.json').read_text()):assert sha(Path(dependency['path']))==dependency['sha256']
for lane in ['baseline','candidate']:
 for path,expected in json.loads((root/(lane+'-source-inputs.json')).read_text())['files'].items():assert sha(root/(lane+'-workspace')/path)==expected,path
 for identity in json.loads((root/'binary-identities.json').read_text())[lane].values():assert sha(Path(identity['path']))==identity['sha256']
builds=json.loads((root/'build-order-receipt.json').read_text())['receipts'];phases=json.loads((root/'valid-cohort-order-receipt.json').read_text())['receipts']
assert len(builds)==4 and len(phases)==2
assert phases[0]['started_unix']>=builds[-1]['started_unix']+builds[-1]['elapsed_seconds']
assert phases[1]['started_unix']>=phases[0]['started_unix']+phases[0]['elapsed_seconds']
for kind,count in [('bare',1044),('census',580)]:
 samples=json.loads((root/(kind+'-samples.json')).read_text());assert len(samples)==count
 for sample in samples:assert sample['exit_code']==0 and sha(Path(sample['log']))==sample['log_sha256']
contracts=json.loads((root/'contracts-summary.json').read_text());assert len(contracts)==36
assert contracts[-2]['actual_exit']==101 and contracts[-1]['actual_exit']==0
assert all(v['pass'] for values in decision['summary']['census'].values() for v in values.values())
files={}
for base,prefix in [(root,'comparison'),(owner,'attribution')]:
 for path in base.rglob('*'):
  relative=path.relative_to(base)
  if base==owner and relative.parts[0]=='comparison':continue
  if path.name=='continuation-automation-receipt.json':continue
  if any(part.endswith('-workspace') or part.endswith('-artifacts') for part in relative.parts):continue
  if path.is_file() and path.suffix in {'.py','.json','.log','.diff','.rs','.c','.md','.txt'}:files[prefix+'/'+str(relative)]=path
for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','LICENSE-APACHE','LICENSE-GPL']:files['native-root/'+name]=root/'candidate-workspace'/name
for lane in ['baseline','candidate']:
 for name in ['scene.rs','gpui.rs','perf_count.rs','window/view_retention/splice_profile.rs','window/view_retention/transcript_profile.rs']:
  files[lane+'/'+name]=root/(lane+'-workspace')/'crates/gpui/src'/name
manifest={name:{'bytes':path.stat().st_size,'sha256':sha(path)} for name,path in sorted(files.items())}
archive=output/'receipts.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=6,mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
 entries=[('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())]+[(name,path.read_bytes()) for name,path in sorted(files.items())]
 for name,data in entries:
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 for name,expected in manifest.items():
  data=tar.extractfile(name).read();assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
evidence={'status':'HELD/unmerged; never unchanged rerun or weaker gates','qualified':False,'baseline':policy['baseline'],'source':'40debf70cef29838e696b8c75fc2655052c56234','fincode_main_at_freeze':policy['fincode_main'],'fincode_gpui':policy['fincode_pin'],'component_pin':policy['component_pin'],'valid_children':1624,'workloads':58,'failures':decision['failures'],'all_primary_allocation_gain_fields_pass':True,'all_census_heap_churn_native_RSS_controls_pass':True,'observed_primary_changes':{case:{metric:decision['summary']['census'][case][metric] for metric in ['allocation_calls','requested_bytes','held_bytes','peak_bytes']} for case in policy['primary_cases']},'important_gain_not_qualified':'6.63–7.13% fewer complete-App allocation calls and0.081–0.100% fewer requested bytes in retained redraw200/512. Fourteen normalCPU/elapsed/whole-child fields fail. Every censusheap/churn/RSS and bareRSS control passes. Primaryheld/peak unchanged.','mechanism':'Do not push false omission flags for stationary layers; stationary EndLayer always pops, moved clipping/tracking unchanged. No fields/timers/cache/renderer resources.','correctness':'36native contract invocations: Scene24, Subscriber4,3nested/partial/moved layer contracts, independent cursor resize,App4,read/nested/idle/retainedoracle16seeds50steps/wheel/dependency/panel/layout/atomic tests pass. Private warmedtwo-buffer no-scratchallocation contract failsbaseline/passescandidate. All1624paired scene/hitbox/state/owner signatures match.','protocol':'Foursequential final native builds50.37/47.58/48.83/48.26s,1044alternatingbare children222.96s, then580countingchildren78.68s. Common59immutableexterns/compiler/runtime/source/binary andfrozenmethod reverified aftercohort. Bare256/census128stimuli frozenbeforecandidate. No repeatperformancecohort.','attribution':'36completecurrent-main nativeApp/Window diagnostics attribute7.11% of retainedredraw200calls to stationary Vec<bool> growth. Existing30transcriptcomponentclocks rankretainedpaint53–73us/draw. Countingdiagnostics are not speed gains.','adverse_setup':'OriginalDebugtest-helper compile failure preserved. Firstcomplete4build contract wrongly warmed onlyone of BoundsTree recorded/previous buffers, leaving320held bytes in BOTH lanes; preservedall4originalbinaries exactgzip roundtrip andallcontracts/identities. Privatehelper warmsboth buffers beforecensus. Productionmechanism/performancefixtures/gates unchanged, allcorrectionsbefore anypaired performance sample.','not_run':'Strict owning Clippy/guard, PR creation, merge and application adoption withheld because performance gates fail.','limits':policy['limits'],'policy_sha256':sha(root/'policy.json'),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(manifest)+1}
(output/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(output/'README.md').write_text('''# Held stationary layer replay tracking

One frozen comparison of 1,624 native children across 58 complete App/Window
workloads passes both allocation targets but fails 14 ordinary CPU controls.
Retained redraws with 200/512 rows use 7.13/6.63% fewer allocation calls and
0.100/0.081% fewer requested bytes. Held/peak requested heap is unchanged.
Every requested-memory, allocation-churn and native RSS control passes.
Do not resample this design unchanged or weaken its gates. No PR, merge or
consumer adoption is qualified.

Stationary replay needs no layer-omission stack; moved clipping is unchanged.
No App fields, timers, caches or renderer resources are added. Thirty-six
native contract invocations pass, including nested/partial/moved layers,
retained output, wheel/dependency changes, panels, layout/atomic claims,
read/nested/idle, existing Scene/App/Subscriber and independent resize checks.
The private fully warmed allocation contract fails before and passes after;
all 1,624 paired scene, hitbox and ownership outputs match.

All raw samples, frozen method, exact source/compiler/runtime/common 59 native
externs/binary identities and sequential process-group receipts are archived
and every member hash verified. Thirty-six complete-component attribution
children and both original setup failures remain preserved. The first test
helper used unsupported Debug; the second warmed only one of two alternating
bounds-tree buffers. All private corrections preceded any performance sample
and left production behavior and performance fixtures/gates unchanged.
Original failed binaries remain losslessly preserved and hash identified.

Linux fake-platform/System component measurements do not establish app,
physical GPU, macOS/Windows or shipped-allocator gains. Timing excludes setup
and four warmups; census includes complete owners and 128 stimuli, frozen
before the candidate. Continue with a distinct important ownership design.
''')
(root/'archive-verification.json').write_text(json.dumps({key:evidence[key] for key in ['archive_sha256','archive_bytes','members','valid_children','qualified']},indent=2)+'\n')
print((root/'archive-verification.json').read_text())
