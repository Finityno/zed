from pathlib import Path
import os,json,subprocess,hashlib,statistics,sys,time
root=Path(__file__).parent
policy=json.loads((root/'policy.json').read_text()); cases=policy['controls']
lanes=json.loads((root/'binary-identities.json').read_text())
kind=sys.argv[1];pair_count=policy['timing_pairs'] if kind=='bare' else policy['memory_pairs']
iterations=policy['timing_iterations'] if kind=='bare' else policy['memory_iterations']
output=root/(kind+'-receipts');output.mkdir()
policy_hash=hashlib.sha256((root/'policy.json').read_bytes()).hexdigest()
rows=[]
for case in cases:
 for pair in range(pair_count):
  for lane in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
   binary=lanes[lane][kind]['path'];assert hashlib.sha256(Path(binary).read_bytes()).hexdigest()==lanes[lane][kind]['sha256']
   transcript=case in policy['transcript_cases'];pattern='profile_transcript_paint' if transcript else 'profile_layout_key_sets'
   command=[str(root/'native-run'),'taskset','-c','2',binary,pattern,'--ignored','--nocapture','--test-threads=1']
   environment=dict(os.environ,LAYOUT_SETS_PROFILE_CASE=case,LAYOUT_SETS_PROFILE_ITERATIONS=str(iterations),TRANSCRIPT_PROFILE_CASE=case,TRANSCRIPT_PROFILE_ITERATIONS=str(iterations))
   path=output/f'{case}-{pair:02}-{lane}.log'
   with path.open('w') as log: result=subprocess.run(command,env=environment,stdout=log,stderr=subprocess.STDOUT,timeout=70)
   text=path.read_text();receipt={'case':case,'pair':pair,'lane':lane,'kind':kind,'command':command,'exit_code':result.returncode,'log':str(path),'log_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'binary_sha256':lanes[lane][kind]['sha256'],'policy_sha256':policy_hash}
   for line in text.splitlines():
    for marker in ['LAYOUT_SETS_PROFILE ','TRANSCRIPT_PROFILE ','OBSERVER_PROFILE ']:
     if marker in line:receipt.update(json.loads(line.split(marker,1)[1]))
    if line.startswith('NATIVE_RECEIPT '):receipt.update(json.loads(line.split(' ',1)[1]));receipt['child_cpu_ns']=(receipt['user_cpu_us']+receipt['system_cpu_us'])*1000
   rows.append(receipt);(root/(kind+'-samples.json')).write_text(json.dumps(rows,indent=2)+'\n')
   if result.returncode or 'cpu_ns' not in receipt:raise SystemExit('Failed native child: '+str(path))
print(json.dumps({'kind':kind,'children':len(rows),'all_exits_zero':all(r['exit_code']==0 for r in rows)}))
