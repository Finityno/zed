from pathlib import Path
import json
import statistics

root = Path(__file__).parent
policy = json.loads((root / 'policy.json').read_text())
results = {}
failures = []
for kind in ['bare', 'census']:
    samples = json.loads((root / (kind + '-samples.json')).read_text())
    expected = policy['timing_pairs'] if kind == 'bare' else policy['memory_pairs']
    assert len(samples) == len(policy['controls']) * expected * 2
    summaries = {}
    for case in policy['controls']:
        baseline = sorted([row for row in samples if row['case'] == case and row['lane'] == 'baseline'], key=lambda row: row['pair'])
        candidate = sorted([row for row in samples if row['case'] == case and row['lane'] == 'candidate'], key=lambda row: row['pair'])
        assert len(baseline) == len(candidate) == expected
        assert all(old['signature'] == new['signature'] and old['exit_code'] == new['exit_code'] == 0 for old, new in zip(baseline, candidate))
        assert all(old['state_count'] == new['state_count'] and old['state_box_bytes'] == new['state_box_bytes'] for old, new in zip(baseline, candidate))
        metrics = ['cpu_ns', 'elapsed_ns', 'child_cpu_ns', 'peak_rss_kib'] if kind == 'bare' else ['held_bytes', 'peak_bytes', 'requested_bytes', 'allocation_calls', 'peak_rss_kib']
        values = {}
        for metric in metrics + ['state_count', 'state_box_bytes']:
            old = [row[metric] for row in baseline]
            new = [row[metric] for row in candidate]
            old_median, new_median = statistics.median(old), statistics.median(new)
            old_range, new_range = max(old) - min(old), max(new) - min(new)
            allowed = old_range if metric in ['cpu_ns', 'elapsed_ns', 'child_cpu_ns', 'peak_rss_kib', 'current_rss_kib'] else 0
            passed = new_median - old_median <= allowed
            if not passed:
                failures.append([kind, case, metric, 'control', new_median - old_median, allowed])
            values[metric] = {'baseline_median': old_median, 'candidate_median': new_median,
                'baseline_min': min(old), 'baseline_max': max(old), 'candidate_min': min(new), 'candidate_max': max(new),
                'baseline_range': old_range, 'candidate_range': new_range,
                'change_percent': (new_median / old_median - 1) * 100 if old_median else None,
                'allowed_increase': allowed, 'pass': passed}
        if kind == 'census' and case in policy['primary_cases']:
            for metric, minimum in [('allocation_calls', 0.05), ('requested_bytes', 0.0)]:
                value = values[metric]
                gain = value['baseline_median'] - value['candidate_median']
                if gain <= 0 or gain / value['baseline_median'] < minimum or gain <= max(value['baseline_range'], value['candidate_range']):
                    failures.append([kind, case, metric, 'primary gain', gain, value['baseline_range'], value['candidate_range'], minimum])
        summaries[case] = values
    results[kind] = summaries
decision = {'qualified': not failures, 'failures': failures, 'summary': results}
(root / 'decision.json').write_text(json.dumps(decision, indent=2) + '\n')
print(json.dumps({'qualified': decision['qualified'], 'failures': failures,
                  'primary': {case: results['census'][case] for case in policy['primary_cases']}}))
