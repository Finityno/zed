
#[cfg(all(test, gpui_layout_sets_census))]
mod nonmoved_layer_memory_contract {
    use super::*;

    #[test]
    fn warmed_nonmoved_layer_replay_allocates_no_scratch() {
        let bounds = Bounds {
            origin: Point::default(),
            size: Size { width: ScaledPixels::from(100.), height: ScaledPixels::from(100.) },
        };
        let mut source = Scene::default();
        for _ in 0..16 { source.push_layer(bounds); }
        source.insert_primitive(Quad {
            bounds,
            content_mask: ContentMask { bounds },
            background: Background::from(Hsla::black()),
            ..Default::default()
        });
        for _ in 0..16 { source.pop_layer(); }
        let mut replayed = Scene::default();
        replayed.replay(0..source.len(), &source);
        replayed.clear();
        crate::perf_count::census::start();
        replayed.replay(0..source.len(), &source);
        let (held, peak, requested, calls) = crate::perf_count::census::finish();
        assert_eq!(held, 0);
        assert_eq!(peak, 0, "replaying stationary layers should use warmed Scene capacity");
        assert_eq!(requested, 0);
        assert_eq!(calls, 0);
        super::nonmoved_layer_tests::assert_same_operations(&source, &replayed);
        assert!(replayed.layer_stack.is_empty());
    }
}
