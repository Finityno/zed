from pathlib import Path
import hashlib
import json
import re
import subprocess

root = Path(__file__).parent
patterns = [
    'scene::tests',
    'subscription::tests',
    'nonmoved_layer_tests',
    'default_hover_listener_updates_after_resize_without_mouse_move',
    'app::test::',
    'sorted_read_union_uses_linear_key_comparisons',
    'sorted_read_unions_preserve_earliest_floor_lifted_versions',
    'empty_nested_tests',
    'test_quiet_window_reclaims_idle_capacity',
    'test_idle_reclaim_waits_for_a_full_quiet_period',
    'a_host_is_drawn_again_around_a_row_whose_dependencies_changed',
    'frames_drawing_views_again_match_frames_drawn_from_scratch',
    'rows_with_scrollers_scrolled_by_the_wheel_are_not_built_after',
    'a_panel_is_drawn_again_around_its_live_row',
    'a_panel_is_built_when_its_live_row_changes_its_layout',
    'a_view_built_in_a_gap_resolves_the_groups_around_it',
    'retained_sets_validate_every_set_before_claiming_any_node',
]
contracts = [(lane, 'bare', pattern, 0) for pattern in patterns for lane in ['baseline', 'candidate']]
contracts += [(lane, 'census', 'nonmoved_layer_memory_contract', 101 if lane == 'baseline' else 0) for lane in ['baseline', 'candidate']]
rows = []
for lane, kind, pattern, expected in contracts:
    binary = root / (lane + '-' + kind + '-artifacts/gpui-ada3fb4d7b1cfe56')
    name = 'contract-' + lane + '-' + kind + '-' + pattern
    command = ['python3', str(root / 'supervise.py'), '--seconds', '60', '--name', name,
               '--cwd', str(root / (lane + '-workspace')), '--', str(binary), pattern,
               '--nocapture', '--test-threads=1']
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    receipt_path = root / (name + '-receipt.json')
    receipt = json.loads(receipt_path.read_text())
    log = (root / (name + '.log')).read_text()
    assert receipt['exit_code'] == result.returncode == expected, result.stdout + log
    assert not receipt['timed_out']
    match = re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;', log)
    assert match, log
    passed, failed = map(int, match.groups())
    assert passed + failed > 0
    if pattern == 'subscription::tests':
        assert (passed, failed) == (4, 0), log
    elif pattern == 'nonmoved_layer_tests':
        assert (passed, failed) == (3, 0), log
    elif pattern == 'nonmoved_layer_memory_contract':
        assert (passed, failed) == ((0, 1) if lane == 'baseline' else (1, 0)), log
    else:
        assert failed == 0
    rows.append({'lane': lane, 'kind': kind, 'pattern': pattern, 'expected_exit': expected,
                 'actual_exit': receipt['exit_code'], 'passed': passed, 'failed': failed,
                 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
                 'receipt': str(receipt_path)})
    (root / 'contracts-summary.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps(rows[-1]), flush=True)
