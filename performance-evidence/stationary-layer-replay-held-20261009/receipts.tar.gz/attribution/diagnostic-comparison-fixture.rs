use super::*;
use std::{hash::{Hash, Hasher}, hint::black_box};

#[cfg(gpui_layout_sets_census)]
pub(crate) use crate::perf_count::census;

#[repr(C)]
struct Timespec {
    seconds: std::os::raw::c_long,
    nanoseconds: std::os::raw::c_long,
}

unsafe extern "C" {
    fn clock_gettime(clock: std::os::raw::c_int, result: *mut Timespec) -> std::os::raw::c_int;
}

pub(super) fn thread_cpu_ns() -> u64 {
    let mut time = Timespec { seconds: 0, nanoseconds: 0 };
    assert_eq!(unsafe { clock_gettime(3, &mut time) }, 0);
    time.seconds as u64 * 1_000_000_000 + time.nanoseconds as u64
}

struct RemovalRow {
    present: bool,
    identity: u64,
    height: f32,
    dependency: Option<DrawDependency>,
}

impl Render for RemovalRow {
    fn render(&mut self, window: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        if let Some(dependency) = &self.dependency {
            window.depend_on(dependency);
        }
        div().h(px(self.height)).when(self.present, |this| {
            this.child(
                div().id(("profile-state", self.identity)).size(px(10.)).bg(hsla(0.4, 0.5, 0.5, 1.)),
            )
        })
    }
}

struct RemovalPanel(Vec<Entity<RemovalRow>>);

impl Render for RemovalPanel {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        div().size_full().flex().flex_col().children(self.0.iter().cloned())
    }
}

struct RemovalShell(Entity<RemovalPanel>);

impl Render for RemovalShell {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        div().size_full().child(self.0.clone())
    }
}

#[test]
#[ignore]
fn profile_layout_key_sets() {
    let case = std::env::var("LAYOUT_SETS_PROFILE_CASE").expect("LAYOUT_SETS_PROFILE_CASE");
    let iterations: usize = std::env::var("LAYOUT_SETS_PROFILE_ITERATIONS")
        .expect("LAYOUT_SETS_PROFILE_ITERATIONS").parse().expect("iterations");
    assert!(iterations > 0 && iterations.is_multiple_of(2));
    let stateful = case.starts_with("state-");
    let workload = case.strip_prefix("state-").unwrap_or(&case);
    let rows = if case.ends_with("256") { 256 } else { 32 };
    let retained = !workload.starts_with("off-");
    #[cfg(gpui_layout_sets_census)]
    census::start();
    let mut cx = TestAppContext::single();
    cx.update(|cx| cx.set_view_retention(retained));
    let leaves: Vec<_> = (0..rows)
        .map(|_| cx.new(|_| RemovalRow { present: true, identity: 0, height: 10., dependency: stateful.then(DrawDependency::new) }))
        .collect();
    let panel = cx.new(|_| RemovalPanel(leaves.clone()));
    let window = cx.add_window(|_, _| RemovalShell(panel.clone()));
    let frame = |cx: &mut TestAppContext| {
        cx.update_window(window.into(), |_, window, cx| window.draw(cx).clear(cx)).unwrap();
    };
    for _ in 0..4 {
        frame(&mut cx);
    }
    let started = Instant::now();
    crate::scene::start_layer_replay_attribution();
    let cpu_started = thread_cpu_ns();
    for iteration in 0..iterations {
        cx.update(|cx| {
            if workload.starts_with("panel-keep-") {
                panel.update(cx, |_, cx| cx.notify());
            } else if workload.starts_with("keep-") {
                window.update(cx, |_, _, cx| cx.notify()).unwrap();
            } else {
                for leaf in &leaves {
                    leaf.update(cx, |leaf, cx| {
                        if workload.starts_with("disjoint-") {
                            leaf.dependency = Some(DrawDependency::new());
                            leaf.height = 10. + (iteration % 3) as f32;
                        } else if workload.starts_with("bump-") {
                            leaf.dependency.as_ref().expect("stateful").changed(cx);
                            leaf.height = 10. + (iteration % 3) as f32;
                        } else if workload.starts_with("remove-") || workload.starts_with("off-remove-") {
                            leaf.present = iteration % 2 == 0;
                        } else if workload.starts_with("replace-") {
                            leaf.identity = iteration as u64 + 1;
                        } else if workload.starts_with("grow-") {
                            leaf.height = 10. + (iteration % 3) as f32;
                        } else {
                            panic!("unknown fixture {case}");
                        }
                        cx.notify();
                    });
                }
            }
        });
        frame(&mut cx);
        black_box(&cx);
    }
    let cpu_ns = thread_cpu_ns() - cpu_started;
    let elapsed_ns = started.elapsed().as_nanos();
    #[cfg(gpui_layout_sets_census)]
    let (held_bytes, peak_bytes, requested_bytes, allocation_calls) = census::finish();
    #[cfg(not(gpui_layout_sets_census))]
    let (held_bytes, peak_bytes, requested_bytes, allocation_calls) = (-1, -1, 0, 0);
    let (state_count, state_box_bytes, frame_hash) = cx.update_window(window.into(), |_, window, _| {
        let states = window.rendered_frame.element_states.iter().filter(|((id, _), _)| {
            matches!(id.0.last(), Some(crate::ElementId::NamedInteger(name, _)) if name.as_ref() == "profile-state")
        });
        let (count, bytes) = states.fold((0, 0), |(count, bytes), (_, state)| {
            (count + 1, bytes + std::mem::size_of_val(state.inner.as_ref()))
        });
        let mut hasher = std::collections::hash_map::DefaultHasher::new();
        describe_frame(window).hash(&mut hasher);
        (count, bytes, hasher.finish())
    }).unwrap();
    let layer_counts = crate::scene::take_layer_replay_attribution();
    println!("LAYER_REPLAY_COUNTS {{\"nonmoved_starts\":{},\"nonmoved_growth_calls\":{},\"nonmoved_requested_bytes\":{},\"moved_starts\":{},\"replay_ranges\":{}}}", layer_counts[0], layer_counts[1], layer_counts[2], layer_counts[3], layer_counts[4]);
    println!("LAYOUT_SETS_PROFILE {{\"case\":\"{case}\",\"iterations\":{iterations},\"cpu_ns\":{cpu_ns},\"elapsed_ns\":{elapsed_ns},\"signature\":{frame_hash},\"state_count\":{state_count},\"state_box_bytes\":{state_box_bytes},\"held_bytes\":{held_bytes},\"peak_bytes\":{peak_bytes},\"requested_bytes\":{requested_bytes},\"allocation_calls\":{allocation_calls}}}");
}
