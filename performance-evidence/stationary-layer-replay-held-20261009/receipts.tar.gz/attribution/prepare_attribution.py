from pathlib import Path
import hashlib
import json
import shutil

root = Path(__file__).parent
source = Path('/workspace/zed-layer-replay')
work = root / 'diagnostic-workspace'
work.mkdir()
previous = Path('/workspace/scratch/gpui-observer-controls-loop/comparison')
crates = json.loads((previous / 'baseline-source-inputs.json').read_text())['crates']
for crate in crates:
    shutil.copytree(source / 'crates' / crate, work / 'crates' / crate, symlinks=True)
for name in ['Cargo.toml', 'Cargo.lock', 'AGENTS.md', 'README.md', 'rust-toolchain.toml', 'LICENSE-APACHE', 'LICENSE-GPL']:
    shutil.copy2(source / name, work / name)
shutil.copytree(source / '.cargo', work / '.cargo', symlinks=True)
for name in ['ibm-plex-sans', 'lilex']:
    shutil.copytree(source / 'assets/fonts' / name, work / 'assets/fonts' / name, symlinks=True)
path = work / 'crates/gpui/src/gpui.rs'
path.write_text(path.read_text() + '\n#[cfg(all(test, gpui_layout_sets_census))]\n#[path = "perf_count.rs"]\npub(crate) mod perf_count;\n')
for name in ['perf-count.rs', 'comparison-fixture.rs', 'transcript-fixture.rs']:
    shutil.copy2(previous / name, root / name)
(work / 'crates/gpui/src/perf_count.rs').write_bytes((root / 'perf-count.rs').read_bytes())
scene = work / 'crates/gpui/src/scene.rs'
text = scene.read_text()
text = text.replace('        let mut layers_left_out: Vec<bool> = Vec::new();', '''        let mut layers_left_out: Vec<bool> = Vec::new();
        #[cfg(gpui_layer_attribution)]
        let mut layer_profile = [0u64; 5];''', 1)
text = text.replace('                        layers_left_out.push(left_out);', '''                        #[cfg(gpui_layer_attribution)]
                        { layer_profile[3] += 1; }
                        layers_left_out.push(left_out);''', 1)
text = text.replace('                        layers_left_out.push(false);', '''                        #[cfg(gpui_layer_attribution)]
                        let previous_capacity = layers_left_out.capacity();
                        layers_left_out.push(false);
                        #[cfg(gpui_layer_attribution)]
                        {
                            layer_profile[0] += 1;
                            if layers_left_out.capacity() != previous_capacity {
                                layer_profile[1] += 1;
                                layer_profile[2] += layers_left_out.capacity() as u64;
                            }
                        }''', 1)
needle = '    pub fn finish(&mut self) {'
prefix, suffix = text.split(needle, 1)
assert prefix.endswith('        }\n    }\n\n')
prefix = prefix[:-len('        }\n    }\n\n')] + '''        }
        #[cfg(gpui_layer_attribution)]
        {
            layer_profile[4] = 1;
            LAYER_REPLAY_ATTRIBUTION.with(|counts| {
                let mut total = counts.get();
                for index in 0..total.len() { total[index] += layer_profile[index]; }
                counts.set(total);
            });
        }
    }

'''
scene.write_text(prefix + needle + suffix + '''
#[cfg(gpui_layer_attribution)]
thread_local! {
    static LAYER_REPLAY_ATTRIBUTION: std::cell::Cell<[u64; 5]> = const { std::cell::Cell::new([0; 5]) };
}
#[cfg(gpui_layer_attribution)]
pub(crate) fn start_layer_replay_attribution() {
    LAYER_REPLAY_ATTRIBUTION.with(|counts| counts.set([0; 5]));
}
#[cfg(gpui_layer_attribution)]
pub(crate) fn take_layer_replay_attribution() -> [u64; 5] {
    LAYER_REPLAY_ATTRIBUTION.with(|counts| counts.get())
}
''')
transcript = (root / 'transcript-fixture.rs').read_text()
transcript = transcript.replace('    let cpu_started =', '''    crate::scene::start_layer_replay_attribution();
    let cpu_started =''', 1)
transcript += '\n'
transcript = transcript.replace('    println!("TRANSCRIPT_PROFILE ', '''    let layer_counts = crate::scene::take_layer_replay_attribution();
    println!("LAYER_REPLAY_COUNTS {{\\\"nonmoved_starts\\\":{},\\\"nonmoved_growth_calls\\\":{},\\\"nonmoved_requested_bytes\\\":{},\\\"moved_starts\\\":{},\\\"replay_ranges\\\":{}}}", layer_counts[0], layer_counts[1], layer_counts[2], layer_counts[3], layer_counts[4]);
    println!("TRANSCRIPT_PROFILE ''', 1)
(root / 'diagnostic-transcript-fixture.rs').write_text(transcript)
(work / 'crates/gpui/src/window/view_retention/transcript_profile.rs').write_text(transcript)
fixture = (root / 'comparison-fixture.rs').read_text()
needle = '    let cpu_started = thread_cpu_ns();'
assert needle in fixture
fixture = fixture.replace(needle, '    crate::scene::start_layer_replay_attribution();\n' + needle, 1)
needle = '    println!("LAYOUT_SETS_PROFILE '
assert needle in fixture
fixture = fixture.replace(needle, '''    let layer_counts = crate::scene::take_layer_replay_attribution();
    println!("LAYER_REPLAY_COUNTS {{\\\"nonmoved_starts\\\":{},\\\"nonmoved_growth_calls\\\":{},\\\"nonmoved_requested_bytes\\\":{},\\\"moved_starts\\\":{},\\\"replay_ranges\\\":{}}}", layer_counts[0], layer_counts[1], layer_counts[2], layer_counts[3], layer_counts[4]);
    println!("LAYOUT_SETS_PROFILE ''', 1)
(root / 'diagnostic-comparison-fixture.rs').write_text(fixture)
(work / 'crates/gpui/src/window/view_retention/splice_profile.rs').write_text(fixture)
path = work / 'crates/gpui/src/window/view_retention/tests.rs'
path.write_text(path.read_text() + '\n#[cfg(target_os = "linux")]\n#[path = "transcript_profile.rs"]\nmod transcript_profile;\n')
files = {str(path.relative_to(work)): hashlib.sha256(path.read_bytes()).hexdigest()
         for path in work.rglob('*') if path.is_file()}
(root / 'diagnostic-source-inputs.json').write_text(json.dumps({
    'baseline': 'df6e7d05b529313ad142f397a4e4ea428c2c01ae', 'candidate': None,
    'lane': 'diagnostic', 'crates': crates, 'files': files,
    'description': 'Current24ownercrates/fullroot/lock/fonts/licenses; private per-replay actual nonmoved Vec<bool> growth/capacity counters added once perrange. Same countingSystem pluscomplete transcript/panel fixtures. No production modification.'}, indent=2) + '\n')
path = root / 'build_native.py'
code = path.read_text().replace("args += ['--cfg', 'gpui_union_attribution']", "args += ['--cfg', 'gpui_layer_attribution']")
path.write_text(code)
print(json.dumps({'baseline': 'df6e7d05b529313ad142f397a4e4ea428c2c01ae', 'files': len(files), 'candidate': None}))
