from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path(__file__).parent
binary = root / 'diagnostic-attribution-layer-artifacts/gpui-ada3fb4d7b1cfe56'
identity = {'path': str(binary), 'bytes': binary.stat().st_size,
            'sha256': hashlib.sha256(binary.read_bytes()).hexdigest()}
(root / 'diagnostic-binary-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
dependencies = json.loads((root / 'external-dependencies.json').read_text())
assert len(dependencies) == 59
for dependency in dependencies:
    assert hashlib.sha256(Path(dependency['path']).read_bytes()).hexdigest() == dependency['sha256']
cases = [f'{scenario}-{mode}-200' for scenario in ['scroll', 'stream', 'tick', 'redraw', 'rebuild']
         for mode in ['off', 'on']]
cases += ['panel-keep-32', 'panel-keep-256']
output = root / 'attribution-receipts'
output.mkdir()
rows = []
for case in cases:
    for repeat in range(3):
        path = output / (case + '-' + str(repeat) + '.log')
        transcript = not case.startswith('panel-')
        pattern = 'profile_transcript_paint' if transcript else 'profile_layout_key_sets'
        command = [str(root / 'native-run'), 'taskset', '-c', '2', str(binary), pattern,
                   '--ignored', '--nocapture', '--test-threads=1']
        environment = dict(os.environ, TRANSCRIPT_PROFILE_CASE=case, TRANSCRIPT_PROFILE_ITERATIONS='128',
                           LAYOUT_SETS_PROFILE_CASE=case, LAYOUT_SETS_PROFILE_ITERATIONS='128')
        with path.open('w') as log:
            result = subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=60)
        log = path.read_text()
        row = {'case': case, 'repeat': repeat, 'command': command, 'exit_code': result.returncode,
               'binary_sha256': identity['sha256'], 'log': str(path),
               'log_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
        for line in log.splitlines():
            for marker in ['TRANSCRIPT_PROFILE ', 'LAYOUT_SETS_PROFILE ', 'LAYER_REPLAY_COUNTS ', 'NATIVE_RECEIPT ']:
                if marker in line:
                    row.update(json.loads(line.split(marker, 1)[1]))
        rows.append(row)
        (root / 'attribution-samples.json').write_text(json.dumps(rows, indent=2) + '\n')
        assert result.returncode == 0 and 'nonmoved_growth_calls' in row and 'cpu_ns' in row, log
print(json.dumps({'diagnostic_children': len(rows), 'all_exits_zero': True,
                  'exact_actual_Vec_capacity_growth_counts': True,
                  'diagnostic_clocks_and_counters_not_paired_gain_evidence': True}))
