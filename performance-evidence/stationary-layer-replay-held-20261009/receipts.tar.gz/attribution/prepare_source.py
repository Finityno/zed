from pathlib import Path
import base64
import hashlib
import json
import os
import shutil
import subprocess

root = Path(__file__).parent
original = Path('/workspace/zed-observer-controls')
work = Path('/workspace/zed-layer-replay')
baseline = 'df6e7d05b529313ad142f397a4e4ea428c2c01ae'
environment = dict(os.environ, GIT_NO_LAZY_FETCH='1')
tree = json.loads((root / 'baseline-tree.json').read_text())
git = lambda *args, **kwargs: subprocess.check_output(['git', '-C', str(original), *args], env=environment, **kwargs)
children = {}
for entry in tree['tree']:
    parent, _, name = entry['path'].rpartition('/')
    children.setdefault(parent, []).append((name, entry))
tree_entries = [entry for entry in tree['tree'] if entry['type'] == 'tree']
for path, expected in [(entry['path'], entry['sha']) for entry in tree_entries] + [('', tree['sha'])]:
    entries = sorted(children.get(path, []), key=lambda item: (item[0] + ('/' if item[1]['type'] == 'tree' else '')).encode())
    raw = b''.join(entry['mode'].lstrip('0').encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(entry['sha'])
                   for name, entry in entries)
    assert hashlib.sha1(b'tree ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == expected
    assert git('hash-object', '-t', 'tree', '-w', '--stdin', input=raw).decode().strip() == expected
git('worktree', 'add', '--no-checkout', '-b', 'perf/layer-replay-tracking-20261009', str(work), baseline)
missing = []
verified = 0
changed = {'crates/gpui_linux/src/linux/wayland/client.rs', 'crates/gpui_linux/src/linux/wayland/window.rs', 'crates/gpui_linux/src/linux/x11/window.rs', 'crates/gpui_wgpu/src/wgpu_renderer.rs'}
restore = {'crates/gpui/src/subscription.rs', 'PERFORMANCE_GOAL.md'}
for entry in tree['tree']:
    if entry['type'] != 'blob':
        continue
    old, new = original / entry['path'], work / entry['path']
    if entry['path'] in changed:
        fetched = json.loads((root / (entry['path'].replace('/', '__') + '.json')).read_text())
        assert fetched['sha'] == entry['sha']
        data = base64.b64decode(fetched['content'])
    elif entry['path'] in restore:
        data = git('show', baseline + ':' + entry['path'])
    elif old.is_symlink():
        data = os.readlink(old).encode()
    elif old.exists():
        data = old.read_bytes()
    else:
        missing.append(entry['path'])
        continue
    actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert actual == entry['sha'], entry['path']
    assert git('hash-object', '-w', '--stdin', input=data).decode().strip() == actual
    new.parent.mkdir(parents=True, exist_ok=True)
    if entry['mode'] == '120000':
        new.symlink_to(data.decode())
    else:
        new.write_bytes(data)
        os.chmod(new, 0o755 if entry['mode'] == '100755' else 0o644)
    verified += 1
subprocess.run(['git', '-C', str(work), 'read-tree', 'HEAD'], env=environment, check=True)
if missing:
    subprocess.run(['git', '-C', str(work), 'update-index', '--skip-worktree', '--stdin'],
                   input='\n'.join(missing) + '\n', env=environment, text=True, check=True)
assert not subprocess.check_output(['git', '-C', str(work), 'status', '--porcelain'], env=environment, text=True).strip()
assert subprocess.check_output(['git', '-C', str(work), 'write-tree', '--missing-ok'], env=environment, text=True).strip() == tree['sha']
assert (work / 'README.md').read_text().startswith('> [!IMPORTANT]\n> Remove this line to confirm')
(root / 'baseline-import-receipt.json').write_text(json.dumps({
    'baseline': baseline, 'tree': tree['sha'], 'clean': True, 'all_materialized_blob_bytes_verified': verified,
    'unmaterialized_blob_identities_preserved': len(missing), 'all_previous_held_changes_removed': True,
    'independent_cursor_and_GPU_recovery_fixes_preserved': True, 'workspace': str(work)}, indent=2) + '\n')
previous = Path('/workspace/scratch/gpui-effect-capacity-loop')
for name in ['build_native.py', 'supervise.py', 'native-run', 'native_run.c', 'external-dependencies.json', 'perf-count.rs']:
    shutil.copy2(previous / name, root / name)
print((root / 'baseline-import-receipt.json').read_text())
