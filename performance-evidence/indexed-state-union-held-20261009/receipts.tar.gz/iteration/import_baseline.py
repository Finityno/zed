import hashlib, json, os, shutil, subprocess
from pathlib import Path

root = Path(__file__).parent
source = Path('/workspace/zed-bounded-reads')
workspace = Path('/workspace/zed-indexed-states')
environment = dict(os.environ, GIT_NO_LAZY_FETCH='1')
tree = json.loads((root / 'baseline-tree.json').read_text())
children = {}
trees = {'': tree['sha']}
for entry in tree['tree']:
    parent, _, name = entry['path'].rpartition('/')
    children.setdefault(parent, []).append((name, entry))
    if entry['type'] == 'tree': trees[entry['path']] = entry['sha']
def write_object(kind, body, expected):
    assert hashlib.sha1(kind.encode() + b' ' + str(len(body)).encode() + b'\0' + body).hexdigest() == expected
    result = subprocess.check_output(['git', '-C', str(source), 'hash-object', '-t', kind, '-w', '--stdin'], input=body, env=environment).decode().strip()
    assert result == expected
for path, expected in trees.items():
    entries = sorted(children.get(path, []), key=lambda item: (item[0] + ('/' if item[1]['type'] == 'tree' else '')).encode())
    body = b''.join(entry['mode'].lstrip('0').encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(entry['sha']) for name, entry in entries)
    write_object('tree', body, expected)
blobs = json.loads((root / 'baseline-blobs.json').read_text())
for entry in blobs: write_object('blob', entry['content'].encode(), entry['sha'])
subprocess.run(['python3', '/workspace/scratch/gpui-empty-recording-adoption-loop/import_signed_commit.py', str(root / 'baseline-raw-commit.json'), str(source)], check=True, env=environment)
commit = json.loads((root / 'baseline-raw-commit.json').read_text())['sha']
subprocess.run(['git', '-C', str(source), 'worktree', 'add', '--no-checkout', '-b', 'perf/indexed-state-union-20261009', str(workspace), commit], check=True, env=environment)
for path in source.iterdir():
    if path.name == '.git': continue
    if path.is_dir(): shutil.copytree(path, workspace / path.name)
    else: shutil.copy2(path, workspace / path.name)
for entry in blobs: (workspace / entry['path']).write_text(entry['content'])
subprocess.run(['git', '-C', str(workspace), 'read-tree', 'HEAD'], check=True, env=environment)
missing = [entry['path'] for entry in tree['tree'] if entry['type'] == 'blob' and not (workspace / entry['path']).exists()]
if missing:
    subprocess.run(['git', '-C', str(workspace), 'update-index', '--skip-worktree', '--stdin'], input='\n'.join(missing)+'\n', text=True, check=True, env=environment)
assert not subprocess.check_output(['git', '-C', str(workspace), 'status', '--porcelain'], text=True, env=environment).strip()
assert subprocess.check_output(['git', '-C', str(workspace), 'write-tree', '--missing-ok'], text=True, env=environment).strip() == tree['sha']
assert (workspace / 'README.md').read_text().startswith('> [!IMPORTANT]\n> Remove this line to confirm')
receipt = {'commit': commit, 'tree': tree['sha'], 'trees_hash_verified': len(trees), 'changed_blobs_hash_verified': len(blobs), 'unmaterialized_blobs_preserved': len(missing), 'worktree': str(workspace), 'clean': True}
(root / 'baseline-import-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
handoff_path = Path('/workspace/scratch/gpui-fork-loop/handoff.json')
handoff = json.loads(handoff_path.read_text())
handoff.update(active_workspace=str(workspace), active_branch='perf/indexed-state-union-20261009', active_iteration=str(root), recent_owned_main=commit, fincode_component_pinned_sha='de14de8f92c6ade7ca616cd1861135f04185d170', phase='Inspect current-main state union shape attribution before candidate; no build/profile active. Prior merges and failed designs preserved.')
handoff['next_iteration'] = {'workspace':str(workspace), 'directory':str(root), 'branch':'perf/indexed-state-union-20261009', 'baseline':commit, 'active_session':None, 'active_stage':'Read-only complete-component diagnostic preparation'}
handoff_path.write_text(json.dumps(handoff, indent=2)+'\n')
print(json.dumps(receipt))
