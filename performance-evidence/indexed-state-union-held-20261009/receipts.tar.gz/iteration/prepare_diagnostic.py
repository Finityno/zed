from pathlib import Path
import hashlib, json, shutil

root = Path(__file__).parent
source = Path('/workspace/zed-indexed-states')
workspace = root / 'diagnostic-workspace'
inputs = json.loads(Path('/workspace/scratch/gpui-layout-sets-loop/source-inputs.json').read_text())['baseline']
crates = sorted({path.split('/')[1] for path in inputs if path.startswith('crates/')})
if not workspace.exists():
    workspace.mkdir()
    for name in crates: shutil.copytree(source / 'crates' / name, workspace / 'crates' / name, symlinks=True)
    shutil.copytree(source / '.cargo', workspace / '.cargo', symlinks=True)
    for name in ['ibm-plex-sans','lilex']: shutil.copytree(source / 'assets/fonts' / name, workspace / 'assets/fonts' / name, symlinks=True)
for name in ['Cargo.toml','Cargo.lock','AGENTS.md','README.md','rust-toolchain.toml','LICENSE-APACHE','LICENSE-GPL']:
    shutil.copy2(source / name, workspace / name)
path = workspace / 'crates/gpui/src/window/view_retention/dependencies.rs'
text = path.read_text()
marker = 'impl RenderDependencies {\n'
assert text.count(marker)==1
text = text.replace(marker, '''#[cfg(gpui_union_attribution)]
thread_local! {
    pub(crate) static STATE_UNION_COST: Cell<[[u64; 3]; 36]> = const { Cell::new([[0; 3]; 36]) };
    pub(crate) static STATE_UNIQUE_COST: Cell<[u64; 4]> = const { Cell::new([0; 4]) };
}

''' + marker)
needle = '        let mut states = self.states.to_vec();\n'
assert text.count(needle)==1
text=text.replace(needle,'''        #[cfg(gpui_union_attribution)]
        let mut comparisons = 0u64;
        #[cfg(gpui_union_attribution)]
        let mut insertions = 0u64;
''' + needle)
needle='states.iter().any(|(version, _)| version.same_state(&state.0))'
assert text.count(needle)==1
text=text.replace(needle,'''states.iter().any(|(version, _)| {
                #[cfg(gpui_union_attribution)]
                { comparisons += 1; }
                version.same_state(&state.0)
            })''')
needle='                states.push(state.clone());\n'
assert text.count(needle)==1
text=text.replace(needle,'''                #[cfg(gpui_union_attribution)]
                { insertions += 1; }
''' + needle)
needle='        Self {\n            entities: merge_reads('
assert text.count(needle)==1
text=text.replace(needle,'''        #[cfg(gpui_union_attribution)]
        STATE_UNION_COST.with(|counts| {
            let bucket = |length| match length { 0 => 0, 1..=3 => 1, 4..=31 => 2, 32..=63 => 3, 64..=255 => 4, _ => 5 };
            let mut values = counts.get();
            let index = bucket(self.states.len()) * 6 + bucket(other.states.len());
            values[index][0] += 1;
            values[index][1] += comparisons;
            values[index][2] += insertions;
            counts.set(values);
        });
''' + needle)
needle='fn unique_states(states: &[(StateVersion, u64)]) -> Rc<[(StateVersion, u64)]> {\n'
assert text.count(needle)==1
text=text.replace(needle,needle+'''    #[cfg(gpui_union_attribution)]
    let mut comparisons = 0u64;
    #[cfg(gpui_union_attribution)]
    let started = Instant::now();
''')
needle='            .any(|(version, _)| version.same_state(&state.0))'
assert text.count(needle)==1
text=text.replace(needle,'''            .any(|(version, _)| {
            #[cfg(gpui_union_attribution)]
            { comparisons += 1; }
            version.same_state(&state.0)
        })''')
needle='    unique.into()\n'
assert text.count(needle)==1
text=text.replace(needle,'''    #[cfg(gpui_union_attribution)]
    STATE_UNIQUE_COST.with(|counts| {
        let mut values = counts.get();
        values[0] += 1;
        values[1] += comparisons;
        values[2] += started.elapsed().as_nanos() as u64;
        values[3] += states.len() as u64;
        counts.set(values);
    });
''' + needle)
path.write_text(text)
fixture=Path('/workspace/scratch/gpui-bounded-reads-loop/comparison-fixture.rs').read_text()
needle='    println!("LAYOUT_SETS_PROFILE '
assert fixture.count(needle)==1
fixture=fixture.replace(needle,'''    #[cfg(gpui_union_attribution)]
    {
        crate::window::view_retention::dependencies::STATE_UNION_COST.with(|counts| {
            println!("STATE_UNION_COST {:?}", counts.get());
        });
        crate::window::view_retention::dependencies::STATE_UNIQUE_COST.with(|counts| {
            println!("STATE_UNIQUE_COST {:?}", counts.get());
        });
    }
''' + needle)
(workspace/'crates/gpui/src/window/view_retention/splice_profile.rs').write_text(fixture)
path=workspace/'crates/gpui/src/window/view_retention.rs'
text=path.read_text();assert 'mod splice_profile;' not in text;path.write_text(text+'\n#[cfg(test)]\nmod splice_profile;\n')
files={str(p.relative_to(workspace)):hashlib.sha256(p.read_bytes()).hexdigest() for p in workspace.rglob('*') if p.is_file()}
(root/'diagnostic-source-inputs.json').write_text(json.dumps({'baseline':'8ceb46cd79dc910bf709b561727bb42e7e9ae2da','crates':crates,'files':files,'scope':'Private original complete App/Window state unions execute unchanged with local counters and shape buckets; unique-state Instant spans include instrumentation. Setup/warmup included. No candidate or paired gain.'},indent=2)+'\n')
for name in ['build_native.py','supervise.py','native-run','native_run.c']:
    shutil.copy2(Path('/workspace/scratch/gpui-bounded-reads-loop')/name,root/name)
print(json.dumps({'files':len(files),'crates':len(crates),'production_candidate':False}))
