from pathlib import Path
import hashlib, json, os, subprocess
root=Path(__file__).parent
binary=root/'diagnostic-attribution2-artifacts/gpui-ada3fb4d7b1cfe56'
cases=json.loads(Path('/workspace/scratch/gpui-bounded-reads-loop/policy.json').read_text())['controls']
processes=subprocess.check_output(['ps','-eo','stat,comm'],text=True).splitlines()[1:]
assert not any(not line.split()[0].startswith('Z') and line.split()[1] in ['cargo','rustc','native-run','gpui-ada3fb4d7b1cfe56'] for line in processes)
output=root/'diagnostic2-receipts';output.mkdir()
binary_hash=hashlib.sha256(binary.read_bytes()).hexdigest()
samples=[]
for case in cases:
    command=[str(root/'native-run'),'taskset','-c','2',str(binary),'profile_layout_key_sets','--ignored','--nocapture','--test-threads=1']
    environment=dict(os.environ,LAYOUT_SETS_PROFILE_CASE=case,LAYOUT_SETS_PROFILE_ITERATIONS='8')
    log=output/(case+'.log')
    with log.open('w') as stream: result=subprocess.run(command,env=environment,stdout=stream,stderr=subprocess.STDOUT,timeout=60)
    sample={'case':case,'command':command,'binary_sha256':binary_hash,'exit_code':result.returncode,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    for line in log.read_text().splitlines():
        for marker in ['STATE_UNION_COST ','STATE_UNIQUE_COST ','LAYOUT_SETS_PROFILE ','NATIVE_RECEIPT ']:
            if marker in line:
                value=json.loads(line.split(marker,1)[1])
                if marker.startswith('STATE_'): sample[marker.strip()]=value
                else: sample.update(value)
    samples.append(sample);(root/'diagnostic2-samples.json').write_text(json.dumps(samples,indent=2)+'\n')
    assert result.returncode==0 and len(sample['STATE_UNION_COST'])==36
    eligible=[value for index,value in enumerate(sample['STATE_UNION_COST']) if index%6>=4]
    print(json.dumps({'case':case,'all_union_comparisons':sum(value[1] for value in sample['STATE_UNION_COST']),'eligible_comparisons':sum(value[1] for value in eligible),'eligible_calls':sum(value[0] for value in eligible),'eligible_insertions':sum(value[2] for value in eligible),'unique':sample['STATE_UNIQUE_COST']}),flush=True)
