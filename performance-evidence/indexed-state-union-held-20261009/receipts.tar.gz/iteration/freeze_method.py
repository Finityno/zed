from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).parent
old=Path('/workspace/scratch/gpui-bounded-reads-loop')
policy=json.loads((old/'policy.json').read_text())
policy.update(goal='Bounded stack identity index for large versioned-state unions, preserve exact read order/left precedence/duplicate left owners, requested allocation/heap and original small/empty-state algorithms.',baseline='8ceb46cd79dc910bf709b561727bb42e7e9ae2da',fincode_pin='4661be26e8da24bda712cd9096bf9fabfe351d5b',component_pin='de14de8f92c6ade7ca616cd1861135f04185d170',primary_cases=['state-panel-keep-256','state-keep-256'],basis='20current-main complete App/Window children: panel-keep256 performs783360 state identity comparisons, keep256261120 in8measured frames plus4warmups/setup. Large-right input buckets account for100% of these comparisons; remove256 has556672/819847 eligible comparisons. Counter/Instant overhead prevents diagnostic timing gain claims. Unique-state recording remains unchanged. Left-empty/right256 and left256/right256 are observed. Prior failed designs stay held.',design_limits='Only RHS>=64 and combined input<=512 enter a non-inlined kernel with512raw identity pointers (4096stack bytes on64-bit); original small/empty loop remains literal. Sort only stack index, binary-search/insert pointer membership, clone/push vector exactly in original order and original growth. Preserve all existing duplicate left entries and first right occurrence. No changed fields/state checker/replay/owner caches or added dependency. Larger lists fall back unchanged.',correctness='Compare exact ordered identity/version outputs to original under arbitrary repeated identities, conflicting/nonmonotonic stamps, empty/asymmetric inputs and63/64/65 and511/512/513 boundaries. Native dependency mutation/frame oracle/scroll/panel/layout/claim/recorder contracts plus owning strictClippy and isolation. All representative state-bump and disjoint controls included before measurement.',status='Frozen before production candidate or paired samples. At least5% complete CPU/elapsed gains beyond both full lane ranges in both primary cases; original strict per-field control rules retained.')
policy['controls']+=['state-replace-32','state-replace-256','state-grow-32','state-grow-256','state-disjoint-32','state-disjoint-256','state-bump-32','state-bump-256']
(root/'policy.json').write_text(json.dumps(policy,indent=2)+'\n')
fixture=(old/'comparison-fixture.rs').read_text()
needle='                        if workload.starts_with("remove-") || workload.starts_with("off-remove-") {\n'
assert fixture.count(needle)==1
fixture=fixture.replace(needle,'''                        if workload.starts_with("disjoint-") {
                            leaf.dependency = Some(DrawDependency::new());
                            leaf.height = 10. + (iteration % 3) as f32;
                        } else if workload.starts_with("bump-") {
                            leaf.dependency.as_ref().expect("stateful").changed(cx);
                            leaf.height = 10. + (iteration % 3) as f32;
                        } else if workload.starts_with("remove-") || workload.starts_with("off-remove-") {
''')
(root/'comparison-fixture.rs').write_text(fixture)
for name in ['measure.py','qualify.py','run_measurements.py','capture_identities.py','external-dependencies.json']:
    shutil.copy2(old/name,root/name)
p=root/'run_measurements.py';t=p.read_text().replace('/workspace/scratch/gpui-linear-reads-loop','/workspace/scratch/gpui-union-state-loop');p.write_text(t)
frozen={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in ['policy.json','measure.py','qualify.py','run_measurements.py','native_run.c','native-run','comparison-fixture.rs','external-dependencies.json']}
(root/'pre-candidate-frozen-method.json').write_text(json.dumps(frozen,indent=2)+'\n')
(root/'design-review.json').write_text(json.dumps({'no_production_candidate_yet':True,'rejected_sorting_output_before_candidate':'State read order can select a different first saved stamp on replay for duplicate left identities. Use ordered output and separate bounded stack membership, preserving exact sequence.','pointer_safety':'Stack stores raw identities solely for Ord/equality; never dereferenced. Both input Rc owners live throughout, no identity reuse. Checked combined cardinality bounds every copy_within and insertion.','allocation':'Same left.to_vec, same unique right clone/push sequence and original Vec growth then Rc conversion; no extra requested heap. Exactly4096bytes temporary stack at512pointers, no retained cache.'},indent=2)+'\n')
print(json.dumps({'controls':len(policy['controls']),'primaries':policy['primary_cases'],'policy_sha256':frozen['policy.json'],'method_frozen':True}))
