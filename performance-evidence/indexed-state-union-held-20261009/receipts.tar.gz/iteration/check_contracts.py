from pathlib import Path
import hashlib
import json
import subprocess

root = Path(__file__).parent
contracts = [
    ('baseline', 'state_union_tests', 0),
    ('candidate', 'state_union_tests', 0),
    ('baseline', 'sorted_read_union_uses_linear_key_comparisons', 0),
    ('baseline', 'sorted_read_unions_preserve_earliest_floor_lifted_versions', 0),
    ('candidate', 'read_union_tests', 0),
    ('candidate', 'empty_nested_tests', 0),
    ('candidate', 'a_host_is_drawn_again_around_a_row_whose_dependencies_changed', 0),
    ('candidate', 'frames_drawing_views_again_match_frames_drawn_from_scratch', 0),
    ('candidate', 'rows_with_scrollers_scrolled_by_the_wheel_are_not_built_after', 0),
    ('candidate', 'a_panel_is_drawn_again_around_its_live_row', 0),
    ('candidate', 'a_panel_is_built_when_its_live_row_changes_its_layout', 0),
    ('candidate', 'a_view_built_in_a_gap_resolves_the_groups_around_it', 0),
    ('candidate', 'retained_sets_validate_every_set_before_claiming_any_node', 0),
]
rows = []
for lane, pattern, expected in contracts:
    binary = root / (lane + '-bare-artifacts/gpui-ada3fb4d7b1cfe56')
    name = lane + '-' + pattern
    command = ['python3', str(root / 'supervise.py'), '--seconds', '60', '--name', name, '--cwd', str(root / (lane + '-workspace')), '--', str(binary), pattern, '--nocapture', '--test-threads=1']
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    log = root / (name + '.log')
    receipt = json.loads((root / (name + '-receipt.json')).read_text())
    assert receipt['exit_code'] == result.returncode == expected, result.stdout + log.read_text()
    assert ('test result: FAILED' if expected else 'test result: ok') in log.read_text()
    assert '0 passed; 0 failed' not in log.read_text()
    rows.append({'lane': lane, 'pattern': pattern, 'expected_exit': expected, 'actual_exit': receipt['exit_code'], 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'receipt': str(root / (name + '-receipt.json'))})
    (root / 'contracts-summary.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(json.dumps(rows[-1]), flush=True)
