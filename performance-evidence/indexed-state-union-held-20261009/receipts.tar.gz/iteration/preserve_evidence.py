from pathlib import Path
import gzip,hashlib,io,json,tarfile
root=Path(__file__).parent;work=Path('/workspace/zed-indexed-states')
output=work/'performance-evidence/indexed-state-union-held-20261009';output.mkdir(parents=True)
decision=json.loads((root/'decision.json').read_text());assert not decision['qualified']
for name,expected in json.loads((root/'frozen-inputs.json').read_text()).items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected
receipts=json.loads((root/'valid-cohort-order-receipt.json').read_text())['receipts']
assert len(receipts)==2 and receipts[1]['started_unix']>=receipts[0]['started_unix']+receipts[0]['elapsed_seconds']
builds=json.loads((root/'build-order-receipt.json').read_text())['receipts']
assert receipts[0]['started_unix']>=builds[-1]['started_unix']+builds[-1]['elapsed_seconds']
for kind,expected_count in [('bare',504),('census',280)]:
    samples=json.loads((root/(kind+'-samples.json')).read_text());assert len(samples)==expected_count
    for sample in samples:
        assert sample['exit_code']==0 and hashlib.sha256(Path(sample['log']).read_bytes()).hexdigest()==sample['log_sha256']
diagnostic=json.loads((root/'diagnostic2-samples.json').read_text());assert len(diagnostic)==20
for sample in diagnostic:
    assert sample['exit_code']==0
    assert hashlib.sha256((root/'diagnostic2-receipts'/(sample['case']+'.log')).read_bytes()).hexdigest()==sample['log_sha256']
assert all(value[metric]['change_percent']==0 for value in decision['summary']['census'].values() for metric in ['held_bytes','peak_bytes','requested_bytes','allocation_calls'])
assert all(value['peak_rss_kib']['pass'] for kind in decision['summary'].values() for value in kind.values())
runtime=json.loads((root/'runtime-identities.json').read_text())
sysroot=Path(runtime['compiler']).parent.parent/'lib/rustlib/x86_64-unknown-linux-gnu/lib'
standard={str(p):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sysroot.iterdir() if p.is_file() and p.suffix in {'.rlib','.so'}}
(root/'native-standard-library-identities.json').write_text(json.dumps(standard,indent=2)+'\n')
original_root=(root/'diagnostic-workspace/crates/gpui/src/window/view_retention.rs').read_bytes()+b'\n#[cfg(test)]\nmod splice_profile;\n'
assert hashlib.sha256(original_root).hexdigest()==json.loads((root/'diagnostic-source-inputs.json').read_text())['files']['crates/gpui/src/window/view_retention.rs']
(root/'initial-rejected-diagnostic-root.rs').write_bytes(original_root)
files={}
private_only={'baseline-raw-commit.json','baseline-tree.json','baseline-blobs.json','component-base-delta.json'}
for path in root.iterdir():
    if path.is_file() and path.suffix in {'.py','.json','.log','.diff','.rs','.c','.md','.txt'} and path.name not in private_only:
        files['iteration/'+path.name]=path
for name in ['bare-receipts','census-receipts','diagnostic2-receipts']:
    for path in (root/name).rglob('*'):
        if path.is_file():files['iteration/'+str(path.relative_to(root))]=path
for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','LICENSE-APACHE','LICENSE-GPL']:
    files['native-root/'+name]=root/'candidate-workspace'/name
for lane in ['baseline','candidate','diagnostic']:
    files[lane+'/dependencies.rs']=root/(lane+'-workspace')/'crates/gpui/src/window/view_retention/dependencies.rs'
manifest={name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in sorted(files.items())}
archive=output/'receipts.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=6,mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
    entries=[('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())]+[(name,p.read_bytes()) for name,p in sorted(files.items())]
    for name,data in entries:
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    for name,expected in manifest.items():
        data=tar.extractfile(name).read();assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
policy=json.loads((root/'policy.json').read_text())
evidence={'status':'HELD/unmerged. No unchanged repeat or weaker gates.','baseline':policy['baseline'],'source':'9740bae5e1a4a4230414442616e37ba39600a736','fincode_gpui':policy['fincode_pin'],'fincode_component':policy['component_pin'],'valid_children':784,'workloads':28,'diagnostic_children':20,'qualified':False,'failures':decision['failures'],'observed_primary_cpu_difference_percent':[-decision['summary']['bare'][c]['cpu_ns']['change_percent'] for c in policy['primary_cases']],'important_gain_not_qualified':'1.84/2.20% targetCPU differences are below frozen5% goal and baseline full ranges. Twenty-three normalCPU/elapsed/whole-child fields also fail, plus four targetCPU/elapsed gain fields. No accepted performance gain.','requested_heap_and_churn':'All28 held/peak/bytes/calls medians exactly identical. All nativeRSS controls pass. 4096temporary stack bytes on64-bit, no retained cache.','mechanism':'Only RHS>=64 and total<=512 enters non-inlined stack identity membership. Exact ordered left duplicates/first saved versions/first right occurrence preserved, original Vec growth/allocation and small/empty loop retained. No changed checker, fields, recorder or GPU.','correctness':'1728ordered arbitrary identity/version/length combinations and changed-after-first-read native contract pass in both lanes; retained oracle16seeds50steps, dependency/wheel/panel/layout/atomic-claim/read/nested contracts pass.','not_run':'Strict owningClippy and application adoption not run: performance unqualified; no PR created or merge permitted.','protocol':'Four sequential native builds completed before one alternating504bare+280census cohort; bare completed before census. Allraw784samples plus20diagnosticchildren verified. No failed valid cohort rerun.','adverse_preparation':'Initial copied symlinks rejected/restored exactly before source use; first private diagnostic compile rejected duplicate fixture attachment, source/hashes/output retained; corrected native fixture before any samples. No failed timing retry.','identities':'Rust1.99 System bare/countingSystem separate lanes;59identicalexterns, compiler/runtime/stdlibrary/source/binary hashes frozen. Current main8ceb independent hidden-surface changes preserved.','coverage_limits':['Linux native complete App/Window fake-platform component; not app/physicalGPU/macOS/Windows/shippedallocator gains.','CPU timers exclude App/setup/4warmups and postloop audits. Census includes App/setup/warmups/finalheldsnapshot.','Diagnostic shape counts include setup/warmups/counter overhead, never used to claim timing gains.','Other independent component/Fincode work preserved; current app still coherent4661/de14.'],'policy_sha256':hashlib.sha256((root/'policy.json').read_bytes()).hexdigest(),'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'members':len(manifest)+1}
(output/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(output/'README.md').write_text('''# Held bounded state identity index

This candidate remains unmerged. One784-child alternating comparison across28
complete App/Window workloads fails its frozen acceptance gates. TargetCPU
differences are1.84–2.20%, below the5%goal and observed baseline variation.
Twenty-three normalCPU/elapsed/whole-child fields regress beyond their controls;
four targetCPU/elapsed gain fields fail. All requested held/peak/churn bytes and
allocation-call medians remain identical. Every nativeRSS control passes.
Do not repeat this design unchanged or weaken its acceptance gates.

The candidate builds a bounded512-pointer stack index only for unions with64or
more right entries and at most512combined entries. Output read order, all left
duplicates, first saved versions and first new right occurrence remain exact.
It uses4096temporary stack bytes on64-bit, with no extra heap or retained cache.
The original small/empty algorithm, Vec growth, checker and renderer remain.

1728ordered identity/version cases include conflicting stamps, duplicate owners,
empty/asymmetric inputs and63/64/65and511/512/513boundaries. Native version-write,
retained frame oracle, dependency changes, wheel scrolling, live-row panels,
layout/atomic-claim/read/nested contracts pass. StrictClippy and application
adoption were not run because performance failed; no PR is opened.

The archive preserves all784valid raw samples,20current-main attribution children,
exact source/compiler/stdlibrary/runtime/common59extern/binary identities, all28
workloads and adverse preparation outputs. Completed process-group deadline
receipts prove compilation, bare timing and census do not overlap. Every member
is hash verified. No failed valid experiment was sampled again.

These are Linux fake-platform complete-component observations with the System
allocator, not whole-app, physicalGPU, macOS/Windows or shipped-allocator gains.
Current main's independent hidden-window GPU-memory changes and original licenses
are preserved. Move to a distinct measured bottleneck.
''')
(root/'archive-verification.json').write_text(json.dumps({k:evidence[k] for k in ['archive_sha256','archive_bytes','members','valid_children','qualified']},indent=2)+'\n')
print(json.dumps({k:evidence[k] for k in ['archive_sha256','archive_bytes','members','valid_children','qualified']}))
