from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path(__file__).parent;source=Path('/workspace/zed-indexed-states')
baseline='8ceb46cd79dc910bf709b561727bb42e7e9ae2da';environment=dict(os.environ,GIT_NO_LAZY_FETCH='1')
candidate=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],env=environment,text=True).strip()
crates=json.loads((root/'diagnostic2-source-inputs.json').read_text())['crates']
dependency_path='crates/gpui/src/window/view_retention/dependencies.rs'
original=subprocess.check_output(['git','-C',str(source),'show',baseline+':'+dependency_path],env=environment).decode()
updated=(source/dependency_path).read_text()
marker='    pub(crate) fn union(&self, other: &Self) -> Self {\n'
start=original.index(marker);end=original.index('\n/// Two sets of reads',start)
updated_start=updated.index(marker);updated_end=updated.index('\n#[inline(never)]\nfn append_indexed_states',updated_start)
baseline_with_tests=updated[:updated_start]+original[start:end]+updated[updated_end:]
fixture=(root/'comparison-fixture.rs').read_bytes()
for lane in ['baseline','candidate']:
    work=root/(lane+'-workspace');work.mkdir()
    for name in crates: shutil.copytree(source/'crates'/name,work/'crates'/name,symlinks=True)
    for name in ['Cargo.toml','Cargo.lock','AGENTS.md','README.md','rust-toolchain.toml','LICENSE-APACHE','LICENSE-GPL']: shutil.copy2(source/name,work/name)
    shutil.copytree(source/'.cargo',work/'.cargo',symlinks=True)
    for name in ['ibm-plex-sans','lilex']: shutil.copytree(source/'assets/fonts'/name,work/'assets/fonts'/name,symlinks=True)
    (work/dependency_path).write_text(baseline_with_tests if lane=='baseline' else updated)
    (work/'crates/gpui/src/window/view_retention/splice_profile.rs').write_bytes(fixture)
    files={str(p.relative_to(work)):hashlib.sha256(p.read_bytes()).hexdigest() for p in work.rglob('*') if p.is_file()}
    (root/(lane+'-source-inputs.json')).write_text(json.dumps({'baseline':baseline,'candidate':candidate,'lane':lane,'crates':crates,'files':files,'description':'Current24actualowningcrates,root/lock/config/fonts/licenses; identical28completeApp/Windowfixtures and new semantic tests/kernel. Only union dispatch differs; old baseline union executes literal original body.'},indent=2)+'\n')
old=json.loads((root/'baseline-source-inputs.json').read_text())['files'];new=json.loads((root/'candidate-source-inputs.json').read_text())['files'];changed=[p for p in old if old[p]!=new[p]]
assert changed==[dependency_path]
(root/'candidate-source.diff').write_bytes(subprocess.check_output(['git','-C',str(source),'diff',baseline,candidate],env=environment))
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==expected for name,expected in json.loads((root/'pre-candidate-frozen-method.json').read_text()).items())
(root/'comparison-source-receipt.json').write_text(json.dumps({'baseline':baseline,'candidate':candidate,'changed_source':changed,'files_each':len(old),'fixture_sha256':hashlib.sha256(fixture).hexdigest(),'policy_sha256':hashlib.sha256((root/'policy.json').read_bytes()).hexdigest()},indent=2)+'\n')
print(json.dumps({'baseline':baseline,'candidate':candidate,'changed':changed,'files':len(old)}))
