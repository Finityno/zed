from pathlib import Path
import gzip
import hashlib
import json
import os
import time

root = Path(__file__).parent
targets = [('/workspace/fincode-gpui/target/debug/deps', 'integration'), ('/workspace/scratch/gpui-fork-loop/candidate-workspace/target/release/deps', 'old-fork-lint')]
rows = []
for source, tag in targets:
    for path in sorted(Path(source).iterdir()):
        if path.suffix not in {'.rmeta', '.rlib'}:
            continue
        output = root / 'inactive-cache' / tag / (path.name + '.gz')
        output.parent.mkdir(parents=True, exist_ok=True)
        assert not output.exists()
        stat = path.stat()
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        with path.open('rb') as inp, output.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=1, mtime=0) as out:
            while block := inp.read(1024 * 1024):
                out.write(block)
        with gzip.open(output, 'rb') as stream:
            restored = hashlib.sha256()
            while block := stream.read(1024 * 1024):
                restored.update(block)
        assert restored.hexdigest() == digest
        rows.append({'original': str(path), 'archive': str(output), 'bytes': stat.st_size, 'sha256': digest, 'mode': stat.st_mode, 'mtime_ns': stat.st_mtime_ns, 'archive_bytes': output.stat().st_size, 'archive_sha256': hashlib.sha256(output.read_bytes()).hexdigest()})
        path.unlink()
        (root / 'inactive-cache-preservation.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps({'files': len(rows), 'saved_bytes': sum(r['bytes'] - r['archive_bytes'] for r in rows), 'roundtrip_verified': True, 'scope': 'Only inactive owned integration and old lint rlib/rmeta caches. All native executables, shared libraries, source/evidence and immutable benchmark externs preserved; original user target untouched.'}))
