from pathlib import Path
import hashlib
import json
import shutil

root = Path(__file__).parent
source = Path('/workspace/zed-state-union')
workspace = root / 'baseline-workspace'
workspace.mkdir()
old = json.loads(Path('/workspace/scratch/gpui-layout-sets-loop/source-inputs.json').read_text())['baseline']
crates = sorted({path.split('/')[1] for path in old if path.startswith('crates/')})
for name in crates:
    shutil.copytree(source / 'crates' / name, workspace / 'crates' / name)
for name in ['Cargo.toml', 'Cargo.lock', 'AGENTS.md', 'README.md', 'rust-toolchain.toml']:
    shutil.copy2(source / name, workspace / name)
shutil.copytree(source / '.cargo', workspace / '.cargo')
path = workspace / 'crates/gpui/src/window/view_retention/dependencies.rs'
text = path.read_text()
needle = '    pub(crate) fn union(&self, other: &Self) -> Self {\n'
assert text.count(needle) == 1
text = text.replace(needle, needle + '''        #[cfg(gpui_union_attribution)]
        UNION_SHAPES.with(|counts| {
            let mut value = counts.get();
            let index = match (self.states.is_empty(), other.states.is_empty()) {
                (true, true) => 0,
                (true, false) => 1,
                (false, true) => 2,
                (false, false) => 3,
            };
            value[index] += 1;
            counts.set(value);
        });
''')
marker = 'impl RenderDependencies {\n'
assert text.count(marker) == 1
text = text.replace(marker, '''#[cfg(gpui_union_attribution)]
thread_local! {
    pub(crate) static UNION_SHAPES: Cell<[u64; 4]> = const { Cell::new([0; 4]) };
}

''' + marker)
path.write_text(text)
path = workspace / 'crates/gpui/src/window/view_retention/splice_profile.rs'
text = path.read_text()
needle = '    println!("LAYOUT_SETS_PROFILE '
assert text.count(needle) == 1
text = text.replace(needle, '''    #[cfg(gpui_union_attribution)]
    crate::window::view_retention::dependencies::UNION_SHAPES.with(|counts| {
        let [both_empty, left_empty, right_empty, neither_empty] = counts.get();
        println!("UNION_ATTRIBUTION {{\\\"both_empty\\\":{both_empty},\\\"left_empty\\\":{left_empty},\\\"right_empty\\\":{right_empty},\\\"neither_empty\\\":{neither_empty}}}");
    });
''' + needle)
path.write_text(text)
identities = {str(path.relative_to(workspace)): hashlib.sha256(path.read_bytes()).hexdigest() for path in workspace.rglob('*') if path.is_file()}
(root / 'baseline-attribution-source-inputs.json').write_text(json.dumps({'current_main': 'eb24f988a4e24c9567d21274c2f87313377c3c86', 'fincode_pin': '3b9c5f36f2b0bc39a70160ac430411efec4dfd48', 'crates': crates, 'files': identities, 'scope': 'Existing complete App/Window retained-frame fixture. Test-only shape counts; no production optimization yet. One attribution observation per workload; not a before/after qualification.'}, indent=2) + '\n')
script = Path('/workspace/scratch/gpui-layout-sets-loop/build_native.py').read_text()
script = script.replace("if kind == 'census':", "if kind in ('census', 'attribution'):")
script = script.replace("args += ['--cfg', 'gpui_layout_sets_census']", "args += ['--cfg', 'gpui_layout_sets_census']\nif kind == 'attribution':\n    args += ['--cfg', 'gpui_union_attribution']")
(root / 'build_native.py').write_text(script)
print(json.dumps({'prepared': str(workspace), 'files': len(identities), 'owning_crates': len(crates), 'production_edit': False}))
