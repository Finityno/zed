from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path(__file__).parent
prior=Path('/workspace/scratch/gpui-indexed-state-loop')
binary=prior/'baseline-bare-artifacts/gpui-ada3fb4d7b1cfe56'
binary_hash=hashlib.sha256(binary.read_bytes()).hexdigest()
identities=json.loads((prior/'binary-identities.json').read_text())['baseline']['bare']
assert binary_hash==identities['sha256']
assert not any(not x.split()[0].startswith('Z') and x.split()[1] in ['cargo','rustc','native-run','gpui-ada3fb4d7b1cfe56'] for x in subprocess.check_output(['ps','-eo','stat,comm'],text=True).splitlines()[1:])
output=root/'transcript-baseline-receipts';output.mkdir()
samples=[]
for scenario in ['Scroll','Stream','Tick','Redraw','Rebuild']:
    for retained in ['false','true']:
        for repeat in range(3):
            case=scenario+':'+retained
            command=[str(prior/'native-run'),'taskset','-c','2',str(binary),'frame_work_transcript','--ignored','--nocapture','--test-threads=1']
            environment=dict(os.environ,GPUI_BENCH_ONLY=case,GPUI_BENCH_FRAMES='240')
            log=output/(scenario+'-'+retained+'-'+str(repeat)+'.log');started=time.time()
            with log.open('w') as stream: result=subprocess.run(command,env=environment,stdout=stream,stderr=subprocess.STDOUT,timeout=60)
            sample={'scenario':scenario,'retained':retained=='true','repeat':repeat,'command':command,'environment':{'GPUI_BENCH_ONLY':case,'GPUI_BENCH_FRAMES':'240'},'exit_code':result.returncode,'started_unix':started,'seconds':time.time()-started,'binary_sha256':binary_hash,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
            for line in log.read_text().splitlines():
                if line.startswith(scenario+' retained '):sample['frame_work']=line
                if line.startswith('NATIVE_RECEIPT '):sample.update(json.loads(line.split(' ',1)[1]))
            samples.append(sample);(root/'transcript-baseline-samples.json').write_text(json.dumps(samples,indent=2)+'\n')
            assert result.returncode==0 and 'frame_work' in sample,log.read_text()
            print(json.dumps({'case':case,'repeat':repeat,'frame_work':sample['frame_work']}),flush=True)
