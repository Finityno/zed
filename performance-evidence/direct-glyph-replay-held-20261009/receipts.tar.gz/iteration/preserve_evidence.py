from pathlib import Path
import gzip, hashlib, io, json, tarfile

root = Path(__file__).parent
work = Path('/workspace/zed-glyph-replay')
output = work / 'performance-evidence/direct-glyph-replay-held-20261009'
output.mkdir(parents=True)
decision = json.loads((root / 'decision.json').read_text())
assert not decision['qualified']
for name, expected in json.loads((root / 'frozen-inputs.json').read_text()).items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected
builds = json.loads((root / 'build-order-receipt.json').read_text())['receipts']
phases = json.loads((root / 'valid-cohort-order-receipt.json').read_text())['receipts']
assert len(phases) == 2
assert phases[0]['started_unix'] >= builds[-1]['started_unix'] + builds[-1]['elapsed_seconds']
assert phases[1]['started_unix'] >= phases[0]['started_unix'] + phases[0]['elapsed_seconds']
for kind, count in [('bare', 1044), ('census', 580)]:
    samples = json.loads((root / (kind + '-samples.json')).read_text())
    assert len(samples) == count
    for sample in samples:
        assert sample['exit_code'] == 0
        assert hashlib.sha256(Path(sample['log']).read_bytes()).hexdigest() == sample['log_sha256']
assert all(value[metric]['change_percent'] == 0 for value in decision['summary']['census'].values() for metric in ['held_bytes', 'peak_bytes', 'requested_bytes', 'allocation_calls'])
files = {}
private = {'current-fincode-open-refresh.json', 'current-zed-open-refresh.json', 'completed-consumer-cache-preservation.json', 'cache-preservation-checkpoint.json', 'remaining-cache-preservation.jsonl'}
for path in root.iterdir():
    if path.is_file() and path.suffix in {'.py', '.json', '.log', '.diff', '.rs', '.c', '.md', '.txt'} and path.name not in private:
        files['iteration/' + path.name] = path
for name in ['bare-receipts', 'census-receipts']:
    for path in (root / name).rglob('*'):
        if path.is_file():
            files['iteration/' + str(path.relative_to(root))] = path
for name in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'LICENSE-APACHE', 'LICENSE-GPL']:
    files['native-root/' + name] = root / 'candidate-workspace' / name
for lane in ['baseline', 'candidate']:
    files[lane + '/scene.rs'] = root / (lane + '-workspace') / 'crates/gpui/src/scene.rs'
diagnostic = Path('/workspace/scratch/gpui-scroll-layer-loop')
for name in ['transcript-attribution-summary.json', 'transcript-attribution-samples.json', 'transcript-attribution.py', 'diagnostic-source-identity.json', 'diagnostic-runtime-identities.json']:
    path = diagnostic / name
    if path.exists():
        files['attribution/' + name] = path
for path in diagnostic.iterdir():
    if path.is_file() and (path.suffix in {'.py', '.json', '.log', '.txt'}) and 'comparison' not in path.name and 'upstream' not in path.name:
        files['attribution/' + path.name] = path
for path in diagnostic.rglob('*.log'):
    if 'comparison' not in str(path.relative_to(diagnostic)) and 'upstream' not in str(path.relative_to(diagnostic)):
        files['attribution/' + str(path.relative_to(diagnostic))] = path
manifest = {name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for name, path in sorted(files.items())}
archive = output / 'receipts.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=6, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
    entries = [('manifest.json', (json.dumps(manifest, indent=2) + '\n').encode())] + [(name, path.read_bytes()) for name, path in sorted(files.items())]
    for name, data in entries:
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    for name, expected in manifest.items():
        data = tar.extractfile(name).read()
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
policy = json.loads((root / 'policy.json').read_text())
evidence = {
    'status': 'HELD/unmerged; no unchanged rerun or weaker gates',
    'baseline': policy['baseline'], 'source': '97bfcabe8c1e681ed5ee2c7a83e0be5d4381730d',
    'initial_fincode_gpui': policy['fincode_pin'], 'initial_component': policy['component_pin'],
    'current_fincode_main': 'cbcfba7301739d768def4ef1ed9b647f5cf8b69c',
    'current_fincode_gpui': policy['baseline'], 'current_component': 'df4ef88228bdad00b830a8fdfb286be84d07b5aa',
    'valid_children': 1624, 'workloads': 58, 'qualified': False, 'failures': decision['failures'],
    'observed_primary_cpu_difference_percent': {case: -decision['summary']['bare'][case]['cpu_ns']['change_percent'] for case in policy['primary_cases']},
    'important_gain_not_qualified': 'Streaming CPU/elapsed differences 4.92/4.91% miss both 5% target and full baseline variation. One census rebuild-off-512 native RSS control fails (404KiB increase, 144KiB baseline range).',
    'heap_and_controls': 'All58 requested held/peak/bytes/calls medians exactly identical. All bare CPU/elapsed/whole-child/RSS controls pass; one census RSS field fails. Three other primary CPU/elapsed differences 7.72/9.18/8.17% exceed target and both ranges but do not qualify the complete design.',
    'mechanism': 'Only final replay insertion dispatch changes. Replayed monochrome/subpixel glyphs use existing typed methods after original movement/clipping/transition/shimmer remapping. Other primitives retain original generic insertion.',
    'correctness': 'Full native Scene tests in both lanes, exhaustive typed/generic glyph equivalence, retained-frame oracle16seeds50steps, wheel/dependency/panel/layout/atomic-claim/read/nested contracts and all1624 paired scene/hitbox/owner signatures pass.',
    'not_run': 'Strict owningClippy, PR creation, merge and application adoption not run because performance gates fail.',
    'protocol': 'Four sequential builds before1044alternating bare children, followed by580alternating separate counting children. Exact59externs/Rust1.99/System/runtime/source/binary identities preserved. Attribution clocks disabled in bare samples. No failed cohort repeated.',
    'attribution': '30prior current-main complete200row transcript children identify retained paint53.27-72.71microseconds/draw. First inline-output parser failure retained/reparsed without rerunning its successful native child; resume setup failure before any child retained. Diagnostic counters/fakeplatform are not gain evidence.',
    'coverage_limits': ['Linux fake-platform complete App/Window, not app/physicalGPU/macOS/Windows/shippedallocator gains.', 'Frame timing excludes setup/4warmups and final audits. Counting census includes setup/warmups/finalheldowners.', 'Private consumer build-cache preservation affects workspace capacity only and is not application memory evidence. Exact22091file restoration metadata remains durable outside this performance archive.', 'Independent owned hidden-window GPU, component and coherentFincode adoption changes are preserved.'],
    'policy_sha256': hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest(),
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'archive_bytes': archive.stat().st_size, 'members': len(manifest) + 1,
}
(output / 'evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')
(output / 'README.md').write_text('''# Held direct glyph replay insertion

One1624-child alternating comparison across58complete App/Window workloads
fails its unchanged acceptance gates. Retained scrolling, ticking and redraw
show7.72/9.18/8.17%lowerCPU, but streaming shows4.92%, below the5%goal and full
baseline variation. One census nativeRSS control increases404KiB beyond its
144KiB baseline range. All58requested held/peak/bytes/allocation-call medians
are identical, and all bare CPU/elapsed/whole-child/RSS controls pass.
The complete design remains held; do not repeat it unchanged or weaken gates.

Only final insertion dispatch changes: replayed monochrome/subpixel glyphs use
the existing typed methods after all original movement, clipping, transition
and animation remapping. Every other primitive retains generic insertion.
Both full native Scene suites, typed/generic equivalence, retained-frame oracle,
wheel/dependency/panel/layout/atomic-claim/read/nested contracts and every paired
scene/hitbox/owner signature pass. StrictClippy, PR and adoption were not run.

The archive preserves all1624raw samples, frozen protocol, source/compiler/
runtime/common59extern/binary identities, sequential process-group deadline
receipts and prior30child transcript attribution, including adverse parser
outputs. Every archive member is hash verified. Attribution is separate from
bare timing and requested-memory counting. These are Linux fake-platform
complete-component observations, not app or physicalGPU percentages.

Current main and independently adopted component/Fincode changes are preserved.
Move to a distinct measured design.
''')
(root / 'archive-verification.json').write_text(json.dumps({key: evidence[key] for key in ['archive_sha256', 'archive_bytes', 'members', 'valid_children', 'qualified']}, indent=2) + '\n')
print(json.dumps({key: evidence[key] for key in ['archive_sha256', 'archive_bytes', 'members', 'valid_children', 'qualified']}))
