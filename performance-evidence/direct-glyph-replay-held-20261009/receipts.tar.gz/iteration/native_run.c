#define _GNU_SOURCE
#include <sys/resource.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <errno.h>
static pid_t task_child;
static void stop_child(int signal_number) { (void) signal_number; if (task_child > 0) kill(-task_child, SIGKILL); }
int main(int argc, char **argv) {
    if (argc < 2) return 2;
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    task_child = fork();
    if (task_child < 0) return 3;
    if (task_child == 0) { setpgid(0,0); execvp(argv[1], argv+1); perror("execvp"); _exit(127); }
    setpgid(task_child, task_child);
    signal(SIGALRM, stop_child); signal(SIGTERM, stop_child); signal(SIGINT, stop_child);
    alarm(60);
    int status; struct rusage usage;
    while (wait4(task_child, &status, 0, &usage) < 0) { if (errno != EINTR) return 4; }
    alarm(0); clock_gettime(CLOCK_MONOTONIC, &end);
    long long elapsed = (end.tv_sec-start.tv_sec)*1000000000LL + end.tv_nsec-start.tv_nsec;
    printf("NATIVE_RECEIPT {\"peak_rss_kib\":%ld,\"user_cpu_us\":%lld,\"system_cpu_us\":%lld,\"process_elapsed_ns\":%lld,\"exit_code\":%d}\n", usage.ru_maxrss, usage.ru_utime.tv_sec*1000000LL+usage.ru_utime.tv_usec,usage.ru_stime.tv_sec*1000000LL+usage.ru_stime.tv_usec,elapsed,WIFEXITED(status)?WEXITSTATUS(status):128+WTERMSIG(status));
    return WIFEXITED(status)?WEXITSTATUS(status):128+WTERMSIG(status);
}
