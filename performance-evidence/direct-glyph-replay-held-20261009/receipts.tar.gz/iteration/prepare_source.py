from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path(__file__).parent;original=Path('/workspace/zed-indexed-states');work=Path('/workspace/zed-glyph-replay')
environment=dict(os.environ,GIT_NO_LAZY_FETCH='1');baseline='8ceb46cd79dc910bf709b561727bb42e7e9ae2da'
tree=json.loads(Path('/workspace/scratch/gpui-indexed-state-loop/baseline-tree.json').read_text())
subprocess.run(['git','-C',str(original),'worktree','add','--no-checkout','-b','perf/direct-glyph-replay-20261009',str(work),baseline],check=True,env=environment)
missing=[]
for entry in tree['tree']:
    if entry['type']!='blob':continue
    old=original/entry['path'];new=work/entry['path']
    if not old.exists():missing.append(entry['path']);continue
    new.parent.mkdir(parents=True,exist_ok=True)
    if entry['mode']=='120000':new.symlink_to(os.readlink(old))
    elif entry['path']=='crates/gpui/src/window/view_retention/dependencies.rs':
        new.write_bytes(subprocess.check_output(['git','-C',str(original),'show',baseline+':'+entry['path']],env=environment));os.chmod(new,0o644)
    else:shutil.copy2(old,new)
subprocess.run(['git','-C',str(work),'read-tree','HEAD'],check=True,env=environment)
if missing:subprocess.run(['git','-C',str(work),'update-index','--skip-worktree','--stdin'],input='\n'.join(missing)+'\n',text=True,check=True,env=environment)
assert not subprocess.check_output(['git','-C',str(work),'status','--porcelain'],env=environment,text=True).strip()
assert subprocess.check_output(['git','-C',str(work),'write-tree','--missing-ok'],env=environment,text=True).strip()==tree['sha']
assert (work/'README.md').read_text().startswith('> [!IMPORTANT]\n> Remove this line to confirm')
(root/'baseline-import-receipt.json').write_text(json.dumps({'baseline':baseline,'tree':tree['sha'],'source_clean':True,'held_state_union_removed_before_use':True,'unmaterialized_blob_identities_preserved':len(missing),'worktree':str(work)},indent=2)+'\n')
prior=Path('/workspace/scratch/gpui-indexed-state-loop')
for name in ['build_native.py','supervise.py','native-run','native_run.c','external-dependencies.json']:
    shutil.copy2(prior/name,root/name)
print(json.dumps({'workspace':str(work),'baseline':baseline,'clean':True}))
