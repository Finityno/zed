from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess
root=Path(__file__).parent;source=Path('/workspace/fincode-gpui/target');destination=root/'preserved-consumer-target'
assert not any(not x.split()[0].startswith('Z') and x.split()[1] in ['cargo','rustc','native-run','gpui-ada3fb4d7b1cfe56'] for x in subprocess.check_output(['ps','-eo','stat,comm'],text=True).splitlines()[1:])
before=shutil.disk_usage('/workspace').free
receipts=json.loads((root/'cache-preservation-checkpoint.json').read_text())['files']
for receipt in receipts:
    path=Path(receipt['source'])
    if path.exists():
        assert hashlib.sha256(path.read_bytes()).hexdigest()==receipt['sha256']
        assert hashlib.sha256(gzip.decompress(Path(receipt['archive']).read_bytes())).hexdigest()==receipt['sha256']
        path.unlink()
paths=[p for p in source.rglob('*') if p.is_file() and not p.is_symlink()]
journal=root/'remaining-cache-preservation.jsonl'
assert not journal.exists()
for path in sorted(paths,key=lambda p:p.stat().st_size,reverse=True):
    relative=path.relative_to(source);archive=destination/(str(relative)+'.gz')
    archive.parent.mkdir(parents=True,exist_ok=True);stat=path.stat()
    data=path.read_bytes();source_hash=hashlib.sha256(data).hexdigest()
    with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=1,mtime=0) as stream: stream.write(data)
    restored=gzip.decompress(archive.read_bytes());assert restored==data
    receipt={'source':str(path),'archive':str(archive),'bytes':len(data),'sha256':source_hash,'archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'mode':stat.st_mode,'mtime_ns':stat.st_mtime_ns}
    receipts.append(receipt)
    with journal.open('a') as stream:
        stream.write(json.dumps(receipt)+'\n')
        stream.flush()
    path.unlink()
after=shutil.disk_usage('/workspace').free
(root/'completed-consumer-cache-preservation.json').write_text(json.dumps({'scope':'All own completed inactive consumer target files, exact gzip roundtrip/metadata. Restore original paths/modes/mtime before reuse. No user original target, any common native59externs/DSOs, compiler/runtime, source or raw samples touched. All build/profiling processes inactive.','source':str(source),'files':receipts},indent=2)+'\n')
(root/'cache-capacity-receipt.json').write_text(json.dumps({'before_free':before,'after_free':after,'actual_reclaimed_bytes':after-before,'files':len(receipts),'all_roundtrips_verified':True},indent=2)+'\n')
print(json.dumps({'files':len(receipts),'actual_reclaimed_bytes':after-before,'free_bytes':after}),flush=True)
