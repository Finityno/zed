from pathlib import Path
import json
import subprocess

root = Path(__file__).parent
receipts = []
for kind, deadline in [('bare', 900), ('census', 600)]:
    processes = subprocess.check_output(['ps', '-eo', 'stat,comm'], text=True).splitlines()[1:]
    assert not any(line.split()[0].startswith('Z') is False and line.split()[1] in ['rustc', 'cargo', 'native-run', 'gpui-ada3fb4d7b1cfe56'] for line in processes)
    command = ['python3', str(root / 'supervise.py'), '--seconds', str(deadline), '--name', kind + '-measurement', '--cwd', str(root), '--', 'python3', str(root / 'measure.py'), kind]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    receipt = json.loads((root / (kind + '-measurement-receipt.json')).read_text())
    assert result.returncode == receipt['exit_code'] == 0 and not receipt['timed_out'], result.stdout
    if receipts:
        previous = receipts[-1]
        assert receipt['started_unix'] >= previous['started_unix'] + previous['elapsed_seconds']
    receipts.append(receipt)
    (root / 'valid-cohort-order-receipt.json').write_text(json.dumps({'sequential': True, 'receipts': receipts, 'previous_failed_design_preserved': '/workspace/scratch/gpui-union-state-loop', 'policy_unchanged': True}, indent=2) + '\n')
    print(json.dumps({'phase': kind, 'completed': True, 'exit_code': receipt['exit_code'], 'seconds': receipt['elapsed_seconds']}), flush=True)
