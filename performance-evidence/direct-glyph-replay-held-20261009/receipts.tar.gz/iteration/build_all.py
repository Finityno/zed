from pathlib import Path
import json,subprocess
root=Path(__file__).parent
receipts=[]
for lane in ['baseline','candidate']:
    for kind in ['bare','census']:
        command=['python3',str(root/'supervise.py'),'--seconds','600','--name',lane+'-'+kind+'-supervised','--cwd',str(root),'--','python3',str(root/'build_native.py'),lane,kind]
        result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        receipt=json.loads((root/(lane+'-'+kind+'-supervised-receipt.json')).read_text())
        assert result.returncode==receipt['exit_code']==0 and not receipt['timed_out'],result.stdout
        if receipts: assert receipt['started_unix']>=receipts[-1]['started_unix']+receipts[-1]['elapsed_seconds']
        receipts.append(receipt);(root/'build-order-receipt.json').write_text(json.dumps({'sequential':True,'receipts':receipts},indent=2)+'\n')
        print(json.dumps({'lane':lane,'kind':kind,'completed':True,'seconds':receipt['elapsed_seconds']}),flush=True)
