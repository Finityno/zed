from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path(__file__).parent;source=Path('/workspace/zed-ordinary-glyph');baseline='8ceb46cd79dc910bf709b561727bb42e7e9ae2da';env=dict(os.environ,GIT_NO_LAZY_FETCH='1')
candidate=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],env=env,text=True).strip()
crates=json.loads(Path('/workspace/scratch/gpui-indexed-state-loop/candidate-source-inputs.json').read_text())['crates'];changed_path='crates/gpui/src/scene.rs'
before=subprocess.check_output(['git','-C',str(source),'show',baseline+':'+changed_path],env=env)
anchor=b'\n}\n\n#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Default)]\n'
assert before.count(anchor)==1
before=before.replace(anchor,b'\n'+(root/'replay-regression.rs').read_bytes()+anchor)
for lane in ['baseline','candidate']:
    work=root/(lane+'-workspace');work.mkdir()
    for name in crates:shutil.copytree(source/'crates'/name,work/'crates'/name,symlinks=True)
    for name in ['Cargo.toml','Cargo.lock','AGENTS.md','README.md','rust-toolchain.toml','LICENSE-APACHE','LICENSE-GPL']:shutil.copy2(source/name,work/name)
    shutil.copytree(source/'.cargo',work/'.cargo',symlinks=True)
    for name in ['ibm-plex-sans','lilex']:shutil.copytree(source/'assets/fonts'/name,work/'assets/fonts'/name,symlinks=True)
    if lane=='baseline':(work/changed_path).write_bytes(before)
    (work/'crates/gpui/src/window/view_retention/splice_profile.rs').write_bytes((root/'comparison-fixture.rs').read_bytes())
    (work/'crates/gpui/src/window/view_retention/transcript_profile.rs').write_bytes((root/'transcript-fixture.rs').read_bytes())
    p=work/'crates/gpui/src/window/view_retention/tests.rs';t=p.read_text();assert 'mod transcript_profile;' not in t;p.write_text(t+'\n#[cfg(target_os = "linux")]\n#[path = "transcript_profile.rs"]\nmod transcript_profile;\n')
    files={str(p.relative_to(work)):hashlib.sha256(p.read_bytes()).hexdigest() for p in work.rglob('*') if p.is_file()}
    (root/(lane+'-source-inputs.json')).write_text(json.dumps({'baseline':baseline,'candidate':candidate,'lane':lane,'crates':crates,'files':files,'description':'Current24actualowningcrates/root/lock/config/fonts/licenses. Identical58completeApp/Windowfixtures, bareframeworkclocksdisabled. Only ordinary glyph replay and exact movement-helper extraction differ. New256packed/generic equivalence cases are identical in both lanes.'},indent=2)+'\n')
left=json.loads((root/'baseline-source-inputs.json').read_text())['files'];right=json.loads((root/'candidate-source-inputs.json').read_text())['files'];changed=[p for p in left if left[p]!=right[p]];assert changed==[changed_path]
for name,expected in json.loads((root/'pre-candidate-frozen-method.json').read_text()).items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected
(root/'candidate-source.diff').write_bytes(subprocess.check_output(['git','-C',str(source),'diff',baseline,candidate],env=env))
(root/'comparison-source-receipt.json').write_text(json.dumps({'baseline':baseline,'candidate':candidate,'changed_source':changed,'files_each':len(left),'policy_sha256':hashlib.sha256((root/'policy.json').read_bytes()).hexdigest()},indent=2)+'\n')
shutil.copy2(Path('/workspace/scratch/gpui-indexed-state-loop/build_all.py'),root/'build_all.py')
print(json.dumps({'baseline':baseline,'candidate':candidate,'changed':changed,'files':len(left)}))
