from pathlib import Path
import gzip, hashlib, io, json, tarfile

root = Path(__file__).parent
work = Path('/workspace/zed-ordinary-glyph')
output = work / 'performance-evidence/ordinary-glyph-replay-held-20261009'
output.mkdir(parents=True)
decision = json.loads((root / 'decision.json').read_text())
assert not decision['qualified']
for name, expected in json.loads((root / 'frozen-inputs.json').read_text()).items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected
builds = json.loads((root / 'build-order-receipt.json').read_text())['receipts']
phases = json.loads((root / 'valid-cohort-order-receipt.json').read_text())['receipts']
assert len(phases) == 2
assert phases[0]['started_unix'] >= builds[-1]['started_unix'] + builds[-1]['elapsed_seconds']
assert phases[1]['started_unix'] >= phases[0]['started_unix'] + phases[0]['elapsed_seconds']
for kind, count in [('bare', 1044), ('census', 580)]:
    samples = json.loads((root / (kind + '-samples.json')).read_text())
    assert len(samples) == count
    for sample in samples:
        assert sample['exit_code'] == 0
        assert hashlib.sha256(Path(sample['log']).read_bytes()).hexdigest() == sample['log_sha256']
assert all(value[metric]['change_percent'] == 0 for value in decision['summary']['census'].values() for metric in ['held_bytes', 'peak_bytes', 'requested_bytes', 'allocation_calls'])
files = {}
private = {'current-fincode-open-refresh.json', 'current-zed-open-refresh.json', 'completed-consumer-cache-preservation.json', 'cache-preservation-checkpoint.json', 'remaining-cache-preservation.jsonl'}
for path in root.iterdir():
    if path.is_file() and path.suffix in {'.py', '.json', '.log', '.diff', '.rs', '.c', '.md', '.txt'} and path.name not in private:
        files['iteration/' + path.name] = path
for name in ['bare-receipts', 'census-receipts']:
    for path in (root / name).rglob('*'):
        if path.is_file():
            files['iteration/' + str(path.relative_to(root))] = path
for name in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'LICENSE-APACHE', 'LICENSE-GPL']:
    files['native-root/' + name] = root / 'candidate-workspace' / name
for lane in ['baseline', 'candidate']:
    files[lane + '/scene.rs'] = root / (lane + '-workspace') / 'crates/gpui/src/scene.rs'
diagnostic = Path('/workspace/scratch/gpui-scroll-layer-loop')
for name in ['transcript-attribution-summary.json', 'transcript-attribution-samples.json', 'transcript-attribution.py', 'diagnostic-source-identity.json', 'diagnostic-runtime-identities.json']:
    path = diagnostic / name
    if path.exists():
        files['attribution/' + name] = path
for path in diagnostic.iterdir():
    if path.is_file() and (path.suffix in {'.py', '.json', '.log', '.txt'}) and 'comparison' not in path.name and 'upstream' not in path.name:
        files['attribution/' + path.name] = path
for path in diagnostic.rglob('*.log'):
    if 'comparison' not in str(path.relative_to(diagnostic)) and 'upstream' not in str(path.relative_to(diagnostic)):
        files['attribution/' + str(path.relative_to(diagnostic))] = path
manifest = {name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for name, path in sorted(files.items())}
archive = output / 'receipts.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=6, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
    entries = [('manifest.json', (json.dumps(manifest, indent=2) + '\n').encode())] + [(name, path.read_bytes()) for name, path in sorted(files.items())]
    for name, data in entries:
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    for name, expected in manifest.items():
        data = tar.extractfile(name).read()
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
policy = json.loads((root / 'policy.json').read_text())
evidence = {
    'status': 'HELD/unmerged; no unchanged rerun or weaker gates',
    'baseline': policy['baseline'], 'source': '9f2e5c64ad4d619eb614d98b9d245d84992e9610',
    'initial_fincode_gpui': policy['fincode_pin'], 'initial_component': policy['component_pin'],
    'current_fincode_main': 'cbcfba7301739d768def4ef1ed9b647f5cf8b69c',
    'current_fincode_gpui': policy['baseline'], 'current_component': 'df4ef88228bdad00b830a8fdfb286be84d07b5aa',
    'valid_children': 1624, 'workloads': 58, 'qualified': False, 'failures': decision['failures'],
    'observed_primary_cpu_difference_percent': {case: -decision['summary']['bare'][case]['cpu_ns']['change_percent'] for case in policy['primary_cases']},
    'important_gain_not_qualified': 'Streaming and ticking primary CPU/elapsed regress2.34/5.11%; four gain fields fail. Six normalCPU/elapsed/whole-child controls and five censusRSSfields fail;15failed fields total.',
    'heap_and_controls': 'All58requested held/peak/bytes/calls medians exactly identical. Scrolling/redraw CPU differences10.25/10.19% do not qualify the complete design. CPU/elapsed/whole-child/RSS control failures are retained exactly.',
    'mechanism': 'Ordinary packedglyphs pad0/animation0/rebaseNone bypass genericPrimitive construction. Movement logic extracted exactly from original mono/subpixel branches. Animated/rebased and allother primitives retain original genericreplay. No newfields/cache/allocator orrenderer resources.',
    'correctness': 'Full native Scene tests and new256packed/generic representation oracle in both lanes, exhaustive typed/generic glyph equivalence, retained-frame oracle16seeds50steps, wheel/dependency/panel/layout/atomic-claim/read/nested contracts and all1624 paired scene/hitbox/owner signatures pass.',
    'not_run': 'Strict owningClippy, PR creation, merge and application adoption not run because performance gates fail.',
    'protocol': 'Four sequential builds before1044alternating bare children, followed by580alternating separate counting children. Exact59externs/Rust1.99/System/runtime/source/binary identities preserved. Attribution clocks disabled in bare samples. No failed cohort repeated.',
    'attribution': '30prior current-main complete200row transcript children identify retained paint53.27-72.71microseconds/draw. First inline-output parser failure retained/reparsed without rerunning its successful native child; resume setup failure before any child retained. Diagnostic counters/fakeplatform are not gain evidence.',
    'coverage_limits': ['Linux fake-platform complete App/Window, not app/physicalGPU/macOS/Windows/shippedallocator gains.', 'Frame timing excludes setup/4warmups and final audits. Counting census includes setup/warmups/finalheldowners.', 'Private consumer build-cache preservation affects workspace capacity only and is not application memory evidence. Exact22091file restoration metadata remains durable outside this performance archive.', 'Independent owned hidden-window GPU, component and coherentFincode adoption changes are preserved.'],
    'policy_sha256': hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest(),
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'archive_bytes': archive.stat().st_size, 'members': len(manifest) + 1,
}
(output / 'evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')
(output / 'README.md').write_text("""# Held ordinary typed glyph replay

One1624-child alternating comparison across58complete App/Window workloads
fails15frozen acceptance fields. Scrolling/redraw CPU differences10.25/10.19%
do not qualify the design: streaming and ticking regress2.34/5.11%; four gain,
six normalCPU/elapsed/whole-child and five censusRSS fields fail. All58requested
held/peak/bytes/allocation-call medians remain identical. Do not rerun this
design unchanged or weaken its gates.

Ordinary packed glyphs bypass genericPrimitive construction only with zero
transition and animation and no rebase. Exact movement of bounds, masks, effect
origins and transformation matrices is shared with original generic replay;
animated/rebased glyphs and other primitives use the original path. A256case
packed-versus-generic representation oracle covers clipping, whole moves,
nonidentity transforms, transitions, landed transitions, shimmers and rebasing
in both lanes. Full native Scene and retainedframe/wheel/dependency/panel/layout/
atomic-claim/read/nested contracts and every paired scene/hitbox/owner pass.
StrictClippy, PR creation, merge and app adoption were not run.

Every1624raw sample, frozen gate, exact source/compiler/runtime/common59extern/
binary identity and sequential process-group receipt is archived and member
hash verified. The earlier30current-main transcript attribution and adverse
parser outputs are preserved. These are Linux fake-platform complete-component
observations, not app/physicalGPU/macOS/Windows/shippedallocator gains.
Current independent owned changes are preserved. Move to a different owner.
""")
(root / 'archive-verification.json').write_text(json.dumps({key: evidence[key] for key in ['archive_sha256', 'archive_bytes', 'members', 'valid_children', 'qualified']}, indent=2) + '\n')
print(json.dumps({key: evidence[key] for key in ['archive_sha256', 'archive_bytes', 'members', 'valid_children', 'qualified']}))
