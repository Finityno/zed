from pathlib import Path
import hashlib, json, os, shutil, subprocess, time

root = Path(__file__).parent
workspace = Path('/workspace/zed-renderer-cache-qualification')
original = Path('/workspace/scratch/gpui-splice-state-loop/baseline-workspace/target/debug')
captured = json.loads(Path('/workspace/scratch/gpui-splice-state-loop/baseline-rustc-command.json').read_text())
assert not (root / 'native-build-plan.json').exists()

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

for font in ['lilex/Lilex-Regular.ttf', 'lilex/Lilex-Bold.ttf', 'ibm-plex-sans/IBMPlexSans-Regular.ttf']:
    destination = workspace / 'assets/fonts' / font
    destination.parent.mkdir(parents=True, exist_ok=True)
    content = subprocess.check_output(['git', '-C', str(workspace), 'show', 'HEAD:assets/fonts/' + font], env={**os.environ, 'GIT_NO_LAZY_FETCH': '1'})
    destination.write_bytes(content)

fingerprints = {}
for directory in (original / '.fingerprint').iterdir():
    if not directory.is_dir():
        continue
    for fingerprint in directory.glob('lib-*'):
        if fingerprint.suffix:
            continue
        value = fingerprint.read_text()
        if len(value) != 16:
            continue
        crate_name = fingerprint.name[4:].replace('-', '_')
        crate_hash = directory.name.rsplit('-', 1)[1]
        artifact = original / 'deps' / ('lib' + crate_name + '-' + crate_hash + '.rlib')
        if not artifact.exists():
            artifact = artifact.with_suffix('.so')
        if artifact.exists():
            fingerprints.setdefault((crate_name, int.from_bytes(bytes.fromhex(value), 'little')), []).append(artifact)

def dependencies(name):
    specification = json.loads((original / '.fingerprint' / name / ('lib-' + name.rsplit('-', 1)[0].replace('-', '_') + '.json')).read_text())
    result = {}
    for _, crate_name, _, crate_hash in specification['deps']:
        if crate_name == 'build_script_build':
            continue
        artifact_name = 'zed_font_kit' if crate_name == 'font_kit' else crate_name
        candidates = fingerprints[(artifact_name, crate_hash)]
        assert len(candidates) == 1, (crate_name, candidates)
        result[crate_name] = str(candidates[0])
    return result, specification

gpui_dependencies, gpui_fingerprint = dependencies('gpui-3328bd54c9e30b17')
wgpu_dependencies, wgpu_fingerprint = dependencies('gpui_wgpu-a02335205646be54')
assert 'gpui_platform' not in gpui_dependencies
output = root / 'native'
output.mkdir()
compiler = captured['args'][0]
common = [compiler, '--edition=2024', '--error-format=short', '-C', 'opt-level=3', '-C', 'embed-bitcode=no', '-C', 'codegen-units=16', '-C', 'debug-assertions=on', '-C', 'symbol-mangling-version=v0', '--cfg', 'tokio_unstable', '-L', 'dependency=' + str(original / 'deps'), '-L', 'dependency=' + str(output), '-L', 'native=/workspace/.fincode-tools/native/usr/lib/x86_64-linux-gnu']
for index, value in enumerate(captured['args']):
    if value == '-L' and captured['args'][index + 1].startswith('native=') and captured['args'][index + 1] not in common:
        common += ['-L', captured['args'][index + 1]]
gpui_command = common + ['--crate-name', 'gpui', 'crates/gpui/src/gpui.rs', '--crate-type=rlib', '--emit=dep-info,metadata,link', '--out-dir', str(output), '-C', 'metadata=renderer_current_08d5555', '-C', 'extra-filename=-renderer08d5555']
for feature in json.loads(gpui_fingerprint['features']):
    gpui_command += ['--cfg', 'feature="' + feature + '"']
for name, artifact in sorted(gpui_dependencies.items()):
    gpui_command += ['--extern', name + '=' + artifact]

wgpu_dependencies['gpui'] = str(output / 'libgpui-renderer08d5555.rlib')
wgpu_dependencies['image'] = gpui_dependencies['image']
wgpu_dependencies['naga'] = str(original / 'deps/libnaga-73ac99a5ca640bc8.rlib')
wgpu_command = common + ['--crate-name', 'gpui_wgpu', 'crates/gpui_wgpu/src/gpui_wgpu.rs', '--test', '--emit=dep-info,link', '--out-dir', str(output), '-C', 'metadata=renderer_tests_08d5555', '-C', 'extra-filename=-renderer08d5555']
for feature in json.loads(wgpu_fingerprint['features']):
    wgpu_command += ['--cfg', 'feature="' + feature + '"']
for name, artifact in sorted(wgpu_dependencies.items()):
    wgpu_command += ['--extern', name + '=' + artifact]

environment = {**captured['environment'], 'CARGO_MANIFEST_DIR': str(workspace / 'crates/gpui'), 'CARGO_MANIFEST_PATH': str(workspace / 'crates/gpui/Cargo.toml')}
sources = {}
for parent in [workspace / 'crates/gpui', workspace / 'crates/gpui_wgpu', workspace / 'assets/fonts']:
    for path in parent.rglob('*'):
        if path.is_file():
            sources[str(path.relative_to(workspace))] = digest(path)
runtime = {}
for path in ['/workspace/.fincode-tools/native/usr/share/vulkan/icd.d/lvp_icd.json', '/workspace/.fincode-tools/native/usr/lib/x86_64-linux-gnu/libvulkan_lvp.so', '/workspace/.fincode-tools/native/usr/lib/x86_64-linux-gnu/libvulkan.so.1.4.309']:
    runtime[path] = digest(path)
artifacts = {path: digest(path) for path in sorted(set(gpui_dependencies.values()) | (set(wgpu_dependencies.values()) - {wgpu_dependencies['gpui']}))}
plan = {'workspace': str(workspace), 'source': subprocess.check_output(['git', '-C', str(workspace), 'rev-parse', 'HEAD'], text=True).strip(), 'commands': {'gpui': gpui_command, 'gpui_wgpu': wgpu_command}, 'environment': environment, 'sources': sources, 'immutable_external_objects': artifacts, 'compiler_path': compiler, 'compiler_sha256': digest(compiler), 'runtime': runtime, 'gpui_fingerprint': gpui_fingerprint, 'wgpu_fingerprint': wgpu_fingerprint, 'limits': ['Current-source GPUI production library rebuilt without dev-dependency gpui_platform; current WGPU tests link only this new GPUI', 'No bench-support/test-support semantic features: cfg(test) enables actual WGPU headless tests; no whole-App headless endpoint yet', 'Original immutable native dependency objects retained and read only; renderer tests add original image/naga objects; no new registry resolution'], 'prepared_unix': time.time()}
(root / 'native-build-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
shutil.copy2(Path('/workspace/scratch/gpui-bounded-glyph-replay-loop/comparison/supervise.py'), root / 'supervise.py')
print({'production_gpui_dependencies': len(gpui_dependencies), 'wgpu_test_dependencies': len(wgpu_dependencies), 'source_files': len(sources), 'immutable_objects': len(artifacts)})
