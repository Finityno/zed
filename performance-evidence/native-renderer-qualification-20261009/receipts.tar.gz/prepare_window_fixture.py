from pathlib import Path
import json, hashlib

root = Path(__file__).parent
workspace = Path('/workspace/zed-renderer-cache-qualification')
source = workspace / 'crates/gpui_wgpu/src/wgpu_renderer.rs'
original = source.read_text()
assert 'owned_renderer_fixture' not in original
benchmark = (workspace / 'crates/gpui_wgpu/benches/transcript_frame.rs').read_text()
imports = benchmark[benchmark.index('use gpui::{'):benchmark.index('struct CountingAllocator;')]
model = benchmark[benchmark.index('const LILEX:'):benchmark.index('struct Sample {')]
fixture = imports + '\nuse crate::CosmicTextSystem;\n' + model + (root / 'complete_window_fixture_tail.rs').read_text()
(root / 'complete_window_fixture.rs').write_text(fixture)
source.write_text(original + '\n#[cfg(all(test, owned_renderer_fixture))]\nmod owned_renderer_fixture {\n    include!("/workspace/scratch/gpui-renderer-cache-loop/complete_window_fixture.rs");\n}\n')
plan = json.loads((root / 'native-headless-build-plan.json').read_text())
command = plan['commands']['gpui_wgpu-headless']
command += ['--cfg', 'owned_renderer_fixture']
command[command.index('metadata=renderer_tests_08d5555')] = 'metadata=renderer_window_fixture_08d5555'
command[command.index('extra-filename=-renderer08d5555')] = 'extra-filename=-window-bare08d5555'
plan['commands'] = {'gpui_wgpu-window-bare': command}
plan['sources']['crates/gpui_wgpu/src/wgpu_renderer.rs'] = hashlib.sha256(source.read_bytes()).hexdigest()
plan['sources']['private-fixture'] = hashlib.sha256(fixture.encode()).hexdigest()
plan['limits'].append('Private diagnostic observer is insertion only. Original production renderer bytes and current GPUI library remain unchanged. It measures actual queue completion, not submit-only wall time; foreground and whole-process CPU both retained. Census includes all Rust threads/setup, excludes Mesa native C allocations covered by RSS.')
(root / 'native-window-bare-build-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
(root / 'native-headless-build-plan.json').rename(root / 'native-headless-core-build-plan.json')
(root / 'native-headless-build-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
print({'private_fixture_bytes': len(fixture.encode()), 'production_bytes_unchanged': source.read_text().startswith(original)})
