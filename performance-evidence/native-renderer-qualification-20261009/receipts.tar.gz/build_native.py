from pathlib import Path
import hashlib, json, os, subprocess, time

root = Path(__file__).parent
plan = json.loads((root / 'native-headless-build-plan.json').read_text())
for name, command in plan['commands'].items():
    environment = {**os.environ, **plan['environment']}
    if name.startswith('gpui_wgpu'):
        environment.update({'CARGO_MANIFEST_DIR': plan['workspace'] + '/crates/gpui_wgpu', 'CARGO_MANIFEST_PATH': plan['workspace'] + '/crates/gpui_wgpu/Cargo.toml', 'CARGO_PKG_NAME': 'gpui_wgpu', 'CARGO_PKG_VERSION': '0.1.0', 'CARGO_PKG_VERSION_MINOR': '1', 'CARGO_PKG_VERSION_PATCH': '0'})
    receipt_path = root / (name + '-build-receipt.json')
    assert not receipt_path.exists()
    start = time.time()
    with (root / (name + '-build.log')).open('xb') as log:
        result = subprocess.run(command, cwd=plan['workspace'], env=environment, stdout=log, stderr=subprocess.STDOUT)
    receipt = {'command': command, 'environment': environment, 'exit_code': result.returncode, 'started_unix': start, 'ended_unix': time.time()}
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    print({'stage': name, 'exit_code': result.returncode, 'elapsed': receipt['ended_unix'] - start}, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
print({'artifacts': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (root / 'native').glob('*') if p.is_file()}}, flush=True)
