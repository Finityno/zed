from pathlib import Path
import gzip, hashlib, json, os, shutil, subprocess, tarfile, time

root = Path(__file__).parent
workspace = Path('/workspace/zed-renderer-cache-qualification')
identity = json.loads((root / 'frozen-identities.json').read_text())
for name, expected in identity['externs'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == expected
preserved = []
for name in ['gpui_wgpu-renderer08d5555', 'gpui_wgpu-window-bare08d5555', 'gpui_wgpu-window-final-bare08d5555', 'gpui_wgpu-window-final-census08d5555', 'libgpui-window08d5555.rmeta']:
    path = root / 'native' / name
    stat = path.stat()
    expected = hashlib.sha256(path.read_bytes()).hexdigest()
    compressed = path.with_suffix(path.suffix + '.gz')
    with path.open('rb') as source, compressed.open('xb') as target:
        with gzip.GzipFile(fileobj=target, mode='wb', compresslevel=1, mtime=0) as output:
            shutil.copyfileobj(source, output)
    with gzip.open(compressed, 'rb') as source:
        assert hashlib.sha256(source.read()).hexdigest() == expected
    os.chmod(compressed, stat.st_mode & 0o7777)
    os.utime(compressed, ns=(stat.st_atime_ns, stat.st_mtime_ns))
    preserved.append({'original': str(path), 'preserved': str(compressed), 'sha256': expected, 'bytes': stat.st_size, 'compressed_bytes': compressed.stat().st_size, 'mode': stat.st_mode & 0o7777, 'mtime_ns': stat.st_mtime_ns, 'roundtrip_verified': True})
    path.unlink()
for name, expected in identity['externs'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == expected
(root / 'completed-native-preservation.json').write_text(json.dumps({'records': preserved, 'all_original_immutable_external_objects_before_after_verified': len(identity['externs']), 'no_build_or_profiling_active': True}, indent=2) + '\n')
for name in ['LICENSE-APACHE', 'LICENSE-GPL', '.rules', 'README.md', 'Cargo.lock', 'assets/fonts/lilex/OFL.txt', 'assets/fonts/ibm-plex-sans/license.txt']:
    destination = root / 'source-snapshot' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    content = subprocess.check_output(['git', '-C', str(workspace), 'show', 'HEAD:' + name], env={**os.environ, 'GIT_NO_LAZY_FETCH': '1'})
    destination.write_bytes(content)
readme = '''# Native renderer qualification and complete-frame attribution

This is a diagnostic foundation, not an optimized source or a merge qualification.
The owned rendering source is `08d5555709d7afab3936c7afcd9f7f0ff9ecbd65`.
Fincode was frozen at `3d7e2953ff58befa0859c8a2e67f0a84682735f2`, with coherent
three rendering pins at that revision and component `ab07cd7695af1dfd9f1c6ad06a77660d288e568d`.
The final refresh at `fb05508b59112510814e9f3d507677eaed6d0b59` preserves those pins.

All 54 existing native WGPU checks pass. 144 bare and 96 counting-System children
cover complete shaped transcript Windows: streaming, scrolling, unchanged redraws,
resizes, two active windows and an inactive sibling, with retention and grayscale/
subpixel modes on/off and a matched renderer-free control. Actual Vulkan CPU adapter,
dual-source blending, every active frame submission, zero inactive-sibling submissions,
retention on/off pixel equality, and complete renderer logical-owner release pass.
The GPU wait is included; readback/checksums are outside timed frames.

Retained scrolling medians on software Vulkan are 7.91–8.15 ms completed wall time,
0.77–0.79 ms foreground CPU and 15.76–16.35 ms process CPU per frame. Foreground
encoding/submit uses 0.26–0.31 ms. Full ranges are retained, including large variance
in grayscale and streaming; these numbers do not qualify an optimization.

Tracked resident renderer bytes for one 1600x2000-device-pixel window include
6,400,000 depth bytes, 2,097,152 instance-buffer bytes, 1,048,576 grayscale or
4,194,304 subpixel-atlas bytes, plus 12,800,000 bytes in the headless readback target.
No cache exists yet. A future cache must declare and enforce its own bounded budget
and measure requested Rust heap, renderer bytes, native RSS and reclamation together.
Zero renderer gauges do not establish that process RSS returned to the OS.

Limits: LLVMPipe Mesa25.0.7/LLVM19.1.7 with two software driver workers, Linux,
System allocator, headless offscreen output. This is not a physical GPU, macOS,
Windows, native presentation, shipped allocator or application percentage. Headless
windows have independent devices; production may share a context. Rust census
includes all Rust threads/setup/warmup and the declared diagnostic sample Vec;
Mesa C requests/library mappings and allocator retention remain unattributed by it.
Native RSS and adverse post-drop resident values are preserved. No malloc_trim.

The unchanged production source is rebuilt coherently. Only isolated private
observers are appended under a non-shipping cfg; the original production prefixes
and all 63 immutable external objects, compiler, runtime, tools and binaries were
verified. Initial dependency-alias, required-feature, harness-import/DPI and host-
guard setup faults are retained; they occurred before the first frozen child.
No first diagnostic child was repeated. Bare timing and census phases are sequential
and no builds, hashing/compression or other profiling overlap them.

The archive contains every first child and receipt, frozen policy and identities,
all setup/adverse results, source snapshot, raw per-frame samples, pixel contracts,
variation and coverage limits. Large native binaries are preserved locally with
round-trip identities, not copied into this source evidence archive.

Next: qualify bounded opaque tile compositing against actual directly rendered pixels,
including grayscale/subpixel, clipping and integer/fractional moves, and renderer/RSS/
requested-memory release, before defining a production scroll-cache candidate.
No PR, production merge, application adoption or performance gain is implied.
'''
(root / 'README.md').write_text(readme)
archive = root / 'receipts.tar.gz'
files = [path for path in root.rglob('*') if path.is_file() and 'native' not in path.relative_to(root).parts and path.name != 'receipts.tar.gz' and '__pycache__' not in path.relative_to(root).parts and path != root / 'archive-verification.json']
members = []
with tarfile.open(archive, 'w:gz', compresslevel=1, dereference=True) as output:
    for path in sorted(files):
        name = str(path.relative_to(root)); stat = path.stat()
        members.append({'path': name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': stat.st_size, 'mode': stat.st_mode & 0o7777, 'mtime': stat.st_mtime})
        output.add(path, arcname=name)
with tarfile.open(archive, 'r:gz') as packed:
    for member in members:
        info = packed.getmember(member['path'])
        assert hashlib.sha256(packed.extractfile(info).read()).hexdigest() == member['sha256']
        assert info.size == member['bytes'] and info.mode == member['mode'] and info.mtime == member['mtime']
verification = {'archive': str(archive), 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'bytes': archive.stat().st_size, 'members': len(members), 'all_bytes_sizes_modes_mtimes_roundtrip_verified': True, 'member_records': members, 'completed_unix': time.time()}
(root / 'archive-verification.json').write_text(json.dumps(verification, indent=2) + '\n')
evidence = workspace / 'performance-evidence/native-renderer-qualification-20261009'
evidence.mkdir(parents=True)
for name in ['README.md', 'diagnostic-policy.json', 'diagnostic-policy.sha256', 'frozen-identities.json', 'diagnostic-summary.json', 'pixel-contracts.json', 'archive-verification.json', 'receipts.tar.gz']:
    shutil.copy2(root / name, evidence / name)
for name in ['crates/gpui/src/window.rs', 'crates/gpui_wgpu/src/wgpu_renderer.rs']:
    original = subprocess.check_output(['git', '-C', str(workspace), 'show', 'HEAD:' + name], env={**os.environ, 'GIT_NO_LAZY_FETCH': '1'})
    assert (workspace / name).read_bytes().startswith(original)
    (workspace / name).write_bytes(original)
print({'archive_sha256': verification['sha256'], 'archive_bytes': verification['bytes'], 'members': len(members), 'completed_own_native_reclaimed': sum(row['bytes'] - row['compressed_bytes'] for row in preserved), 'only_own_private_observers_restored_after_preserved_snapshot': True})
