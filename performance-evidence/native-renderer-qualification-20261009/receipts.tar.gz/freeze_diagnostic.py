from pathlib import Path
import hashlib, json, os, subprocess, time

root = Path(__file__).parent
plan = json.loads((root / 'native-window-frozen-build-plan.json').read_text())
assert not (root / 'diagnostic-policy.json').exists()
policy = {'kind': 'New current-owned complete-component attribution, not optimization qualification', 'source': plan['source'], 'workspace': plan['workspace'], 'fincode_source': '3d7e2953ff58befa0859c8a2e67f0a84682735f2', 'gpui_pins': ['08d5555709d7afab3936c7afcd9f7f0ff9ecbd65'] * 3, 'component_pin': 'ab07cd7695af1dfd9f1c6ad06a77660d288e568d', 'cases': ['stream', 'scroll', 'redraw', 'resize', 'multi', 'background'], 'retained': [False, True], 'subpixel': [False, True], 'phases': {'bare': {'repetitions': 3, 'frames': 48, 'children': 144}, 'census': {'repetitions': 2, 'frames': 32, 'children': 96}}, 'runtime_environment': {'VK_DRIVER_FILES': '/workspace/.fincode-tools/native/usr/share/vulkan/icd.d/lvp_icd.json', 'XDG_RUNTIME_DIR': str(root / 'runtime'), 'MESA_SHADER_CACHE_DISABLE': 'true', 'LP_NUM_THREADS': '2'}, 'declared_contracts': ['54 existing native WGPU correctness checks pass', 'Actual software CPU adapter, Vulkan backend and dual-source blending verified', 'Complete native draw+queue completion and whole-process/foreground CPU recorded; readback checksums outside timed frames', 'Grayscale/subpixel actual glyphs nonzero and each active frame submitted, inactive sibling submits none', 'Initial/final pixel hashes match retained on/off and repetitions within glyph mode; resize final readback intentionally omitted', 'All logical renderer gauges return to original after App/renderer drop', 'CPU statistics only from bare lanes; census CPU diagnostic only; no per-child hashing or compression', 'All first diagnostic samples retained, no optimization gain claimed; acceptance gates for future candidate must be frozen separately'], 'requested_heap_scope': 'Process-global counting System, all Rust threads, startup/warmup included in absolute live/peak. Measured delta includes a pre-sized 16-byte-per-frame diagnostic sample Vec allocated after warmed snapshot. Native Mesa C requests excluded; process RSS retained. No malloc_trim.', 'limits': plan['limits'] + ['LLVMPipe software Vulkan Mesa25.0.7 LLVM19.1.7 fixed two driver workers, default test display scale2 at800x1000 logical /1600x2000 device', 'Matched renderer-free control is not identical atlas/raster allocation behavior and is not a whole-app baseline; wrapped rendering/submit and wait attributed separately', 'No physical GPU/presentation, actual shipped app, macOS/Windows or shipped allocator claim', 'No frozen improvement target here: diagnostic foundation and owner attribution only; do not merge an optimization using it alone'], 'frozen_unix': time.time()}
policy_bytes = (json.dumps(policy, indent=2) + '\n').encode()
(root / 'diagnostic-policy.json').write_bytes(policy_bytes)
(root / 'diagnostic-policy.sha256').write_text(hashlib.sha256(policy_bytes).hexdigest() + '\n')
identities = {'compiler': plan['compiler_path'], 'compiler_sha256': plan['compiler_sha256'], 'externs': plan['immutable_external_objects'], 'source_files': plan['sources'], 'runtime': plan['runtime'], 'binaries': {}, 'tools': {}, 'frozen_source_production_prefix_checks': {}}
for name in ['gpui_wgpu-window-final-bare08d5555', 'gpui_wgpu-window-final-census08d5555', 'libgpui-window08d5555.rlib']:
    path = root / 'native' / name
    identities['binaries'][str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
for name in ['complete_window_fixture.rs', 'diagnostic_measure.py', 'supervise.py', 'diagnostic-policy.json']:
    path = root / name
    identities['tools'][str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
for name in ['crates/gpui/src/window.rs', 'crates/gpui_wgpu/src/wgpu_renderer.rs']:
    original = subprocess.check_output(['git', '-C', plan['workspace'], 'show', 'HEAD:' + name], env={**os.environ, 'GIT_NO_LAZY_FETCH': '1'})
    path = Path(plan['workspace']) / name
    assert path.read_bytes().startswith(original)
    identities['frozen_source_production_prefix_checks'][name] = {'unchanged_original_bytes': len(original), 'original_sha256': hashlib.sha256(original).hexdigest(), 'observer_appended_bytes': path.stat().st_size - len(original), 'original_production_prefix_byte_identical': True}
for path, expected in identities['externs'].items():
    assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected, path
assert hashlib.sha256(Path(plan['compiler_path']).read_bytes()).hexdigest() == plan['compiler_sha256']
runtime_paths = set()
for target in [root / 'native/gpui_wgpu-window-final-bare08d5555', Path('/workspace/.fincode-tools/native/usr/lib/x86_64-linux-gnu/libvulkan_lvp.so')]:
    output = subprocess.check_output(['ldd', str(target)], text=True)
    (root / ('ldd-' + target.name + '.log')).write_text(output)
    for line in output.splitlines():
        fields = line.split()
        for field in fields:
            if field.startswith('/') and Path(field).is_file():
                runtime_paths.add(field)
for path in sorted(runtime_paths):
    identities['runtime'][path] = hashlib.sha256(Path(path).read_bytes()).hexdigest()
(root / 'frozen-identities.json').write_text(json.dumps(identities, indent=2) + '\n')
print({'diagnostic_bare_children': 144, 'census_children': 96, 'original_production_bytes_unchanged': True, 'immutable_objects': len(identities['externs']), 'policy_sha256': hashlib.sha256(policy_bytes).hexdigest()})
