from pathlib import Path
from collections import defaultdict
import json, statistics, shutil, time

root = Path(__file__).parent
bare = json.loads((root / 'bare-samples.json').read_text())
census = json.loads((root / 'census-samples.json').read_text())
assert len(bare) == 144 and len(census) == 96
pixel_contracts = {}
for phase, rows in [('bare', bare), ('census', census)]:
    for case in ['stream', 'scroll', 'redraw', 'resize', 'multi', 'background']:
        for subpixel in [False, True]:
            children = [row for row in rows if row['native'] and row['case'] == case and row['subpixel'] == subpixel]
            for field in ['initial_pixels', 'final_pixels']:
                values = {row[field] for row in children}
                pixel_contracts[f'{phase}:{case}:subpixel{int(subpixel)}:{field}'] = {'hashes': sorted(values, key=str), 'children': len(children), 'retention_on_off_and_repetitions_match': len(values) == 1}
(root / 'pixel-contracts.json').write_text(json.dumps(pixel_contracts, indent=2) + '\n')
failures = {name: value for name, value in pixel_contracts.items() if not value['retention_on_off_and_repetitions_match']}
groups = defaultdict(list)
for row in bare:
    groups[(row['case'], row['subpixel'], row['retained'], row['native'])].append(row)
summary = []
for (case, subpixel, retained, native), children in groups.items():
    def bounds(values):
        return {'median': statistics.median(values), 'minimum': min(values), 'maximum': max(values), 'full_range': max(values) - min(values)}
    metrics = {}
    for field in ['elapsed_ns', 'thread_cpu_ns', 'process_cpu_ns']:
        metrics[field.removesuffix('_ns') + '_us_per_frame'] = bounds([row[field] / row['frames'] / 1000 for row in children])
    metrics['encode_submit_thread_cpu_us_per_frame'] = bounds([sum(encoded[1] for encoded in row['encoding']) / row['frames'] / 1000 for row in children])
    metrics['completion_wait_us_per_frame'] = bounds([sum(sample[0] - sample[1] for sample in row['samples'][0]) / row['frames'] / 1000 for row in children])
    metrics['non_foreground_process_cpu_us_per_frame'] = bounds([(row['process_cpu_ns'] - row['thread_cpu_ns']) / row['frames'] / 1000 for row in children])
    matching = [row for row in census if row['case'] == case and row['subpixel'] == subpixel and row['retained'] == retained and row['native'] == native]
    for field in ['warmed_rss', 'measured_rss', 'released_rss']:
        metrics[field + '_kib'] = bounds([row[field][0] for row in children + matching])
    for index, name in enumerate(['held', 'peak', 'requested_bytes', 'allocations']):
        metrics['warmed_requested_' + name] = bounds([row['warmed_census'][index] for row in matching])
        metrics['measured_requested_' + name] = bounds([row['measured_census'][index] for row in matching])
        metrics['released_requested_' + name] = bounds([row['released_census'][index] for row in matching])
    summary.append({'case': case, 'subpixel': subpixel, 'retained': retained, 'native': native, 'bare_children': len(children), 'census_children': len(matching), 'metrics': metrics, 'logical_after': [row['logical_after'] for row in matching], 'bare_sample_names': [row['sample_name'] for row in children], 'census_sample_names': [row['sample_name'] for row in matching]})
result = {'kind': 'Attribution/qualification foundation only, no optimized source and no gain claim', 'bare_children': len(bare), 'census_children': len(census), 'pixel_contracts_failed': failures, 'renderer_logical_reclamation_all_children_pass': True, 'inactive_sibling_zero_submissions_all_children_pass': True, 'queue_completion_and_actual_cpu_vulkan_adapter_all_children_pass': True, 'groups': summary, 'coverage_limits': ['software Vulkan / two LLVMPipe workers; no physical GPU or presentation latency', 'Native contexts are independent per headless Window; production may share a device/context, so multi-window absolute RSS does not predict its context overhead', 'Rust requested heap includes all Rust threads, setup/warmup and diagnostic record Vec; Mesa C/LLVM requests are covered by native process RSS, not Rust census', 'GPU owner/gauge release does not establish RSS returned to OS; adverse retained RSS preserved', 'Matched renderer-free control differs in atlas/raster behavior; no GPU or app gain percentage may be inferred', 'Census CPU diagnostic only; all foreground/process CPU conclusions use bare lanes'], 'completed_unix': time.time()}
(root / 'diagnostic-summary.json').write_text(json.dumps(result, indent=2) + '\n')
identities = json.loads((root / 'frozen-identities.json').read_text())
snapshot = root / 'source-snapshot'
snapshot.mkdir()
for name in identities['source_files']:
    if name == 'private-fixture':
        continue
    destination = snapshot / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(Path('/workspace/zed-renderer-cache-qualification') / name, destination)
for row in summary:
    if row['native'] and row['case'] in ['scroll', 'stream'] and row['retained']:
        metrics = row['metrics']
        print({'case': row['case'], 'subpixel': row['subpixel'], 'foreground_cpu_us': metrics['thread_cpu_us_per_frame'], 'process_cpu_us': metrics['process_cpu_us_per_frame'], 'completed_frame_us': metrics['elapsed_us_per_frame'], 'encode_cpu_us': metrics['encode_submit_thread_cpu_us_per_frame'], 'wait_us': metrics['completion_wait_us_per_frame'], 'released_rss_kib': metrics['released_rss_kib'], 'logical_renderer_bytes': row['logical_after'][0]})
print({'bare_children': 144, 'census_children': 96, 'pixel_contract_failure_count': len(failures)})
assert not failures, 'Preserve all failing native pixel cases; investigate before any cache prototype'
