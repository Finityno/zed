from pathlib import Path
import argparse, json, os, subprocess, time

root = Path(__file__).parent
parser = argparse.ArgumentParser()
parser.add_argument('phase', choices=['bare', 'census'])
arguments = parser.parse_args()
policy = json.loads((root / 'diagnostic-policy.json').read_text())
phase = arguments.phase
repetitions = policy['phases'][phase]['repetitions']
frames = policy['phases'][phase]['frames']
binary = root / ('native/gpui_wgpu-window-final-' + phase + '08d5555')
receipts = root / (phase + '-children')
receipts.mkdir(exist_ok=True)
assert not list(receipts.iterdir()), 'Preserve first diagnostic children; never repeat a phase unchanged'

def host_guard():
    snapshot = subprocess.check_output(['ps', '-eo', 'pid,stat,comm,args'], text=True)
    for line in snapshot.splitlines()[1:]:
        values = line.split(None, 3)
        if len(values) != 4 or values[1].startswith('Z') or int(values[0]) in {os.getpid(), os.getppid()}:
            continue
        assert values[2] not in {'cargo', 'rustc', 'cc', 'gcc', 'clang', 'gzip', 'pigz', 'zstd', 'sha256sum', 'b3sum', 'perf', 'hyperfine'}, line
        assert not values[2].startswith(('gpui-', 'gpui_wgpu-')), line
        if values[2].startswith('python'):
            assert not any(part in values[3] for part in ['build_native.py', 'preserve_inactive_cache.py', 'package_held.py', 'measure.py', 'measure_diagnostic.py']), line
    return snapshot

samples = []
for repetition in range(repetitions):
    for case in policy['cases']:
        for subpixel in policy['subpixel']:
            for retained in policy['retained']:
                for native in ([False, True] if repetition % 2 == 0 else [True, False]):
                    name = f'{len(samples):04d}-{case}-subpixel{int(subpixel)}-retained{int(retained)}-native{int(native)}'
                    before = host_guard()
                    environment = {**os.environ, **policy['runtime_environment'], 'OWNED_RENDERER': 'native' if native else 'none', 'OWNED_SUBPIXEL': str(int(subpixel)), 'OWNED_RETAINED': str(int(retained)), 'OWNED_CASE': case, 'OWNED_FRAMES': str(frames)}
                    command = [str(binary), '--ignored', '--exact', 'wgpu_renderer::owned_renderer_fixture::owned_complete_transcript_renderer_diagnostic', '--test-threads=1', '--nocapture']
                    start = time.time()
                    with (receipts / (name + '.log')).open('xb') as output:
                        result = subprocess.run(command, env=environment, cwd=policy['workspace'], stdout=output, stderr=subprocess.STDOUT, timeout=45)
                    end = time.time()
                    after = host_guard()
                    receipt = {'name': name, 'phase': phase, 'repetition': repetition, 'case': case, 'subpixel': subpixel, 'retained': retained, 'native': native, 'frames': frames, 'command': command, 'environment': environment, 'started_unix': start, 'ended_unix': end, 'exit_code': result.returncode, 'host_before': before, 'host_after': after}
                    (receipts / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
                    assert result.returncode == 0, receipt
                    output = (receipts / (name + '.log')).read_text()
                    row = json.loads(output.split('OWNED_RENDERER_DIAGNOSTIC ', 1)[1].split('\n', 1)[0])
                    assert row['case'] == case and row['native'] == native and row['retained'] == retained and row['subpixel'] == subpixel
                    assert row['frames'] == frames
                    assert row['initial_device_size'] == [1600, 2000]
                    assert row['allocator'] == ('bare System' if phase == 'bare' else 'process-global counting System')
                    assert len(row['samples'][0]) == frames
                    if native:
                        assert len(row['encoding']) == row['windows']
                        for index, encoding in enumerate(row['encoding']):
                            expected = 0 if case == 'background' and index == 1 else frames
                            assert encoding[2] == expected, (name, encoding, expected)
                            if expected:
                                assert encoding[5 if subpixel else 4] > 0, (name, encoding)
                        assert row['initial_pixels'] is not None
                        assert all('device_type: Cpu' in adapter and 'backend: Vulkan' in adapter and 'llvmpipe' in adapter for adapter in row['adapter'])
                    else:
                        assert row['encoding'] == [] and row['logical_after'] == [0] * 6
                    row.update({'sample_name': name, 'phase': phase, 'repetition': repetition, 'started_unix': start, 'ended_unix': end})
                    samples.append(row)
                    (root / (phase + '-samples.json')).write_text(json.dumps(samples, indent=2) + '\n')
    print({'phase': phase, 'completed_repetitions': repetition + 1, 'children': len(samples)}, flush=True)
print({'phase': phase, 'children': len(samples), 'complete': True}, flush=True)
