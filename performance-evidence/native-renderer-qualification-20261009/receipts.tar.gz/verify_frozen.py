from pathlib import Path
import hashlib, json, sys, time

root = Path(__file__).parent
identity = json.loads((root / 'frozen-identities.json').read_text())
phase = sys.argv[1]
checked = {}
for category in ['externs', 'runtime', 'binaries', 'tools']:
    for name, expected in identity[category].items():
        actual = hashlib.sha256(Path(name).read_bytes()).hexdigest()
        assert actual == expected, (category, name)
        checked[category + ':' + name] = actual
assert hashlib.sha256(Path(identity['compiler']).read_bytes()).hexdigest() == identity['compiler_sha256']
for name, expected in identity['source_files'].items():
    path = root / 'complete_window_fixture.rs' if name == 'private-fixture' else Path('/workspace/zed-renderer-cache-qualification') / name
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    assert actual == expected, name
    checked['source:' + name] = actual
receipt = {'phase': phase, 'checked_unix': time.time(), 'compiler_and_source_and_dependency_and_allocator_tools_and_runtime_and_binaries_unchanged': True, 'identities_checked': len(checked), 'checked': checked}
(root / (phase + '-frozen-verification.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print({'phase': phase, 'unchanged_identities': len(checked)})
