from pathlib import Path
import json, hashlib

root = Path(__file__).parent
plan = json.loads((root / 'native-build-plan.json').read_text())
original = json.loads(Path('/workspace/scratch/gpui-splice-state-loop/baseline-rustc-command.json').read_text())
externs = {}
for index, argument in enumerate(original['args']):
    if argument == '--extern':
        name, path = original['args'][index + 1].split('=', 1)
        externs[name] = path
command = plan['commands']['gpui']
command[command.index('metadata=renderer_current_08d5555')] = 'metadata=renderer_headless_current_08d5555'
command[command.index('extra-filename=-renderer08d5555')] = 'extra-filename=-headless08d5555'
for feature in ['test-support', 'leak-detection', 'backtrace', 'proptest']:
    command += ['--cfg', 'feature="' + feature + '"']
for name in ['backtrace', 'proptest']:
    command += ['--extern', name + '=' + externs[name]]
    plan['immutable_external_objects'][externs[name]] = hashlib.sha256(Path(externs[name]).read_bytes()).hexdigest()
wgpu_command = plan['commands']['gpui_wgpu']
for index, value in enumerate(wgpu_command):
    if value.startswith('gpui='):
        wgpu_command[index] = value.replace('libgpui-renderer08d5555.rlib', 'libgpui-headless08d5555.rlib')
plan['commands'] = {'gpui-support': command, 'gpui_wgpu-headless': wgpu_command}
plan['limits'][1] = 'Exact current GPUI test-support, leak-detection, backtrace and proptest features enable headless interfaces. Native external objects retain original unified test-support features. No installed app or physical GPU.'
plan['feature_recovery'] = 'First WGPU test compile failed because production GPUI omits PlatformHeadlessRenderer; successful production library is preserved. This build enables the required library feature, preserving source and dependency choices. No metric samples exist or are repeated.'
(root / 'native-headless-build-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
print({'headless_features_added': ['test-support', 'leak-detection', 'backtrace', 'proptest'], 'current_gpui_dev_platform_excluded': 'gpui_platform' not in externs or 'gpui_platform=' not in ' '.join(command)})
