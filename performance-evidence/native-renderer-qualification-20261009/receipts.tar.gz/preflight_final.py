from pathlib import Path
import json, os, subprocess, time

root = Path(__file__).parent
environment = {**os.environ, 'VK_DRIVER_FILES': '/workspace/.fincode-tools/native/usr/share/vulkan/icd.d/lvp_icd.json', 'XDG_RUNTIME_DIR': str(root / 'runtime'), 'MESA_SHADER_CACHE_DISABLE': 'true', 'LP_NUM_THREADS': '2'}
cases = [('bare', 'native', '1', '0', 'scroll'), ('bare', 'native', '0', '1', 'scroll'), ('census', 'native', '1', '1', 'background'), ('bare', 'none', '0', '0', 'stream')]
commands = [('core', [str(root / 'native/gpui_wgpu-window-final-bare08d5555'), '--test-threads=1', '--nocapture'], environment)]
for index, (allocator, renderer, retained, subpixel, case) in enumerate(cases):
    commands.append(('fixture-' + str(index), [str(root / ('native/gpui_wgpu-window-final-' + allocator + '08d5555')), '--ignored', '--exact', 'wgpu_renderer::owned_renderer_fixture::owned_complete_transcript_renderer_diagnostic', '--test-threads=1', '--nocapture'], {**environment, 'OWNED_RENDERER': renderer, 'OWNED_RETAINED': retained, 'OWNED_SUBPIXEL': subpixel, 'OWNED_CASE': case, 'OWNED_FRAMES': '3'}))
for name, command, environment in commands:
    start = time.time()
    with (root / ('final-preflight-' + name + '.log')).open('xb') as log:
        result = subprocess.run(command, env=environment, cwd='/workspace/zed-renderer-cache-qualification', stdout=log, stderr=subprocess.STDOUT)
    receipt = {'command': command, 'environment': environment, 'started_unix': start, 'ended_unix': time.time(), 'exit_code': result.returncode, 'not_a_frozen_diagnostic_sample': True}
    (root / ('final-preflight-' + name + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print({'name': name, 'exit_code': result.returncode}, flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
