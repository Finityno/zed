
use super::WgpuHeadlessRenderer;
use gpui::{HeadlessAppContext, PlatformHeadlessRenderer, PlatformAtlas, Scene, DevicePixels, Size};
use std::{cell::RefCell, rc::Rc, alloc::{GlobalAlloc, Layout, System}};

#[cfg(owned_renderer_census)]
mod census {
    use super::*;
    use std::sync::atomic::{AtomicU64, Ordering::Relaxed};
    pub static LIVE: AtomicU64 = AtomicU64::new(0);
    pub static PEAK: AtomicU64 = AtomicU64::new(0);
    pub static BYTES: AtomicU64 = AtomicU64::new(0);
    pub static CALLS: AtomicU64 = AtomicU64::new(0);
    pub struct CountingSystem;
    fn add(bytes: u64) {
        let live = LIVE.fetch_add(bytes, Relaxed) + bytes;
        PEAK.fetch_max(live, Relaxed);
        BYTES.fetch_add(bytes, Relaxed);
        CALLS.fetch_add(1, Relaxed);
    }
    unsafe impl GlobalAlloc for CountingSystem {
        unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
            let result = unsafe { System.alloc(layout) };
            if !result.is_null() { add(layout.size() as u64); }
            result
        }
        unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
            let result = unsafe { System.alloc_zeroed(layout) };
            if !result.is_null() { add(layout.size() as u64); }
            result
        }
        unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
            LIVE.fetch_sub(layout.size() as u64, Relaxed);
            unsafe { System.dealloc(pointer, layout) };
        }
        unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, size: usize) -> *mut u8 {
            let result = unsafe { System.realloc(pointer, layout, size) };
            if !result.is_null() {
                LIVE.fetch_sub(layout.size() as u64, Relaxed);
                add(size as u64);
            }
            result
        }
    }
    #[global_allocator]
    static ALLOCATOR: CountingSystem = CountingSystem;
    pub fn snapshot() -> [u64; 4] {
        [LIVE.load(Relaxed), PEAK.load(Relaxed), BYTES.load(Relaxed), CALLS.load(Relaxed)]
    }
}

fn census_snapshot() -> [u64; 4] {
    #[cfg(owned_renderer_census)] { census::snapshot() }
    #[cfg(not(owned_renderer_census))] { [0; 4] }
}

#[repr(C)]
struct NativeTimespec { seconds: i64, nanoseconds: i64 }
unsafe extern "C" { fn clock_gettime(clock: i32, value: *mut NativeTimespec) -> i32; }
fn cpu_time(clock: i32) -> anyhow::Result<u64> {
    let mut value = NativeTimespec { seconds: 0, nanoseconds: 0 };
    anyhow::ensure!(unsafe { clock_gettime(clock, &mut value) } == 0, "native CPU clock failed");
    Ok(value.seconds as u64 * 1_000_000_000 + value.nanoseconds as u64)
}

#[derive(Default)]
struct EncodingStats { elapsed: u64, thread_cpu: u64, calls: u64, quads: usize, monochrome: usize, subpixel: usize, paths: usize }
struct ObservedRenderer { inner: Rc<RefCell<WgpuHeadlessRenderer>>, stats: Rc<RefCell<EncodingStats>> }
impl PlatformHeadlessRenderer for ObservedRenderer {
    fn render_scene_to_image(&mut self, scene: &Scene, size: Size<DevicePixels>) -> anyhow::Result<image::RgbaImage> {
        self.inner.borrow_mut().render_scene_to_image(scene, size)
    }
    fn render_scene(&mut self, scene: &Scene, size: Size<DevicePixels>) -> anyhow::Result<()> {
        let cpu = cpu_time(3)?;
        let start = Instant::now();
        self.inner.borrow_mut().render_scene(scene, size)?;
        let elapsed = start.elapsed().as_nanos() as u64;
        let mut stats = self.stats.borrow_mut();
        stats.elapsed += elapsed;
        stats.thread_cpu += cpu_time(3)? - cpu;
        stats.calls += 1;
        stats.quads = scene.quads.len();
        stats.monochrome = scene.monochrome_sprites.len();
        stats.subpixel = scene.subpixel_sprites.len();
        stats.paths = scene.paths.len();
        Ok(())
    }
    fn sprite_atlas(&self) -> Arc<dyn PlatformAtlas> { self.inner.borrow().sprite_atlas() }
}

type RendererHandle = (Rc<RefCell<WgpuHeadlessRenderer>>, Rc<RefCell<EncodingStats>>);
fn wait_renderers(handles: &[RendererHandle]) -> anyhow::Result<()> {
    for (renderer, _) in handles {
        let mut renderer = renderer.borrow_mut();
        renderer.context.device.poll(wgpu::PollType::Wait { submission_index: None, timeout: Some(Duration::from_secs(30)) })
            .map_err(|error| anyhow::anyhow!("actual queue completion failed: {error}"))?;
        renderer.check_gpu_errors()?;
    }
    Ok(())
}
fn rss() -> anyhow::Result<[u64; 2]> {
    let status = std::fs::read_to_string("/proc/self/status")?;
    let field = |name: &str| -> anyhow::Result<u64> {
        status.lines().find_map(|line| line.strip_prefix(name)).and_then(|value| value.split_whitespace().next()).and_then(|value| value.parse().ok()).ok_or_else(|| anyhow::anyhow!("missing {name}"))
    };
    Ok([field("VmRSS:")?, field("VmHWM:")?])
}
fn logical_renderer_bytes(handles: &[RendererHandle]) -> [u64; 6] {
    let gauges = gpui::render_memory_gauges();
    let headless_targets = handles.iter().map(|(renderer, _)| renderer.borrow().render_target.as_ref().map_or(0, |target| super::texture_bytes(&target.texture))).sum();
    [gauges.atlas_monochrome_bytes, gauges.atlas_polychrome_bytes, gauges.instance_buffer_bytes, gauges.depth_texture_bytes, gauges.path_texture_bytes, headless_targets]
}
fn pixels(cx: &mut HeadlessAppContext, window: WindowHandle<Transcript>) -> anyhow::Result<u64> {
    let image = cx.capture_screenshot(window.into())?;
    anyhow::ensure!(image.dimensions() == (800, 1000), "unexpected transcript image size");
    anyhow::ensure!(image.pixels().any(|pixel| pixel.0 != [255, 255, 255, 255]), "transcript contains no painted text/controls");
    Ok(image.as_raw().iter().fold(14695981039346656037, |hash, byte| (hash ^ u64::from(*byte)).wrapping_mul(1099511628211)))
}
fn draw_window(cx: &mut HeadlessAppContext, window: WindowHandle<Transcript>) -> anyhow::Result<()> {
    cx.update_window(window.into(), |_, window, cx| {
        window.draw(cx).clear(cx);
        window.present_if_needed();
    })?;
    Ok(())
}

#[test]
#[ignore]
fn owned_complete_transcript_renderer_diagnostic() -> anyhow::Result<()> {
    let initial_census = census_snapshot();
    let initial_gauges = gpui::render_memory_gauges();
    let native = std::env::var("OWNED_RENDERER")? == "native";
    let retained = std::env::var("OWNED_RETAINED")? == "1";
    let case = std::env::var("OWNED_CASE")?;
    let frames: usize = std::env::var("OWNED_FRAMES")?.parse()?;
    let window_count = if matches!(case.as_str(), "multi" | "background") { 2 } else { 1 };
    let handles: Rc<RefCell<Vec<RendererHandle>>> = Rc::new(RefCell::new(Vec::with_capacity(window_count)));
    let text_system = CosmicTextSystem::new_without_system_fonts("IBM Plex Sans");
    gpui::PlatformTextSystem::add_fonts(&text_system, vec![Cow::Borrowed(LILEX), Cow::Borrowed(IBM_PLEX)])?;
    let mut cx = HeadlessAppContext::with_platform(Arc::new(text_system), Arc::new(()), {
        let handles = handles.clone();
        move || {
            if !native { return Ok(None); }
            let renderer = Rc::new(RefCell::new(WgpuHeadlessRenderer::new()?));
            let stats = Rc::new(RefCell::new(EncodingStats::default()));
            handles.borrow_mut().push((renderer.clone(), stats.clone()));
            Ok(Some(Box::new(ObservedRenderer { inner: renderer, stats })))
        }
    });
    cx.update(|cx| cx.set_view_retention(retained));
    let mut windows = Vec::with_capacity(window_count);
    let mut roots = Vec::with_capacity(window_count);
    for _ in 0..window_count {
        let window = cx.open_window(size(px(800.), px(1000.)), |_, cx| cx.new(|_| Transcript::new(200)))?;
        roots.push(window.root(&mut cx)?);
        windows.push(window);
        draw_window(&mut cx, window)?;
    }
    wait_renderers(&handles.borrow())?;
    let setup_census = census_snapshot();
    for _ in 0..8 {
        for &window in &windows {
            cx.update_window(window.into(), |_, window, _| window.refresh())?;
            draw_window(&mut cx, window)?;
        }
        wait_renderers(&handles.borrow())?;
    }
    let initial_pixels = if native { Some(pixels(&mut cx, windows[0])?) } else { None };
    wait_renderers(&handles.borrow())?;
    let warmed_census = census_snapshot();
    let warmed_rss = rss()?;
    let logical_before = logical_renderer_bytes(&handles.borrow());
    for (_, stats) in handles.borrow().iter() { *stats.borrow_mut() = EncodingStats::default(); }
    let mut samples = Vec::with_capacity(frames);
    let process_start = cpu_time(2)?;
    let thread_start = cpu_time(3)?;
    let start = Instant::now();
    for step in 0..frames {
        let frame_start = Instant::now();
        for (index, (&window, transcript)) in windows.iter().zip(&roots).enumerate() {
            if case == "background" && index == 1 { continue; }
            match case.as_str() {
                "stream" | "multi" | "background" => { cx.update(|cx| transcript.update(cx, |transcript, cx| transcript.stream(step, cx))); },
                "scroll" => { cx.update(|cx| transcript.update(cx, |transcript, cx| { transcript.list.scroll_by(if (step / 32).is_multiple_of(2) { px(-37.) } else { px(37.) }); cx.notify(); })); },
                "redraw" => { cx.update_window(window.into(), |_, window, _| window.refresh())?; },
                "resize" => { cx.update_window(window.into(), |_, window, _| window.resize(size(px([800., 640., 520., 700.][step % 4]), px(1000.))))?; },
                _ => anyhow::bail!("undeclared workload {case}"),
            }
            draw_window(&mut cx, window)?;
        }
        let before_wait = frame_start.elapsed().as_nanos() as u64;
        wait_renderers(&handles.borrow())?;
        samples.push([frame_start.elapsed().as_nanos() as u64, before_wait]);
    }
    let elapsed = start.elapsed().as_nanos() as u64;
    let thread_cpu = cpu_time(3)? - thread_start;
    let process_cpu = cpu_time(2)? - process_start;
    let measured_census = census_snapshot();
    let measured_rss = rss()?;
    let logical_after = logical_renderer_bytes(&handles.borrow());
    let encoding: Vec<_> = handles.borrow().iter().map(|(_, stats)| { let stats = stats.borrow(); [stats.elapsed, stats.thread_cpu, stats.calls, stats.quads as u64, stats.monochrome as u64, stats.subpixel as u64, stats.paths as u64] }).collect();
    if native && case == "background" { assert_eq!(encoding[1][2], 0, "inactive sibling submitted GPU work"); }
    let adapter: Vec<_> = handles.borrow().iter().map(|(renderer, _)| { let renderer = renderer.borrow(); format!("{:?}", renderer.context.adapter.get_info()) }).collect();
    let final_pixels = if native && case != "resize" { Some(pixels(&mut cx, windows[0])?) } else { None };
    wait_renderers(&handles.borrow())?;
    drop(roots);
    drop(windows);
    drop(cx);
    wait_renderers(&handles.borrow())?;
    let app_closed_census = census_snapshot();
    let app_closed_rss = rss()?;
    handles.borrow_mut().clear();
    drop(handles);
    let released_census = census_snapshot();
    let released_rss = rss()?;
    assert_eq!(gpui::render_memory_gauges(), initial_gauges, "renderer logical owners survived close/drop");
    println!("OWNED_RENDERER_DIAGNOSTIC {}", gpui::private::serde_json::json!({"case":case,"native":native,"retained":retained,"frames":frames,"windows":window_count,"elapsed_ns":elapsed,"thread_cpu_ns":thread_cpu,"process_cpu_ns":process_cpu,"samples":[samples],"encoding":encoding,"adapter":adapter,"initial_census":initial_census,"setup_census":setup_census,"warmed_census":warmed_census,"measured_census":measured_census,"app_closed_census":app_closed_census,"released_census":released_census,"warmed_rss":warmed_rss,"measured_rss":measured_rss,"app_closed_rss":app_closed_rss,"released_rss":released_rss,"logical_before":logical_before,"logical_after":logical_after,"initial_pixels":initial_pixels,"final_pixels":final_pixels,"allocator":if cfg!(owned_renderer_census) {"process-global counting System"} else {"bare System"},"rasterizer":"software Vulkan; headless offscreen; queue completion included; no presentation or physical GPU claim"}));
    Ok(())
}
