from pathlib import Path
import json,subprocess,os,sys,hashlib,time
root=Path(__file__).parent;lane=sys.argv[1];label=sys.argv[2] if len(sys.argv)>2 else 'build'
configuration=json.loads((root/(lane+'-rustc-command.json')).read_text())
args=configuration['args'];output=root/(lane+'-census-'+label+'-artifacts');output.mkdir()
args[args.index('--out-dir')+1]=str(output)
args += ['--cfg','gpui_splice_census']
log=root/(lane+'-census-'+label+'.log');environment=dict(os.environ,**configuration['environment'])
started=time.time()
with log.open('w') as stream: result=subprocess.run(['timeout','-k','10','600',*args],cwd=configuration['cwd'],env=environment,stdout=stream,stderr=subprocess.STDOUT)
receipt={'lane':lane,'command':args,'cwd':configuration['cwd'],'exit_code':result.returncode,'seconds':time.time()-started,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
(root/(lane+'-census-'+label+'-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(log.read_text());print(json.dumps({k:v for k,v in receipt.items() if k != "command"}))
raise SystemExit(result.returncode)
