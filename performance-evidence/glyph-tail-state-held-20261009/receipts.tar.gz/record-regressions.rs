    #[test]
    fn direct_records_preserve_published_prefixes_and_independent_sources() {
        fn require_send_sync<T: Send + Sync>() {}
        require_send_sync::<Scene>();
        let mut source = Scene::default();
        source.push_layer(unit_bounds());
        let line = source.glyph_watermark();
        for tile in 1..=2 {
            let mut sprite = shimmering_glyph(0);
            sprite.effect = SpriteEffect::default();
            sprite.tile.tile_id = crate::TileId(tile);
            source.insert_monochrome_sprite(sprite);
        }
        let published = source.len();
        for tile in 3..=8 {
            let mut sprite = shimmering_glyph(0);
            sprite.effect = SpriteEffect::default();
            sprite.tile.tile_id = crate::TileId(tile);
            source.insert_monochrome_sprite(sprite);
        }
        let second = source.glyph_watermark();
        for tile in 9..=12 {
            let mut sprite = shimmering_glyph(0);
            sprite.effect = SpriteEffect::default();
            sprite.tile.tile_id = crate::TileId(tile);
            source.insert_monochrome_sprite(sprite);
        }
        let Some(second_operations) = source.glyph_sprites_since(second) else {
            panic!("the second published range still names its glyphs");
        };
        let first = painted_glyphs(&source, line.operations..published);
        let middle = painted_glyphs(&source, published..second.operations);
        let last = painted_glyphs(&source, second_operations.clone());
        assert_eq!(first.iter().map(|glyph| glyph.1).collect::<Vec<_>>(), [1, 2]);
        assert_eq!(middle.iter().map(|glyph| glyph.1).collect::<Vec<_>>(), [3, 4, 5, 6, 7, 8]);
        assert_eq!(last.iter().map(|glyph| glyph.1).collect::<Vec<_>>(), [9, 10, 11, 12]);
        let source_operations = source.len();
        let mut whole_copy = Scene::default();
        whole_copy.replay(0..source_operations, &source);
        assert_eq!(whole_copy.len(), source_operations, "nested retained ranges keep their operation offsets");
        assert_eq!(painted_glyphs(&whole_copy, 1..whole_copy.len()), painted_glyphs(&source, 1..source_operations));
        source.finish();
        for sprite in &mut source.monochrome_sprites {
            sprite.tile.tile_id = crate::TileId(999);
        }
        let mut copied = Scene::default();
        copied.push_layer(unit_bounds());
        let start = copied.glyph_watermark();
        assert!(copied.replay_glyph_sprites(&source, second_operations));
        let Some(operations) = copied.glyph_sprites_since(start) else {
            panic!("the copied range still names its glyphs");
        };
        assert_eq!(painted_glyphs(&copied, operations), last);
        source.clear();
        source.push_layer(unit_bounds());
        let start = source.glyph_watermark();
        source.insert_monochrome_sprite(shimmering_glyph(0));
        source.insert_monochrome_sprite(shimmering_glyph(0));
        assert!(source.glyph_sprites_since(start).is_some());
    }

    #[test]
    fn direct_records_replay_like_scalar_glyphs_when_moved_or_rebased() {
        let started_at = std::time::Instant::now();
        let build = |compact: bool| {
            let mut source = Scene::default();
            let Some(transition) = source.push_transition(rolling_in(started_at)) else {
                panic!("a first transition always fits");
            };
            let animation = source.push_shimmer_animation(ShimmerAnimation {
                band_start: -40., travel: 1000.,
                period: std::time::Duration::from_secs(1), hold: 0.,
            });
            let bounds = Bounds::new(point(ScaledPixels(0.), ScaledPixels(0.)), Size { width: ScaledPixels(400.), height: ScaledPixels(80.) });
            source.push_layer(bounds);
            source.set_current_transition(transition);
            for index in 0..20 {
                let mut sprite = shimmering_glyph(if index < 16 { animation } else { 0 });
                sprite.bounds.origin.x = ScaledPixels(index as f32 * 20.);
                sprite.content_mask.bounds = bounds;
                sprite.tile.tile_id = crate::TileId(index);
                if (8..16).contains(&index) {
                    source.insert_subpixel_sprite(SubpixelSprite {
                        order: sprite.order, pad: sprite.pad, bounds: sprite.bounds,
                        content_mask: sprite.content_mask, color: sprite.color,
                        effect: sprite.effect, tile: sprite.tile, transformation: sprite.transformation,
                    });
                } else {
                    source.insert_monochrome_sprite(sprite);
                }
                if !compact { source.len(); }
            }
            source.pop_layer();
            source.set_current_transition(0);
            source.finish();
            source
        };
        let scalar = build(false);
        let compact = build(true);
        assert_eq!(scalar.clipped_only_inside(0..scalar.len(), [0., 0., 400., 80.]), compact.clipped_only_inside(0..compact.len(), [0., 0., 400., 80.]));
        let moved = SceneMove { delta: point(ScaledPixels(4.), ScaledPixels(20.)), old_outer: [0., 0., 400., 80.], new_outer: [0., 0., 400., 60.] };
        for rebase in [None, Some((1, 2))] {
            for moving in [None, Some(&moved)] {
                let render = |source: &Scene| {
                    let mut result = Scene::default();
                    result.push_transition(rolling_in(started_at));
                    result.push_transition(rolling_in(started_at));
                    result.replay_inside(0..source.len(), source, rebase, moving);
                    result.finish();
                    result.advance_transitions(started_at + std::time::Duration::from_millis(50));
                    format!("{:?}{:?}{:?}", result.monochrome_sprites, result.subpixel_sprites, result.transitions)
                };
                assert_eq!(render(&scalar), render(&compact));
            }
        }
    }

