from pathlib import Path
import json,hashlib,tarfile,shutil,re,subprocess,os,collections
r=Path(__file__).parent;c=r/'comparison';w=Path('/workspace/zed-glyph-tail-state');d=json.loads((c/'decision.json').read_text());assert d['status']=='HELD_UNMERGED' and len(d['failures'])==19
public=w/'performance-evidence/glyph-tail-state-held-20261009';public.mkdir(parents=True,exist_ok=True)
files=[]
for p in r.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(r)
 if any(part=='__pycache__' or part.endswith('-artifacts') for part in rel.parts):
  if p.suffix!='.d':continue
 if p.name.endswith('.pyc') or p.name.endswith('.preserved.gz'):continue
 files.append((str(rel),p))
archive=public/'receipts.tar.gz';seen={};linked=0
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for name,p in sorted(files):
  st=p.stat();raw=p.read_bytes();sha=hashlib.sha256(raw).hexdigest();key=(sha,st.st_size,st.st_mode,st.st_mtime_ns);info=t.gettarinfo(str(p),arcname=name)
  if key in seen:
   info.type=tarfile.LNKTYPE;info.linkname=seen[key];info.size=0;t.addfile(info);linked+=1
  else:
   seen[key]=name
   with p.open('rb') as f:t.addfile(info,f)
expected={name:p for name,p in files};resolved={};members=0
with tarfile.open(archive,'r|gz') as t:
 for member in t:
  p=expected[member.name];wanted=hashlib.sha256(p.read_bytes()).hexdigest()
  if member.islnk():
   assert member.linkname in resolved;actual=resolved[member.linkname]
  else:
   assert member.isfile();actual=hashlib.sha256(t.extractfile(member).read()).hexdigest()
  assert actual==wanted,member.name
  resolved[member.name]=actual;members+=1
assert members==len(files)
sha=hashlib.sha256(archive.read_bytes()).hexdigest();metadata={'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'archive_members':len(files),'byte_exact_roundtrip':True,'identical_member_hardlinks':linked,'hardlink_note':'Tar links deduplicate members only when bytes, size, mode and nanosecond modification time match; all members resolve to original exact bytes. No raw sample/source removed.','held':True,'merged':False,'production_source':'b706c55f84ac00c4fa44176742df5cb439f847d8','baseline':'08d5555709d7afab3936c7afcd9f7f0ff9ecbd65','never_resample_unchanged':True,'no_app_GPU_platform_or_shipped_allocator_gain':True};(r/'archive-verification.json').write_text(json.dumps(metadata,indent=2)+'\n');(public/'evidence.json').write_text(json.dumps(metadata,indent=2)+'\n')
for name in ['decision.json','summary.json','policy.json','policy.sha256','correctness-summary.json','window-record-owner-regression-receipts.json','candidate-exact-production-proof.json','empty-owner-correctness-receipts.json','compiler-dependency-identities.json','external-dependencies.json','binary-identities.json','native-runtime-identity.json','candidate-source-receipt.json','lane-source-difference-proof.json']:shutil.copy2(c/name,public/name)
for name in ['diagnostic-decision.json','diagnostic-binary-identity.json']:shutil.copy2(r/name,public/name)
(public/'README.md').write_text(f"""# Held padding-resident glyph tail state

This design remains unmerged. Its first and only 3,418 alternating native
children cover 121 Window workloads and three standalone Scene owners. All 20
frozen memory targets pass: complete App/Window held requested heap falls
10.24–28.77% and allocated paint-record capacity falls 75–97.92%, exceeding both
full lane ranges and the 5%/50% goals. Requested held/peak/bytes and allocation
calls meet every frozen control with zero fixed-overhead allowance. Native
Scene/Window/record widths stay exactly 1632/12944/184 bytes. Every standalone
Scene releases all counted owners.

19 frozen fields fail. The bare cohort fails six thread CPU, six elapsed,
two whole-child CPU and one current RSS fields. The separate census fails
three current RSS and one peak RSS fields. Panel keep/removal, retained redraw,
recoloring and decorated text have adverse CPU fields; resizing, state changes
and redraw have adverse RSS fields. Every failure and full raw lane range is
preserved. No PR, merge, adoption or unchanged resampling follows this result.

Two publication flags fit existing Scene padding. Scene.len checks the local
tail kind and publishes a glyph tail without a heap lookup. Uniform glyph
ranges extend in place without scalar promotion or post-paint scanning. Non-glyph
replay movement/remap/animation/insertion remains exactly the owned source.
The native compiler inlines Scene.len, but this is mechanism evidence, not a
CPU gain. A distinct next design will keep index capture and ordinary Scene
insertion unchanged and scope coalescing to a line painter; no benefit is yet
inferred for that design.

Final native correctness has 624 common passes, 278 children, 121 exact matched
frame histories, six standalone owner releases and one cold-line expected-red/
green child per lane. Two legacy zero-test filters remain explicit coverage gaps.
Shared positive-test definition order matches. Private observers normalize logical
overlay indices and preserve raw compact metadata. Exact owned transformations
reproduce both changed source files. Earlier failed designs stay preserved.

Source: b706c55f84ac00c4fa44176742df5cb439f847d8.
Owned baseline: 08d5555709d7afab3936c7afcd9f7f0ff9ecbd65.
Frozen policy SHA256: 46c6519e7fa13140b3e94f4c6dfa07b830e0cad5f48e7fcacb05e3f9715cbe34.
Frozen consumer source: 63f5d04838ef9a00429666a22da927c457e7fc78, with coherent
rendering pin 08d5555709d7afab3936c7afcd9f7f0ff9ecbd65 and component pin
ab07cd7695af1dfd9f1c6ad06a77660d288e568d. A later read-only refresh observed
consumer 1561838d1be2dda701a59e59811973c2abb64649 with the same pins; its
independent changes are preserved. Owned rendering main and open drafts stay unchanged.

Bare and counting cohorts run separately, sequentially, and once. All source,
compiler, 59 immutable dependency objects, runtime, four binary and policy hashes
pass before/after checks. opt-level=3, 16 codegen units and debug assertions stay
fixed. Host guards precede every child. There is no overlap with builds, hashing,
compression or other profiling. Counted CPU is not CPU gain evidence.

A managed-session reconnection lost the outer supervisor receipt for three builds.
All three inner compiler receipts independently show actual exit zero, exact log
hashes and sequential start/end timestamps. The saved recovery receipt distinguishes
these observed exits from the unavailable outer receipt. No build or sample was
repeated. The reconnect occurred before paired measurements. Both native cohorts
have observed outer exits and exact logs. Original inactive native objects remain
losslessly preserved with identity and metadata receipts.

Archive SHA256: {sha}. All {len(files)} members roundtrip to original exact bytes.
Tar hardlinks apply only to identical bytes, sizes, modes and nanosecond mtimes.
Linux fake GPUI platform/text with System and separate counting-System fixtures
establish no application, physical GPU, macOS, Windows or shipped-allocator gain.
Owning Clippy is not claimed after failed performance gates. Continue a distinct
line-local design; never repeat this failed source unchanged or weaken gates.
""")
p=w/'PERFORMANCE_GOAL.md';s=p.read_text();s+='\n\nPadding-resident glyph tail state at `b706c55f84ac00c4fa44176742df5cb439f847d8`\nremains held. Across 3,418 native children all 20 memory targets pass: 10.24–28.77%\nless complete requested live heap and 75–97.92% less record capacity, with exact\noriginal object widths, zero fixed overhead and every requested heap/churn control\npassing. Nineteen CPU/elapsed/whole-child/current/peak-RSS fields fail. Native output\nand retained/release contracts pass; preserve all failures and coverage limits in\n`performance-evidence/glyph-tail-state-held-20261009`. Never repeat this source\nunchanged. Continue with distinct line-local coalescing that leaves ordinary Scene\nindex capture/insertion unchanged. No application or GPU gain is established.\n';p.write_text(s)
if archive.stat().st_size > 8*1024*1024:
 raw=archive.read_bytes();parts=[]
 for i,offset in enumerate(range(0,len(raw),8*1024*1024)):
  part=public/f'receipts.tar.gz.part-{i:02d}';part.write_bytes(raw[offset:offset+8*1024*1024]);parts.append({'path':part.name,'sha256':hashlib.sha256(part.read_bytes()).hexdigest(),'bytes':part.stat().st_size})
 assert b''.join((public/v['path']).read_bytes() for v in parts)==raw
 shutil.move(str(archive),str(r/'held-original-archive.tar.gz'));(public/'archive-parts.json').write_text(json.dumps({'archive_sha256':sha,'parts':parts,'byte_exact_join_verified':True},indent=2)+'\n')
env=os.environ|{'GIT_NO_LAZY_FETCH':'1'};subprocess.run(['git','add','--sparse','PERFORMANCE_GOAL.md',str(public.relative_to(w))],cwd=w,env=env,check=True);subprocess.run(['git','commit','-m','Preserve held glyph tail state evidence [skip ci]'],cwd=w,env=env,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,env=env,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=w,env=env,text=True).strip();metadata.update({'held_head':head,'held_tree':tree});(r/'held-final-source-receipt.json').write_text(json.dumps(metadata,indent=2)+'\n')
paths=list(json.loads((c/'candidate-source-receipt.json').read_text())['files'])+['PERFORMANCE_GOAL.md']+[str(p.relative_to(w)) for p in public.iterdir() if p.is_file()];manifest=[]
for name in sorted(paths):
 p=w/name;blob=subprocess.check_output(['git','hash-object',name],cwd=w,env=env,text=True).strip();manifest.append({'path':name,'local':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'blob':blob})
(r/'publication-files.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(metadata,indent=2))
