from pathlib import Path
import json,hashlib
root=Path(__file__).parent;worktree=Path('/workspace/zed-glyph-tail-state');previous=Path('/workspace/zed-record-publication')
assert (worktree/'README.md').read_text().startswith('> [!IMPORTANT]\n> Remove this line to confirm you\'ve reviewed this PR before submitting.')
assert hashlib.sha256((root/'policy.json').read_bytes()).hexdigest()==(root/'policy.sha256').read_text().strip()
source=(previous/'crates/gpui/src/scene.rs').read_text();owned=json.loads(Path('/workspace/scratch/gpui-record-publication-loop/comparison/candidate-source-receipt.json').read_text());assert hashlib.sha256(source.encode()).hexdigest()==owned['files']['crates/gpui/src/scene.rs']
needle='    current_transition: u32,\n';assert source.count(needle)==1;source=source.replace(needle,needle+'''    // Capturing an index need not touch the wide metadata entry on the heap.
    tail_is_glyph: bool,
    published_glyph_tail: AtomicBool,
''')
needle='        paint_operations.clear_vec(&mut self.paint_operations);\n';assert source.count(needle)==1;source=source.replace(needle,needle+'''        self.tail_is_glyph = false;
        self.published_glyph_tail.store(false, Ordering::Relaxed);
''')
old='''    pub fn len(&self) -> usize {
        if let Some(PaintOperation::MonochromeSprites(record) | PaintOperation::SubpixelSprites(record)) =
            self.paint_operations.last()
        {
            record.published.store(true, Ordering::Relaxed);
        }
        self.paint_operations.len()
    }''';new='''    pub fn len(&self) -> usize {
        if self.tail_is_glyph {
            self.published_glyph_tail.store(true, Ordering::Relaxed);
        }
        self.paint_operations.len()
    }''';assert source.count(old)==1;source=source.replace(old,new)
start=source.index('    #[inline]\n    fn append_glyph_record(');end=source.index('    /// The number of paint operations and of painted glyph sprites so far,',start)
source=source[:start]+'''    #[inline]
    fn append_glyph_record(&mut self, subpixel: bool, index: usize) {
        if self.tail_is_glyph && !self.published_glyph_tail.load(Ordering::Relaxed)
            && let Some(last) = self.paint_operations.last_mut()
        {
            match last {
                PaintOperation::MonochromeSprites(indices)
                    if !subpixel && indices.end == index =>
                {
                    indices.end = index + 1;
                    return;
                }
                PaintOperation::SubpixelSprites(indices)
                    if subpixel && indices.end == index =>
                {
                    indices.end = index + 1;
                    return;
                }
                _ => {}
            }
        }
        self.push_glyph_record(subpixel, index..index + 1);
    }

    #[inline]
    fn push_glyph_record(&mut self, subpixel: bool, indices: Range<usize>) {
        self.paint_operations.push(PaintOperation::glyphs(subpixel, indices));
        self.tail_is_glyph = true;
        self.published_glyph_tail.store(false, Ordering::Relaxed);
    }

'''+source[end:]
# Every non-glyph insertion is an immutable barrier. Cached glyph append
# resets publication only because it creates a fresh record.
needle='''            mask,
        }));
    }

    pub fn pop_layer''';repl='''            mask,
        }));
        self.tail_is_glyph = false;
    }

    pub fn pop_layer''';assert source.count(needle)==1;source=source.replace(needle,repl)
needle='        self.paint_operations.push(PaintOperation::EndLayer);\n';assert source.count(needle)==1;source=source.replace(needle,needle+'        self.tail_is_glyph = false;\n')
needle='''        self.paint_operations
            .push(PaintOperation::Primitive(primitive));
''';assert source.count(needle)==1;source=source.replace(needle,needle+'        self.tail_is_glyph = false;\n')
for flag in ['true','false']:
 old=f'                self.paint_operations.push(PaintOperation::glyphs({flag}, start as usize..start as usize + count));';new=f'                self.push_glyph_record({flag}, start as usize..start as usize + count);';assert source.count(old)==1;source=source.replace(old,new)
source=source.replace('PaintOperation::MonochromeSprites(record) => self.painted_monochrome_sprites[record.indices.clone()]','PaintOperation::MonochromeSprites(indices) => self.painted_monochrome_sprites[indices.clone()]').replace('PaintOperation::SubpixelSprites(record) => self.painted_subpixel_sprites[record.indices.clone()]','PaintOperation::SubpixelSprites(indices) => self.painted_subpixel_sprites[indices.clone()]')
source=source.replace('                PaintOperation::MonochromeSprites(record)\n                | PaintOperation::SubpixelSprites(record) => {','                PaintOperation::MonochromeSprites(indices)\n                | PaintOperation::SubpixelSprites(indices) => {').replace('                    for index in record.indices.clone() {','                    for index in indices.clone() {')
source=source.replace('    MonochromeSprites(GlyphPaintRecord),\n    SubpixelSprites(GlyphPaintRecord),','    MonochromeSprites(Range<usize>),\n    SubpixelSprites(Range<usize>),')
start=source.index('pub(crate) struct GlyphPaintRecord {');end=source.index('\n#[derive(Clone)]\n',start)
source=source[:start]+'''impl PaintOperation {
    fn glyph_indices(&self) -> Option<(bool, Range<usize>)> {
        match self {
            Self::MonochromeSprites(indices) => Some((false, indices.clone())),
            Self::SubpixelSprites(indices) => Some((true, indices.clone())),
            Self::Primitive(_) | Self::StartLayer(_) | Self::EndLayer => None,
        }
    }

    fn glyphs(subpixel: bool, indices: Range<usize>) -> Self {
        if subpixel {
            Self::SubpixelSprites(indices)
        } else {
            Self::MonochromeSprites(indices)
        }
    }
}
''' +source[end:]
assert 'GlyphPaintRecord' not in source and 'record.published' not in source and 'record.indices' not in source
(worktree/'crates/gpui/src/scene.rs').write_text(source)
(worktree/'crates/gpui/src/window/view_retention/tests.rs').write_text((previous/'crates/gpui/src/window/view_retention/tests.rs').read_text())
(root/'tail-state-write-path-audit.json').write_text(json.dumps({'owned_input_source':'7b351af5175206fb3727cd02fa2eca277f56e249','non_glyph_barriers':['push_clipped_layer','pop_layer','insert_primitive'],'fresh_glyph_append_paths':['append_glyph_record via push_glyph_record','cached monochrome replay via push_glyph_record','cached subpixel replay via push_glyph_record'],'clear_resets_both_flags':True,'scene_len_no_heap_tail_lookup':True,'no_record_flag_or_scalar_promotion':True,'no_gain_claim':True},indent=2)+'\n')
