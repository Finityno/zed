from pathlib import Path
import json,hashlib,statistics,sys
r=Path(__file__).parent;p=json.loads((r/'policy.json').read_text());assert hashlib.sha256((r/'policy.json').read_bytes()).hexdigest()==(r/'policy.sha256').read_text().strip();summary=[];failures=[];kinds=['bare'] if '--bare-only' in sys.argv else ['bare','census'];cpu_gains=[]
for kind in kinds:
 pairs=p['timing_pairs'] if kind=='bare' else p['memory_pairs'];cases=p['controls']+(p['standalone_scene_memory_controls'] if kind=='census' else []);rows=json.loads((r/(kind+'-samples.json')).read_text());assert len(rows)==len(cases)*pairs*2
 for case in cases:
  standalone=case in p['standalone_scene_memory_controls'];lanes={lane:[v for v in rows if v['case']==case and v['lane']==lane] for lane in ['baseline','candidate']};assert all(len(v)==pairs and all(row['exit_code']==0 for row in v) for v in lanes.values())
  for pair in range(pairs):
   b=next(v for v in lanes['baseline'] if v['pair']==pair);c=next(v for v in lanes['candidate'] if v['pair']==pair)
   for field in ['signature','frame_hash','state_count','state_box_bytes','frames','nodes','node_high_water','count','window_closed']:
    if field in b or field in c:assert b[field]==c[field],(kind,case,pair,field,b.get(field),c.get(field))
   if standalone:
    assert b['after_drop_bytes']==c['after_drop_bytes']==0
    assert c['scene_width']-b['scene_width']<=p['scene_fixed_header_budget_bytes']
   else:
    assert b['record_owner']['logical_overlay_index']==c['record_owner']['logical_overlay_index']
    for scene in ['rendered','spare']:
     bo=b['record_owner'][scene];co=c['record_owner'][scene];assert bo['width']==co['width']==184
     assert co['scene_width']-bo['scene_width']<=p['scene_fixed_header_budget_bytes']
     assert co['window_width']-bo['window_width']<=p['heap_fixed_header_budget_bytes_per_window']
  fields=['cpu_ns','elapsed_ns','child_cpu_ns','current_rss_kib','peak_rss_kib'] if kind=='bare' else ['held_bytes','peak_bytes','requested_bytes','allocation_calls','current_rss_kib','peak_rss_kib']
  if kind=='census' and case in p['primary']:fields+=['record_owner_bytes']
  entry={'kind':kind,'case':case,'fields':{}}
  for field in fields:
   base=[v[field] for v in lanes['baseline']];cand=[v[field] for v in lanes['candidate']];bm=statistics.median(base);cm=statistics.median(cand);br=max(base)-min(base);cr=max(cand)-min(cand);delta=cm-bm;gain=-delta/bm if bm else 0;target=None
   primary=kind=='census' and case in p['primary'] and field in ['held_bytes','record_owner_bytes']
   if primary:
    target=p['primary_live_gain_fraction'] if field=='held_bytes' else p['primary_record_gain_fraction'];passed=gain>=target and -delta>max(br,cr);budget=None;gate='declared_owner_live_primary_above_both_full_ranges'
   else:
    budget=(p['scene_fixed_header_budget_bytes']*lanes['baseline'][0]['count'] if standalone else p['heap_fixed_header_budget_bytes_per_window']) if field in ['held_bytes','peak_bytes','requested_bytes'] else 0 if field=='allocation_calls' else br;passed=delta<=budget;gate='predeclared_fixed_header_only_or_full_baseline_range_control'
   metric={'baseline_median':bm,'candidate_median':cm,'delta':delta,'fraction_gain':gain,'baseline_range':br,'candidate_range':cr,'budget':budget,'target_fraction':target,'gate':gate,'pass':passed};entry['fields'][field]=metric
   if not passed:failures.append({'kind':kind,'case':case,'field':field,**metric})
   if kind=='bare' and field in ['cpu_ns','elapsed_ns'] and gain>=0.05 and -delta>max(br,cr):cpu_gains.append({'case':case,'field':field,**metric})
  summary.append(entry)
name='bare-only-decision' if len(kinds)==1 else 'decision';(r/('bare-only-summary.json' if len(kinds)==1 else 'summary.json')).write_text(json.dumps(summary,indent=2)+'\n');decision={'qualified':not failures and len(kinds)==2,'status':'PERFORMANCE_GATES_PASS_PENDING_OWNING_CHECKS_REVIEW' if not failures and len(kinds)==2 else 'HELD_UNMERGED' if failures else 'BARE_PASS_PENDING_CENSUS','failures':failures,'controls':len(p['controls']),'standalone_memory_controls':len(p['standalone_scene_memory_controls']),'native_children':sum((len(p['controls'])+(len(p['standalone_scene_memory_controls']) if k=='census' else 0))*(p['timing_pairs'] if k=='bare' else p['memory_pairs'])*2 for k in kinds),'primary':[v for v in summary if v['kind']=='census' and v['case'] in p['primary']],'secondary_CPU_fields_meeting_predeclared5percent_and_both_ranges':cpu_gains,'policy_sha256':hashlib.sha256((r/'policy.json').read_bytes()).hexdigest(),'no_unchanged_resampling':True,'no_app_GPU_platform_gain':True,'fixed_header_budget_bytes_per_window':p['heap_fixed_header_budget_bytes_per_window'],'fixed_header_budget_bytes_per_scene':p['scene_fixed_header_budget_bytes']};(r/(name+'.json')).write_text(json.dumps(decision,indent=2)+'\n');print(json.dumps({'qualified':decision['qualified'],'children':decision['native_children'],'failed_fields':len(failures),'failures':[(f['kind'],f['case'],f['field'],f['delta'],f['budget']) for f in failures],'primary':[(v['case'],v['fields']['held_bytes']['fraction_gain'],v['fields']['record_owner_bytes']['fraction_gain']) for v in decision['primary']],'secondary_cpu_fields_above5_and_ranges':len(cpu_gains)}))
