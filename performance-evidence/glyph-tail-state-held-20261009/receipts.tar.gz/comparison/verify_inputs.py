from pathlib import Path
import json,hashlib,subprocess,sys,time,os
r=Path(__file__).parent;stage=sys.argv[1];assert hashlib.sha256((r/'policy.json').read_bytes()).hexdigest()==(r/'policy.sha256').read_text().strip()
compiler=json.loads((r/'compiler-dependency-identities.json').read_text());assert hashlib.sha256(Path(compiler['compiler_path']).read_bytes()).hexdigest()==compiler['compiler_sha256']
for lane in ['baseline','candidate']:
 w=r/(lane+'-workspace');manifest=json.loads((r/(lane+'-source-inputs.json')).read_text())['files']
 for path,sha in manifest.items():assert hashlib.sha256((w/path).read_bytes()).hexdigest()==sha,(lane,path)
for dep in json.loads((r/'external-dependencies.json').read_text()):assert hashlib.sha256(Path(dep['path']).read_bytes()).hexdigest()==dep['sha256']
for lane in json.loads((r/'binary-identities.json').read_text()).values():
 for binary in lane.values():assert hashlib.sha256(Path(binary['path']).read_bytes()).hexdigest()==binary['sha256']
for path,sha in json.loads((r/'native-runtime-identity.json').read_text())['libraries'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==sha
identity=json.loads((r/'candidate-source-receipt.json').read_text());repo=Path('/workspace/zed-glyph-tail-state')
for path,sha in identity['files'].items():assert hashlib.sha256((repo/path).read_bytes()).hexdigest()==sha
processes=subprocess.check_output(['ps','-eo','pid,ppid,etimes,%cpu,comm'],text=True);(r/(stage+'-verification.json')).write_text(json.dumps({'stage':stage,'verified_unix':time.time(),'all_source_dep_compiler_runtime_binaries_policy_unchanged':True,'source':identity['source'],'process_snapshot':processes},indent=2)+'\n');print(json.dumps({'stage':stage,'all_inputs_unchanged':True}))
