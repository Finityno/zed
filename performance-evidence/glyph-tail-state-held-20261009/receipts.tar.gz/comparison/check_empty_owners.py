from pathlib import Path
import hashlib, json, os, subprocess

root = Path(__file__).parent
policy = json.loads((root / 'policy.json').read_text())
binaries = json.loads((root / 'binary-identities.json').read_text())
out = root / 'empty-owner-correctness'
out.mkdir()
rows = []
for case in policy['standalone_scene_memory_controls']:
    pair = []
    for lane in ['baseline', 'candidate']:
        binary = binaries[lane]['census']
        command = [str(root / 'native-run'), binary['path'], 'profile_empty_scene_owner', '--ignored', '--nocapture', '--test-threads=1']
        path = out / f'{case}-{lane}.log'
        with path.open('w') as stream:
            result = subprocess.run(command, env=os.environ | {'RECORD_PROFILE_CASE': case}, stdout=stream, stderr=subprocess.STDOUT, timeout=60)
        row = {'case': case, 'lane': lane, 'command': command, 'exit_code': result.returncode, 'log': str(path), 'log_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'binary_sha256': binary['sha256']}
        for line in path.read_text().splitlines():
            if 'SCENE_OWNER_PROFILE ' in line:
                row.update(json.loads(line.split('SCENE_OWNER_PROFILE ', 1)[1]))
        assert result.returncode == 0 and row['after_drop_bytes'] == 0, row
        rows.append(row)
        pair.append(row)
        (root / 'empty-owner-correctness-receipts.json').write_text(json.dumps(rows, indent=2) + '\n')
    before, after = pair
    assert after['scene_width'] - before['scene_width'] <= policy['scene_fixed_header_budget_bytes']
    for field in ['held_bytes', 'peak_bytes', 'requested_bytes']:
        assert after[field] - before[field] <= policy['scene_fixed_header_budget_bytes'] * before['count'], (case, field, before[field], after[field])
    assert after['allocation_calls'] <= before['allocation_calls']
print(json.dumps({'children': len(rows), 'all_owners_released': True, 'predeclared_header_only': True}))
