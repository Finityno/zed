use super::*;
use std::{hint::black_box, hash::{Hash, Hasher}};

#[test]
#[ignore]
fn profile_empty_record_window() {
    struct Empty;
    impl Render for Empty {
        fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement { div() }
    }
    let case = std::env::var("RECORD_PROFILE_CASE").expect("case");
    let iterations: usize = std::env::var("RECORD_PROFILE_ITERATIONS").expect("iterations").parse().expect("iterations");
    let retained = case.ends_with("on");
    #[cfg(gpui_layout_sets_census)] crate::perf_count::census::start();
    let mut cx = super::super::super::layout_retention_tests::text_system_context(0);
    cx.update(|cx| cx.set_view_retention(retained));
    let window = cx.add_window(|_, _| Empty);
    for _ in 0..4 { cx.update_window(window.into(), |_, window, cx| window.draw(cx).clear(cx)).expect("warm"); }
    cx.update_window(window.into(), |_, window, _| window.reset_frame_work_stats(false)).expect("disable clocks");
    let audit_frames = std::env::var_os("LAYOUT_AUDIT_FRAMES").is_some();
    let mut audit = Vec::with_capacity(if audit_frames { iterations } else { 0 });
    let cpu_started = super::splice_profile::thread_cpu_ns();
    let started = std::time::Instant::now();
    for _ in 0..iterations {
        window.update(&mut cx, |_, _, cx| cx.notify()).expect("notify");
        cx.update_window(window.into(), |_, window, cx| window.draw(cx).clear(cx)).expect("draw");
        if audit_frames { audit.push(cx.update_window(window.into(), |_, window, _| describe_frame(window)).expect("audit")); }
        black_box(&cx);
    }
    let cpu_ns = super::splice_profile::thread_cpu_ns() - cpu_started;
    let elapsed_ns = started.elapsed().as_nanos();
    let (signature, owners, raw_overlay_index, logical_overlay_index) = cx.update_window(window.into(), |_, window, _| {
        let mut hasher = std::collections::hash_map::DefaultHasher::new();describe_frame(window).hash(&mut hasher);
        let owner = |scene: &crate::Scene| scene.diagnostic_record_owner_tuple();
        (hasher.finish(), (owner(&window.rendered_frame.scene), owner(&window.next_frame.scene)), window.rendered_frame.overlay_scene_start, window.rendered_frame.scene.diagnostic_expanded_paint_index(window.rendered_frame.overlay_scene_start))
    }).expect("owner");
    #[cfg(gpui_layout_sets_census)] let (held_bytes, _, _, _) = crate::perf_count::census::snapshot();
    #[cfg(not(gpui_layout_sets_census))] let held_bytes = -1;
    cx.update_window(window.into(), |_, window, _| window.remove_window()).expect("close");
    assert!(cx.update_window(window.into(), |_, _, _| ()).is_err());
    #[cfg(gpui_layout_sets_census)] let (after_close_bytes, peak_bytes, requested_bytes, allocation_calls) = crate::perf_count::census::finish();
    #[cfg(not(gpui_layout_sets_census))] let (after_close_bytes, peak_bytes, requested_bytes, allocation_calls) = (-1, -1, 0, 0);
    let describe = |owner: (usize, usize, usize, usize, usize, usize)| serde_json::json!({"length":owner.0,"capacity":owner.1,"width":owner.2,"bytes":owner.3,"scene_width":owner.4,"window_width":owner.5});
    let owner = serde_json::json!({"rendered":describe(owners.0),"spare":describe(owners.1),"raw_overlay_index":raw_overlay_index,"logical_overlay_index":logical_overlay_index});
    println!("LINE_RECORD_OWNER {}", owner);
    let current_rss_kib = crate::perf_count::native_current_rss_kib();
    if audit_frames { let mut hasher = std::collections::hash_map::DefaultHasher::new();audit.hash(&mut hasher);println!("FRAME_AUDIT {}",hasher.finish()); }
    println!("RECORD_WINDOW_PROFILE {}",serde_json::json!({"case":case,"iterations":iterations,"cpu_ns":cpu_ns,"elapsed_ns":elapsed_ns,"signature":signature,"after_close_bytes":after_close_bytes,"window_closed":true,"held_bytes":held_bytes,"peak_bytes":peak_bytes,"requested_bytes":requested_bytes,"allocation_calls":allocation_calls,"current_rss_kib":current_rss_kib}));
}

#[test]
#[ignore]
fn profile_empty_scene_owner() {
    let case = std::env::var("RECORD_PROFILE_CASE").expect("case");
    let count: usize = case.rsplit('-').next().expect("count").parse().expect("integer");
    #[cfg(gpui_layout_sets_census)] crate::perf_count::census::start();
    let mut owners = Vec::new();
    for _ in 0..count { owners.push(Box::new(crate::Scene::default())); }
    black_box(&owners);
    #[cfg(gpui_layout_sets_census)] let (held_bytes, peak_bytes, requested_bytes, allocation_calls) = crate::perf_count::census::snapshot();
    #[cfg(not(gpui_layout_sets_census))] let (held_bytes, peak_bytes, requested_bytes, allocation_calls) = (-1, -1, 0, 0);
    drop(owners);
    #[cfg(gpui_layout_sets_census)] let (after_drop_bytes, _, _, _) = crate::perf_count::census::finish();
    #[cfg(not(gpui_layout_sets_census))] let after_drop_bytes = -1;
    let current_rss_kib = crate::perf_count::native_current_rss_kib();
    println!("SCENE_OWNER_PROFILE {}",serde_json::json!({"case":case,"count":count,"scene_width":std::mem::size_of::<crate::Scene>(),"held_bytes":held_bytes,"peak_bytes":peak_bytes,"requested_bytes":requested_bytes,"allocation_calls":allocation_calls,"after_drop_bytes":after_drop_bytes,"current_rss_kib":current_rss_kib}));
}
