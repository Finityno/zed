from pathlib import Path
import os,json,subprocess,hashlib,sys
r=Path(__file__).parent;p=json.loads((r/'policy.json').read_text());bins=json.loads((r/'binary-identities.json').read_text());kind=sys.argv[1];pairs=p['timing_pairs'] if kind=='bare' else p['memory_pairs'];iterations=p['timing_iterations'] if kind=='bare' else p['memory_iterations'];out=r/(kind+'-receipts');out.mkdir();rows=[];policy_hash=hashlib.sha256((r/'policy.json').read_bytes()).hexdigest()
def guard_host():
 forbidden={'rustc','cargo','cc','gcc','clang','cmake','make','ninja','gzip','pigz','zstd','sha256sum','b3sum','perf','hyperfine'}
 snapshot=subprocess.check_output(['ps','-eo','pid,stat,comm,args'],text=True)
 conflicts=[]
 for line in snapshot.splitlines()[1:]:
  parts=line.split(None,3)
  if len(parts)<4 or parts[1].startswith('Z'):continue
  pid,state,comm,args=parts
  if comm in forbidden or comm.startswith('gpui-') or (comm.startswith('python') and any(n in args for n in ['build_native.py','build_remaining.py','measure_diagnostic.py','package_held.py'])):conflicts.append(line)
 if conflicts:
  (r/(kind+'-host-conflict.txt')).write_text(snapshot)
  raise RuntimeError(('Timing/profiling blocked by activehost work',conflicts))
for case in p['controls'] + (p['standalone_scene_memory_controls'] if kind=='census' else []):
 for pair in range(pairs):
  for lane in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
   guard_host()
   binary=bins[lane][kind];assert hashlib.sha256(Path(binary['path']).read_bytes()).hexdigest()==binary['sha256']
   case_iterations=iterations
   pattern='profile_empty_scene_owner' if case in p['standalone_scene_memory_controls'] else 'profile_empty_record_window' if case in p['new_window_controls'] else 'profile_owned_layout_cache' if case in p['layout_cases'] else 'profile_transcript_paint' if case in p['transcript_cases'] else 'profile_colored_transcript' if case in p['color_cases'] else 'profile_layout_key_sets';command=[str(r/'native-run'),'taskset','-c','2',binary['path'],pattern,'--ignored','--nocapture','--test-threads=1'];env=os.environ|{'RECORD_PROFILE_CASE':case,'RECORD_PROFILE_ITERATIONS':str(case_iterations),'LAYOUT_OWNER_CASE':case,'LAYOUT_OWNER_ITERATIONS':str(case_iterations),'TRANSCRIPT_PROFILE_CASE':case,'TRANSCRIPT_PROFILE_ITERATIONS':str(case_iterations),'LAYOUT_SETS_PROFILE_CASE':case,'LAYOUT_SETS_PROFILE_ITERATIONS':str(case_iterations),'COLOR_PROFILE_CASE':case,'COLOR_PROFILE_ITERATIONS':str(case_iterations)};path=out/f'{case}-{pair:02}-{lane}.log'
   with path.open('w') as f:result=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=70)
   row={'case':case,'pair':pair,'kind':kind,'lane':lane,'command':command,'exit_code':result.returncode,'log':str(path),'log_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'binary_sha256':binary['sha256'],'policy_sha256':policy_hash}
   for line in path.read_text().splitlines():
    for marker in ['LAYOUT_OWNER ','TRANSCRIPT_PROFILE ','LAYOUT_SETS_PROFILE ','COLOR_PROFILE ','RECORD_WINDOW_PROFILE ','SCENE_OWNER_PROFILE ']:
     if marker in line:row.update(json.loads(line.split(marker,1)[1]))
    if 'LINE_RECORD_OWNER ' in line:
     row['record_owner']=json.loads(line.split('LINE_RECORD_OWNER ',1)[1]);row['record_owner_bytes']=sum(v['bytes'] for k,v in row['record_owner'].items() if k in ['rendered','spare'])
    if line.startswith('NATIVE_RECEIPT '):row.update(json.loads(line.split(' ',1)[1]));row['child_cpu_ns']=(row['user_cpu_us']+row['system_cpu_us'])*1000
   rows.append(row);(r/(kind+'-samples.json')).write_text(json.dumps(rows,indent=2)+'\n');assert result.returncode==0 and ('held_bytes' in row if case in p['standalone_scene_memory_controls'] else 'cpu_ns' in row),path.read_text()
print(json.dumps({'kind':kind,'children':len(rows),'all_exit_zero':True}))
