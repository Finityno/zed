from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,tarfile,time
root=Path(__file__).parent; comparison=root/'comparison';workspace=Path('/workspace/zed-marker-state-checks')
decision=json.loads((comparison/'decision.json').read_text());assert decision['status']=='HELD_UNMERGED'
snapshot=subprocess.check_output(['ps','-eo','pid,stat,comm,args'],text=True)
for line in snapshot.splitlines()[1:]:
 values=line.split(None,3)
 if len(values)!=4 or values[1].startswith('Z') or int(values[0])==os.getpid():continue
 assert values[2] not in ['rustc','cargo','cc','gzip','pigz','zstd','perf'] and not values[2].startswith('gpui-')
 if values[2].startswith('python'):assert not any(name in values[3] for name in ['measure.py','run_metric_phase.py','build_native.py'])
for name,digest in json.loads((comparison/'measurement-tool-identities.json').read_text()).items():assert hashlib.sha256((comparison/name).read_bytes()).hexdigest()==digest
binaries=json.loads((comparison/'binary-identities.json').read_text());policy_sha=(comparison/'policy.sha256').read_text().strip();phases={}
for kind,count in [('bare',1620),('census',420)]:
 samples=json.loads((comparison/(kind+'-samples.json')).read_text());assert len(samples)==count
 for row in samples:
  assert row['exit_code']==0 and row['policy_sha256']==policy_sha and row['binary_sha256']==binaries[row['lane']][kind]['sha256']
  assert hashlib.sha256(Path(row['log']).read_bytes()).hexdigest()==row['log_sha256']
 receipt=json.loads((comparison/(kind+'-measurement-receipt.json')).read_text());assert receipt['exit_code']==0 and not receipt['timed_out']
 assert hashlib.sha256((comparison/(kind+'-measurement.log')).read_bytes()).hexdigest()==receipt['log_sha256'];phases[kind]=receipt
assert phases['census']['started_unix']>=phases['bare']['started_unix']+phases['bare']['elapsed_seconds']
subprocess.run(['python3','verify_inputs.py','final-held'],cwd=comparison,check=True)
identity=json.loads((root/'candidate-source-receipt.json').read_text());rel='crates/gpui/src/window/view_retention/dependencies.rs'
assert (workspace/rel).read_bytes()==(comparison/'candidate-workspace'/rel).read_bytes()
(comparison/'candidate-exact-production-proof.json').write_text(json.dumps({'source':identity['source'],'compiled_candidate_dependencies_file_byte_exact_to_reviewed_source':True,'normal_checker_original_body_byte_exact':True,'small_original_body_after_threshold_byte_exact':True,'different_lane_production_files':[rel],'all_other_final_private_fixtures_identical':True},indent=2)+'\n')
(root/'completed-raw-receipt-proof.json').write_text(json.dumps({'children':2040,'all_source_compiler59_runtime_binaries_policy_tools_and_raw_logs_verified':True,'actual_bare_outer_exit':0,'actual_census_outer_exit':0,'all_native_exits_zero':True,'phases_sequential':True,'host_guard_before_each_child':True,'no_cohort_repeat':True,'process_snapshot':snapshot},indent=2)+'\n')
nonzero=[{key:row[key] for key in ['lane','case','pair','held_bytes','peak_bytes','requested_bytes','allocation_calls']} for row in json.loads((comparison/'census-samples.json').read_text()) if row['held_bytes']!=0]
(root/'census-live-outliers.json').write_text(json.dumps({'all_nonzero_samples':nonzero,'counter_scope':'Counting-System with const TLS enable on the checking thread. Both native scope regressions count foreground1234bytes/one call, exclude synchronized worker7777bytes and release all owner bytes. All420 owner samples have zero held bytes. Whole-child current/peak RSS and additional census CPU gates remain required.','no_resample':True},indent=2)+'\n')
preserved=[]
for lanes in binaries.values():
 for binary in lanes.values():
  path=Path(binary['path']);status=path.stat();assert hashlib.sha256(path.read_bytes()).hexdigest()==binary['sha256'];target=path.with_name(path.name+'.preserved.gz')
  with path.open('rb') as source,target.open('xb') as raw:
   with gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=6,mtime=0) as compressed:shutil.copyfileobj(source,compressed,1024*1024)
  digest=hashlib.sha256()
  with gzip.open(target,'rb') as stream:
   for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
  assert digest.hexdigest()==binary['sha256']
  preserved.append({'path':str(path),'sha256':binary['sha256'],'bytes':status.st_size,'mode':status.st_mode&0o777,'mtime_ns':status.st_mtime_ns,'gzip':str(target),'gzip_bytes':target.stat().st_size,'gzip_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'roundtrip_verified':True});path.unlink()
(root/'completed-native-preservation.json').write_text(json.dumps({'files':preserved,'reclaimed_bytes':sum(item['bytes']-item['gzip_bytes'] for item in preserved),'no_timing_or_build_active':True},indent=2)+'\n')
public=workspace/'performance-evidence/marker-state-reconciliation-held-20261009';public.mkdir(parents=True)
files=[]
for path in root.rglob('*'):
 if not path.is_file():continue
 relative=path.relative_to(root)
 if any(part=='__pycache__' or part.endswith('-artifacts') for part in relative.parts) and path.suffix!='.d':continue
 if path.name.endswith('.pyc') or path.name.endswith('.preserved.gz'):continue
 files.append((str(relative),path))
archive=root/'receipts.tar.gz';seen={};links=0
with tarfile.open(archive,'w:gz',compresslevel=6) as stream:
 for name,path in sorted(files):
  stat=path.stat();key=(hashlib.sha256(path.read_bytes()).hexdigest(),stat.st_size,stat.st_mode,stat.st_mtime_ns);info=stream.gettarinfo(str(path),arcname=name)
  if key in seen:info.type=tarfile.LNKTYPE;info.linkname=seen[key];info.size=0;stream.addfile(info);links+=1
  else:
   seen[key]=name
   with path.open('rb') as data:stream.addfile(info,data)
expected=dict(files);resolved={}
with tarfile.open(archive,'r|gz') as stream:
 for member in stream:
  actual=resolved[member.linkname] if member.islnk() else hashlib.sha256(stream.extractfile(member).read()).hexdigest();assert actual==hashlib.sha256(expected[member.name].read_bytes()).hexdigest();resolved[member.name]=actual
assert len(resolved)==len(files)
raw=archive.read_bytes();parts=[]
for number,begin in enumerate(range(0,len(raw),8*1024*1024)):
 path=public/('receipts.tar.gz' if len(raw)<=8*1024*1024 else f'receipts.tar.gz.part-{number:03}');path.write_bytes(raw[begin:begin+8*1024*1024]);parts.append({'path':str(path.relative_to(workspace)),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
assert b''.join((workspace/item['path']).read_bytes() for item in parts)==raw
metadata={'production_source':identity['source'],'baseline':identity['baseline'],'archive_sha256':hashlib.sha256(raw).hexdigest(),'archive_bytes':len(raw),'archive_members':len(files),'identical_member_hardlinks':links,'all_members_byte_exact_roundtrip':True,'children':2040,'failed_fields':len(decision['failures']),'all_four_primary_bare_CPU_elapsed_20percent_and_variation_gates_pass':True,'all_primary_census_transient_allocations_eliminated':True,'all12_complete_Window_bare_controls_pass':True,'all_bare_CPU_elapsed_childCPU_current_peak_RSS_controls_pass':True,'all_requested_heap_churn_controls_pass':True,'both_native_owner_scope_regressions_pass':True,'held':True,'merged':False,'never_resample_unchanged':True,'no_app_GPU_platform_shipped_allocator_gain':True,'parts':parts}
(root/'archive-verification.json').write_text(json.dumps(metadata,indent=2)+'\n');(public/'evidence.json').write_text(json.dumps(metadata,indent=2)+'\n')
for name in ['decision.json','decision-summary.json','policy.json','policy.sha256','correctness-summary.json','compiler-dependency-identities.json','external-dependencies.json','binary-identities.json','native-runtime-identity.json','candidate-source-receipt.json','candidate-exact-production-proof.json','measurement-tool-identities.json']:shutil.copy2(comparison/name,public/name)
for name in ['source-equivalence.json','completed-raw-receipt-proof.json','census-live-outliers.json','allocator-scope-identity.json','execution-protocol.json']:shutil.copy2(root/name,public/name)
(public/'README.md').write_text('''# Held marker-present bounded state reconciliation

This distinct routing design is held and unmerged. Its first2,040 fresh native
children cover42 complete-App check cases and12 complete-Window controls. Only
marker-present lists of at least64 states enter the outlined reconciliation
kernel; the original marker-presence scan, absent-marker path, normal checker
and small-list body are preserved. This removes the prior held design's measured
absent-marker double traversal. No failed design was repeated unchanged.

All four primary bare CPU and elapsed targets pass:59.67–89.14% lower thread CPU,
above both full lane ranges and the frozen20% goal. Every bare CPU, elapsed,
whole-child CPU and current/peak RSS control passes, including all12 complete
Window workloads. All requested live/peak/bytes/calls controls pass, with primary
transient allocations eliminated and zero held owner bytes in all420 census
children. No new App/Window fields, cache, persistent owner or fixed heap/header
budget exists.

Four other fields fail. Census current RSS for the8-state marker-first case
rises232 KiB against its216 KiB baseline range. Peak RSS for the256-state normal
changed case rises192 KiB against172 KiB. The additionally strict census empty
exception-check CPU and elapsed medians rise15,262/15,193 ns across32,768 calls,
against240/160 ns full baseline ranges. These remain failures; no Clippy, PR,
merge or consumer adoption was attempted. Never rerun this design unchanged
or weaken its gates.

The requested-memory fixture uses System forwarding with a const TLS enable on
the checking foreground thread. This synchronous complete-App checker creates
and drops filtered snapshots locally; no measured ownership crosses threads.
Two native scope regressions prove1234 foreground bytes/one call counted exactly,
7777 synchronized worker bytes excluded, and zero owner bytes after release.
Whole-child native RSS still includes every thread. The prior held process-global
144-byte outliers remain archived and untraced; no original owner is guessed.
Both lanes use identical foreground-scope allocator source and exact identities.

All62 correctness children pass:654 suite/fixture passes, matched frame histories
for all12 retention on/off, resize, state-update and row-removal cases; state
oracle63/64/65/128/256 boundaries and32 state/entity/global/deadline combinations;
layout, atomic claims, input and retained-frame contracts. Source proof preserves
the normal checker and original exception method after removing only the new
marker-present threshold guard. Four final native binaries use the same compiler,
immutable59 dependency objects and runtime. Both actual external deadline phases
complete successfully in sequence, every raw child signature matches, and every
source/policy/tool/log identity is verified. Setup spelling assertion fired before
source modification and is preserved; no sample cohort was repeated.

Archive parts and all members are verified byte-for-byte. Completed native
binaries remain losslessly preserved in the managed workspace with round-trip
hashes. These are Linux fake-platform/System component results, not whole-app,
physical GPU, macOS/Windows, shipped-allocator or Fincode adoption percentages.
Continue with a distinct bounded typed glyph dispatcher for the owned transcript
paint-replay bottleneck, preserving small ranges and generic animated/moved
semantics. No runtime glyph-span scanner is repeated unchanged.
''')
env=os.environ|{'GIT_NO_LAZY_FETCH':'1'}
subprocess.run(['git','diff','--check'],cwd=workspace,env=env,check=True)
subprocess.run(['git','add','--sparse',str(public.relative_to(workspace))],cwd=workspace,env=env,check=True)
subprocess.run(['git','commit','-m','Preserve held marker-present state routing and census controls [skip ci]'],cwd=workspace,env=env,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=workspace,env=env,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=workspace,env=env,text=True).strip();paths=subprocess.check_output(['git','diff','--name-only',identity['baseline'],head],cwd=workspace,env=env,text=True).splitlines();manifest=[]
for path in paths:
 file=workspace/path;manifest.append({'path':path,'local':str(file),'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'git_blob':subprocess.check_output(['git','hash-object',str(file)],cwd=workspace,text=True).strip()})
(root/'publication-manifest.json').write_text(json.dumps({'local_head':head,'tree':tree,'parent':identity['baseline'],'files':manifest},indent=2)+'\n')
hp=Path('/workspace/scratch/gpui-fork-loop/handoff.json');handoff=json.loads(hp.read_text());handoff['held_iterations']['marker_state_reconciliation_20261009']=metadata|{'local_held_head':head,'tree':tree,'branch':'perf/marker-state-reconciliation-20261009','directory':str(root),'publication_pending':True};handoff['active_supervisor_pid']=None;handoff['active_session']=None;handoff['next_iteration']['supervisor_pid']=None;handoff['next_iteration']['active_stage']='Held marker-present source003fc897:2040 children, allfour primary CPU/heap targets and allbare/12Window controls pass; four census fields fail. Exact source/raw archive packaged, owned publication pending; continue distinct bounded typed glyph replay.';handoff['phase']=handoff['next_iteration']['active_stage'];handoff['next_steps']=['Publish held owned branch and verify every blob/whole tree/parent/ref; no PR/merge/resampling.','Continue distinct bounded typed glyph dispatcher on current owned main, preserving original small-range replay; freeze5percent full-Window CPU goals and prior original58 controls plus current scenes/layout/overlay safeguards. No runtime glyph-span/scanner repeat.'];hp.write_text(json.dumps(handoff,indent=2)+'\n')
print(json.dumps(metadata|{'local_held_head':head,'tree':tree,'publication_files':len(manifest)}))
