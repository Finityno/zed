from pathlib import Path
import argparse, hashlib, json, os, subprocess, time

parser = argparse.ArgumentParser()
parser.add_argument('name')
parser.add_argument('seconds', type=int)
parser.add_argument('command', nargs=argparse.REMAINDER)
arguments = parser.parse_args()
root = Path(__file__).parent / 'comparison'
command = arguments.command
if command and command[0] == '--':
    command = command[1:]
assert command
receipt_path = root / (arguments.name + '-detached-launch.json')
assert not receipt_path.exists(), 'A launched phase must be recovered, never duplicated'
assert not (root / (arguments.name + '-receipt.json')).exists()
snapshot = subprocess.check_output(['ps', '-eo', 'pid,stat,comm,args'], text=True)
for line in snapshot.splitlines()[1:]:
    values = line.split(None, 3)
    if len(values) != 4 or values[1].startswith('Z') or int(values[0]) == os.getpid():
        continue
    assert values[2] not in {'rustc', 'cargo', 'cc', 'gcc', 'clang', 'gzip', 'pigz', 'zstd', 'sha256sum', 'b3sum', 'perf', 'hyperfine'}
    assert not values[2].startswith('gpui-')
    if values[2].startswith('python'):
        assert not any(name in values[3] for name in ['measure.py', 'measure_diagnostic.py', 'build_native.py', 'build_remaining.py', 'package_held.py', 'preserve_inactive_cache.py'])
supervised = ['python3', str(root / 'supervise.py'), '--seconds', str(arguments.seconds), '--name', arguments.name, '--cwd', str(root), '--', *command]
with (root / (arguments.name + '-detached-launch.log')).open('xb') as output:
    process = subprocess.Popen(supervised, cwd=root, stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    receipt = {'supervisor_pid': process.pid, 'command': supervised, 'started_unix': time.time(), 'supervisor_sha256': hashlib.sha256((root / 'supervise.py').read_bytes()).hexdigest(), 'detached_outer_deadline_survives_tool_session_loss': True, 'initial_process_snapshot': snapshot, 'no_completion_claim_from_launch': True}
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
handoff_path = Path('/workspace/scratch/gpui-fork-loop/handoff.json')
handoff = json.loads(handoff_path.read_text())
handoff['active_session'] = None
handoff['next_iteration']['active_session'] = None
handoff['next_iteration']['supervisor_pid'] = process.pid
handoff['next_iteration']['active_stage'] = arguments.name + ' active under detached external process-group deadline; recover actual PID/receipt before continuation; never duplicate.'
handoff['phase'] = handoff['next_iteration']['active_stage']
handoff_path.write_text(json.dumps(handoff, indent=2) + '\n')
print({'phase': arguments.name, 'supervisor_pid': process.pid, 'external_deadline_seconds': arguments.seconds})
