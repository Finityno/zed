from pathlib import Path
root=Path(__file__).parent
old=Path('/workspace/scratch/gpui-bounded-state-loop/finalize_held.py').read_text()
s=old.replace('/workspace/zed-bounded-state-checks','/workspace/zed-marker-state-checks').replace('bounded-state-reconciliation-held-20261009','marker-state-reconciliation-held-20261009').replace('bounded_state_reconciliation_20261009','marker_state_reconciliation_20261009').replace('perf/bounded-state-reconciliation-20261009','perf/marker-state-reconciliation-20261009')
s=s.replace("'counter_scope':'Process-global counting-System allocator, includes other child threads while enabled. Two extra allocations totaling144 bytes occur in four children; their allocating thread/owner was not traced. No attribution to the checker or removal from gates. Preserve as adverse and retain the two candidate all-samples-zero failures.'","'counter_scope':'Counting-System with const TLS enable on the checking thread. Both native scope regressions count foreground1234bytes/one call, exclude synchronized worker7777bytes and release all owner bytes. All420 owner samples have zero held bytes. Whole-child current/peak RSS and additional census CPU gates remain required.'")
s=s.replace("'all12_complete_Window_bare_controls_pass':True","'all12_complete_Window_bare_controls_pass':True,'all_bare_CPU_elapsed_childCPU_current_peak_RSS_controls_pass':True,'all_requested_heap_churn_controls_pass':True,'both_native_owner_scope_regressions_pass':True")
s=s.replace("'prepaired-fixture-contract-correction.json','execution-protocol.json'","'allocator-scope-identity.json','execution-protocol.json'")
a=s.index("(public/'README.md').write_text('''");b=s.index("''')\nenv=os.environ",a)
s=s[:a]+"""(public/'README.md').write_text('''# Held marker-present bounded state reconciliation

This distinct routing design is held and unmerged. Its first2,040 fresh native
children cover42 complete-App check cases and12 complete-Window controls. Only
marker-present lists of at least64 states enter the outlined reconciliation
kernel; the original marker-presence scan, absent-marker path, normal checker
and small-list body are preserved. This removes the prior held design's measured
absent-marker double traversal. No failed design was repeated unchanged.

All four primary bare CPU and elapsed targets pass:59.67–89.14% lower thread CPU,
above both full lane ranges and the frozen20% goal. Every bare CPU, elapsed,
whole-child CPU and current/peak RSS control passes, including all12 complete
Window workloads. All requested live/peak/bytes/calls controls pass, with primary
transient allocations eliminated and zero held owner bytes in all420 census
children. No new App/Window fields, cache, persistent owner or fixed heap/header
budget exists.

Four other fields fail. Census current RSS for the8-state marker-first case
rises232 KiB against its216 KiB baseline range. Peak RSS for the256-state normal
changed case rises192 KiB against172 KiB. The additionally strict census empty
exception-check CPU and elapsed medians rise15,262/15,193 ns across32,768 calls,
against240/160 ns full baseline ranges. These remain failures; no Clippy, PR,
merge or consumer adoption was attempted. Never rerun this design unchanged
or weaken its gates.

The requested-memory fixture uses System forwarding with a const TLS enable on
the checking foreground thread. This synchronous complete-App checker creates
and drops filtered snapshots locally; no measured ownership crosses threads.
Two native scope regressions prove1234 foreground bytes/one call counted exactly,
7777 synchronized worker bytes excluded, and zero owner bytes after release.
Whole-child native RSS still includes every thread. The prior held process-global
144-byte outliers remain archived and untraced; no original owner is guessed.
Both lanes use identical foreground-scope allocator source and exact identities.

All62 correctness children pass:654 suite/fixture passes, matched frame histories
for all12 retention on/off, resize, state-update and row-removal cases; state
oracle63/64/65/128/256 boundaries and32 state/entity/global/deadline combinations;
layout, atomic claims, input and retained-frame contracts. Source proof preserves
the normal checker and original exception method after removing only the new
marker-present threshold guard. Four final native binaries use the same compiler,
immutable59 dependency objects and runtime. Both actual external deadline phases
complete successfully in sequence, every raw child signature matches, and every
source/policy/tool/log identity is verified. Setup spelling assertion fired before
source modification and is preserved; no sample cohort was repeated.

Archive parts and all members are verified byte-for-byte. Completed native
binaries remain losslessly preserved in the managed workspace with round-trip
hashes. These are Linux fake-platform/System component results, not whole-app,
physical GPU, macOS/Windows, shipped-allocator or Fincode adoption percentages.
Continue with a distinct bounded typed glyph dispatcher for the owned transcript
paint-replay bottleneck, preserving small ranges and generic animated/moved
semantics. No runtime glyph-span scanner is repeated unchanged.
"""+s[b:]
s=s.replace('Preserve held bounded state reconciliation and adverse controls [skip ci]','Preserve held marker-present state routing and census controls [skip ci]')
s=s.replace('Held bounded state candidate9244e2fc:2040 children, all four CPU/heap targets and12 Window controls pass,21 controls fail. Exact source/raw archive packaged; owned branch publication pending; next distinct marker-present routing.','Held marker-present source003fc897:2040 children, allfour primary CPU/heap targets and allbare/12Window controls pass; four census fields fail. Exact source/raw archive packaged, owned publication pending; continue distinct bounded typed glyph replay.')
s=s.replace('Freeze and implement distinct marker-present bounded routing preserving the original absent-marker and normal/small paths, with identical prior controls and explicit owner-thread census attribution before samples.','Continue distinct bounded typed glyph dispatcher on current owned main, preserving original small-range replay; freeze5percent full-Window CPU goals and prior original58 controls plus current scenes/layout/overlay safeguards. No runtime glyph-span/scanner repeat.')
(root/'finalize_held.py').write_text(s)
print('Held marker source packaging adapted to actual four failures and exact foreground-owner scope')
