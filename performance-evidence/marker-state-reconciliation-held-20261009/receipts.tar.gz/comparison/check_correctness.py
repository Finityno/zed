from pathlib import Path
import subprocess,os,json,hashlib
r=Path(__file__).parent;policy=json.loads((r/'policy.json').read_text());rows=json.loads((r/'correctness-receipts.json').read_text()) if (r/'correctness-receipts.json').exists() else [];out=r/'correctness';out.mkdir(exist_ok=True);bins={lane:str(r/f'{lane}-bare-artifacts/gpui-ada3fb4d7b1cfe56') for lane in ['baseline','candidate']}
patterns=['taffy::','window::layout_retention_tests::','window::view_retention::tests::','window::view_retention::dependencies::','window::layout_keys::','text_system::','scene::tests::','window::glyph_painting::tests::','app::tests::','arena::tests::','elements::div::tests::','elements::list::test::','elements::uniform_list::test::','elements::text::tests::','elements::deferred::tests::','window::text_glyph_cache_tests::','window::tests::','subscription::tests::']
for lane,binary in bins.items():
 for i,pattern in enumerate(patterns):
  if any(row.get('lane')==lane and row.get('pattern')==pattern for row in rows):continue
  command=[binary,pattern,'--nocapture','--test-threads=1'];p=out/f'{lane}-{i:02}.log'
  with p.open('w') as f:result=subprocess.run(command,env=os.environ,stdout=f,stderr=subprocess.STDOUT,timeout=180)
  rows.append({'lane':lane,'pattern':pattern,'command':command,'exit_code':result.returncode,'log':str(p),'log_sha256':hashlib.sha256(p.read_bytes()).hexdigest()});(r/'correctness-receipts.json').write_text(json.dumps(rows,indent=2)+'\n')
  assert result.returncode==0,p.read_text()
for case in policy['complete_window_bare_controls']:
 audits=[]
 for lane,binary in bins.items():
  command=[binary,'profile_bounded_state_frames','--ignored','--nocapture','--test-threads=1'];environment=os.environ|{'BOUNDED_WINDOW_CASE':case,'BOUNDED_WINDOW_ITERATIONS':'32','LAYOUT_AUDIT_FRAMES':'1'};path=out/f'frames-{case}-{lane}.log'
  assert not path.exists(), 'Recover an existing receipt, never duplicate a validation child'
  with path.open('x') as output:code=subprocess.run(command,env=environment,stdout=output,stderr=subprocess.STDOUT,timeout=60).returncode
  row={'case':case,'lane':lane,'command':command,'exit_code':code,'log':str(path),'log_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
  for line in path.read_text().splitlines():
   if 'FRAME_AUDIT ' in line:row['frame_audit']=int(line.split('FRAME_AUDIT ',1)[1])
   if 'BOUNDED_WINDOW_PROFILE ' in line:row.update(json.loads(line.split('BOUNDED_WINDOW_PROFILE ',1)[1]))
  rows.append(row);(r/'correctness-receipts.json').write_text(json.dumps(rows,indent=2)+'\n');assert code==0 and 'frame_audit' in row,path.read_text();audits.append(row)
 for field in ['frame_audit','signature','state_count','state_box_bytes','iterations','nodes','node_high_water','retained']:
  assert audits[0][field]==audits[1][field],(case,field,audits[0].get(field),audits[1].get(field))
print(json.dumps({'children':len(rows),'all_pass':True,'per_frame_audit_cases':len(policy['complete_window_bare_controls'])}))

for lane in ['baseline', 'candidate']:
 binary = str(r / (lane + '-census-artifacts/gpui-ada3fb4d7b1cfe56'))
 command = [binary, 'dependency_census_only_counts_checking_thread', '--nocapture', '--test-threads=1']
 path = out / ('census-scope-' + lane + '.log')
 with path.open('x') as output: code = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT, timeout=60).returncode
 row = {'lane': lane, 'pattern': 'owner_thread_census_scope', 'command': command, 'exit_code': code, 'log': str(path), 'log_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
 rows.append(row); (r / 'correctness-receipts.json').write_text(json.dumps(rows, indent=2) + '\n')
 assert code == 0 and 'running 1 test' in path.read_text(), path.read_text()
print(json.dumps({'children': len(rows), 'all_pass': True, 'both_owner_thread_scope_regressions_pass': True}))
