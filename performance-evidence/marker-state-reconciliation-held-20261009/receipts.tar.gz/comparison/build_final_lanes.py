from pathlib import Path
import json, subprocess, time

root = Path(__file__).parent
rows = []
commands = [['python3', 'build_native.py', 'candidate', 'bare'], ['python3', 'preflight.py'], ['python3', 'build_native.py', 'baseline', 'bare'], ['python3', 'build_native.py', 'baseline', 'census'], ['python3', 'build_native.py', 'candidate', 'census']]
for command in commands:
    started = time.time()
    result = subprocess.run(command, cwd=root, timeout=630)
    rows.append({'command': command, 'started_unix': started, 'finished_unix': time.time(), 'exit_code': result.returncode})
    (root / 'final-native-build-order.json').write_text(json.dumps(rows, indent=2) + '\n')
    assert result.returncode == 0
