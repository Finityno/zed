from pathlib import Path
import hashlib, json, statistics, sys

root = Path(__file__).parent
policy = json.loads((root / 'policy.json').read_text())
policy_sha = hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest()
assert policy_sha == (root / 'policy.sha256').read_text().strip()
kinds = ['bare'] if '--bare-only' in sys.argv else ['bare', 'census']
summary = []
failures = []
for kind in kinds:
    samples = json.loads((root / (kind + '-samples.json')).read_text())
    assert len(samples) == (1620 if kind == 'bare' else 420)
    cases = [('component', case) for case in policy['controls']]
    if kind == 'bare':
        cases += [('window', case) for case in policy['complete_window_bare_controls']]
    for scope, case in cases:
        pairs = policy['complete_window_control_pairs'] if scope == 'window' else policy['timing_pairs'] if kind == 'bare' else policy['memory_pairs']
        lanes = {lane: sorted([row for row in samples if row['case'] == case and row['scope'] == scope and row['lane'] == lane], key=lambda row: row['pair']) for lane in ['baseline', 'candidate']}
        for lane, rows in lanes.items():
            assert len(rows) == pairs and [row['pair'] for row in rows] == list(range(pairs))
            for row in rows:
                assert row['exit_code'] == 0 and row['policy_sha256'] == policy_sha
                assert hashlib.sha256(Path(row['log']).read_bytes()).hexdigest() == row['log_sha256']
        for baseline, candidate in zip(lanes['baseline'], lanes['candidate']):
            for field in ['signature', 'iterations', 'retained', 'state_count', 'state_box_bytes', 'nodes', 'node_high_water']:
                if field in baseline or field in candidate:
                    assert baseline[field] == candidate[field], (kind, scope, case, field)
        metrics = ['cpu_ns', 'elapsed_ns', 'child_cpu_ns', 'current_rss_kib', 'peak_rss_kib']
        if kind == 'census':
            metrics += ['held_bytes', 'peak_bytes', 'requested_bytes', 'allocation_calls']
        entry = {'kind': kind, 'scope': scope, 'case': case, 'fields': {}}
        for metric in metrics:
            baseline = [row[metric] for row in lanes['baseline']]
            candidate = [row[metric] for row in lanes['candidate']]
            bm = statistics.median(baseline); cm = statistics.median(candidate)
            br = max(baseline) - min(baseline); cr = max(candidate) - min(candidate)
            delta = cm - bm
            budget = 0 if metric in ['held_bytes', 'peak_bytes', 'requested_bytes', 'allocation_calls'] else br
            passed = delta <= budget
            field = {'baseline_median': bm, 'candidate_median': cm, 'baseline_min': min(baseline), 'baseline_max': max(baseline), 'candidate_min': min(candidate), 'candidate_max': max(candidate), 'baseline_range': br, 'candidate_range': cr, 'delta': delta, 'fraction_gain': -delta / bm if bm else None, 'budget': budget, 'control_pass': passed}
            if not passed:
                failures.append({'kind': kind, 'scope': scope, 'case': case, 'field': metric, 'gate': 'control', **field})
            if kind == 'census' and metric == 'held_bytes' and any(value != 0 for value in candidate):
                failures.append({'kind': kind, 'scope': scope, 'case': case, 'field': metric, 'gate': 'zero_retained_foreground_owner_heap_all_samples', **field})
            primary = scope == 'component' and case in policy['primary_cases']
            if primary and kind == 'bare' and metric in ['cpu_ns', 'elapsed_ns']:
                primary_pass = cm <= bm * .8 and -delta > max(br, cr)
                field['primary_pass'] = primary_pass
                if not primary_pass:
                    failures.append({'kind': kind, 'scope': scope, 'case': case, 'field': metric, 'gate': '20_percent_above_both_full_ranges', **field})
            if primary and kind == 'census' and metric in ['peak_bytes', 'requested_bytes', 'allocation_calls']:
                primary_pass = bm > 0 and all(value == 0 for value in candidate)
                field['primary_pass'] = primary_pass
                if not primary_pass:
                    failures.append({'kind': kind, 'scope': scope, 'case': case, 'field': metric, 'gate': 'all_primary_transient_allocations_eliminated', **field})
            entry['fields'][metric] = field
        summary.append(entry)
name = 'bare-only-decision' if len(kinds) == 1 else 'decision'
(root / (name + '-summary.json')).write_text(json.dumps(summary, indent=2) + '\n')
decision = {'qualified': not failures and len(kinds) == 2, 'status': 'HELD_UNMERGED' if failures else 'PERFORMANCE_GATES_PASS_PENDING_OWNING_REVIEW' if len(kinds) == 2 else 'BARE_PASS_PENDING_CENSUS', 'failures': failures, 'policy_sha256': policy_sha, 'native_children': sum(1620 if kind == 'bare' else 420 for kind in kinds), 'component_controls': 42, 'complete_window_bare_controls': 12, 'primary': [row for row in summary if row['scope'] == 'component' and row['case'] in policy['primary_cases']], 'census_CPU_diagnostic_with_additional_full_range_controls': True, 'bare_CPU_only_gain_claim': True, 'no_app_GPU_platform_shipped_allocator_claim': True, 'no_resampling_or_weakened_gates': True}
(root / (name + '.json')).write_text(json.dumps(decision, indent=2) + '\n')
print(json.dumps({'status': decision['status'], 'children': decision['native_children'], 'failed_fields': len(failures), 'failures': [(row['kind'], row['scope'], row['case'], row['field'], row['gate'], row['delta'], row['budget']) for row in failures], 'primary': [(row['kind'], row['case'], row['fields']['cpu_ns']['fraction_gain'], row['fields'].get('requested_bytes', {}).get('fraction_gain')) for row in decision['primary']]}))
