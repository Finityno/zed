from pathlib import Path
import subprocess,json,time
root=Path(__file__).parent
assert json.loads((root/'final-native-builds-receipt.json').read_text())['exit_code']==0
rows=[]
for command in [['python3','collect_identities.py'],['python3','verify_inputs.py','before-correctness'],['python3','check_correctness.py'],['python3','verify_inputs.py','after-correctness']]:
 started=time.time();code=subprocess.run(command,cwd=root,timeout=600).returncode
 rows.append({'command':command,'exit_code':code,'started_unix':started,'finished_unix':time.time()})
 (root/'correctness-order.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert code==0
