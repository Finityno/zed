from pathlib import Path
import hashlib, json, os, subprocess, sys, time

root = Path(__file__).parent
policy = json.loads((root / 'policy.json').read_text())
identities = json.loads((root / 'binary-identities.json').read_text())
kind = sys.argv[1]
assert kind in ['bare', 'census']
policy_sha = hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest()
assert policy_sha == (root / 'policy.sha256').read_text().strip()
output = root / (kind + '-receipts')
output.mkdir()
for lane in ['baseline', 'candidate']:
    binary = identities[lane][kind]
    assert hashlib.sha256(Path(binary['path']).read_bytes()).hexdigest() == binary['sha256']
rows = []

def guard_host():
    forbidden = {'rustc', 'cargo', 'cc', 'gcc', 'clang', 'cmake', 'make', 'ninja', 'gzip', 'pigz', 'zstd', 'sha256sum', 'b3sum', 'perf', 'hyperfine'}
    snapshot = subprocess.check_output(['ps', '-eo', 'pid,ppid,stat,comm,args'], text=True)
    conflicts = []
    for line in snapshot.splitlines()[1:]:
        fields = line.split(None, 4)
        if len(fields) != 5 or fields[2].startswith('Z'):
            continue
        pid, parent, state, command, arguments = fields
        if int(pid) in [os.getpid(), os.getppid()]:
            continue
        if int(pid) == int(Path(f'/proc/{os.getppid()}/status').read_text().split('PPid:', 1)[1].splitlines()[0].strip()) and str(root / 'supervise.py') in arguments:
            continue
        if command in forbidden or command.startswith('gpui-'):
            conflicts.append(line)
        elif command.startswith('python') and any(word in arguments for word in ['measure', 'build_native', 'build_final', 'preserve', 'package_', 'finalize_', 'verify_inputs', 'collect_identities', 'compression', 'hashing']):
            conflicts.append(line)
    if conflicts:
        (root / (kind + '-host-conflict.txt')).write_text(snapshot)
        raise RuntimeError(('Active host work blocks timing/profiling', conflicts))
    return '\n'.join(line for line in snapshot.splitlines() if len(line.split(None, 4)) != 5 or not line.split(None, 4)[2].startswith('Z')) + '\n'

cases = [('component', case) for case in policy['controls']]
if kind == 'bare':
    cases += [('window', case) for case in policy['complete_window_bare_controls']]
for scope, case in cases:
    pairs = policy['complete_window_control_pairs'] if scope == 'window' else policy['timing_pairs'] if kind == 'bare' else policy['memory_pairs']
    iterations = policy['complete_window_control_iterations'] if scope == 'window' else policy['timing_iterations'] if kind == 'bare' else policy['memory_iterations']
    for pair in range(pairs):
        for lane in (['baseline', 'candidate'] if pair % 2 == 0 else ['candidate', 'baseline']):
            snapshot = guard_host()
            binary = identities[lane][kind]
            pattern = 'profile_bounded_state_frames' if scope == 'window' else 'profile_state_checks'
            command = [str(root / 'native-run'), 'taskset', '-c', '2', binary['path'], pattern, '--ignored', '--nocapture', '--test-threads=1']
            environment = os.environ | {'GPUI_STATE_PROFILE_CASE': case, 'GPUI_STATE_PROFILE_ITERATIONS': str(iterations), 'BOUNDED_WINDOW_CASE': case, 'BOUNDED_WINDOW_ITERATIONS': str(iterations)}
            path = output / f'{scope}-{case}-{pair:02}-{lane}.log'
            started = time.time()
            with path.open('x') as log:
                result = subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=70)
            finished = time.time()
            row = {'scope': scope, 'case': case, 'pair': pair, 'lane': lane, 'kind': kind, 'command': command, 'exit_code': result.returncode, 'log': str(path), 'log_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'binary_sha256': binary['sha256'], 'policy_sha256': policy_sha, 'started_unix': started, 'finished_unix': finished, 'prechild_process_snapshot': snapshot}
            for line in path.read_text().splitlines():
                for marker in ['STATE_PROFILE ', 'BOUNDED_WINDOW_PROFILE ']:
                    if marker in line:
                        row.update(json.loads(line.split(marker, 1)[1]))
                if line.startswith('NATIVE_RECEIPT '):
                    native = json.loads(line.split(' ', 1)[1])
                    assert native['exit_code'] == result.returncode
                    row.update(native)
            assert 'user_cpu_us' in row and 'current_rss_kib' in row, path.read_text()
            row['child_cpu_ns'] = (row['user_cpu_us'] + row['system_cpu_us']) * 1000
            rows.append(row)
            (root / (kind + '-samples.json')).write_text(json.dumps(rows, indent=2) + '\n')
            assert result.returncode == 0 and 'cpu_ns' in row, path.read_text()
expected = 1620 if kind == 'bare' else 420
assert len(rows) == expected
print(json.dumps({'kind': kind, 'children': len(rows), 'all_exit_zero': True, 'one_fresh_cohort': True}))
