from pathlib import Path
import hashlib, json, os, re, subprocess, time

root = Path(__file__).parent
binary = str(root / 'candidate-bare-artifacts/gpui-ada3fb4d7b1cfe56')
receipt = json.loads((root / 'candidate-bare-build-receipt.json').read_text())
assert receipt['exit_code'] == 0
rows = []
for index, pattern in enumerate(['window::view_retention::dependencies::state_check_tests::', 'window::view_retention::tests::', 'scene::tests::']):
    command = [binary, pattern, '--nocapture', '--test-threads=1']
    log = root / f'candidate-preflight-{index}.log'
    started = time.time()
    with log.open('w') as output:
        code = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT, timeout=180).returncode
    row = {'command': command, 'exit_code': code, 'started_unix': started, 'finished_unix': time.time(), 'log': str(log), 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    rows.append(row)
    (root / 'candidate-preflight-receipts.json').write_text(json.dumps(rows, indent=2) + '\n')
    assert code == 0, log.read_text()
    result = re.findall(r'test result:.*', log.read_text())[-1]
    print(result, flush=True)
policy = json.loads((root / 'policy.json').read_text())
out = root / 'candidate-case-preflight'
out.mkdir()
cases = []
for case in policy['controls']:
    command = [binary, 'profile_state_checks', '--ignored', '--nocapture', '--test-threads=1']
    log = out / (case + '.log')
    with log.open('w') as output:
        code = subprocess.run(command, env=os.environ | {'GPUI_STATE_PROFILE_CASE': case, 'GPUI_STATE_PROFILE_ITERATIONS': '1'}, stdout=output, stderr=subprocess.STDOUT, timeout=60).returncode
    cases.append({'case': case, 'command': command, 'exit_code': code, 'log': str(log), 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(), 'single_iteration_correctness_only': True})
    (root / 'candidate-case-preflight-receipts.json').write_text(json.dumps(cases, indent=2) + '\n')
    assert code == 0 and 'STATE_PROFILE ' in log.read_text(), log.read_text()
print(json.dumps({'candidate_case_contracts': len(cases), 'all_exit_zero': True, 'no_gain_claim_or_paired_metrics': True}), flush=True)

for case in policy['complete_window_bare_controls']:
    command = [binary, 'profile_bounded_state_frames', '--ignored', '--nocapture', '--test-threads=1']
    log = out / ('window-' + case + '.log')
    with log.open('x') as stream:
        code = subprocess.run(command, env=os.environ | {'BOUNDED_WINDOW_CASE': case, 'BOUNDED_WINDOW_ITERATIONS': '2'}, stdout=stream, stderr=subprocess.STDOUT, timeout=60).returncode
    cases.append({'case': case, 'scope': 'window', 'command': command, 'exit_code': code, 'log': str(log), 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(), 'single_contract_only': True})
    (root / 'candidate-case-preflight-receipts.json').write_text(json.dumps(cases, indent=2) + '\n')
    assert code == 0 and 'BOUNDED_WINDOW_PROFILE ' in log.read_text(), log.read_text()
print(json.dumps({'all54_candidate_contracts_pass': True, 'no_paired_metrics': True}))
