from pathlib import Path
import json,subprocess,time,sys
root=Path(__file__).parent
kind=sys.argv[1];assert kind in ['bare','census']
assert json.loads((root/'native-correctness-receipt.json').read_text())['exit_code']==0
if kind=='census':assert json.loads((root/'bare-measurement-receipt.json').read_text())['exit_code']==0
rows=[]
commands=[['python3','verify_inputs.py','before-'+kind],['python3','measure.py',kind],['python3','verify_inputs.py','after-'+kind]]
commands += [['python3','decide.py','--bare-only']] if kind=='bare' else [['python3','decide.py']]
for command in commands:
 started=time.time();code=subprocess.run(command,cwd=root,timeout=3400).returncode
 rows.append({'command':command,'exit_code':code,'started_unix':started,'finished_unix':time.time()})
 (root/(kind+'-phase-order.json')).write_text(json.dumps(rows,indent=2)+'\n')
 assert code==0
