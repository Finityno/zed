from pathlib import Path
import json,hashlib,shutil,subprocess,os,time
root=Path(__file__).parent;comparison=root/'comparison';workspace=Path('/workspace/zed-marker-state-checks');old=Path('/workspace/scratch/gpui-bounded-state-loop');sha=(root/'policy.sha256').read_text().strip();assert hashlib.sha256((root/'policy.json').read_bytes()).hexdigest()==sha
rel='crates/gpui/src/window/view_retention/dependencies.rs';source=workspace/rel;original=source.read_text();held=Path('/workspace/zed-bounded-state-checks')/rel
text=held.read_text();external='        if dependencies.states.len() >= 64 {\n            return self.dependencies_changed_except_large(dependencies, inside_notified, now, except);\n        }\n';assert text.count(external)==1;text=text.replace(external,'')
start=text.index('    pub(crate) fn dependencies_changed_except(');end=text.index('    #[inline(never)]',start);method=text[start:end]
needle='        {\n            let mut dependencies = dependencies.clone();';assert method.count(needle)==1
replacement='        {\n'+external.replace('        if','            if').replace('            return','                return').replace('        }','            }')+'            let mut dependencies = dependencies.clone();'
changed=method.replace(needle,replacement);text=text[:start]+changed+text[end:]
assert text!=held.read_text();source.write_text(text)
original_method=original[original.index('    pub(crate) fn dependencies_changed_except('):original.index('    /// Whether anything in `dependencies` may have changed',original.index('    pub(crate) fn dependencies_changed_except('))]
stripped=changed.replace(external.replace('        if','            if').replace('            return','                return').replace('        }','            }'),'')
assert stripped==original_method
normal=original[original.index('    pub(crate) fn dependencies_changed('):original.index('\n}\n\n/// What changed',original.index('    pub(crate) fn dependencies_changed('))]
assert normal in text
subprocess.run(['git','diff','--check'],cwd=workspace,check=True)
subprocess.run(['git','add',rel],cwd=workspace,check=True)
subprocess.run(['git','commit','-m','Route large marker-bearing state checks through outlined reconciliation [skip ci]'],cwd=workspace,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=workspace,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=workspace,text=True).strip()
identity={'source':head,'tree':tree,'baseline':'08d5555709d7afab3936c7afcd9f7f0ff9ecbd65','files':{rel:hashlib.sha256(source.read_bytes()).hexdigest()},'normal_checker_byte_exact':True,'original_marker_presence_scan_absent_path_and_small_body_after_guard_byte_exact':True,'held_kernel_body_unchanged_but_reached_only_for64plus_marker_present':True,'no_heap_header_persistent_storage':True,'policy_sha256':sha};(root/'candidate-source-receipt.json').write_text(json.dumps(identity,indent=2)+'\n');(comparison/'candidate-source-receipt.json').write_text(json.dumps(identity,indent=2)+'\n')
for lane in ['baseline','candidate']:
 prior=old/'comparison'/(lane+'-workspace');target=comparison/(lane+'-workspace');shutil.copytree(prior,target,symlinks=True)
 if lane=='candidate':shutil.copy2(source,target/rel)
 for name in ['compiler-dependency-identities.json','external-dependencies.json','native-runtime-identity.json','native-run','build_native.py','build_final_lanes.py','collect_identities.py','verify_inputs.py','check_correctness.py','preflight.py','supervise.py','measure.py','decide.py','run_correctness.py','run_metric_phase.py']:
  if not (comparison/name).exists():shutil.copy2(old/'comparison'/name,comparison/name)
 manifest=json.loads((old/'comparison'/(lane+'-source-inputs.json')).read_text());manifest['baseline']=identity['baseline'];manifest['source']=head if lane=='candidate' else identity['baseline']
 if lane=='candidate':manifest['files'][rel]=hashlib.sha256((target/rel).read_bytes()).hexdigest()
 (comparison/(lane+'-source-inputs.json')).write_text(json.dumps(manifest,indent=2)+'\n')
(counter_original:=root/'pre-owner-scope-dependency-profile.rs').write_text((comparison/'baseline-workspace/crates/gpui/src/window/view_retention/dependency_profile.rs').read_text())
for lane in ['baseline','candidate']:
 p=comparison/(lane+'-workspace/crates/gpui/src/window/view_retention/dependency_profile.rs');s=p.read_text();s=s.replace('use std::sync::atomic::{AtomicBool, AtomicIsize, AtomicUsize, Ordering::Relaxed};','use std::cell::Cell;\n    use std::sync::atomic::{AtomicIsize, AtomicUsize, Ordering::Relaxed};')
 assert s.count('static ENABLED: AtomicBool = AtomicBool::new(false);')==1
 s=s.replace('    static ENABLED: AtomicBool = AtomicBool::new(false);','    thread_local! {\n        static ENABLED: Cell<bool> = const { Cell::new(false) };\n    }')
 s=s.replace('ENABLED.load(Relaxed)','ENABLED.try_with(|enabled| enabled.get()).unwrap_or(false)').replace('ENABLED.store(true, Relaxed);','ENABLED.with(|enabled| enabled.set(true));').replace('ENABLED.store(false, Relaxed);','ENABLED.with(|enabled| enabled.set(false));')
 s+='''
#[cfg(gpui_dependency_census)]
#[test]
fn dependency_census_only_counts_checking_thread() {
    use std::sync::{Arc, Barrier};
    let barrier = Arc::new(Barrier::new(2));
    let worker = std::thread::spawn({
        let barrier = Arc::clone(&barrier);
        move || {
            for phase in 0..3 {
                barrier.wait();
                if phase == 2 {
                    let owner = Box::new([7_u8; 7777]);
                    black_box(&owner);
                    drop(owner);
                }
                barrier.wait();
            }
        }
    });
    for _ in 0..2 { barrier.wait(); barrier.wait(); }
    census::start();
    let owner = Box::new([1_u8; 1234]);
    black_box(&owner);
    barrier.wait();
    barrier.wait();
    drop(owner);
    let actual = census::finish();
    worker.join().expect("worker");
    assert_eq!(actual, (0, 1234, 1234, 1));
}
''';p.write_text(s)
 manifest_path=comparison/(lane+'-source-inputs.json');manifest=json.loads(manifest_path.read_text());manifest['files']['crates/gpui/src/window/view_retention/dependency_profile.rs']=hashlib.sha256(p.read_bytes()).hexdigest();manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copy2(old/'launch_phase.py',root/'launch_phase.py')
p=comparison/'verify_inputs.py';p.write_text(p.read_text().replace('/workspace/zed-bounded-state-checks','/workspace/zed-marker-state-checks'))
p=comparison/'check_correctness.py';s=p.read_text();s+='''
for lane in ['baseline', 'candidate']:
 binary = str(r / (lane + '-census-artifacts/gpui-ada3fb4d7b1cfe56'))
 command = [binary, 'dependency_census_only_counts_checking_thread', '--nocapture', '--test-threads=1']
 path = out / ('census-scope-' + lane + '.log')
 with path.open('x') as output: code = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT, timeout=60).returncode
 row = {'lane': lane, 'pattern': 'owner_thread_census_scope', 'command': command, 'exit_code': code, 'log': str(path), 'log_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
 rows.append(row); (r / 'correctness-receipts.json').write_text(json.dumps(rows, indent=2) + '\\n')
 assert code == 0 and 'running 1 test' in path.read_text(), path.read_text()
print(json.dumps({'children': len(rows), 'all_pass': True, 'both_owner_thread_scope_regressions_pass': True}))
''';p.write_text(s)
p=comparison/'run_metric_phase.py';s=p.read_text().replace("assert json.loads((root/'native-correctness-receipt.json').read_text())['exit_code']==0","assert json.loads((root/'native-correctness-receipt.json').read_text())['exit_code']==0");p.write_text(s)
p=comparison/'decide.py';s=p.read_text().replace("'zero_retained_heap_all_samples'","'zero_retained_foreground_owner_heap_all_samples'");p.write_text(s)
(root/'allocator-scope-identity.json').write_text(json.dumps({'bare':'System','census':'System with global Counter forwarding and const TLS enable on the checking thread only; live/peak/bytes/calls owner scope','same_both_lanes':True,'original_process_global_counter_preserved':str(counter_original),'original144_byte_owner_untraced_not_guessed':True,'all_child_current_peak_RSS_and_CensusCPU_controls_preserved':True,'primary_bare_CPU_gain_only':True,'private_profile_source_sha256':hashlib.sha256((comparison/'baseline-workspace/crates/gpui/src/window/view_retention/dependency_profile.rs').read_bytes()).hexdigest(),'no_owner_allocations_cross_threads':'Complete synchronous App checker only creates/drops locally filtered Rc snapshots; no outputs or leases leave the checking thread.','scope_contract_regression_required_before_pairs':True},indent=2)+'\n')
files=[str(p.relative_to(comparison/'baseline-workspace')) for p in (comparison/'baseline-workspace/crates/gpui/src').rglob('*') if p.is_file()];diffs=[p for p in files if (comparison/'baseline-workspace'/p).read_bytes()!=(comparison/'candidate-workspace'/p).read_bytes()];assert diffs==[rel],diffs
(root/'source-equivalence.json').write_text(json.dumps(identity|{'all_private_fixtures_and_owner_thread_allocator_identical':True,'different_compiled_files':diffs,'all42_component_and12Window_controls_preserved':True},indent=2)+'\n')
hp=Path('/workspace/scratch/gpui-fork-loop/handoff.json');h=json.loads(hp.read_text());h.update({'workspace':str(workspace),'branch':'perf/marker-state-reconciliation-20261009','iteration_directory':str(root),'candidate_source':head,'active_supervisor_pid':None,'active_session':None});h['next_iteration']={'workspace':str(workspace),'branch':'perf/marker-state-reconciliation-20261009','directory':str(root),'source':head,'tree':tree,'baseline':identity['baseline'],'policy_sha256':sha,'active_session':None,'supervisor_pid':None,'active_stage':'Distinct marker-present routing source prepared; frozen42component+12Window controls and owner-thread census validation; four native binaries pending.','planned_children':2040};h['phase']=h['next_iteration']['active_stage'];h['next_steps']=['Build four native lanes sequentially under explicit deadlines and required native state/Window/census scope checks.','Verify all identities and owner scope, run only fresh1620bare+420census paired children with all prior numerical gates.','No unchanged failed candidate repeat; hold any failed field or complete owning checks/review/PR/squash/verified coherent consumer adoption then next distinct bottleneck.'];hp.write_text(json.dumps(h,indent=2)+'\n')
print(json.dumps(identity))
