from pathlib import Path
import shutil,json,hashlib
r=Path(__file__).parent;w=r/'baseline-workspace';source=Path('/workspace/scratch/gpui-glyph-spans-loop/baseline-workspace');shutil.copytree(source,w)
p=w/'crates/gpui/src/scene.rs';s=p.read_text();mark='    pub fn finish(&mut self) {';assert s.count(mark)==1
method='''    pub(crate) fn diagnostic_sort_inputs(&self) -> serde_json::Value {
        let mono: Vec<_> = self.painted_monochrome_sprites.iter().map(|sprite| (sprite.order, sprite.tile.texture_id.index, sprite.tile.tile_id.0, sprite.pad, sprite.effect.animation)).collect();
        let subpixel: Vec<_> = self.painted_subpixel_sprites.iter().map(|sprite| (sprite.order, sprite.tile.texture_id.index, sprite.tile.tile_id.0, sprite.pad, sprite.effect.animation)).collect();
        let color: Vec<_> = self.polychrome_sprites.iter().map(|sprite| (sprite.order, sprite.tile.texture_id.index, sprite.tile.tile_id.0, sprite.pad)).collect();
        serde_json::json!({
            "monochrome":mono,"subpixel":subpixel,"polychrome":color,
            "quad_orders":self.quads.iter().map(|quad| quad.order).collect::<Vec<_>>(),
            "shadow_orders":self.shadows.iter().map(|shadow| shadow.order).collect::<Vec<_>>(),
            "path_orders":self.paths.iter().map(|path| path.order).collect::<Vec<_>>(),
            "underline_orders":self.underlines.iter().map(|underline| underline.order).collect::<Vec<_>>(),
            "surface_orders":self.surfaces.iter().map(|surface| surface.order).collect::<Vec<_>>(),
            "scratch_owner_bytes":[self.draw_order_scratch.keys.capacity()*8,self.draw_order_scratch.sprite_keys.capacity()*16,self.draw_order_scratch.radix_scratch.capacity()*8,self.draw_order_scratch.permutation.capacity()*4],
            "time_animation_quads":self.quads.iter().filter(|quad| quad.background.time_animation()!=0).count(),
            "transitions":self.transitions.len(),"shimmer_animations":self.shimmer_animations.len(),"quad_animations":self.quad_animations.len()
        })
    }

''';p.write_text(s.replace(mark,method+mark))
for name in ['transcript_profile.rs','color_profile.rs']:
 p=w/'crates/gpui/src/window/view_retention'/name;s=p.read_text();i=s.index('    let current_rss_kib = ');s=s[:i]+'''    let sort_inputs = cx.update_window(window.into(), |_, window, _| window.rendered_frame.scene.diagnostic_sort_inputs()).expect("sort inputs");
    println!("SCENE_SORT_INPUT {}", sort_inputs);
'''+s[i:];p.write_text(s)
(r/'baseline-source-inputs.json').write_text(json.dumps({'baseline':'08d5555709d7afab3936c7afcd9f7f0ff9ecbd65','private_capture_only':True,'files':{str(p.relative_to(w)):hashlib.sha256(p.read_bytes()).hexdigest() for p in w.rglob('*') if p.is_file()}},indent=2)+'\n')
method={'baseline':'08d5555709d7afab3936c7afcd9f7f0ff9ecbd65','fincode_main':'1db05b87837ca90f42e4714e0f43593967cc9cb3','fincode_pin':'6b18c87dd5f2d1ccbee1ee641054295f2a78390b','component_pin':'031f54b627333272a8c157cbe4ca1cf591d16172','production_candidate_exists':False,'cases':[f'{scenario}-{mode}-{count}' for scenario in ['scroll','stream','tick','redraw'] for mode in ['off','on'] for count in [200,512]]+['color-redraw-off-200-32','color-redraw-on-200-32','color-decorated-off-200-32','color-decorated-on-200-32'],'iterations':128,'purpose':'Current-main measured completeWindow owner/captured-sortkey attribution. Existing independent40child trace shows Scene.finish11.15-13.82us/frame. Stored key/index duplicate may permit direct sortedcopy without permutationVec. Capture actual ordering/key bits/counts/staticanimation eligibility and capacities after timers/census. No hypothetical source gains claimed.','measurement_limits':'CountingSystem CPU notgain evidence. Captured keys/array counts are actual native fakeplatform scenes. Geometry/texture resource bytes notcaptured; any reconstructed finishfixture must be labeled controlled key-and-payload-size fixture, not fullphysicalrenderer/app scene. No GPU/platform/app claims.','no_failed_candidate_repeated':'Baseline originalmain08d source; neither heldglyphspan norcompactrecord code reused.'};(r/'diagnostic-method.json').write_text(json.dumps(method,indent=2)+'\n');print('Private real scene sortkeys andscratch owner capture prepared; production worktree clean.')
