    #[test]
    fn copied_sprite_sort_preserves_source_without_a_permutation_owner() {
        for widest in [31, u32::MAX] {
            let items: Vec<_> = (0..2048u32)
                .map(|index| (widest - index % 32, index % 3, widest - index % 16, index))
                .collect();
            let original = items.clone();
            let mut expected = items.clone();
            expected.sort_by_key(|item| (item.0, item.1, item.2));
            let mut scratch = DrawOrderScratch::default();
            let mut copied = Vec::new();
            scratch.sort_sprites_into(&items, &mut copied, |item| (item.0, item.1, item.2));
            assert_eq!(copied, expected);
            assert_eq!(items, original);
            assert_eq!(scratch.permutation.capacity(), 0);
            let mut in_place = items.clone();
            scratch.sort_sprites(&mut in_place, |item| (item.0, item.1, item.2));
            assert_eq!(in_place, expected);
            assert!(scratch.permutation.capacity() >= items.len());
            let capacity = scratch.permutation.capacity();
            scratch.sort_sprites_into(&items, &mut copied, |item| (item.0, item.1, item.2));
            assert_eq!(copied, expected);
            assert_eq!(scratch.permutation.capacity(), capacity);
        }
    }

