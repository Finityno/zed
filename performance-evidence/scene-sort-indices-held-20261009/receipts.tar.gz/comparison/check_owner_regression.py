from pathlib import Path
import subprocess,json,hashlib,os
r=Path(__file__).parent;out=r/'copy-owner-regression';out.mkdir();rows=[]
for lane in ['baseline','candidate']:
 cmd=[str(r/f'{lane}-bare-artifacts/gpui-ada3fb4d7b1cfe56'),'copied_sprite_sort_preserves_source_without_a_permutation_owner','--nocapture','--test-threads=1'];p=out/(lane+'.log')
 with p.open('w') as f:code=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=120).returncode
 rows.append({'lane':lane,'command':cmd,'exit_code':code,'log':str(p),'log_sha256':hashlib.sha256(p.read_bytes()).hexdigest()});(r/'copy-owner-regression-receipts.json').write_text(json.dumps(rows,indent=2)+'\n')
 assert 'running 1 test' in p.read_text()
 assert code==(101 if lane=='baseline' else 0),p.read_text()
 if lane=='baseline':assert 'left: 2048' in p.read_text() and 'right: 0' in p.read_text(),p.read_text()
print('native source unchanged/copy stable/permutationowner fails before; passes after both64/128bit andinplace reuse')
