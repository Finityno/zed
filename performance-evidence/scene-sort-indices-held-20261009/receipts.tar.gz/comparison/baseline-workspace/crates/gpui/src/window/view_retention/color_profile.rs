use super::*;
use std::{hash::{Hash, Hasher}, hint::black_box};

struct CodeRow { index: usize, runs: usize, tail: usize, recolor: bool, decorated: bool }

impl Render for CodeRow {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        let mut text = "token ".repeat(self.runs);
        if self.tail > 0 { text.replace_range(text.len()-6.., &format!("{:05} ", self.tail % 100000)); }
        let highlights = (0..self.runs).map(|run| {
            (run*6..(run+1)*6, crate::HighlightStyle {
                color: Some(PALETTE[(run + usize::from(self.recolor)) % PALETTE.len()]),
                underline: self.decorated.then_some(crate::UnderlineStyle { thickness: px(1.), color: None, wavy: false }),
                ..Default::default()
            })
        }).collect::<Vec<_>>();
        div().id(("code-row", self.index)).w_full().h(px(24.)).whitespace_nowrap()
            .child(crate::StyledText::new(SharedString::from(text)).with_highlights(highlights))
    }
}

struct CodeTranscript { rows: Vec<Entity<CodeRow>>, list_state: ListState }

impl Render for CodeTranscript {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        let rows = self.rows.clone();
        div().size_full().child(list(self.list_state.clone(), move |index, _, _| rows[index].clone().into_any_element()).size_full())
    }
}

#[test]
#[ignore]
fn profile_colored_transcript() {
    let case = std::env::var("COLOR_PROFILE_CASE").expect("case");
    let iterations: usize = std::env::var("COLOR_PROFILE_ITERATIONS").expect("iterations").parse().expect("iterations");
    let parts: Vec<_> = case.split('-').collect();
    let scenario = parts[1];
    let retained = parts[2] == "on";
    let count: usize = parts[3].parse().expect("rows");
    let runs: usize = parts[4].parse().expect("runs");
    assert!(iterations > 0 && iterations.is_multiple_of(2));
    #[cfg(gpui_layout_sets_census)] crate::perf_count::census::start();
    let mut cx = super::super::super::layout_retention_tests::text_system_context(0);
    cx.update(|cx| cx.set_view_retention(retained));
    let window = cx.add_window(|_, cx| {
        let rows = (0..count).map(|index| cx.new(|_| CodeRow { index, runs, tail: 0, recolor: false, decorated: scenario == "decorated" })).collect();
        CodeTranscript { rows, list_state: ListState::new(count, ListAlignment::Bottom, px(200.)) }
    });
    cx.simulate_window_resize(window.into(), size(px(900.), px(1200.)));
    let (rows, list_state) = window.read_with(&cx, |view, _| (view.rows.clone(), view.list_state.clone())).expect("window");
    if scenario == "scroll" { list_state.scroll_to(ListOffset { item_ix: count.saturating_sub(30), offset_in_item: px(0.) }); }
    let frame = |cx: &mut TestAppContext| {
        cx.update_window(window.into(), |_, window, cx| window.draw(cx).clear(cx)).expect("draw");
    };
    for _ in 0..4 { frame(&mut cx); }
    cx.update_window(window.into(), |_, window, _| window.reset_frame_work_stats(false)).expect("disable clocks");
    #[cfg(gpui_line_color_attribution)] crate::window::glyph_painting::color_attribution::reset();
    let audit_frames = std::env::var_os("LAYOUT_AUDIT_FRAMES").is_some();
    let mut audit = Vec::with_capacity(if audit_frames { iterations } else { 0 });
    let start = Instant::now();
    let cpu_start = super::splice_profile::thread_cpu_ns();
    for index in 0..iterations {
        match scenario {
            "redraw" | "decorated" => window.update(&mut cx, |_, _, cx| cx.notify()).expect("notify"),
            "rebuild" => window.update(&mut cx, |_, window, _| window.refresh()).expect("refresh"),
            "stream" => rows[count-1].update(&mut cx, |row, cx| { row.tail += 1; cx.notify(); }),
            "recolor" => {
                for row in &rows { row.update(&mut cx, |row, cx| { row.recolor = !row.recolor; cx.notify(); }); }
            }
            "scroll" => { list_state.scroll_by(px(if (index/60)%2 == 0 { 6. } else { -6. })); window.update(&mut cx, |_, _, cx| cx.notify()).expect("notify"); }
            "resize" => cx.simulate_window_resize(window.into(), size(px(if index%2 == 0 { 880. } else { 900. }), px(1200.))),
            _ => panic!("unknown scenario"),
        }
        frame(&mut cx);
        if audit_frames { audit.push(cx.update_window(window.into(), |_, window, _| describe_frame(window)).expect("audit frame")); }
        black_box(&cx);
    }
    let cpu_ns = super::splice_profile::thread_cpu_ns()-cpu_start;
    let elapsed_ns = start.elapsed().as_nanos();
    #[cfg(gpui_layout_sets_census)] let (held_bytes, peak_bytes, requested_bytes, allocation_calls) = crate::perf_count::census::finish();
    #[cfg(not(gpui_layout_sets_census))] let (held_bytes, peak_bytes, requested_bytes, allocation_calls) = (-1,-1,0,0);
    let (state_count, state_box_bytes, signature, replayed) = cx.update_window(window.into(), |_, window, _| {
        let mut hasher = std::collections::hash_map::DefaultHasher::new();
        describe_frame(window).hash(&mut hasher);
        (window.rendered_frame.element_states.len(), window.rendered_frame.element_states.values().map(|state| std::mem::size_of_val(state.inner.as_ref())).sum::<usize>(), hasher.finish(), window.line_glyph_cache.replayed_lines)
    }).expect("audit");
    let (frames, nodes, node_high_water) = cx.update_window(window.into(), |_, window, _| {
        (window.frame_work_stats().frames, window.layout_engine.as_ref().expect("engine").layout_owner_node_counts(), window.layout_engine.as_ref().expect("engine").layout_owner_node_high_water())
    }).expect("owner counts");
    let current_rss_kib = crate::perf_count::native_current_rss_kib();
    if audit_frames { let mut hasher = std::collections::hash_map::DefaultHasher::new(); audit.hash(&mut hasher); println!("FRAME_AUDIT {}", hasher.finish()); }

    println!("COLOR_PROFILE {{\"case\":\"{case}\",\"iterations\":{iterations},\"cpu_ns\":{cpu_ns},\"elapsed_ns\":{elapsed_ns},\"signature\":{signature},\"state_count\":{state_count},\"state_box_bytes\":{state_box_bytes},\"replayed\":{replayed},\"frames\":{frames},\"nodes\":{nodes},\"node_high_water\":{node_high_water},\"current_rss_kib\":{current_rss_kib},\"held_bytes\":{held_bytes},\"peak_bytes\":{peak_bytes},\"requested_bytes\":{requested_bytes},\"allocation_calls\":{allocation_calls}}}");
}
