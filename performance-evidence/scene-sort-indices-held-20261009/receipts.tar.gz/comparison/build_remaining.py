from pathlib import Path
import subprocess,json,time
r=Path(__file__).parent;rows=[]
for lane,kind in [('baseline','bare'),('baseline','census'),('candidate','census')]:
 start=time.time();result=subprocess.run(['python3',str(r/'build_native.py'),lane,kind],cwd=r,timeout=630);rows.append({'lane':lane,'kind':kind,'exit_code':result.returncode,'started_unix':start,'finished_unix':time.time()});(r/'remaining-build-order.json').write_text(json.dumps(rows,indent=2)+'\n');assert result.returncode==0
