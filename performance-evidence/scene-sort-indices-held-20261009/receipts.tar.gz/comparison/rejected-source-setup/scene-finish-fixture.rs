use super::*;
use std::{hint::black_box, hash::{Hash, Hasher}, time::Instant};

fn profile_scene(case: &str, captures: &serde_json::Value) -> Scene {
    let mut scene = Scene::default();
    let name = case.strip_prefix("finish-").expect("case prefix");
    let glyph = |order, texture, tile| {
        let mut glyph = shimmering_glyph(0);
        glyph.effect = SpriteEffect::default();
        glyph.order = order;
        glyph.tile.texture_id.index = texture;
        glyph.tile.tile_id = crate::TileId(tile);
        glyph
    };
    if let Some(control) = name.strip_prefix("control-") {
        for index in 0..if control=="empty" {0} else {2048u32} {
            let key = match control {
                "sorted" => (index,0,index),
                "equal" => (0,0,0),
                "wide" => (u32::MAX-index,u32::MAX-index/3,u32::MAX-index/7),
                "reverse" => (2048-index,0,index),
                "mixed" => (index%17,index%3,index%29),
                _ => panic!("control"),
            };
            scene.painted_monochrome_sprites.push(glyph(key.0,key.1,key.2));
        }
    } else {
        let data = &captures[name];
        let number = |v: &serde_json::Value| u32::try_from(v.as_u64().expect("integer")).expect("u32");
        for key in data["monochrome"].as_array().expect("mono") {
            assert_eq!(number(&key[3]),0);assert_eq!(number(&key[4]),0);
            scene.painted_monochrome_sprites.push(glyph(number(&key[0]),number(&key[1]),number(&key[2])));
        }
        for order in data["quad_orders"].as_array().expect("quads") {
            let mut quad = opaque_quad();quad.order=number(order);scene.quads.push(quad);
        }
        assert!(data["subpixel"].as_array().expect("subpixel").is_empty());
        assert!(data["polychrome"].as_array().expect("color").is_empty());
        assert!(data["shadow_orders"].as_array().expect("shadows").is_empty());
        assert!(data["path_orders"].as_array().expect("paths").is_empty());
        assert!(data["surface_orders"].as_array().expect("surfaces").is_empty());
        for order in data["underline_orders"].as_array().expect("underlines") {
            scene.underlines.push(Underline { order:number(order),pad:0,bounds:unit_bounds(),content_mask:ContentMask{bounds:unit_bounds()},color:crate::white(),thickness:ScaledPixels(1.),wavy:false.into() });
        }
    }
    scene
}

fn thread_cpu_ns() -> u64 {
    let mut clock = libc::timespec { tv_sec: 0, tv_nsec: 0 };
    assert_eq!(unsafe { libc::clock_gettime(libc::CLOCK_THREAD_CPUTIME_ID, &mut clock) }, 0);
    clock.tv_sec as u64 * 1_000_000_000 + clock.tv_nsec as u64
}

#[test]
#[ignore]
fn profile_captured_scene_finish() {
    let case=std::env::var("SCENE_FINISH_CASE").expect("case");
    let iterations:usize=std::env::var("SCENE_FINISH_ITERATIONS").expect("iterations").parse().expect("number");
    let captures: serde_json::Value = serde_json::from_str(include_str!("captured-sort-inputs.json")).expect("captured input");
    #[cfg(gpui_layout_sets_census)] crate::perf_count::census::start();
    let mut scene=profile_scene(&case, &captures);
    for _ in 0..4 {scene.finish();}
    let cpu_start=thread_cpu_ns();
    let start=Instant::now();
    for _ in 0..iterations {scene.finish();black_box(&scene);}
    let elapsed_ns=start.elapsed().as_nanos();
    let cpu_ns=thread_cpu_ns()-cpu_start;
    #[cfg(gpui_layout_sets_census)] let (held_bytes,peak_bytes,requested_bytes,allocation_calls)=crate::perf_count::census::finish();
    #[cfg(not(gpui_layout_sets_census))] let (held_bytes,peak_bytes,requested_bytes,allocation_calls)=(-1,-1,0,0);
    let scratch_bytes=scene.draw_order_scratch.keys.capacity()*8+scene.draw_order_scratch.sprite_keys.capacity()*16+scene.draw_order_scratch.radix_scratch.capacity()*8+scene.draw_order_scratch.permutation.capacity()*4;
    let permutation_bytes=scene.draw_order_scratch.permutation.capacity()*4;
    let mut hasher=std::collections::hash_map::DefaultHasher::new();
    format!("{:?}{:?}{:?}",scene.monochrome_sprites,scene.quads,scene.underlines).hash(&mut hasher);
    let signature=hasher.finish();
    let glyphs=scene.monochrome_sprites.len();
    let current_rss_kib=crate::perf_count::native_current_rss_kib();
    println!("SCENE_FINISH_PROFILE {}",serde_json::json!({"case":case,"iterations":iterations,"cpu_ns":cpu_ns,"elapsed_ns":elapsed_ns,"held_bytes":held_bytes,"peak_bytes":peak_bytes,"requested_bytes":requested_bytes,"allocation_calls":allocation_calls,"signature":signature,"glyphs":glyphs,"scratch_bytes":scratch_bytes,"permutation_bytes":permutation_bytes,"current_rss_kib":current_rss_kib}));
}
