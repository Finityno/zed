from pathlib import Path
import json,hashlib,statistics,sys
r=Path(__file__).parent;p=json.loads((r/'policy.json').read_text());assert hashlib.sha256((r/'policy.json').read_bytes()).hexdigest()==(r/'policy.sha256').read_text().strip();summary=[];failures=[]
kinds=['bare'] if '--bare-only' in sys.argv else ['bare','census']
for kind in kinds:
 pairs=p['timing_pairs'] if kind=='bare' else p['memory_pairs'];rows=json.loads((r/(kind+'-samples.json')).read_text());assert len(rows)==len(p['controls'])*pairs*2
 for case in p['controls']:
  lanes={lane:[v for v in rows if v['case']==case and v['lane']==lane] for lane in ['baseline','candidate']};assert all(len(v)==pairs and all(row['exit_code']==0 for row in v) for v in lanes.values())
  for pair in range(pairs):
   b=next(v for v in lanes['baseline'] if v['pair']==pair);c=next(v for v in lanes['candidate'] if v['pair']==pair)
   for field in ['signature','frame_hash','state_count','state_box_bytes','frames','nodes','node_high_water','glyphs']:
    if field in b or field in c:assert b[field]==c[field],(kind,case,pair,field,b.get(field),c.get(field))
  fields=['cpu_ns','elapsed_ns','child_cpu_ns','current_rss_kib','peak_rss_kib'] if kind=='bare' else ['held_bytes','peak_bytes','requested_bytes','allocation_calls','current_rss_kib','peak_rss_kib']
  if kind=='census' and case in p['primary']:fields+=['scratch_bytes']
  entry={'kind':kind,'case':case,'fields':{}}
  for field in fields:
   base=[v[field] for v in lanes['baseline']];cand=[v[field] for v in lanes['candidate']];bm=statistics.median(base);cm=statistics.median(cand);br=max(base)-min(base);cr=max(cand)-min(cand);delta=cm-bm;gain=-delta/bm if bm else 0;target=None
   primary=case in p['primary'] and ((kind=='bare' and field in ['cpu_ns','elapsed_ns']) or (kind=='census' and field in ['held_bytes','scratch_bytes']))
   if primary:
    target=p['primary_gain_fraction'] if kind=='bare' else p['primary_live_gain_fraction'] if field=='held_bytes' else p['primary_scratch_gain_fraction'];passed=gain>=target and -delta>max(br,cr);budget=None;gate='declared_primary_above_both_full_ranges'
   else:
    budget=0 if field in ['held_bytes','peak_bytes','requested_bytes','allocation_calls'] else br;passed=delta<=budget;gate='zero_heap_churn_or_full_baseline_range_control'
   metric={'baseline_median':bm,'candidate_median':cm,'delta':delta,'fraction_gain':gain,'baseline_range':br,'candidate_range':cr,'budget':budget,'target_fraction':target,'gate':gate,'pass':passed};entry['fields'][field]=metric
   if not passed:failures.append({'kind':kind,'case':case,'field':field,**metric})
  summary.append(entry)
name='bare-only-decision' if '--bare-only' in sys.argv else 'decision'
(r/('bare-only-summary.json' if '--bare-only' in sys.argv else 'summary.json')).write_text(json.dumps(summary,indent=2)+'\n');decision={'qualified':not failures and kinds==['bare','census'],'status':'PERFORMANCE_GATES_PASS_PENDING_OWNING_CHECKS_REVIEW' if not failures and len(kinds)==2 else 'HELD_UNMERGED' if failures else 'BARE_PASS_PENDING_CENSUS','failures':failures,'controls':len(p['controls']),'native_children':sum(len(p['controls'])*(p['timing_pairs'] if k=='bare' else p['memory_pairs'])*2 for k in kinds),'primary':[v for v in summary if v['case'] in p['primary']],'policy_sha256':hashlib.sha256((r/'policy.json').read_bytes()).hexdigest(),'no_unchanged_resampling':True,'no_app_GPU_platform_gain':True,'memory_growth_budget':0};(r/(name+'.json')).write_text(json.dumps(decision,indent=2)+'\n');print(json.dumps({'qualified':decision['qualified'],'children':decision['native_children'],'failed_fields':len(failures),'failures':[(f['kind'],f['case'],f['field'],f['delta'],f['budget']) for f in failures],'primary':[(v['kind'],v['case'],{k:f['fraction_gain'] for k,f in v['fields'].items() if f['target_fraction']}) for v in decision['primary']]}))
