from pathlib import Path
import hashlib,json
r=Path(__file__).parent;bins={lane:{kind:{'path':str(r/f'{lane}-{kind}-artifacts/gpui-ada3fb4d7b1cfe56'),'sha256':hashlib.sha256((r/f'{lane}-{kind}-artifacts/gpui-ada3fb4d7b1cfe56').read_bytes()).hexdigest(),'bytes':(r/f'{lane}-{kind}-artifacts/gpui-ada3fb4d7b1cfe56').stat().st_size} for kind in ['bare','census']} for lane in ['baseline','candidate']};(r/'binary-identities.json').write_text(json.dumps(bins,indent=2)+'\n');print({lane:{kind:value['sha256'] for kind,value in b.items()} for lane,b in bins.items()})
