#[cfg(feature = "profiler")]
use crate::DebugFrameOverlayMode;
#[cfg(any(feature = "inspector", debug_assertions))]
use crate::Inspector;
#[cfg(feature = "profiler")]
use crate::profiler;
use crate::{
    Action, AnyDrag, AnyElement, AnyImageCache, AnyTooltip, AnyView, App, AppContext, Arena, Asset,
    AsyncWindowContext, AtlasTile, AvailableSpace, Background, BorderStyle, Bounds, BoxShadow,
    Capslock, Context, Corners, CursorHideMode, CursorStyle, Decorations, DevicePixels,
    DispatchActionListener, DispatchNodeId, DispatchTree, DisplayId, Edges, Effect, Entity,
    EntityId, EventEmitter, FileDropEvent, FontId, Global, GlobalElementId, GlyphId, GpuSpecs,
    Hsla, InputHandler, IsZero, KeyBinding, KeyContext, KeyDownEvent, KeyEvent, Keystroke,
    KeystrokeEvent, LayoutId, LineLayoutIndex, Modifiers, ModifiersChangedEvent, MonochromeSprite,
    MouseButton, MouseEvent, MouseMoveEvent, MouseUpEvent, NativeMenuItem, Path, Pixels,
    PlatformAtlas,
    PlatformDisplay, PlatformInput, PlatformInputHandler, PlatformWindow, Point, PolychromeSprite,
    PresentOutcome, Priority, PromptButton, PromptLevel, Quad, Render, RenderGlyphParams,
    RenderImage,
    RenderImageParams, RenderSvgParams, Replay, ResizeEdge, Rgba, SMOOTH_SVG_SCALE_FACTOR,
    SUBPIXEL_VARIANTS_X, SUBPIXEL_VARIANTS_Y, ScaledPixels, Scene, Shadow, SharedString, Size,
    OpacityCycle, SpriteEffect, StrikethroughStyle, Style, SubscriberSet, Subscription,
    TimeTransition,
    SystemWindowTab, SystemWindowTabController, TabStopMap, TaffyLayoutEngine, Task,
    TextInputConfiguration, TextInputStateChange, TextRenderingMode, TextStyle,
    TextStyleRefinement, ThermalState,
    TransformationMatrix, Underline, UnderlineStyle, WindowAppearance, WindowBackgroundAppearance,
    WindowBounds, WindowControls, WindowDecorations, WindowGlassStyle, WindowOptions, WindowParams,
    WindowTextSystem, WindowVisibility, point, prelude::*, px, rems, size, transparent_black,
};

use crate::gestures::{GestureTuning, RecognizedTouchGesture, TouchGestureRecognizer};
use crate::interactive::TouchEvent;
use anyhow::{Context as _, Result, anyhow};
use collections::{FxHashMap, FxHashSet};
#[cfg(target_os = "macos")]
use core_video::pixel_buffer::CVPixelBuffer;
use derive_more::{Deref, DerefMut};
use futures::channel::oneshot;
use gpui_util::post_inc;
use gpui_util::{ResultExt, measure};
use itertools::FoldWhile::{Continue, Done};
use itertools::Itertools;
use parking_lot::RwLock;
use raw_window_handle::{HandleError, HasDisplayHandle, HasWindowHandle};
use refineable::Refineable;
use scheduler::Instant;
use slotmap::SlotMap;
use smallvec::SmallVec;
use std::{
    any::{Any, TypeId},
    borrow::Cow,
    cell::{Cell, RefCell},
    cmp,
    fmt::{Debug, Display},
    hash::{Hash, Hasher},
    marker::PhantomData,
    mem,
    ops::{DerefMut, Range},
    rc::Rc,
    sync::{
        Arc, Weak,
        atomic::{AtomicBool, AtomicUsize, Ordering::SeqCst},
    },
    thread::AccessError,
    time::Duration,
};
use uuid::Uuid;

pub(crate) mod a11y;
#[cfg(feature = "profiler")]
mod draw_profile;
mod frame_work;
mod glyph_painting;
mod layout_keys;
#[cfg(test)]
mod layout_retention_tests;
#[cfg(test)]
mod replay_tests;
pub(crate) mod view_retention;
mod prompts;

pub use a11y::A11ySubtreeBuilder;
pub use frame_work::{FrameWorkStats, ViewRebuildCounts};
pub use view_retention::{DrawDependency, ViewRebuildReason};
pub(crate) use frame_work::add_elapsed;
pub(crate) use glyph_painting::{LineGlyphPainter, LineGlyphsLayout};

use self::a11y::A11y;
#[cfg(not(target_family = "wasm"))]
use self::a11y::ROOT_NODE_ID;
use crate::arena::SHRINK_AFTER_DURATION;
use crate::util::{
    CapacityShrink, atomic_incr_if_not_zero, ceil_to_device_pixel, floor_to_device_pixel,
    round_half_toward_zero, round_half_toward_zero_f64, round_stroke_to_device_pixel,
    round_to_device_pixel,
};
pub use prompts::*;

/// Default window size used when no explicit size is provided.
pub const DEFAULT_WINDOW_SIZE: Size<Pixels> = size(px(1536.), px(1095.));

/// A 6:5 aspect ratio minimum window size to be used for functional,
/// additional-to-main-Zed windows, like the settings and rules library windows.
pub const DEFAULT_ADDITIONAL_WINDOW_SIZE: Size<Pixels> = Size {
    width: Pixels(900.),
    height: Pixels(750.),
};

/// Represents the two different phases when dispatching events.
#[derive(Default, Copy, Clone, Debug, Eq, PartialEq)]
pub enum DispatchPhase {
    /// After the capture phase comes the bubble phase, in which mouse event listeners are
    /// invoked front to back and keyboard event listeners are invoked from the focused element
    /// to the root of the element tree. This is the phase you'll most commonly want to use when
    /// registering event listeners.
    #[default]
    Bubble,
    /// During the initial capture phase, mouse event listeners are invoked back to front, and keyboard
    /// listeners are invoked from the root of the tree downward toward the focused element. This phase
    /// is used for special purposes such as clearing the "pressed" state for click events. If
    /// you stop event propagation during this phase, you need to know what you're doing. Handlers
    /// outside of the immediate region may rely on detecting non-local events during this phase.
    Capture,
}

impl DispatchPhase {
    /// Returns true if this represents the "bubble" phase.
    #[inline]
    pub fn bubble(self) -> bool {
        self == DispatchPhase::Bubble
    }

    /// Returns true if this represents the "capture" phase.
    #[inline]
    pub fn capture(self) -> bool {
        self == DispatchPhase::Capture
    }
}

struct WindowInvalidatorInner {
    #[cfg(feature = "profiler")]
    pub window_id: WindowId,
    pub dirty: bool,
    pub draw_phase: DrawPhase,
    pub dirty_views: FxHashSet<EntityId>,
    pub update_count: usize,
    #[cfg(feature = "profiler")]
    pub frame_dirty: FrameDirtyAccumulator,
    pub platform_waker: Option<Rc<dyn Fn()>>,
}

/// Per-frame invalidation bookkeeping, drained at draw time and emitted to the
/// frame profiler. Tracks when the current frame first became dirty and how
/// many invalidations were coalesced into it, whenever the profiler is
/// compiled in. Retention of the resulting per-frame records is what
/// `profiler::trace_enabled()` controls, not this measurement.
#[cfg(feature = "profiler")]
#[derive(Default)]
struct FrameDirtyAccumulator {
    dirty_at: Option<Instant>,
    invalidations: u64,
}

#[derive(Clone)]
pub(crate) struct WindowInvalidator {
    inner: Rc<RefCell<WindowInvalidatorInner>>,
}

impl WindowInvalidator {
    pub fn new(#[allow(unused_variables)] window_id: WindowId) -> Self {
        WindowInvalidator {
            inner: Rc::new(RefCell::new(WindowInvalidatorInner {
                #[cfg(feature = "profiler")]
                window_id,
                dirty: true,
                draw_phase: DrawPhase::None,
                dirty_views: FxHashSet::default(),
                update_count: 0,
                #[cfg(feature = "profiler")]
                frame_dirty: FrameDirtyAccumulator::default(),
                platform_waker: None,
            })),
        }
    }

    pub fn invalidate_view(&self, entity: EntityId, cx: &mut App) -> bool {
        let mut inner = self.inner.borrow_mut();
        inner.update_count += 1;
        inner.dirty_views.insert(entity);
        if inner.draw_phase == DrawPhase::None {
            #[cfg(feature = "profiler")]
            let dirty_at = Self::record_frame_dirty(&mut inner);
            let became_dirty = !inner.dirty;
            inner.dirty = true;
            let waker = became_dirty.then(|| inner.platform_waker.clone()).flatten();
            #[cfg(feature = "profiler")]
            let window_id = inner.window_id;
            drop(inner);
            #[cfg(feature = "profiler")]
            if became_dirty {
                profiler::journal::record_frame_pending(window_id, dirty_at);
            }
            cx.push_effect(Effect::Notify { emitter: entity });
            if let Some(waker) = waker {
                waker();
            }
            true
        } else {
            false
        }
    }

    pub fn is_dirty(&self) -> bool {
        self.inner.borrow().dirty
    }

    pub fn set_dirty(&self, dirty: bool) {
        let mut inner = self.inner.borrow_mut();
        let became_dirty = dirty && !inner.dirty;
        inner.dirty = dirty;
        if dirty {
            inner.update_count += 1;
        }
        #[cfg(feature = "profiler")]
        let dirty_at = dirty.then(|| Self::record_frame_dirty(&mut inner));
        let waker = became_dirty.then(|| inner.platform_waker.clone()).flatten();
        #[cfg(feature = "profiler")]
        let window_id = inner.window_id;
        drop(inner);
        #[cfg(feature = "profiler")]
        if became_dirty && let Some(dirty_at) = dirty_at {
            profiler::journal::record_frame_pending(window_id, dirty_at);
        }
        if let Some(waker) = waker {
            waker();
        }
    }

    pub fn set_platform_waker(&self, waker: Option<Rc<dyn Fn()>>) {
        let mut inner = self.inner.borrow_mut();
        inner.platform_waker = waker;
        let waker = inner.dirty.then(|| inner.platform_waker.clone()).flatten();
        drop(inner);
        if let Some(waker) = waker {
            waker();
        }
    }

    /// Wakes the platform's frame-request source so a frame request is
    /// delivered even if the platform stops requesting frames for idle
    /// windows. No-op on platforms without a frame waker.
    pub fn wake_platform(&self) {
        let waker = self.inner.borrow().platform_waker.clone();
        if let Some(waker) = waker {
            waker();
        }
    }

    pub fn set_phase(&self, phase: DrawPhase) {
        self.inner.borrow_mut().draw_phase = phase
    }

    pub fn update_count(&self) -> usize {
        self.inner.borrow().update_count
    }

    #[cfg(feature = "profiler")]
    fn record_frame_dirty(inner: &mut WindowInvalidatorInner) -> Instant {
        let dirty_at = *inner.frame_dirty.dirty_at.get_or_insert_with(Instant::now);
        inner.frame_dirty.invalidations += 1;
        dirty_at
    }

    #[cfg(feature = "profiler")]
    fn take_frame_dirty(&self) -> FrameDirtyAccumulator {
        mem::take(&mut self.inner.borrow_mut().frame_dirty)
    }

    pub fn take_views(&self) -> FxHashSet<EntityId> {
        mem::take(&mut self.inner.borrow_mut().dirty_views)
    }

    pub fn replace_views(&self, views: FxHashSet<EntityId>) {
        self.inner.borrow_mut().dirty_views = views;
    }

    pub fn not_drawing(&self) -> bool {
        self.inner.borrow().draw_phase == DrawPhase::None
    }

    #[track_caller]
    pub fn debug_assert_paint(&self) {
        debug_assert!(
            matches!(self.inner.borrow().draw_phase, DrawPhase::Paint),
            "this method can only be called during paint"
        );
    }

    #[track_caller]
    pub fn debug_assert_prepaint(&self) {
        debug_assert!(
            matches!(self.inner.borrow().draw_phase, DrawPhase::Prepaint),
            "this method can only be called during request_layout, or prepaint"
        );
    }

    pub fn is_painting(&self) -> bool {
        matches!(self.inner.borrow().draw_phase, DrawPhase::Paint)
    }

    #[track_caller]
    pub fn debug_assert_paint_or_prepaint(&self) {
        debug_assert!(
            matches!(
                self.inner.borrow().draw_phase,
                DrawPhase::Paint | DrawPhase::Prepaint
            ),
            "this method can only be called during request_layout, prepaint, or paint"
        );
    }
}

type AnyObserver = Box<dyn FnMut(&mut Window, &mut App) -> bool + 'static>;

pub(crate) type AnyWindowFocusListener =
    Box<dyn FnMut(&WindowFocusEvent, &mut Window, &mut App) -> bool + 'static>;

pub(crate) struct WindowFocusEvent {
    pub(crate) previous_focus_path: SmallVec<[FocusId; 8]>,
    pub(crate) current_focus_path: SmallVec<[FocusId; 8]>,
}

impl WindowFocusEvent {
    pub fn is_focus_in(&self, focus_id: FocusId) -> bool {
        !self.previous_focus_path.contains(&focus_id) && self.current_focus_path.contains(&focus_id)
    }

    pub fn is_focus_out(&self, focus_id: FocusId) -> bool {
        self.previous_focus_path.contains(&focus_id) && !self.current_focus_path.contains(&focus_id)
    }
}

/// This is provided when subscribing for `Context::on_focus_out` events.
pub struct FocusOutEvent {
    /// A weak focus handle representing what was blurred.
    pub blurred: WeakFocusHandle,
}

slotmap::new_key_type! {
    /// A globally unique identifier for a focusable element.
    pub struct FocusId;
}

thread_local! {
    /// Fallback arena used when no app-specific arena is active.
    /// In production, each window draw sets CURRENT_ELEMENT_ARENA to the app's arena.
    pub(crate) static ELEMENT_ARENA: RefCell<Arena> = RefCell::new(Arena::new(1024 * 1024));

    /// Points to the current App's element arena during draw operations.
    /// This allows multiple test Apps to have isolated arenas, preventing
    /// cross-session corruption when the scheduler interleaves their tasks.
    static CURRENT_ELEMENT_ARENA: Cell<Option<*const RefCell<Arena>>> = const { Cell::new(None) };
}

/// Whether a window draw is currently in progress on this thread.
///
/// This holds exactly while an `ElementArenaScope` is active: nested scopes
/// restore the previous (still set) arena pointer, so `CURRENT_ELEMENT_ARENA`
/// is `Some` from the outermost draw's start to its end.
///
/// The `on_request_frame` callback uses this to defer draw requests that
/// arrive re-entrantly while a draw is already on the stack (e.g. via nested
/// message pumping in the Windows window procedure), instead of running a
/// nested draw or panicking on the already-borrowed App.
fn draw_in_progress() -> bool {
    CURRENT_ELEMENT_ARENA.with(|current| current.get().is_some())
}

/// Allocates an element in the current arena. Uses the app-specific arena if one
/// is active (during draw), otherwise falls back to the thread-local ELEMENT_ARENA.
#[inline(always)]
pub(crate) fn with_element_arena<R>(callback: impl FnOnce(&mut Arena) -> R) -> R {
    let mut callback = Some(callback);
    let mut result = None;
    let access = with_element_arena_erased(&mut |arena| {
        result = Some(callback.take().expect("arena callback runs once")(arena));
    });
    drop(callback);
    access.expect("cannot access a Thread Local Storage value during or after destruction");
    result.expect("arena callback produces a result")
}

/// Scope guard that sets CURRENT_ELEMENT_ARENA for the duration of a draw
/// operation and tracks the arena's scope depth, so that a nested draw's
/// `ArenaClearNeeded::clear` is deferred rather than freeing memory the outer
/// draw still references (see `Arena::clear`).
///
/// Call [`ElementArenaScope::exit`] with the same arena that was entered to
/// obtain the [`ArenaClearNeeded`] token the draw now owes; requiring `exit`
/// makes it impossible to request a clear before the scope has ended. The
/// scope's teardown — restoring the thread-local and balancing `begin_scope`
/// with `end_scope` — happens in `Drop`, so the arena's scope depth stays
/// balanced on every path, including when a panic unwinds a draw before `exit`
/// is reached. (If teardown lived only in `exit`, such a panic would leave the
/// scope depth permanently elevated and defer every future clear, leaking
/// memory unboundedly.)
pub(crate) struct ElementArenaScope {
    /// The entered arena: compared against the argument in `exit`, and
    /// dereferenced in `Drop` to end its scope (see the SAFETY note there).
    entered: *const RefCell<Arena>,
    previous: Option<*const RefCell<Arena>>,
    exited: bool,
}

impl ElementArenaScope {
    /// Enter a scope where element allocations use the given arena.
    pub(crate) fn enter(arena: &RefCell<Arena>) -> Self {
        arena.borrow_mut().begin_scope();
        let previous = CURRENT_ELEMENT_ARENA.with(|current| {
            let prev = current.get();
            current.set(Some(arena as *const RefCell<Arena>));
            prev
        });
        Self {
            entered: arena as *const RefCell<Arena>,
            previous,
            exited: false,
        }
    }

    /// End the scope: restores the previously-current arena and ends the
    /// arena's clear-deferral scope. Returns the token for the arena clear the
    /// draw now owes; producing it here makes it impossible to request a clear
    /// before the scope has ended (which would be silently deferred forever).
    ///
    /// Panics if passed a different arena than was entered: ending the scope
    /// of the wrong arena would unbalance two arenas' scope depths, allowing
    /// one of them to clear while a draw still references its memory.
    pub(crate) fn exit(mut self, arena: &RefCell<Arena>) -> ArenaClearNeeded {
        assert!(
            std::ptr::eq(self.entered, arena),
            "ElementArenaScope::exit called with a different arena than was entered"
        );
        self.exited = true;
        // Teardown (restoring the thread-local and ending the arena's
        // clear-deferral scope) runs in `Drop`, which fires both here — `self`
        // is dropped as `exit` returns, before the token reaches the caller —
        // and when a panic unwinds the draw before `exit` is reached.
        ArenaClearNeeded::new(arena)
    }
}

impl Drop for ElementArenaScope {
    fn drop(&mut self) {
        // Teardown lives here (rather than in `exit`) so it runs exactly once on
        // every path: `exit` consumes and drops the guard on the normal path,
        // and unwinding drops it on the panic path. Balancing `begin_scope` here
        // keeps the arena's scope depth correct even when a draw panics; if this
        // only happened in `exit`, a panic between `enter` and `exit` would leave
        // the depth elevated and defer every future clear.
        CURRENT_ELEMENT_ARENA.with(|current| {
            current.set(self.previous);
        });
        // SAFETY: `entered` came from a `&RefCell<Arena>` in `enter`, and the
        // arena (owned by the `App` being drawn) outlives this guard on both the
        // normal and unwinding paths, since the guard is a local of the draw.
        unsafe { &*self.entered }.borrow_mut().end_scope();
        if !self.exited && !std::thread::panicking() {
            debug_assert!(false, "ElementArenaScope dropped without calling exit()");
            log::error!(
                "ElementArenaScope dropped without calling exit(); \
                 the arena clear for this draw was never requested"
            );
        }
    }
}

/// Returned when the element arena has been used and so must be cleared before the next draw.
#[must_use]
pub struct ArenaClearNeeded {
    /// Identity of the arena that was drawn into. Only ever compared against
    /// another pointer in `clear`; never dereferenced.
    arena: *const RefCell<Arena>,
}

impl ArenaClearNeeded {
    /// Create a new ArenaClearNeeded token for the App whose arena was drawn
    /// into. Private: the only way to obtain one is [`ElementArenaScope::exit`].
    fn new(arena: &RefCell<Arena>) -> Self {
        Self {
            arena: arena as *const RefCell<Arena>,
        }
    }

    /// Clear the element arena of the App the draw ran against. If an enclosing
    /// draw is still in progress (this draw was nested inside it), the clear is
    /// deferred to the enclosing draw's own `ArenaClearNeeded` so that its live
    /// allocations aren't freed.
    ///
    /// Panics if passed a different App than the draw ran against, since
    /// clearing another App's arena could free memory its draws still
    /// reference.
    pub fn clear(self, cx: &mut App) {
        assert!(
            std::ptr::eq(self.arena, &cx.element_arena),
            "ArenaClearNeeded::clear called with a different App than the draw ran against"
        );
        let now = cx.background_executor().now();
        cx.element_arena.borrow_mut().clear_at(now);
    }
}

pub(crate) type FocusMap = RwLock<SlotMap<FocusId, FocusRef>>;
pub(crate) struct FocusRef {
    pub(crate) ref_count: AtomicUsize,
    pub(crate) tab_index: isize,
    pub(crate) tab_stop: bool,
}

impl FocusId {
    /// Obtains whether the element associated with this handle is currently focused.
    pub fn is_focused(&self, window: &Window) -> bool {
        window.focus == Some(*self)
    }

    /// Obtains whether the element associated with this handle contains the focused
    /// element or is itself focused.
    pub fn contains_focused(&self, window: &Window, cx: &App) -> bool {
        window
            .focused(cx)
            .is_some_and(|focused| self.contains(focused.id, window))
    }

    /// Obtains whether the element associated with this handle is contained within the
    /// focused element or is itself focused.
    pub fn within_focused(&self, window: &Window, cx: &App) -> bool {
        let focused = window.focused(cx);
        focused.is_some_and(|focused| focused.id.contains(*self, window))
    }

    /// Obtains whether this handle contains the given handle in the most recently rendered frame.
    pub(crate) fn contains(&self, other: Self, window: &Window) -> bool {
        window.note_actions_read();
        window
            .rendered_frame
            .dispatch_tree
            .focus_contains(*self, other)
    }
}

/// A handle which can be used to track and manipulate the focused element in a window.
pub struct FocusHandle {
    pub(crate) id: FocusId,
    handles: Arc<FocusMap>,
    /// The index of this element in the tab order.
    pub tab_index: isize,
    /// Whether this element can be focused by tab navigation.
    pub tab_stop: bool,
}

impl std::fmt::Debug for FocusHandle {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_fmt(format_args!("FocusHandle({:?})", self.id))
    }
}

impl FocusHandle {
    pub(crate) fn new(handles: &Arc<FocusMap>) -> Self {
        let id = handles.write().insert(FocusRef {
            ref_count: AtomicUsize::new(1),
            tab_index: 0,
            tab_stop: false,
        });

        Self {
            id,
            tab_index: 0,
            tab_stop: false,
            handles: handles.clone(),
        }
    }

    pub(crate) fn for_id(id: FocusId, handles: &Arc<FocusMap>) -> Option<Self> {
        let lock = handles.read();
        let focus = lock.get(id)?;
        if atomic_incr_if_not_zero(&focus.ref_count) == 0 {
            return None;
        }
        Some(Self {
            id,
            tab_index: focus.tab_index,
            tab_stop: focus.tab_stop,
            handles: handles.clone(),
        })
    }

    /// Sets the tab index of the element associated with this handle.
    pub fn tab_index(mut self, index: isize) -> Self {
        self.tab_index = index;
        if let Some(focus) = self.handles.write().get_mut(self.id) {
            focus.tab_index = index;
        }
        self
    }

    /// Sets whether the element associated with this handle is a tab stop.
    ///
    /// When `false`, the element will not be included in the tab order.
    pub fn tab_stop(mut self, tab_stop: bool) -> Self {
        self.tab_stop = tab_stop;
        if let Some(focus) = self.handles.write().get_mut(self.id) {
            focus.tab_stop = tab_stop;
        }
        self
    }

    /// Converts this focus handle into a weak variant, which does not prevent it from being released.
    pub fn downgrade(&self) -> WeakFocusHandle {
        WeakFocusHandle {
            id: self.id,
            handles: Arc::downgrade(&self.handles),
        }
    }

    /// Moves the focus to the element associated with this handle.
    pub fn focus(&self, window: &mut Window, cx: &mut App) {
        window.focus(self, cx)
    }

    /// Obtains whether the element associated with this handle is currently focused.
    pub fn is_focused(&self, window: &Window) -> bool {
        self.id.is_focused(window)
    }

    /// Obtains whether the element associated with this handle contains the focused
    /// element or is itself focused.
    pub fn contains_focused(&self, window: &Window, cx: &App) -> bool {
        self.id.contains_focused(window, cx)
    }

    /// Obtains whether the element associated with this handle is contained within the
    /// focused element or is itself focused.
    pub fn within_focused(&self, window: &Window, cx: &mut App) -> bool {
        self.id.within_focused(window, cx)
    }

    /// Obtains whether this handle contains the given handle in the most recently rendered frame.
    pub fn contains(&self, other: &Self, window: &Window) -> bool {
        self.id.contains(other.id, window)
    }

    /// Dispatch an action on the element that rendered this focus handle
    pub fn dispatch_action(&self, action: &dyn Action, window: &mut Window, cx: &mut App) {
        if let Some(node_id) = window
            .rendered_frame
            .dispatch_tree
            .focusable_node_id(self.id)
        {
            window.dispatch_action_on_node(node_id, action, cx)
        }
    }
}

impl Clone for FocusHandle {
    fn clone(&self) -> Self {
        Self::for_id(self.id, &self.handles).unwrap()
    }
}

impl PartialEq for FocusHandle {
    fn eq(&self, other: &Self) -> bool {
        self.id == other.id
    }
}

impl Eq for FocusHandle {}

impl Drop for FocusHandle {
    fn drop(&mut self) {
        self.handles
            .read()
            .get(self.id)
            .unwrap()
            .ref_count
            .fetch_sub(1, SeqCst);
    }
}

/// A weak reference to a focus handle.
#[derive(Clone, Debug)]
pub struct WeakFocusHandle {
    pub(crate) id: FocusId,
    pub(crate) handles: Weak<FocusMap>,
}

impl WeakFocusHandle {
    /// Attempts to upgrade the [WeakFocusHandle] to a [FocusHandle].
    pub fn upgrade(&self) -> Option<FocusHandle> {
        let handles = self.handles.upgrade()?;
        FocusHandle::for_id(self.id, &handles)
    }
}

impl PartialEq for WeakFocusHandle {
    fn eq(&self, other: &WeakFocusHandle) -> bool {
        self.id == other.id
    }
}

impl Eq for WeakFocusHandle {}

impl PartialEq<FocusHandle> for WeakFocusHandle {
    fn eq(&self, other: &FocusHandle) -> bool {
        self.id == other.id
    }
}

impl PartialEq<WeakFocusHandle> for FocusHandle {
    fn eq(&self, other: &WeakFocusHandle) -> bool {
        self.id == other.id
    }
}

/// Focusable allows users of your view to easily
/// focus it (using window.focus_view(cx, view))
pub trait Focusable: 'static {
    /// Returns the focus handle associated with this view.
    fn focus_handle(&self, cx: &App) -> FocusHandle;
}

impl<V: Focusable> Focusable for Entity<V> {
    fn focus_handle(&self, cx: &App) -> FocusHandle {
        self.read(cx).focus_handle(cx)
    }
}

/// ManagedView is a view (like a Modal, Popover, Menu, etc.)
/// where the lifecycle of the view is handled by another view.
pub trait ManagedView: Focusable + EventEmitter<DismissEvent> + Render {}

impl<M: Focusable + EventEmitter<DismissEvent> + Render> ManagedView for M {}

/// Emitted by implementers of [`ManagedView`] to indicate the view should be dismissed, such as when a view is presented as a modal.
pub struct DismissEvent;

type FrameCallback = Box<dyn FnOnce(&mut Window, &mut App)>;

pub(crate) type AnyMouseListener =
    Box<dyn FnMut(&dyn Any, DispatchPhase, &mut Window, &mut App) + 'static>;

/// A mouse listener registered for the next frame.
pub(crate) enum MouseListener {
    Any(AnyMouseListener),
    Hover(HoverListener),
    Active(ActiveListener),
}

/// Notifies `view` when a mouse move changes whether `hitbox` is hovered.
///
/// Every element with hover styling registers one of these each frame, so it
/// is kept as plain data next to the boxed listeners, in the same order, rather
/// than as one more boxed closure.
pub(crate) struct HoverListener {
    pub(crate) hitbox: HitboxId,
    /// Whether `hitbox` was hovered in the frame the listener belongs to,
    /// updated on each transition the listener observes.
    pub(crate) was_hovered: bool,
    pub(crate) hover_state: Option<Rc<RefCell<crate::ElementHoverState>>>,
    /// Whether this tracks the element's group, rather than the element.
    pub(crate) group: bool,
    pub(crate) view: EntityId,
}

/// Tracks whether an element is pressed: a mouse down on its hitbox (or its
/// active group's) marks it clicked, and any mouse up clears that.
///
/// Every element with an id registers this each frame, so like
/// [`HoverListener`] it is plain data. It stands in for two adjacent closures,
/// one for each event type, so every event still meets it at the same place
/// among the other listeners.
pub(crate) struct ActiveListener {
    pub(crate) clicked_state: Rc<RefCell<crate::ElementClickedState>>,
    pub(crate) hitbox: HitboxId,
    pub(crate) group_hitbox: Option<HitboxId>,
}

impl MouseListener {
    fn dispatch(
        &mut self,
        event: &dyn Any,
        phase: DispatchPhase,
        window: &mut Window,
        cx: &mut App,
    ) {
        match self {
            MouseListener::Any(listener) => listener(event, phase, window, cx),
            MouseListener::Hover(listener) => {
                if phase == DispatchPhase::Capture && event.is::<MouseMoveEvent>() {
                    let hovered = listener.hitbox.is_hovered(window);
                    if hovered != listener.was_hovered {
                        listener.was_hovered = hovered;
                        if let Some(hover_state) = &listener.hover_state {
                            let mut hover_state = hover_state.borrow_mut();
                            if listener.group {
                                hover_state.group = hovered;
                            } else {
                                hover_state.element = hovered;
                            }
                        }
                        cx.notify(listener.view);
                    }
                }
            }
            MouseListener::Active(listener) => {
                if event.is::<MouseUpEvent>() {
                    let clicked_state = &listener.clicked_state;
                    if phase == DispatchPhase::Capture && clicked_state.borrow().is_clicked() {
                        *clicked_state.borrow_mut() = crate::ElementClickedState::default();
                        window.refresh();
                    }
                } else if event.is::<crate::MouseDownEvent>()
                    && phase == DispatchPhase::Bubble
                    && !window.default_prevented()
                {
                    let group_hovered = listener
                        .group_hitbox
                        .is_some_and(|group_hitbox_id| group_hitbox_id.is_hovered(window));
                    let element_hovered = listener.hitbox.is_hovered(window);
                    if group_hovered || element_hovered {
                        *listener.clicked_state.borrow_mut() = crate::ElementClickedState {
                            group: group_hovered,
                            element: element_hovered,
                        };
                        window.refresh();
                    }
                }
            }
        }
    }
}

#[derive(Clone)]
pub(crate) struct CursorStyleRequest {
    pub(crate) hitbox_id: Option<HitboxId>,
    pub(crate) style: CursorStyle,
}

#[derive(Default, Eq, PartialEq)]
pub(crate) struct HitTest {
    pub(crate) ids: SmallVec<[HitboxId; 8]>,
    pub(crate) hover_hitbox_count: usize,
}

/// A type of window control area that corresponds to the platform window.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum WindowControlArea {
    /// An area that allows dragging of the platform window.
    Drag,
    /// An area that allows closing of the platform window.
    Close,
    /// An area that allows maximizing of the platform window.
    Max,
    /// An area that allows minimizing of the platform window.
    Min,
}

/// An identifier for a [Hitbox] which also includes [HitboxBehavior].
#[derive(Copy, Clone, Debug, Eq, PartialEq, Hash)]
pub struct HitboxId(u64);

#[cfg(feature = "test-support")]
impl HitboxId {
    /// A placeholder HitboxId exclusively for integration testing API's that
    /// need a hitbox but where the value of the hitbox does not matter. The
    /// alternative is to make the Hitbox optional but that complicates the
    /// implementation.
    pub const fn placeholder() -> Self {
        Self(0)
    }
}

impl HitboxId {
    /// Checks if the hitbox with this ID is currently hovered. Returns `false` during keyboard
    /// input modality so that keyboard navigation suppresses hover highlights. Except when handling
    /// `ScrollWheelEvent`, this is typically what you want when determining whether to handle mouse
    /// events or paint hover styles.
    ///
    /// See [`Hitbox::is_hovered`] for details.
    pub fn is_hovered(self, window: &Window) -> bool {
        if let Some(hovered) = view_retention::note_hover_read(window, self, false) {
            return hovered;
        }
        // If this hitbox has captured the pointer, it's always considered hovered
        if window.captured_hitbox == Some(self) {
            return true;
        }
        if window.last_input_was_keyboard() {
            return false;
        }
        self.hit_test(window)
    }

    /// Checks if the hitbox with this ID is currently hovered, regardless of the last
    /// input modality used.
    ///
    /// See [`HitboxId::is_hovered`] for more details.
    pub(crate) fn is_hovered_ignoring_last_input(self, window: &Window) -> bool {
        if let Some(hovered) = view_retention::note_hover_read(window, self, true) {
            return hovered;
        }
        // If this hitbox has captured the pointer, it's always considered hovered
        if window.captured_hitbox == Some(self) {
            return true;
        }
        self.hit_test(window)
    }

    /// What [`Self::is_hovered`], or with `ignoring_modality`
    /// [`Self::is_hovered_ignoring_last_input`], answers, without noting that
    /// it was asked.
    pub(crate) fn hovered_now(self, window: &Window, ignoring_modality: bool) -> bool {
        if window.captured_hitbox == Some(self) {
            return true;
        }
        if !ignoring_modality && window.last_input_modality == InputModality::Keyboard {
            return false;
        }
        self.hit_test(window)
    }

    fn hit_test(self, window: &Window) -> bool {
        let hit_test = &window.mouse_hit_test;
        for id in hit_test.ids.iter().take(hit_test.hover_hitbox_count) {
            if self == *id {
                return true;
            }
        }
        false
    }

    /// Checks if the hitbox with this ID contains the mouse and should handle scroll events.
    /// Typically this should only be used when handling `ScrollWheelEvent`, and otherwise
    /// `is_hovered` should be used. See the documentation of `Hitbox::is_hovered` for details about
    /// this distinction.
    pub fn should_handle_scroll(self, window: &Window) -> bool {
        window.mouse_hit_test.ids.contains(&self)
    }

    fn next(mut self) -> HitboxId {
        HitboxId(self.0.wrapping_add(1))
    }
}

/// A rectangular region that potentially blocks hitboxes inserted prior.
/// See [Window::insert_hitbox] for more details.
#[derive(Clone, Debug, Deref)]
pub struct Hitbox {
    /// A unique identifier for the hitbox.
    pub id: HitboxId,
    /// The bounds of the hitbox.
    #[deref]
    pub bounds: Bounds<Pixels>,
    /// The content mask when the hitbox was inserted.
    pub content_mask: ContentMask<Pixels>,
    /// Flags that specify hitbox behavior.
    pub behavior: HitboxBehavior,
}

impl Hitbox {
    /// Checks if the hitbox is currently hovered. Returns `false` during keyboard input modality
    /// so that keyboard navigation suppresses hover highlights. Except when handling
    /// `ScrollWheelEvent`, this is typically what you want when determining whether to handle mouse
    /// events or paint hover styles.
    ///
    /// This can return `false` even when the hitbox contains the mouse, if a hitbox in front of
    /// this sets `HitboxBehavior::BlockMouse` (`InteractiveElement::occlude`) or
    /// `HitboxBehavior::BlockMouseExceptScroll` (`InteractiveElement::block_mouse_except_scroll`),
    /// or if the current input modality is keyboard (see [`Window::last_input_was_keyboard`]).
    ///
    /// Handling of `ScrollWheelEvent` should typically use `should_handle_scroll` instead.
    /// Concretely, this is due to use-cases like overlays that cause the elements under to be
    /// non-interactive while still allowing scrolling. More abstractly, this is because
    /// `is_hovered` is about element interactions directly under the mouse - mouse moves, clicks,
    /// hover styling, etc. In contrast, scrolling is about finding the current outer scrollable
    /// container.
    pub fn is_hovered(&self, window: &Window) -> bool {
        self.id.is_hovered(window)
    }

    /// Checks whether this hitbox would be hovered at `position`, regardless of the current input
    /// modality or mouse position.
    pub fn is_hovered_at(&self, position: Point<Pixels>, window: &Window) -> bool {
        let hit_test = window.rendered_frame.hit_test(position);
        hit_test
            .ids
            .iter()
            .take(hit_test.hover_hitbox_count)
            .any(|id| self.id == *id)
    }

    /// Checks if the hitbox contains the mouse and should handle scroll events. Typically this
    /// should only be used when handling `ScrollWheelEvent`, and otherwise `is_hovered` should be
    /// used. See the documentation of `Hitbox::is_hovered` for details about this distinction.
    ///
    /// This can return `false` even when the hitbox contains the mouse, if a hitbox in front of
    /// this sets `HitboxBehavior::BlockMouse` (`InteractiveElement::occlude`).
    pub fn should_handle_scroll(&self, window: &Window) -> bool {
        self.id.should_handle_scroll(window)
    }
}

/// How the hitbox affects mouse behavior.
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq)]
pub enum HitboxBehavior {
    /// Normal hitbox mouse behavior, doesn't affect mouse handling for other hitboxes.
    #[default]
    Normal,

    /// All hitboxes behind this hitbox will be ignored and so will have `hitbox.is_hovered() ==
    /// false` and `hitbox.should_handle_scroll() == false`. Typically for elements this causes
    /// skipping of all mouse events, hover styles, and tooltips. This flag is set by
    /// [`InteractiveElement::occlude`].
    ///
    /// For mouse handlers that check those hitboxes, this behaves the same as registering a
    /// bubble-phase handler for every mouse event type:
    ///
    /// ```ignore
    /// window.on_mouse_event(move |_: &EveryMouseEventTypeHere, phase, window, cx| {
    ///     if phase == DispatchPhase::Capture && hitbox.is_hovered(window) {
    ///         cx.stop_propagation();
    ///     }
    /// })
    /// ```
    ///
    /// This has effects beyond event handling - any use of hitbox checking, such as hover
    /// styles and tooltips. These other behaviors are the main point of this mechanism. An
    /// alternative might be to not affect mouse event handling - but this would allow
    /// inconsistent UI where clicks and moves interact with elements that are not considered to
    /// be hovered.
    BlockMouse,

    /// All hitboxes behind this hitbox will have `hitbox.is_hovered() == false`, even when
    /// `hitbox.should_handle_scroll() == true`. Typically for elements this causes all mouse
    /// interaction except scroll events to be ignored - see the documentation of
    /// [`Hitbox::is_hovered`] for details. This flag is set by
    /// [`InteractiveElement::block_mouse_except_scroll`].
    ///
    /// For mouse handlers that check those hitboxes, this behaves the same as registering a
    /// bubble-phase handler for every mouse event type **except** `ScrollWheelEvent`:
    ///
    /// ```ignore
    /// window.on_mouse_event(move |_: &EveryMouseEventTypeExceptScroll, phase, window, cx| {
    ///     if phase == DispatchPhase::Bubble && hitbox.should_handle_scroll(window) {
    ///         cx.stop_propagation();
    ///     }
    /// })
    /// ```
    ///
    /// See the documentation of [`Hitbox::is_hovered`] for details of why `ScrollWheelEvent` is
    /// handled differently than other mouse events. If also blocking these scroll events is
    /// desired, then a `cx.stop_propagation()` handler like the one above can be used.
    ///
    /// This has effects beyond event handling - this affects any use of `is_hovered`, such as
    /// hover styles and tooltips. These other behaviors are the main point of this mechanism.
    /// An alternative might be to not affect mouse event handling - but this would allow
    /// inconsistent UI where clicks and moves interact with elements that are not considered to
    /// be hovered.
    BlockMouseExceptScroll,
}

/// An identifier for a tooltip.
#[derive(Copy, Clone, Debug, Default, Eq, PartialEq)]
pub struct TooltipId(usize);

impl TooltipId {
    /// Checks if the tooltip is currently hovered.
    pub fn is_hovered(&self, window: &Window) -> bool {
        window
            .tooltip_bounds
            .as_ref()
            .is_some_and(|tooltip_bounds| {
                tooltip_bounds.id == *self
                    && tooltip_bounds.bounds.contains(&window.mouse_position())
            })
    }
}

/// A measurement closure with the key [`Window::request_measured_layout_with_key`]
/// was given, and the type of the closure, which the key is only compared
/// within.
struct KeyedMeasurement {
    key: u64,
    closure: std::any::TypeId,
    measure: Box<
        dyn Fn(Size<Option<Pixels>>, Size<AvailableSpace>, &mut Window, &mut App) -> Size<Pixels>,
    >,
}

pub(crate) struct TooltipBounds {
    id: TooltipId,
    bounds: Bounds<Pixels>,
}

#[derive(Clone)]
pub(crate) struct TooltipRequest {
    id: TooltipId,
    tooltip: AnyTooltip,
}

pub(crate) struct DeferredDraw {
    current_view: EntityId,
    priority: usize,
    /// Painted before every overlay-plane deferred draw and left on the base
    /// scene plane; see [`Window::defer_draw_beneath_native_surfaces`].
    beneath_native_surfaces: bool,
    parent_node: DispatchNodeId,
    element_id_stack: SmallVec<[ElementId; 32]>,
    text_style_stack: Vec<TextStyleRefinement>,
    content_mask: Option<ContentMask<Pixels>>,
    rem_size: Pixels,
    element: Option<AnyElement>,
    absolute_offset: Point<Pixels>,
    prepaint_range: Range<PrepaintStateIndex>,
    paint_range: Range<PaintIndex>,
    /// The retained views it was deferred from, whose dependencies what it
    /// reads while it is drawn are.
    enclosing_views: view_retention::EnclosingViews,
    /// The records of the retained views it drew, in its frame's records.
    retained_records: Range<usize>,
}

pub(crate) struct Frame {
    pub(crate) focus: Option<FocusId>,
    pub(crate) window_active: bool,
    pub(crate) element_states: FxHashMap<(GlobalElementId, TypeId), ElementStateBox>,
    accessed_element_states: Vec<(GlobalElementId, TypeId)>,
    pub(crate) mouse_listeners: Vec<Option<MouseListener>>,
    pub(crate) dispatch_tree: DispatchTree,
    pub(crate) scene: Scene,
    /// First paint operation that belongs on the GPUI overlay surface.
    pub(crate) overlay_scene_start: usize,
    pub(crate) hitboxes: Vec<Hitbox>,
    pub(crate) window_control_hitboxes: Vec<(WindowControlArea, Hitbox)>,
    pub(crate) deferred_draws: Vec<DeferredDraw>,
    /// State outside the frame that elements wrote their position into as
    /// they prepainted (a scroll handle's bounds, a text layout's), with
    /// view retention on, and how far each was moved with the view it was
    /// copied with; see [`view_retention::PositionedState`].
    pub(crate) positioned_states: Vec<(Rc<dyn view_retention::PositionedState>, Point<Pixels>)>,
    /// The bounds elements inside retained views asked to be scrolled into
    /// view as they prepainted (see [`Window::request_autoscroll`]). A
    /// request is for the frame it is made in, and whatever scrolls answers
    /// it as it prepaints, so a view that made one is built again.
    pub(crate) autoscroll_requests: Vec<Bounds<Pixels>>,
    /// What elements registered as they painted to be moved with the view
    /// they were painted in (see [`Window::on_replayed_at_offset`]).
    pub(crate) painted_positions: Vec<Rc<dyn view_retention::PositionedState>>,
    pub(crate) input_handlers: Vec<Option<PlatformInputHandler>>,
    pub(crate) tooltip_requests: Vec<Option<TooltipRequest>>,
    pub(crate) cursor_styles: Vec<CursorStyleRequest>,
    #[cfg(any(test, feature = "test-support"))]
    pub(crate) debug_bounds: FxHashMap<String, Bounds<Pixels>>,
    #[cfg(any(test, feature = "test-support"))]
    debug_bounds_records: Vec<(String, Bounds<Pixels>)>,
    #[cfg(any(feature = "inspector", debug_assertions))]
    pub(crate) next_inspector_instance_ids: FxHashMap<Rc<crate::InspectorElementPath>, usize>,
    #[cfg(any(feature = "inspector", debug_assertions))]
    pub(crate) inspector_hitboxes: FxHashMap<HitboxId, crate::InspectorElementId>,
    pub(crate) tab_stops: TabStopMap,
    /// The views drawn in this frame with view retention on, for the next
    /// frame to draw again from it.
    pub(crate) retained_views: view_retention::RetainedViews,
    shrink: FrameShrink,
}

/// Hysteresis trackers for the per-frame collections a `Frame` refills every
/// draw; see [`CapacityShrink`].
#[derive(Default)]
struct FrameShrink {
    /// Fed from [`Frame::finish`] rather than [`Frame::clear`]: live element
    /// states are moved forward into the new frame there, so by the time the
    /// old frame is cleared its map holds only the states that died, and
    /// measuring that would shrink the map every window and regrow it the
    /// next frame.
    element_states: CapacityShrink,
    accessed_element_states: CapacityShrink,
    mouse_listeners: CapacityShrink,
    hitboxes: CapacityShrink,
    window_control_hitboxes: CapacityShrink,
    deferred_draws: CapacityShrink,
    input_handlers: CapacityShrink,
    tooltip_requests: CapacityShrink,
    cursor_styles: CapacityShrink,
}

#[derive(Clone, Default)]
pub(crate) struct PrepaintStateIndex {
    hitboxes_index: usize,
    tooltips_index: usize,
    deferred_draws_index: usize,
    positioned_states_index: usize,
    autoscroll_requests_index: usize,
    dispatch_tree_index: usize,
    accessed_element_states_index: usize,
    line_layout_index: LineLayoutIndex,
}

#[derive(Clone, Default)]
pub(crate) struct PaintIndex {
    scene_index: usize,
    window_control_hitboxes_index: usize,
    #[cfg(any(test, feature = "test-support"))]
    debug_bounds_index: usize,
    mouse_listeners_index: usize,
    input_handlers_index: usize,
    cursor_styles_index: usize,
    accessed_element_states_index: usize,
    tab_handle_index: usize,
    painted_positions_index: usize,
    line_layout_index: LineLayoutIndex,
}

impl Frame {
    #[cfg(any(test, feature = "test-support"))]
    pub(crate) fn record_debug_bounds(&mut self, selector: String, bounds: Bounds<Pixels>) {
        self.debug_bounds.insert(selector.clone(), bounds);
        self.debug_bounds_records.push((selector, bounds));
    }

    pub(crate) fn new(dispatch_tree: DispatchTree) -> Self {
        Frame {
            focus: None,
            window_active: false,
            element_states: FxHashMap::default(),
            accessed_element_states: Vec::new(),
            mouse_listeners: Vec::new(),
            dispatch_tree,
            scene: Scene::default(),
            overlay_scene_start: 0,
            hitboxes: Vec::new(),
            window_control_hitboxes: Vec::new(),
            deferred_draws: Vec::new(),
            positioned_states: Vec::new(),
            autoscroll_requests: Vec::new(),
            painted_positions: Vec::new(),
            input_handlers: Vec::new(),
            tooltip_requests: Vec::new(),
            cursor_styles: Vec::new(),

            #[cfg(any(test, feature = "test-support"))]
            debug_bounds: FxHashMap::default(),
            #[cfg(any(test, feature = "test-support"))]
            debug_bounds_records: Vec::new(),

            #[cfg(any(feature = "inspector", debug_assertions))]
            next_inspector_instance_ids: FxHashMap::default(),

            #[cfg(any(feature = "inspector", debug_assertions))]
            inspector_hitboxes: FxHashMap::default(),
            tab_stops: TabStopMap::default(),
            retained_views: Default::default(),
            shrink: FrameShrink::default(),
        }
    }

    pub(crate) fn clear(&mut self) {
        let shrink = &mut self.shrink;
        self.element_states.clear();
        shrink
            .accessed_element_states
            .clear_vec(&mut self.accessed_element_states);
        shrink.mouse_listeners.clear_vec(&mut self.mouse_listeners);
        self.dispatch_tree.clear();
        self.scene.clear();
        self.overlay_scene_start = 0;
        shrink.input_handlers.clear_vec(&mut self.input_handlers);
        shrink.tooltip_requests.clear_vec(&mut self.tooltip_requests);
        shrink.cursor_styles.clear_vec(&mut self.cursor_styles);
        shrink.hitboxes.clear_vec(&mut self.hitboxes);
        shrink
            .window_control_hitboxes
            .clear_vec(&mut self.window_control_hitboxes);
        shrink.deferred_draws.clear_vec(&mut self.deferred_draws);
        self.positioned_states.clear();
        self.autoscroll_requests.clear();
        self.painted_positions.clear();
        self.tab_stops.clear();
        self.retained_views.clear();
        self.focus = None;

        #[cfg(any(test, feature = "test-support"))]
        {
            self.debug_bounds.clear();
            self.debug_bounds_records.clear();
        }

        #[cfg(any(feature = "inspector", debug_assertions))]
        {
            self.next_inspector_instance_ids.clear();
            self.inspector_hitboxes.clear();
        }
    }

    /// Shrinks this cleared frame's collections to twice the fill of
    /// `rendered`, the frame still on screen, once the window has stopped
    /// drawing; see [`CapacityShrink::idle_target`]. Only the retired frame
    /// is touched: `rendered` is what event dispatch and presentation still
    /// read.
    pub(crate) fn shrink_idle(&mut self, rendered: &Frame) {
        let shrink = &mut self.shrink;
        shrink
            .element_states
            .shrink_map_idle(&mut self.element_states, rendered.element_states.len());
        shrink.accessed_element_states.shrink_vec_idle(
            &mut self.accessed_element_states,
            rendered.accessed_element_states.len(),
        );
        shrink
            .mouse_listeners
            .shrink_vec_idle(&mut self.mouse_listeners, rendered.mouse_listeners.len());
        shrink
            .input_handlers
            .shrink_vec_idle(&mut self.input_handlers, rendered.input_handlers.len());
        shrink
            .tooltip_requests
            .shrink_vec_idle(&mut self.tooltip_requests, rendered.tooltip_requests.len());
        shrink
            .cursor_styles
            .shrink_vec_idle(&mut self.cursor_styles, rendered.cursor_styles.len());
        shrink
            .hitboxes
            .shrink_vec_idle(&mut self.hitboxes, rendered.hitboxes.len());
        shrink.window_control_hitboxes.shrink_vec_idle(
            &mut self.window_control_hitboxes,
            rendered.window_control_hitboxes.len(),
        );
        shrink
            .deferred_draws
            .shrink_vec_idle(&mut self.deferred_draws, rendered.deferred_draws.len());
        self.dispatch_tree.shrink_idle(&rendered.dispatch_tree);
        self.scene.shrink_idle(&rendered.scene);
    }

    pub(crate) fn cursor_style(&self, window: &Window) -> Option<CursorStyle> {
        self.cursor_styles
            .iter()
            .rev()
            .fold_while(None, |style, request| match request.hitbox_id {
                None => Done(Some(request.style)),
                Some(hitbox_id) => Continue(style.or_else(|| {
                    hitbox_id
                        .is_hovered_ignoring_last_input(window)
                        .then_some(request.style)
                })),
            })
            .into_inner()
    }

    pub(crate) fn hit_test(&self, position: Point<Pixels>) -> HitTest {
        let mut set_hover_hitbox_count = false;
        let mut hit_test = HitTest::default();
        for hitbox in self.hitboxes.iter().rev() {
            let bounds = hitbox.bounds.intersect(&hitbox.content_mask.bounds);
            if bounds.contains(&position) {
                hit_test.ids.push(hitbox.id);
                if !set_hover_hitbox_count
                    && hitbox.behavior == HitboxBehavior::BlockMouseExceptScroll
                {
                    hit_test.hover_hitbox_count = hit_test.ids.len();
                    set_hover_hitbox_count = true;
                }
                if hitbox.behavior == HitboxBehavior::BlockMouse {
                    break;
                }
            }
        }
        if !set_hover_hitbox_count {
            hit_test.hover_hitbox_count = hit_test.ids.len();
        }
        hit_test
    }

    pub(crate) fn focus_path(&self) -> SmallVec<[FocusId; 8]> {
        self.focus
            .map(|focus_id| self.dispatch_tree.focus_path(focus_id))
            .unwrap_or_default()
    }

    pub(crate) fn finish(&mut self, prev_frame: &mut Self) {
        for element_state_key in &self.accessed_element_states {
            if let Some((element_state_key, element_state)) =
                prev_frame.element_states.remove_entry(element_state_key)
            {
                self.element_states.insert(element_state_key, element_state);
            }
        }
        // The old frame's map is nearly empty now, so shrinking it here is a
        // rehash of a handful of dead entries; it comes back as the live map
        // next frame at a capacity sized for the live count.
        if let Some(target) = prev_frame
            .shrink
            .element_states
            .record(self.element_states.len(), prev_frame.element_states.capacity())
        {
            prev_frame.element_states.shrink_to(target);
        }

        self.scene.finish();
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Ord, PartialOrd)]
enum InputModality {
    Mouse,
    Keyboard,
    Touch,
}

/// Holds the state for a specific window.
pub struct Window {
    pub(crate) handle: AnyWindowHandle,
    pub(crate) invalidator: WindowInvalidator,
    pub(crate) removed: bool,
    pub(crate) platform_window: Box<dyn PlatformWindow>,
    display_id: Option<DisplayId>,
    is_resizable: bool,
    is_minimizable: bool,
    sprite_atlas: Arc<dyn PlatformAtlas>,
    /// The sprite atlas's frame counter when this window last presented. The
    /// retained scene's tiles were all marked used at that frame, so while it is
    /// recent they cannot have been retired; see `rendered_scene_may_reference_retired_tiles`.
    atlas_frame_at_last_present: u64,
    /// Set when the frame loop rebuilds the scene because its tiles may have
    /// been retired, and cleared by the next present that is not deferred. A
    /// deferral does not move `atlas_frame_at_last_present`, so without this
    /// every retry of the owed frame would rebuild the scene again, once per
    /// display refresh.
    retired_tile_redraw_deferred: bool,
    text_system: Arc<WindowTextSystem>,
    text_rendering_mode: Rc<Cell<TextRenderingMode>>,
    rem_size: Pixels,
    /// The stack of override values for the window's rem size.
    ///
    /// This is used by `with_rem_size` to allow rendering an element tree with
    /// a given rem size.
    rem_size_override_stack: SmallVec<[Pixels; 8]>,
    pub(crate) viewport_size: Size<Pixels>,
    layout_engine: Option<TaffyLayoutEngine>,
    pub(crate) layout_keys: layout_keys::LayoutKeys,
    pub(crate) root: Option<AnyView>,
    pub(crate) element_id_stack: SmallVec<[ElementId; 32]>,
    pub(crate) global_element_ids: crate::element::GlobalElementIdCache,
    pub(crate) text_style_stack: Vec<TextStyleRefinement>,
    pub(crate) rendered_entity_stack: Vec<EntityId>,
    pub(crate) element_offset_stack: Vec<Point<Pixels>>,
    pub(crate) element_opacity: f32,
    pub(crate) glass_content: bool,
    pub(crate) content_mask_stack: Vec<ContentMask<Pixels>>,
    pub(crate) text_shimmer_stack: Vec<TextShimmerStyle>,
    glyph_raster_cache: glyph_painting::GlyphRasterCache,
    pub(crate) line_glyph_cache: glyph_painting::LineGlyphCache,
    pub(crate) frame_work: frame_work::FrameWorkCounters,
    pub(crate) opacity_cycle_stack: Vec<OpacityCycle>,
    pub(crate) view_retention: view_retention::ViewRetention,
    pub(crate) requested_autoscroll: Option<Bounds<Pixels>>,
    /// The [`TextInputConfiguration`] most recently forwarded to the platform
    /// window, so that only actual changes are forwarded (reconfiguring a live
    /// input session can restart the IME connection).
    last_text_input_configuration: Option<TextInputConfiguration>,
    focused_text_input_active: bool,
    /// While a deferred draw is being prepainted, whether it sits beneath native
    /// surfaces, so a deferred draw it registers inherits the overlay plane
    /// when its parent is there.
    prepainting_deferred_draw_beneath_native_surfaces: Option<bool>,
    pub(crate) image_cache_stack: Vec<AnyImageCache>,
    pub(crate) rendered_frame: Frame,
    pub(crate) next_frame: Frame,
    next_hitbox_id: HitboxId,
    pub(crate) next_tooltip_id: TooltipId,
    pub(crate) tooltip_bounds: Option<TooltipBounds>,
    pub(crate) next_frame_callbacks: Rc<RefCell<Vec<FrameCallback>>>,
    pub(crate) dirty_views: FxHashSet<EntityId>,
    /// The group containers around what is being painted.
    pub(crate) group_hitboxes: crate::GroupHitboxes,
    focus_listeners: SubscriberSet<(), AnyWindowFocusListener>,
    pub(crate) focus_lost_listeners: SubscriberSet<(), AnyObserver>,
    focus_lost_path: SmallVec<[FocusId; 8]>,
    default_prevented: bool,
    mouse_position: Point<Pixels>,
    mouse_hit_test: HitTest,
    modifiers: Modifiers,
    capslock: Capslock,
    scale_factor: f32,
    pub(crate) bounds_observers: SubscriberSet<(), AnyObserver>,
    appearance: WindowAppearance,
    pub(crate) appearance_observers: SubscriberSet<(), AnyObserver>,
    pub(crate) button_layout_observers: SubscriberSet<(), AnyObserver>,
    active: Rc<Cell<bool>>,
    visibility: WindowVisibility,
    pub(crate) visibility_observers:
        SubscriberSet<(), Box<dyn FnMut(WindowVisibility, &mut Window, &mut App) -> bool>>,
    hovered: Rc<Cell<bool>>,
    pub(crate) needs_present: Rc<Cell<bool>>,
    /// Whether the rendered scene moves with time on its own, so the window
    /// keeps presenting it while nothing redraws it.
    scene_animates: Rc<Cell<bool>>,
    /// Whether a transition in the rendered scene has yet to land, so the
    /// window presents it on every frame rather than at the time-animation
    /// rate.
    scene_transitioning: Rc<Cell<bool>>,
    /// When the rendered scene was last presented.
    last_present_at: Rc<Cell<Option<Instant>>>,
    /// Tracks recent input event timestamps to determine if input is arriving at a high rate.
    /// Used to selectively enable VRR optimization only when input rate exceeds 60fps.
    pub(crate) input_rate_tracker: Rc<RefCell<InputRateTracker>>,
    #[cfg(feature = "profiler")]
    window_profiler: profiler::WindowProfiler,
    #[cfg(feature = "profiler")]
    pub(crate) draw_clock: draw_profile::DrawClock,
    #[cfg(feature = "profiler")]
    draw_resources: draw_profile::DrawResourceSampler,
    #[cfg(feature = "profiler")]
    view_timer: draw_profile::ViewTimer,
    last_input_modality: InputModality,
    touch_gestures: TouchGestureRecognizer,
    touch_prediction_enabled: bool,
    long_press_timer: Option<Task<()>>,
    long_press_capture: Option<EntityId>,
    /// When the last draw finished, by the executor's clock, and the timer
    /// that reclaims per-frame capacity once that is `SHRINK_AFTER_DURATION`
    /// ago; see [`Self::reclaim_idle_capacity`].
    last_draw_at: Instant,
    pub(crate) idle_capacity_reclaim: Option<Task<()>>,
    pub(crate) refreshing: bool,
    pub(crate) activation_observers: SubscriberSet<(), AnyObserver>,
    pub(crate) focus: Option<FocusId>,
    focus_enabled: bool,
    /// Incremented every time focus moves. Used to invalidate a
    /// pending keyboard activation state when focus changes.
    pub(crate) focus_generation: u64,
    pending_input: Option<PendingInput>,
    pending_modifier: ModifierState,
    pub(crate) pending_input_observers: SubscriberSet<(), AnyObserver>,
    prompt: Option<RenderablePromptHandle>,
    pub(crate) client_inset: Option<Pixels>,
    /// The hitbox that has captured the pointer, if any.
    /// While captured, mouse events route to this hitbox regardless of hit testing.
    captured_hitbox: Option<HitboxId>,
    #[cfg(any(feature = "inspector", debug_assertions))]
    inspector: Option<Entity<Inspector>>,
    #[cfg(feature = "profiler")]
    debug_frame_overlay: crate::debug_overlay::DebugFrameOverlay,
    pub(crate) a11y: A11y,
}

#[derive(Clone, Debug, Default)]
struct ModifierState {
    modifiers: Modifiers,
    saw_other_input: bool,
}

/// Tracks input event timestamps to determine if input is arriving at a high rate.
/// Used for selective VRR (Variable Refresh Rate) optimization.
#[derive(Clone, Debug)]
pub(crate) struct InputRateTracker {
    timestamps: Vec<Instant>,
    window: Duration,
    inputs_per_second: u32,
    sustain_until: Instant,
    sustain_duration: Duration,
}

impl Default for InputRateTracker {
    fn default() -> Self {
        Self {
            timestamps: Vec::new(),
            window: Duration::from_millis(100),
            inputs_per_second: 60,
            sustain_until: Instant::now(),
            sustain_duration: Duration::from_secs(1),
        }
    }
}

impl InputRateTracker {
    pub fn record_input(&mut self) {
        let now = Instant::now();
        self.timestamps.push(now);
        self.prune_old_timestamps(now);

        let min_events = self.inputs_per_second as u128 * self.window.as_millis() / 1000;
        if self.timestamps.len() as u128 >= min_events {
            self.sustain_until = now + self.sustain_duration;
        }
    }

    pub fn is_high_rate(&self) -> bool {
        Instant::now() < self.sustain_until
    }

    fn prune_old_timestamps(&mut self, now: Instant) {
        self.timestamps
            .retain(|&t| now.duration_since(t) <= self.window);
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub(crate) enum DrawPhase {
    None,
    Prepaint,
    Paint,
    Focus,
}

pub(crate) const PENDING_INPUT_TIMEOUT: Duration = Duration::from_secs(1);

/// Pending input for a potential multi-stroke key binding.
pub struct PendingInputStatus<'a> {
    keystrokes: &'a [Keystroke],
    timeout: Option<PendingInputTimeoutStatus>,
}

impl<'a> PendingInputStatus<'a> {
    /// Returns the keystrokes entered so far.
    pub fn keystrokes(&self) -> &'a [Keystroke] {
        self.keystrokes
    }

    /// Returns the timeout state for flushing this input, if it needs a timeout.
    pub fn timeout(&self) -> Option<PendingInputTimeoutStatus> {
        self.timeout
    }
}

/// The timeout state for pending input.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct PendingInputTimeoutStatus {
    duration: Duration,
    remaining: Duration,
    started_at: Option<Instant>,
    paused: bool,
}

impl PendingInputTimeoutStatus {
    /// Returns the full timeout duration.
    pub fn duration(&self) -> Duration {
        self.duration
    }

    /// Returns the duration remaining before pending input is flushed.
    pub fn remaining(&self, cx: &App) -> Duration {
        self.started_at
            .map(|started_at| {
                self.remaining
                    .saturating_sub(cx.background_executor().now() - started_at)
            })
            .unwrap_or(self.remaining)
    }

    /// Returns whether the timeout is paused.
    pub fn is_paused(&self) -> bool {
        self.paused
    }
}

#[derive(Debug)]
struct PendingInputTimeout {
    duration: Duration,
    remaining: Duration,
    state: PendingInputTimeoutState,
}

#[derive(Debug)]
enum PendingInputTimeoutState {
    Running { started_at: Instant, task: Task<()> },
    Paused { pause: PendingInputTimeoutPause },
}

#[derive(Debug)]
struct PendingInputTimeoutPause {
    owner_id: EntityId,
    _release_subscription: Subscription,
}

impl PendingInputTimeout {
    fn is_paused(&self) -> bool {
        matches!(&self.state, PendingInputTimeoutState::Paused { .. })
    }

    fn pause(&mut self, pause: PendingInputTimeoutPause, now: Instant) -> bool {
        match std::mem::replace(&mut self.state, PendingInputTimeoutState::Paused { pause }) {
            PendingInputTimeoutState::Running { started_at, task } => {
                self.remaining = self.remaining.saturating_sub(now - started_at);
                drop(task);
                true
            }
            previous_state @ PendingInputTimeoutState::Paused { .. } => {
                self.state = previous_state;
                false
            }
        }
    }

    fn pause_owner_id(&self) -> Option<EntityId> {
        match &self.state {
            PendingInputTimeoutState::Running { .. } => None,
            PendingInputTimeoutState::Paused { pause } => Some(pause.owner_id),
        }
    }

    fn resume(&mut self, owner_id: EntityId, started_at: Instant, task: Task<()>) -> bool {
        match std::mem::replace(
            &mut self.state,
            PendingInputTimeoutState::Running { started_at, task },
        ) {
            PendingInputTimeoutState::Paused { pause } if pause.owner_id == owner_id => true,
            previous_state => {
                self.state = previous_state;
                false
            }
        }
    }

    fn reset_duration(&mut self, duration: Duration) {
        self.duration = duration;
        self.remaining = duration;
    }

    fn status(&self) -> PendingInputTimeoutStatus {
        let (started_at, paused) = match &self.state {
            PendingInputTimeoutState::Running { started_at, .. } => (Some(*started_at), false),
            PendingInputTimeoutState::Paused { .. } => (None, true),
        };
        PendingInputTimeoutStatus {
            duration: self.duration,
            remaining: self.remaining,
            started_at,
            paused,
        }
    }
}

#[derive(Default, Debug)]
struct PendingInput {
    keystrokes: SmallVec<[Keystroke; 1]>,
    focus: Option<FocusId>,
    timeout: Option<PendingInputTimeout>,
}

pub(crate) struct ElementStateBox {
    pub(crate) inner: Box<dyn Any>,
    #[cfg(debug_assertions)]
    pub(crate) type_name: &'static str,
}

fn default_bounds(display_id: Option<DisplayId>, cx: &mut App) -> WindowBounds {
    // TODO, BUG: if you open a window with the currently active window
    // on the stack, this will erroneously fallback to `None`
    //
    // TODO these should be the initial window bounds not considering maximized/fullscreen
    let active_window_bounds = cx
        .active_window()
        .and_then(|w| w.update(cx, |_, window, _| window.window_bounds()).ok());

    const CASCADE_OFFSET: f32 = 25.0;

    let display = display_id
        .map(|id| cx.find_display(id))
        .unwrap_or_else(|| cx.primary_display());

    let default_placement = || Bounds::new(point(px(0.), px(0.)), DEFAULT_WINDOW_SIZE);

    // Use visible_bounds to exclude taskbar/dock areas
    let display_bounds = display
        .as_ref()
        .map(|d| d.visible_bounds())
        .unwrap_or_else(default_placement);

    let (
        Bounds {
            origin: base_origin,
            size: base_size,
        },
        window_bounds_ctor,
    ): (_, fn(Bounds<Pixels>) -> WindowBounds) = match active_window_bounds {
        Some(bounds) => match bounds {
            WindowBounds::Windowed(bounds) => (bounds, WindowBounds::Windowed),
            WindowBounds::Maximized(bounds) => (bounds, WindowBounds::Maximized),
            WindowBounds::Fullscreen(bounds) => (bounds, WindowBounds::Fullscreen),
        },
        None => (
            display
                .as_ref()
                .map(|d| d.default_bounds())
                .unwrap_or_else(default_placement),
            WindowBounds::Windowed,
        ),
    };

    let cascade_offset = point(px(CASCADE_OFFSET), px(CASCADE_OFFSET));
    let proposed_origin = base_origin + cascade_offset;
    let proposed_bounds = Bounds::new(proposed_origin, base_size);

    let display_right = display_bounds.origin.x + display_bounds.size.width;
    let display_bottom = display_bounds.origin.y + display_bounds.size.height;
    let window_right = proposed_bounds.origin.x + proposed_bounds.size.width;
    let window_bottom = proposed_bounds.origin.y + proposed_bounds.size.height;

    let fits_horizontally = window_right <= display_right;
    let fits_vertically = window_bottom <= display_bottom;

    let final_origin = match (fits_horizontally, fits_vertically) {
        (true, true) => proposed_origin,
        (false, true) => point(display_bounds.origin.x, base_origin.y),
        (true, false) => point(base_origin.x, display_bounds.origin.y),
        (false, false) => display_bounds.origin,
    };
    window_bounds_ctor(Bounds::new(final_origin, base_size))
}

impl Window {
    pub(crate) fn new(
        handle: AnyWindowHandle,
        options: WindowOptions,
        cx: &mut App,
    ) -> Result<Self> {
        let WindowOptions {
            window_bounds,
            titlebar,
            focus,
            show,
            kind,
            is_movable,
            app_owns_titlebar_drag,
            inactive_frame_interval,
            is_resizable,
            is_minimizable,
            display_id,
            window_background,
            app_id,
            window_min_size,
            window_decorations,
            #[cfg_attr(
                not(any(target_os = "linux", target_os = "freebsd")),
                allow(unused_variables)
            )]
            icon,
            #[cfg_attr(not(target_os = "macos"), allow(unused_variables))]
            tabbing_identifier,
        } = options;

        let initial_window_title = titlebar
            .as_ref()
            .and_then(|titlebar| titlebar.title.clone());

        let window_bounds = window_bounds.unwrap_or_else(|| default_bounds(display_id, cx));
        let mut platform_window = cx.platform.open_window(
            handle,
            WindowParams {
                bounds: window_bounds.get_bounds(),
                titlebar,
                kind,
                is_movable,
                app_owns_titlebar_drag,
                is_resizable,
                is_minimizable,
                focus,
                show,
                display_id,
                window_min_size,
                app_id: app_id.clone(),
                icon,
                #[cfg(target_os = "macos")]
                tabbing_identifier,
            },
        )?;

        let tab_bar_visible = platform_window.tab_bar_visible();
        SystemWindowTabController::init_visible(cx, tab_bar_visible);
        if let Some(tabs) = platform_window.tabbed_windows() {
            SystemWindowTabController::add_tab(cx, handle.window_id(), tabs);
        }

        let display_id = platform_window.display().map(|display| display.id());
        let sprite_atlas = platform_window.sprite_atlas();
        let mouse_position = platform_window.mouse_position();
        let modifiers = platform_window.modifiers();
        let capslock = platform_window.capslock();
        let content_size = platform_window.content_size();
        let scale_factor = platform_window.scale_factor();
        let appearance = platform_window.appearance();
        let text_system = Arc::new(WindowTextSystem::new(cx.text_system().clone()));
        let invalidator = WindowInvalidator::new(handle.window_id());
        let active = Rc::new(Cell::new(platform_window.is_active()));
        let visibility = platform_window.visibility();
        #[cfg(feature = "profiler")]
        profiler::journal::record_window_visibility(handle.window_id(), visibility);
        let hovered = Rc::new(Cell::new(platform_window.is_hovered()));
        let needs_present = Rc::new(Cell::new(false));
        let scene_animates = Rc::new(Cell::new(false));
        let scene_transitioning = Rc::new(Cell::new(false));
        let last_present_at = Rc::new(Cell::new(None));
        let next_frame_callbacks: Rc<RefCell<Vec<FrameCallback>>> = Default::default();
        let input_rate_tracker = Rc::new(RefCell::new(InputRateTracker::default()));
        let last_frame_time = Rc::new(Cell::new(None));

        platform_window
            .request_decorations(window_decorations.unwrap_or(WindowDecorations::Server));
        platform_window.set_background_appearance(window_background);

        match window_bounds {
            WindowBounds::Fullscreen(_) => platform_window.toggle_fullscreen(),
            WindowBounds::Maximized(_) => platform_window.zoom(),
            WindowBounds::Windowed(_) => {}
        }

        let accessibility_force_disabled = cx.accessibility_force_disabled;
        let a11y_active_flag = Arc::new(AtomicBool::new(false));

        #[cfg(not(target_family = "wasm"))]
        if !accessibility_force_disabled {
            let mut initial_root_node = accesskit::Node::new(accesskit::Role::Window);
            if let Some(title) = &initial_window_title {
                initial_root_node.set_label(title.to_string());
            }
            let initial_tree = accesskit::TreeUpdate {
                nodes: vec![(ROOT_NODE_ID, initial_root_node)],
                tree: Some(accesskit::Tree::new(ROOT_NODE_ID)),
                tree_id: accesskit::TreeId::ROOT,
                focus: ROOT_NODE_ID,
            };
            let (activation_sender, activation_receiver) = async_channel::unbounded::<()>();
            let (deactivation_sender, deactivation_receiver) = async_channel::unbounded::<()>();
            let (action_sender, action_receiver) =
                async_channel::unbounded::<accesskit::ActionRequest>();

            platform_window.a11y_init(crate::A11yCallbacks {
                activation: {
                    let active_flag = a11y_active_flag.clone();
                    Box::new(move || {
                        log::info!("Accessibility activated");
                        active_flag.store(true, SeqCst);
                        activation_sender.send_blocking(()).log_err();
                        Some(initial_tree.clone())
                    })
                },
                action: Box::new(move |request| {
                    action_sender.send_blocking(request).log_err();
                }),
                deactivation: {
                    let active_flag = a11y_active_flag.clone();
                    Box::new(move || {
                        log::info!("Accessibility deactivated");
                        active_flag.store(false, SeqCst);
                        deactivation_sender.send_blocking(()).log_err();
                    })
                },
            });

            // A11y can be activated at any time, and so we cannot compute a
            // correct `TreeUpdate` on-demand. When this happens, we return a
            // default empty `TreeUpdate`.
            //
            // So we force a new frame, which will then send a correct `TreeUpdate`.
            let mut async_cx = cx.to_async();
            cx.foreground_executor()
                .spawn(async move {
                    while activation_receiver.recv().await.is_ok() {
                        handle
                            .update(&mut async_cx, |_, window, _| window.refresh())
                            .log_err();
                    }
                })
                .detach();

            let mut async_cx = cx.to_async();
            cx.foreground_executor()
                .spawn(async move {
                    while deactivation_receiver.recv().await.is_ok() {
                        handle
                            .update(&mut async_cx, |_, window, _| window.refresh())
                            .log_err();
                    }
                })
                .detach();

            let mut async_cx = cx.to_async();
            cx.foreground_executor()
                .spawn(async move {
                    while let Ok(request) = action_receiver.recv().await {
                        handle
                            .update(&mut async_cx, |_, window, cx| {
                                window.handle_a11y_action(request, cx);
                            })
                            .log_err();
                    }
                })
                .detach();
        }

        platform_window.on_close(Box::new({
            let window_id = handle.window_id();
            let mut cx = cx.to_async();
            move || {
                let _ = handle.update(&mut cx, |_, window, _| window.remove_window());
                let _ = cx.update(|cx| {
                    SystemWindowTabController::remove_tab(cx, window_id);
                });
            }
        }));
        platform_window.on_request_frame(Box::new({
            let mut cx = cx.to_async();
            let invalidator = invalidator.clone();
            let active = active.clone();
            let needs_present = needs_present.clone();
            let scene_animates = scene_animates.clone();
            let scene_transitioning = scene_transitioning.clone();
            let last_present_at = last_present_at.clone();
            let next_frame_callbacks = next_frame_callbacks.clone();
            let input_rate_tracker = input_rate_tracker.clone();
            let mut deferred_force_render = false;
            move |request_frame_options| {
                #[cfg(feature = "profiler")]
                let _foreground_turn = profiler::journal::foreground_turn();
                // This must be checked before anything else: if this request
                // arrived re-entrantly while a draw is on this thread's stack
                // (e.g. via a nested message pump in the Windows window
                // procedure), drawing would nest draws, and even touching the
                // App would panic on its already-mutable borrow. Skip instead;
                // the platform leaves the window invalidated (or re-invalidates
                // it), so a fresh request arrives once the in-progress draw
                // unwinds. Remember force_render so the deferred frame still
                // bypasses the view cache.
                //
                // Returning here skips `complete_frame`, which on Wayland would
                // stall the window's frame callbacks (no `surface.commit()`) —
                // but calling it would hit the App borrow panic above, and this
                // branch is unreachable there in practice: only Windows pumps
                // platform events (and thus requests frames) mid-draw.
                if draw_in_progress() {
                    log::debug!("deferring re-entrant window draw request");
                    deferred_force_render |= request_frame_options.force_render;
                    // Platforms that stop requesting frames for idle windows
                    // would otherwise never deliver the deferred frame. The
                    // waker only touches the invalidator, never the App.
                    invalidator.wake_platform();
                    return;
                }
                // Take the deferred flag first: `||` short-circuits, and leaving
                // the flag set when this request already forces a render would
                // force a second, redundant render on the next frame.
                let force_render =
                    mem::take(&mut deferred_force_render) || request_frame_options.force_render;

                // Throttle frame rate based on conditions:
                // - Thermal pressure (Serious/Critical): cap to ~60fps
                // - Inactive window (not focused): cap to ~30fps to save energy
                //
                // An unfocused window's own redraws count as demand too: an
                // app that paces its animations with timers and notifies per
                // streamed chunk has no next-frame callbacks for the cap to
                // see, and redrew at the display's rate in the background.
                // Input-driven redraws stay exempt through the rate tracker.
                let has_demand = request_frame_options.force_render
                    || !next_frame_callbacks.borrow().is_empty()
                    || (!active.get() && invalidator.is_dirty());
                let min_frame_interval = if request_frame_options.require_presentation
                    || !has_demand
                {
                    None
                } else if !active.get() && !input_rate_tracker.borrow_mut().is_high_rate() {
                    inactive_frame_interval
                } else if let Some(ThermalState::Critical | ThermalState::Serious) = handle
                    .update(&mut cx, |_, _, cx| cx.thermal_state())
                    .log_err()
                {
                    Some(Duration::from_micros(16667))
                } else {
                    None
                };

                let now = Instant::now();
                if let Some(min_interval) = min_frame_interval {
                    if let Some(last_frame) = last_frame_time.get()
                        && now.duration_since(last_frame) < min_interval
                    {
                        // Don't lose a pending forced render to throttling.
                        deferred_force_render |= force_render;
                        // Deferred by throttling: ask demand-driven platforms to retry.
                        handle
                            .update(&mut cx, |_, window, _| {
                                window.platform_window.schedule_frame();
                            })
                            .log_err();
                        // The demand that entered this branch (a deferred forced
                        // render or pending next-frame callbacks) is still
                        // unserved; platforms that stop requesting frames for
                        // idle windows need a wakeup to deliver the retry.
                        invalidator.wake_platform();
                        return;
                    }
                }
                last_frame_time.set(Some(now));

                let pending_next_frame_callbacks = next_frame_callbacks.take();
                if !pending_next_frame_callbacks.is_empty() {
                    handle
                        .update(&mut cx, |_, window, cx| {
                            for callback in pending_next_frame_callbacks {
                                callback(window, cx);
                            }
                        })
                        .log_err();
                }

                // Keep presenting if input was recently arriving at a high rate (>= 60fps).
                // Once high-rate input is detected, we sustain presentation for 1 second
                // to prevent display underclocking during active input.
                //
                // A scene that animates on its own (a sweeping text shimmer)
                // is presented again at the time-animation rate, with nothing
                // rendered, laid out or painted: `present` moves it to now.
                // A transition is a short one-shot move the reader is
                // watching, so it presents at the faster transition rate.
                let presented_within = |interval: Duration| {
                    last_present_at.get().is_none_or(|last_present| {
                        now.duration_since(last_present) + TIME_ANIMATION_FRAME_SLACK >= interval
                    })
                };
                let needs_present = request_frame_options.require_presentation
                    || needs_present.get()
                    || input_rate_tracker.borrow_mut().is_high_rate()
                    || (scene_transitioning.get()
                        && presented_within(time_transition_frame_interval()))
                    || (scene_animates.get()
                        && last_present_at.get().is_none_or(|last_present| {
                            let interval = if active.get() {
                                time_animation_frame_interval()
                            } else {
                                time_animation_frame_interval()
                                    .max(inactive_frame_interval.unwrap_or_default())
                            };
                            // Frame requests arrive on vsync, so an interval
                            // that is a whole number of refreshes lands a hair
                            // early or late; without the slack, 30 fps on a
                            // 120 Hz display would present every fifth vsync.
                            now.duration_since(last_present)
                                + TIME_ANIMATION_FRAME_SLACK
                                >= interval
                        }));

                if invalidator.is_dirty() || force_render {
                    measure("frame duration", || {
                        handle
                            .update(&mut cx, |_, window, cx| {
                                if force_render {
                                    // Bypass cached view reuse so we don't replay stale
                                    // atlas tile references after a GPU device recovery.
                                    window.refresh();
                                }
                                let arena_clear_needed = window.draw(cx);
                                window.present();
                                arena_clear_needed.clear(cx);
                            })
                            .log_err();
                    })
                } else if needs_present {
                    handle
                        .update(&mut cx, |_, window, cx| {
                            if window.rendered_scene_may_reference_retired_tiles()
                                && !window.retired_tile_redraw_deferred
                            {
                                // The retained scene is old enough that the atlas may
                                // have reclaimed tiles it names. Rebuild it without
                                // cached-view replay so every tile is fetched afresh.
                                // Once per run of deferred presents: the retries
                                // present this rebuild.
                                window.retired_tile_redraw_deferred = true;
                                window.refresh();
                                let arena_clear_needed = window.draw(cx);
                                window.present();
                                arena_clear_needed.clear(cx);
                            } else {
                                window.present();
                            }
                        })
                        .log_err();
                }

                // `needs_present` is still set after the present above only
                // when the platform deferred it (see `PresentOutcome`):
                // presented and dropped frames both clear it. That is what
                // keeps this from looping: a platform that reported a
                // repeating error as deferred would be asked for a frame on
                // every request, so errors must stay `Dropped`.
                let present_owed = handle
                    .update(&mut cx, |_, window, _| {
                        let present_owed = window.needs_present.get();
                        if window.invalidator.is_dirty()
                            || !window.next_frame_callbacks.borrow().is_empty()
                            || window.scene_animates.get()
                            || present_owed
                        {
                            window.platform_window.schedule_frame();
                        }
                        present_owed
                    })
                    .log_err()
                    .unwrap_or(false);

                // Platforms that stop requesting frames for idle windows only
                // deliver another request after a wakeup. If demand remains
                // after this frame, re-arm the frame source explicitly:
                // - the window was re-invalidated mid-draw;
                // - animations scheduled next-frame callbacks;
                // - the scene animates on its own, or a transition is running
                //   (both present on later requests without being dirty);
                // - the present was deferred;
                // - high-rate input keeps presentation going for a while
                //   after it stops, so the display does not underclock;
                // - a forced render is still owed (a throttled frame, or a
                //   re-entrant request deferred above).
                // A platform-required presentation is served by this frame
                // and needs no follow-up unless it was deferred, which
                // `present_owed` covers. A missed wake leaves the window frozen until unrelated
                // activity, so this errs toward waking.
                if invalidator.is_dirty()
                    || !next_frame_callbacks.borrow().is_empty()
                    || scene_animates.get()
                    || scene_transitioning.get()
                    || present_owed
                    || deferred_force_render
                    || input_rate_tracker.borrow().is_high_rate()
                {
                    invalidator.wake_platform();
                }
            }
        }));
        invalidator.set_platform_waker(platform_window.frame_waker());
        platform_window.on_visual_viewport_changed(Box::new({
            let mut cx = cx.to_async();
            move || {
                handle
                    .update(&mut cx, |_, window, _| window.refresh())
                    .log_err();
            }
        }));
        platform_window.on_insets_changed(Box::new({
            let mut cx = cx.to_async();
            move |_| {
                handle
                    .update(&mut cx, |_, window, _| window.refresh())
                    .log_err();
            }
        }));
        platform_window.on_resize(Box::new({
            let mut cx = cx.to_async();
            move |_, _| {
                handle
                    .update(&mut cx, |_, window, cx| window.bounds_changed(cx))
                    .log_err();
            }
        }));
        platform_window.on_moved(Box::new({
            let mut cx = cx.to_async();
            move || {
                handle
                    .update(&mut cx, |_, window, cx| window.bounds_changed(cx))
                    .log_err();
            }
        }));
        platform_window.on_appearance_changed(Box::new({
            let cx = cx.to_async();
            let foreground_executor = cx.foreground_executor().clone();
            move || {
                let mut cx = cx.clone();
                // Defer the update because changing the AppKit appearance may
                // synchronously invoke this callback while App is already borrowed.
                foreground_executor
                    .spawn(async move {
                        handle
                            .update(&mut cx, |_, window, cx| window.appearance_changed(cx))
                            .log_err();
                    })
                    .detach();
            }
        }));
        platform_window.on_button_layout_changed(Box::new({
            let mut cx = cx.to_async();
            move || {
                handle
                    .update(&mut cx, |_, window, cx| window.button_layout_changed(cx))
                    .log_err();
            }
        }));
        platform_window.on_active_status_change(Box::new({
            let mut cx = cx.to_async();
            move |active| {
                handle
                    .update(&mut cx, |_, window, cx| {
                        window.active.set(active);
                        window.modifiers = window.platform_window.modifiers();
                        window.capslock = window.platform_window.capslock();
                        window
                            .activation_observers
                            .clone()
                            .retain(&(), |callback| callback(window, cx));

                        window.bounds_changed(cx);
                        window.refresh();

                        SystemWindowTabController::update_last_active(cx, window.handle.id);
                    })
                    .log_err();
            }
        }));
        platform_window.on_visibility_change(Box::new({
            let mut cx = cx.to_async();
            move |_| {
                handle
                    .update(&mut cx, |_, window, cx| {
                        window.refresh_visibility(cx);
                    })
                    .log_err();
            }
        }));
        platform_window.on_hover_status_change(Box::new({
            let mut cx = cx.to_async();
            move |active| {
                handle
                    .update(&mut cx, |_, window, _| {
                        window.hovered.set(active);
                        window.refresh();
                    })
                    .log_err();
            }
        }));
        platform_window.on_input({
            let mut cx = cx.to_async();
            Box::new(move |event| {
                handle
                    .update(&mut cx, |_, window, cx| window.dispatch_event(event, cx))
                    .log_err()
                    .unwrap_or(DispatchEventResult::default())
            })
        });
        platform_window.on_hit_test_window_control({
            let mut cx = cx.to_async();
            Box::new(move || {
                handle
                    .update(&mut cx, |_, window, _cx| {
                        for (area, hitbox) in &window.rendered_frame.window_control_hitboxes {
                            if window.mouse_hit_test.ids.contains(&hitbox.id) {
                                return Some(*area);
                            }
                        }
                        None
                    })
                    .log_err()
                    .unwrap_or(None)
            })
        });
        platform_window.on_move_tab_to_new_window({
            let mut cx = cx.to_async();
            Box::new(move || {
                handle
                    .update(&mut cx, |_, _window, cx| {
                        SystemWindowTabController::move_tab_to_new_window(cx, handle.window_id());
                    })
                    .log_err();
            })
        });
        platform_window.on_merge_all_windows({
            let mut cx = cx.to_async();
            Box::new(move || {
                handle
                    .update(&mut cx, |_, _window, cx| {
                        SystemWindowTabController::merge_all_windows(cx, handle.window_id());
                    })
                    .log_err();
            })
        });
        platform_window.on_select_next_tab({
            let mut cx = cx.to_async();
            Box::new(move || {
                handle
                    .update(&mut cx, |_, _window, cx| {
                        SystemWindowTabController::select_next_tab(cx, handle.window_id());
                    })
                    .log_err();
            })
        });
        platform_window.on_select_previous_tab({
            let mut cx = cx.to_async();
            Box::new(move || {
                handle
                    .update(&mut cx, |_, _window, cx| {
                        SystemWindowTabController::select_previous_tab(cx, handle.window_id())
                    })
                    .log_err();
            })
        });
        platform_window.on_toggle_tab_bar({
            let mut cx = cx.to_async();
            Box::new(move || {
                handle
                    .update(&mut cx, |_, window, cx| {
                        let tab_bar_visible = window.platform_window.tab_bar_visible();
                        SystemWindowTabController::set_visible(cx, tab_bar_visible);
                    })
                    .log_err();
            })
        });

        if let Some(app_id) = app_id {
            platform_window.set_app_id(&app_id);
        }

        platform_window.map_window().unwrap();

        Ok(Window {
            handle,
            invalidator,
            removed: false,
            platform_window,
            display_id,
            is_resizable,
            is_minimizable,
            sprite_atlas,
            atlas_frame_at_last_present: 0,
            retired_tile_redraw_deferred: false,
            text_system,
            text_rendering_mode: cx.text_rendering_mode.clone(),
            rem_size: px(16.),
            rem_size_override_stack: SmallVec::new(),
            viewport_size: content_size,
            layout_engine: Some(TaffyLayoutEngine::new()),
            layout_keys: layout_keys::LayoutKeys::default(),
            root: None,
            element_id_stack: SmallVec::default(),
            global_element_ids: crate::element::GlobalElementIdCache::default(),
            text_style_stack: Vec::new(),
            rendered_entity_stack: Vec::new(),
            element_offset_stack: Vec::new(),
            content_mask_stack: Vec::new(),
            text_shimmer_stack: Vec::new(),
            glyph_raster_cache: glyph_painting::GlyphRasterCache::default(),
            line_glyph_cache: glyph_painting::LineGlyphCache::default(),
            frame_work: frame_work::FrameWorkCounters::default(),
            opacity_cycle_stack: Vec::new(),
            view_retention: view_retention::ViewRetention::new(cx),
            element_opacity: 1.0,
            glass_content: false,
            requested_autoscroll: None,
            last_text_input_configuration: None,
            focused_text_input_active: false,
            prepainting_deferred_draw_beneath_native_surfaces: None,
            rendered_frame: Frame::new(DispatchTree::new(cx.keymap.clone(), cx.actions.clone())),
            next_frame: Frame::new(DispatchTree::new(cx.keymap.clone(), cx.actions.clone())),
            next_frame_callbacks,
            next_hitbox_id: HitboxId(0),
            next_tooltip_id: TooltipId::default(),
            tooltip_bounds: None,
            dirty_views: FxHashSet::default(),
            group_hitboxes: Default::default(),
            focus_listeners: SubscriberSet::new(),
            focus_lost_listeners: SubscriberSet::new(),
            focus_lost_path: SmallVec::new(),
            default_prevented: true,
            mouse_position,
            mouse_hit_test: HitTest::default(),
            modifiers,
            capslock,
            scale_factor,
            bounds_observers: SubscriberSet::new(),
            appearance,
            appearance_observers: SubscriberSet::new(),
            button_layout_observers: SubscriberSet::new(),
            active,
            visibility,
            visibility_observers: SubscriberSet::new(),
            hovered,
            needs_present,
            scene_animates,
            scene_transitioning,
            last_present_at,
            input_rate_tracker,
            #[cfg(feature = "profiler")]
            window_profiler: profiler::WindowProfiler::new(handle.window_id())?,
            #[cfg(feature = "profiler")]
            draw_clock: draw_profile::DrawClock::new(),
            #[cfg(feature = "profiler")]
            draw_resources: draw_profile::DrawResourceSampler::new(),
            #[cfg(feature = "profiler")]
            view_timer: draw_profile::ViewTimer::new(),
            last_input_modality: InputModality::Mouse,
            touch_gestures: TouchGestureRecognizer::new(
                cx.platform
                    .gestures()
                    .map_or_else(GestureTuning::default, |gestures| gestures.tuning()),
            ),
            touch_prediction_enabled: true,
            long_press_timer: None,
            long_press_capture: None,
            last_draw_at: cx.background_executor().now(),
            idle_capacity_reclaim: None,
            refreshing: false,
            activation_observers: SubscriberSet::new(),
            focus: None,
            focus_enabled: true,
            focus_generation: 0,
            pending_input: None,
            pending_modifier: ModifierState::default(),
            pending_input_observers: SubscriberSet::new(),
            prompt: None,
            client_inset: None,
            image_cache_stack: Vec::new(),
            captured_hitbox: None,
            #[cfg(any(feature = "inspector", debug_assertions))]
            inspector: None,
            #[cfg(feature = "profiler")]
            debug_frame_overlay: crate::debug_overlay::DebugFrameOverlay::new(),
            a11y: A11y::new(
                a11y_active_flag,
                accessibility_force_disabled,
                initial_window_title,
            ),
        })
    }

    pub(crate) fn new_focus_listener(
        &self,
        value: AnyWindowFocusListener,
    ) -> (Subscription, impl FnOnce() + use<>) {
        self.focus_listeners.insert((), value)
    }
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
#[expect(missing_docs)]
pub struct DispatchEventResult {
    pub propagate: bool,
    pub default_prevented: bool,
}

/// Indicates which region of the window is visible. Content falling outside of this mask will not be
/// rendered. Currently, only rectangular content masks are supported, but we give the mask its own type
/// to leave room to support more complex shapes in the future.
#[derive(Copy, Clone, Debug, Default, PartialEq, Eq)]
#[repr(C)]
pub struct ContentMask<P: Clone + Debug + Default + PartialEq> {
    /// The bounds
    pub bounds: Bounds<P>,
}

impl ContentMask<Pixels> {
    /// Scale the content mask's pixel units by the given scaling factor.
    pub fn scale(&self, factor: f32) -> ContentMask<ScaledPixels> {
        ContentMask {
            bounds: self.bounds.scale(factor),
        }
    }

    /// Intersect the content mask with the given content mask.
    pub fn intersect(&self, other: &Self) -> Self {
        let bounds = self.bounds.intersect(&other.bounds);
        ContentMask { bounds }
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub(crate) struct TextShimmerStyle {
    pub origin: Point<Pixels>,
    pub highlight_color: Hsla,
    pub band_origin: Pixels,
    pub band_width: Pixels,
    pub direction: [f32; 2],
    pub peak: f32,
    pub falloff: f32,
    pub core_gain: f32,
    pub core_spread: f32,
    /// The scene's [`SpriteEffect::animation`] for this band; set by
    /// [`Window::with_text_shimmer`] when the band sweeps.
    pub animation: u32,
}

/// How a [`TextShimmerStyle`]'s band moves with time, in logical pixels along
/// its direction. See [`crate::scene::ShimmerAnimation`].
#[derive(Clone, Copy, Debug, PartialEq)]
pub(crate) struct TextShimmerSweep {
    pub band_start: Pixels,
    pub travel: Pixels,
    pub period: Duration,
    pub hold: f32,
}

impl TextShimmerStyle {
    fn scale(self, factor: f32) -> SpriteEffect {
        // `direction` is a unit vector and the profile fields are all fractions
        // of the band, so they are scale-invariant; only the band's position and
        // width along `direction` convert to device pixels.
        SpriteEffect {
            kind: SpriteEffect::SHIMMER_KIND,
            peak: self.peak,
            falloff: self.falloff,
            core_gain: self.core_gain,
            origin: self.origin.scale(factor),
            core_spread: self.core_spread,
            animation: self.animation,
            highlight_color: self.highlight_color,
            band_origin: self.band_origin.0 * factor,
            band_width: self.band_width.0 * factor,
            direction: self.direction,
        }
    }
}

/// How early a time-animation frame may be presented, so an interval that is
/// a whole number of display refreshes is not pushed to the next one by vsync
/// jitter.
const TIME_ANIMATION_FRAME_SLACK: Duration = Duration::from_millis(2);

static TIME_ANIMATION_FRAME_NANOS: std::sync::atomic::AtomicU64 =
    std::sync::atomic::AtomicU64::new(33_333_333);

/// Sets how often a window whose scene animates on its own (a sweeping text
/// shimmer) presents that scene again while nothing redraws it. Defaults to
/// 30 fps. An inactive window never goes faster than its
/// [`WindowOptions::inactive_frame_interval`].
///
/// These frames render, lay out and paint nothing, but each one still encodes
/// and rasterizes the whole scene on the GPU, so an app in the background may
/// want to slow them down.
pub fn set_time_animation_frame_interval(interval: Duration) {
    TIME_ANIMATION_FRAME_NANOS.store(
        u64::try_from(interval.as_nanos()).unwrap_or(u64::MAX),
        std::sync::atomic::Ordering::Relaxed,
    );
}

fn time_animation_frame_interval() -> Duration {
    Duration::from_nanos(TIME_ANIMATION_FRAME_NANOS.load(std::sync::atomic::Ordering::Relaxed))
}

/// Sets how often a window presents while a [`TimeTransition`] in its scene
/// has yet to land. Defaults to 60 fps: a transition is a short move the
/// reader is watching, but presenting on every refresh of a 120 Hz display
/// doubles its cost for a step nobody sees.
pub fn set_time_transition_frame_interval(interval: Duration) {
    TIME_TRANSITION_FRAME_NANOS.store(
        u64::try_from(interval.as_nanos()).unwrap_or(u64::MAX),
        std::sync::atomic::Ordering::Relaxed,
    );
}

static TIME_TRANSITION_FRAME_NANOS: std::sync::atomic::AtomicU64 =
    std::sync::atomic::AtomicU64::new(16_666_667);

fn time_transition_frame_interval() -> Duration {
    Duration::from_nanos(TIME_TRANSITION_FRAME_NANOS.load(std::sync::atomic::Ordering::Relaxed))
}

/// `GPUI_DISABLE_TEXT_SHIMMER=1` paints shimmered text as plain text without
/// changing anything else about the scene. The primitive stream keeps the same
/// shape and count, so an A/B of the same binary isolates exactly what the
/// shimmer costs on the GPU (see fincode's `docs/gpu-profiling.md`).
pub(crate) fn text_shimmer_disabled() -> bool {
    static DISABLED: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *DISABLED.get_or_init(|| {
        std::env::var("GPUI_DISABLE_TEXT_SHIMMER")
            .is_ok_and(|value| value == "1" || value.eq_ignore_ascii_case("true"))
    })
}

impl Window {
    fn mark_view_dirty(&mut self, view_id: EntityId) {
        // Mark ancestor views as dirty. If already in the `dirty_views` set, then all its ancestors
        // should already be dirty.
        for view_id in self
            .rendered_frame
            .dispatch_tree
            .view_path_reversed(view_id)
        {
            if !self.dirty_views.insert(view_id) {
                break;
            }
        }
    }

    pub(crate) fn refresh_visibility(&mut self, cx: &mut App) {
        let visibility = self.platform_window.visibility();
        if self.visibility != visibility {
            self.visibility = visibility;
            #[cfg(feature = "profiler")]
            profiler::journal::record_window_visibility(self.handle.window_id(), visibility);
            self.visibility_observers
                .clone()
                .retain(&(), |callback| callback(visibility, self, cx));
        }
        #[cfg(feature = "profiler")]
        if self.invalidator.is_dirty() || self.needs_present.get() {
            profiler::journal::record_frame_pending(self.handle.window_id(), Instant::now());
        }
    }

    /// Whether the platform is presenting this window's frames (see
    /// [`WindowVisibility`]).
    pub fn visibility(&self) -> WindowVisibility {
        self.visibility
    }

    /// Whether frames drawn for this window will be shown.
    ///
    /// This is not the window's shown/hidden state: a shown window that is
    /// fully behind another window, minimized, or on a sleeping display is not
    /// visible here.
    pub fn is_visible(&self) -> bool {
        self.visibility.is_visible()
    }

    /// Registers a callback to be invoked when the window's visibility changes.
    pub fn observe_window_visibility(
        &self,
        mut callback: impl FnMut(WindowVisibility, &mut Window, &mut App) + 'static,
    ) -> Subscription {
        let (subscription, activate) = self.visibility_observers.insert(
            (),
            Box::new(move |visibility, window, cx| {
                callback(visibility, window, cx);
                true
            }),
        );
        activate();
        subscription
    }

    /// Registers a callback to be invoked when the window appearance changes.
    pub fn observe_window_appearance(
        &self,
        mut callback: impl FnMut(&mut Window, &mut App) + 'static,
    ) -> Subscription {
        let (subscription, activate) = self.appearance_observers.insert(
            (),
            Box::new(move |window, cx| {
                callback(window, cx);
                true
            }),
        );
        activate();
        subscription
    }

    /// Registers a callback to be invoked when the window button layout changes.
    pub fn observe_button_layout_changed(
        &self,
        mut callback: impl FnMut(&mut Window, &mut App) + 'static,
    ) -> Subscription {
        let (subscription, activate) = self.button_layout_observers.insert(
            (),
            Box::new(move |window, cx| {
                callback(window, cx);
                true
            }),
        );
        activate();
        subscription
    }

    /// Replaces the root entity of the window with a new one.
    pub fn replace_root<E>(
        &mut self,
        cx: &mut App,
        build_view: impl FnOnce(&mut Window, &mut Context<E>) -> E,
    ) -> Entity<E>
    where
        E: 'static + Render,
    {
        let view = cx.new(|cx| build_view(self, cx));
        self.root = Some(view.clone().into());
        self.refresh();
        view
    }

    /// Returns the root entity of the window, if it has one.
    pub fn root<E>(&self) -> Option<Option<Entity<E>>>
    where
        E: 'static + Render,
    {
        self.root
            .as_ref()
            .map(|view| view.clone().downcast::<E>().ok())
    }

    /// Obtain a handle to the window that belongs to this context.
    pub fn window_handle(&self) -> AnyWindowHandle {
        self.handle
    }

    /// Enables an experimental transparent GPUI scene plane above native child
    /// views hosted by this window.
    ///
    /// The root scene remains on the primary surface. Deferred elements and
    /// window-level overlays are rendered on the transparent plane, except
    /// deferred draws registered through
    /// [`Self::defer_draw_beneath_native_surfaces`], which stay on the base
    /// plane.
    pub fn enable_scene_overlay(&self) -> anyhow::Result<()> {
        self.platform_window.enable_scene_overlay()
    }

    /// Tears down the transparent scene plane [`Self::enable_scene_overlay`]
    /// created, returning the window to single-surface rendering: every
    /// deferred draw is painted on the primary surface again, and the overlay
    /// surface's GPU memory is released. A no-op when no overlay is enabled.
    ///
    /// Call it once the last native child view is gone. While one is still
    /// hosted, disabling the overlay puts popups and menus back behind it.
    pub fn disable_scene_overlay(&self) {
        self.platform_window.disable_scene_overlay()
    }

    /// Creates a native surface slot between the root scene and GPUI's
    /// deferred/window-level overlay scene.
    pub fn create_native_surface(&self) -> anyhow::Result<Rc<dyn crate::PlatformNativeSurface>> {
        self.platform_window.create_native_surface()
    }

    /// Mark the window as dirty, scheduling it to be redrawn on the next frame.
    pub fn refresh(&mut self) {
        if self.invalidator.not_drawing() {
            self.refreshing = true;
            self.invalidator.set_dirty(true);
        }
    }

    /// Close this window.
    pub fn remove_window(&mut self) {
        self.removed = true;
    }

    /// Obtain the currently focused [`FocusHandle`]. If no elements are focused, returns `None`.
    pub fn focused(&self, cx: &App) -> Option<FocusHandle> {
        self.focus
            .and_then(|id| FocusHandle::for_id(id, &cx.focus_handles))
    }

    /// While focus-lost listeners are being dispatched, returns the closest ancestor of the
    /// previously focused element that can still receive focus, making it a suitable target
    /// for focus restoration. Returns `None` at all other times, or when no such ancestor exists.
    pub fn focus_lost_restore_target(&self, cx: &App) -> Option<FocusHandle> {
        let (_leaf, ancestors) = self.focus_lost_path.split_last()?;
        ancestors.iter().rev().find_map(|id| {
            self.rendered_frame.dispatch_tree.focusable_node_id(*id)?;
            FocusHandle::for_id(*id, &cx.focus_handles)
        })
    }

    /// Move focus to the element associated with the given [`FocusHandle`].
    pub fn focus(&mut self, handle: &FocusHandle, cx: &mut App) {
        if !self.focus_enabled || self.focus == Some(handle.id) {
            return;
        }

        self.focus = Some(handle.id);
        self.focus_generation = self.focus_generation.wrapping_add(1);
        self.clear_pending_keystrokes(cx);

        self.refresh();
    }

    /// Remove focus from all elements within this context's window.
    pub fn blur(&mut self, cx: &mut App) {
        self.clear_pending_keystrokes(cx);

        if !self.focus_enabled {
            return;
        }

        if self.focus.is_some() {
            self.focus_generation = self.focus_generation.wrapping_add(1);
        }
        self.focus = None;
        self.refresh();
    }

    /// Blur the window and don't allow anything in it to be focused again.
    pub fn disable_focus(&mut self, cx: &mut App) {
        self.blur(cx);
        self.focus_enabled = false;
    }

    /// Move focus to next tab stop.
    pub fn focus_next(&mut self, cx: &mut App) {
        if !self.focus_enabled {
            return;
        }

        if let Some(handle) = self.rendered_frame.tab_stops.next(self.focus.as_ref()) {
            self.focus(&handle, cx)
        }
    }

    /// Move focus to previous tab stop.
    pub fn focus_prev(&mut self, cx: &mut App) {
        if !self.focus_enabled {
            return;
        }

        if let Some(handle) = self.rendered_frame.tab_stops.prev(self.focus.as_ref()) {
            self.focus(&handle, cx)
        }
    }

    /// Accessor for the text system.
    pub fn text_system(&self) -> &Arc<WindowTextSystem> {
        &self.text_system
    }

    /// The current text style. Which is composed of all the style refinements provided to `with_text_style`.
    pub fn text_style(&self) -> TextStyle {
        let mut style = TextStyle::default();
        for refinement in &self.text_style_stack {
            style.refine(refinement);
        }
        style
    }

    /// Check if the platform window is maximized.
    ///
    /// On some platforms (namely Windows) this is different than the bounds being the size of the display
    pub fn is_maximized(&self) -> bool {
        self.platform_window.is_maximized()
    }

    /// request a certain window decoration (Wayland)
    pub fn request_decorations(&self, decorations: WindowDecorations) {
        self.platform_window.request_decorations(decorations);
    }

    /// Set the exclusive zone for a layer-shell surface: how much screen space it
    /// reserves so other surfaces avoid occluding it (e.g. a panel reserving space).
    /// Positive values reserve that distance from the anchored edge, 0 lets the
    /// surface be moved out of others' exclusive zones, and -1 ignores reserved
    /// space and may extend under other surfaces. (Wayland layer-shell windows only)
    pub fn set_exclusive_zone(&self, zone: Pixels) {
        self.platform_window.set_exclusive_zone(zone);
    }

    /// Set which anchored edge a layer-shell surface's exclusive zone applies to.
    /// This is only needed to disambiguate a corner-anchored surface; otherwise the
    /// edge is deduced from the anchor. The edge must be a single edge the surface
    /// is anchored to, or it is ignored. (Wayland layer-shell windows only)
    #[cfg(all(target_os = "linux", feature = "wayland"))]
    pub fn set_exclusive_edge(&self, edge: crate::layer_shell::Anchor) {
        self.platform_window.set_exclusive_edge(edge);
    }

    /// Start an interactive window resize operation if this window is resizable.
    pub fn start_window_resize(&self, edge: ResizeEdge) {
        if self.is_resizable {
            self.platform_window.start_window_resize(edge);
        }
    }

    /// Linux (wayland) only: Set the window's input region, the area that receives pointer
    /// and touch input. Events outside it pass through to whatever is below the window.
    ///
    /// - `Some(rects)` restricts input to the union of `rects`, in window coordinates.
    /// - `Some(&[])` is an empty region, so the window receives no pointer or touch input.
    /// - `None` resets the region to the default, so the whole window receives input again.
    pub fn set_input_region(&self, region: Option<&[Bounds<Pixels>]>) {
        self.platform_window.set_input_region(region);
    }

    /// Return the `WindowBounds` to indicate that how a window should be opened
    /// after it has been closed
    pub fn window_bounds(&self) -> WindowBounds {
        self.platform_window.window_bounds()
    }

    /// Return the `WindowBounds` excluding insets (Wayland and X11)
    pub fn inner_window_bounds(&self) -> WindowBounds {
        self.platform_window.inner_window_bounds()
    }

    /// Encode the window's native restorable state into an opaque blob.
    /// Returns `None` on platforms without native state restoration or if encoding fails.
    pub fn native_window_state(&self) -> Option<Vec<u8>> {
        self.platform_window.native_window_state()
    }

    /// Restore the window's native state from a blob previously produced
    /// by [`Window::native_window_state`]. A no-op on platforms without native state restoration.
    pub fn restore_native_window_state(&self, state: &[u8]) {
        self.platform_window.restore_native_window_state(state);
    }

    /// Dispatch the given action on the currently focused element.
    pub fn dispatch_action(&mut self, action: Box<dyn Action>, cx: &mut App) {
        let focus_id = self.focused(cx).map(|handle| handle.id);

        let window = self.handle;
        cx.defer(move |cx| {
            window
                .update(cx, |_, window, cx| {
                    let node_id = window.focus_node_id_in_rendered_frame(focus_id);
                    window.dispatch_action_on_node(node_id, action.as_ref(), cx);
                })
                .log_err();
        })
    }

    pub(crate) fn dispatch_keystroke_observers(
        &mut self,
        keystroke: &Keystroke,
        action: Option<&dyn Action>,
        context_stack: Vec<KeyContext>,
        cx: &mut App,
    ) {
        cx.keystroke_observers.clone().retain(&(), move |callback| {
            (callback)(
                &KeystrokeEvent {
                    keystroke: keystroke.clone(),
                    action: action.map(|action| action.boxed_clone()),
                    context_stack: context_stack.clone(),
                },
                self,
                cx,
            )
        });
    }

    pub(crate) fn dispatch_keystroke_interceptors(
        &mut self,
        keystroke: &Keystroke,
        context_stack: Vec<KeyContext>,
        cx: &mut App,
    ) {
        cx.keystroke_interceptors
            .clone()
            .retain(&(), move |callback| {
                (callback)(
                    &KeystrokeEvent {
                        keystroke: keystroke.clone(),
                        action: None,
                        context_stack: context_stack.clone(),
                    },
                    self,
                    cx,
                )
            });
    }

    /// Schedules the given function to be run at the end of the current effect cycle, allowing entities
    /// that are currently on the stack to be returned to the app.
    pub fn defer(&self, cx: &mut App, f: impl FnOnce(&mut Window, &mut App) + 'static) {
        let handle = self.handle;
        cx.defer(move |cx| {
            handle.update(cx, |_, window, cx| f(window, cx)).ok();
        });
    }

    /// Subscribe to events emitted by a entity.
    /// The entity to which you're subscribing must implement the [`EventEmitter`] trait.
    /// The callback will be invoked a handle to the emitting entity, the event, and a window context for the current window.
    pub fn observe<T: 'static>(
        &mut self,
        observed: &Entity<T>,
        cx: &mut App,
        mut on_notify: impl FnMut(Entity<T>, &mut Window, &mut App) + 'static,
    ) -> Subscription {
        let entity_id = observed.entity_id();
        let observed = observed.downgrade();
        let window_handle = self.handle;
        cx.new_observer(
            entity_id,
            Box::new(move |cx| {
                window_handle
                    .update(cx, |_, window, cx| {
                        if let Some(handle) = observed.upgrade() {
                            on_notify(handle, window, cx);
                            true
                        } else {
                            false
                        }
                    })
                    .unwrap_or(false)
            }),
        )
    }

    /// Subscribe to events emitted by a entity.
    /// The entity to which you're subscribing must implement the [`EventEmitter`] trait.
    /// The callback will be invoked a handle to the emitting entity, the event, and a window context for the current window.
    pub fn subscribe<Emitter, Evt>(
        &mut self,
        entity: &Entity<Emitter>,
        cx: &mut App,
        mut on_event: impl FnMut(Entity<Emitter>, &Evt, &mut Window, &mut App) + 'static,
    ) -> Subscription
    where
        Emitter: EventEmitter<Evt>,
        Evt: 'static,
    {
        let entity_id = entity.entity_id();
        let handle = entity.downgrade();
        let window_handle = self.handle;
        cx.new_subscription(
            entity_id,
            (
                TypeId::of::<Evt>(),
                Box::new(move |event, cx| {
                    window_handle
                        .update(cx, |_, window, cx| {
                            if let Some(entity) = handle.upgrade() {
                                let event = event.downcast_ref().expect("invalid event type");
                                on_event(entity, event, window, cx);
                                true
                            } else {
                                false
                            }
                        })
                        .unwrap_or(false)
                }),
            ),
        )
    }

    /// Register a callback to be invoked when the given `Entity` is released.
    pub fn observe_release<T>(
        &self,
        entity: &Entity<T>,
        cx: &mut App,
        mut on_release: impl FnOnce(&mut T, &mut Window, &mut App) + 'static,
    ) -> Subscription
    where
        T: 'static,
    {
        let entity_id = entity.entity_id();
        let window_handle = self.handle;
        let (subscription, activate) = cx.release_listeners.insert(
            entity_id,
            Box::new(move |entity, cx| {
                let entity = entity.downcast_mut().expect("invalid entity type");
                let _ = window_handle.update(cx, |_, window, cx| on_release(entity, window, cx));
            }),
        );
        activate();
        subscription
    }

    /// Creates an [`AsyncWindowContext`], which has a static lifetime and can be held across
    /// await points in async code.
    pub fn to_async(&self, cx: &App) -> AsyncWindowContext {
        AsyncWindowContext::new_context(cx.to_async(), self.handle)
    }

    /// Schedule the given closure to be run directly after the current frame is rendered.
    pub fn on_next_frame(&self, callback: impl FnOnce(&mut Window, &mut App) + 'static) {
        RefCell::borrow_mut(&self.next_frame_callbacks).push(Box::new(callback));
        self.platform_window.schedule_frame();
        // Next-frame callbacks create frame demand without dirtying the
        // window, so the platform's frame source must be woken explicitly.
        self.invalidator.wake_platform();
    }

    /// Schedule a frame to be drawn on the next animation frame.
    ///
    /// This is useful for elements that need to animate continuously, such as a video player or an animated GIF.
    /// It will cause the window to redraw on the next frame, even if no other changes have occurred.
    ///
    /// If called from within a view, it will notify that view on the next frame. Otherwise, it will refresh the entire window.
    ///
    /// Callers driving purely decorative animations (spinners, pulses, and the
    /// like) should prefer [`AnimationExt::with_animation`](crate::AnimationExt::with_animation),
    /// which automatically respects [`App::reduce_motion`]. When using this
    /// method directly for decorative motion, check [`App::reduce_motion`]
    /// and skip the frame request when it is set.
    pub fn request_animation_frame(&self) {
        let entity = self.current_view();
        self.on_next_frame(move |_, cx| cx.notify(entity));
    }

    /// Runs all callbacks scheduled via [`Self::on_next_frame`], returning how many ran.
    ///
    /// Tests have no platform frame loop, so this simulates the delivery of the
    /// next frame.
    #[cfg(any(test, feature = "test-support"))]
    pub fn simulate_next_frame(&mut self, cx: &mut App) -> usize {
        let callbacks = self.next_frame_callbacks.take();
        let count = callbacks.len();
        for callback in callbacks {
            callback(self, cx);
        }
        count
    }

    /// Spawn the future returned by the given closure on the application thread pool.
    /// The closure is provided a handle to the current window and an `AsyncWindowContext` for
    /// use within your future.
    #[track_caller]
    pub fn spawn<AsyncFn, R>(&self, cx: &App, f: AsyncFn) -> Task<R>
    where
        R: 'static,
        AsyncFn: AsyncFnOnce(&mut AsyncWindowContext) -> R + 'static,
    {
        let handle = self.handle;
        cx.spawn(async move |app| {
            let mut async_window_cx = AsyncWindowContext::new_context(app.clone(), handle);
            f(&mut async_window_cx).await
        })
    }

    /// Spawn the future returned by the given closure on the application thread
    /// pool, with the given priority. The closure is provided a handle to the
    /// current window and an `AsyncWindowContext` for use within your future.
    #[track_caller]
    pub fn spawn_with_priority<AsyncFn, R>(
        &self,
        priority: Priority,
        cx: &App,
        f: AsyncFn,
    ) -> Task<R>
    where
        R: 'static,
        AsyncFn: AsyncFnOnce(&mut AsyncWindowContext) -> R + 'static,
    {
        let handle = self.handle;
        cx.spawn_with_priority(priority, async move |app| {
            let mut async_window_cx = AsyncWindowContext::new_context(app.clone(), handle);
            f(&mut async_window_cx).await
        })
    }

    /// Notify the window that its bounds have changed.
    ///
    /// This updates internal state like `viewport_size` and `scale_factor` from
    /// the platform window, then notifies observers. Normally called automatically
    /// by the platform's resize callback, but exposed publicly for test infrastructure.
    pub fn bounds_changed(&mut self, cx: &mut App) {
        // Test input updates Window directly; every bounds callback must preserve that cursor.
        #[cfg(any(test, feature = "test-support"))]
        if let Some(window) = self.platform_window.as_test() {
            window.set_mouse_position(self.mouse_position);
        }
        self.scale_factor = self.platform_window.scale_factor();
        self.viewport_size = self.platform_window.content_size();
        self.display_id = self.platform_window.display().map(|display| display.id());
        self.mouse_position = self.platform_window.mouse_position();

        self.refresh();

        self.bounds_observers
            .clone()
            .retain(&(), |callback| callback(self, cx));
    }

    /// Returns the bounds of the current window in the global coordinate space, which could span across multiple displays.
    pub fn bounds(&self) -> Bounds<Pixels> {
        self.platform_window.bounds()
    }

    /// Renders the current frame's scene to a texture and returns the pixel data as an RGBA image.
    /// This does not present the frame to screen - useful for visual testing where we want
    /// to capture what would be rendered without displaying it or requiring the window to be visible.
    #[cfg(any(test, feature = "test-support"))]
    pub fn render_to_image(&self) -> anyhow::Result<image::RgbaImage> {
        self.platform_window
            .render_to_image(&self.rendered_frame.scene)
    }

    /// Returns the quads in the most recently rendered frame's scene, so tests can assert on
    /// painted output without rasterizing the frame. Quad bounds are in scaled pixels and are
    /// not clipped; each quad carries the content mask it will be clipped to when drawn. Quads
    /// whose bounds don't intersect their content mask are culled at paint time and won't appear.
    #[cfg(any(test, feature = "test-support"))]
    pub fn painted_quads(&self) -> Vec<Quad> {
        self.rendered_frame.scene.quads.clone()
    }

    /// Returns the underlines in the most recently rendered frame's scene.
    #[cfg(any(test, feature = "test-support"))]
    pub fn painted_underlines(&self) -> Vec<Underline> {
        self.rendered_frame.scene.underlines.clone()
    }

    /// How many glyph sprites the last rendered frame put in the scene.
    ///
    /// Lets a test tell "the scene never had the glyph" apart from "the draw path lost it",
    /// which are very different bugs with the same symptom.
    #[cfg(any(test, feature = "test-support"))]
    pub fn rendered_glyph_sprite_count(&self) -> usize {
        self.rendered_frame.scene.monochrome_sprites.len()
            + self.rendered_frame.scene.subpixel_sprites.len()
    }

    /// Glyph sprites in the last rendered frame, split as `(monochrome, subpixel)`.
    ///
    /// Which of the two a glyph lands in is decided by `should_use_subpixel_rendering`, and the
    /// two take entirely different atlases, shaders and blend states. A test that means to cover
    /// the Windows pipeline has to assert it actually got subpixel sprites, because the flag
    /// defaults off and the grayscale path would otherwise pass while covering nothing.
    #[cfg(any(test, feature = "test-support"))]
    pub fn rendered_glyph_sprite_counts(&self) -> (usize, usize) {
        (
            self.rendered_frame.scene.monochrome_sprites.len(),
            self.rendered_frame.scene.subpixel_sprites.len(),
        )
    }

    /// Set the content size of the window.
    pub fn resize(&mut self, size: Size<Pixels>) {
        self.platform_window.resize(size);
    }

    /// Returns whether or not the window is currently fullscreen
    pub fn is_fullscreen(&self) -> bool {
        self.platform_window.is_fullscreen()
    }

    /// Returns whether the window is currently in simple (borderless) fullscreen,
    /// where it covers the entire screen including the menu bar and notch area.
    /// Always `false` on platforms other than macOS.
    pub fn is_simple_fullscreen(&self) -> bool {
        self.platform_window.is_simple_fullscreen()
    }

    pub(crate) fn appearance_changed(&mut self, cx: &mut App) {
        let appearance = self.platform_window.appearance();
        if appearance != self.appearance {
            view_retention::dependencies::ambient_changed::<view_retention::dependencies::ambient::Appearance>(cx);
        }
        self.appearance = appearance;

        self.appearance_observers
            .clone()
            .retain(&(), |callback| callback(self, cx));
    }

    pub(crate) fn button_layout_changed(&mut self, cx: &mut App) {
        self.button_layout_observers
            .clone()
            .retain(&(), |callback| callback(self, cx));
    }

    /// Returns the appearance of the current window.
    pub fn appearance(&self) -> WindowAppearance {
        self.view_retention
            .ambient_reads
            .note::<view_retention::dependencies::ambient::Appearance>();
        self.appearance
    }

    /// Returns the size of the drawable area within the window.
    pub fn viewport_size(&self) -> Size<Pixels> {
        self.viewport_size
    }

    /// Returns the platform's visible viewport in window-local logical pixels.
    ///
    /// Unlike `viewport_size`, this can shrink or move when the keyboard opens.
    /// During drawing this is a consistent frame snapshot. Outside drawing it
    /// reflects the latest platform sample, not a synchronous geometry query.
    pub fn visual_viewport_bounds(&self) -> Bounds<Pixels> {
        self.platform_window.visual_viewport_bounds()
    }

    /// Returns a conservative rectangle avoiding platform-known obscured content.
    ///
    /// Intersects the visual viewport with the full layout area inset by system
    /// safe areas and keyboard occlusion. Unknown overlays cannot be excluded.
    pub fn fully_visible_bounds(&self) -> Bounds<Pixels> {
        let insets = self.platform_window.insets().effective();
        let viewport = self.viewport_size();
        let left = insets.left.max(Pixels::ZERO).min(viewport.width);
        let top = insets.top.max(Pixels::ZERO).min(viewport.height);
        let right = (viewport.width - insets.right.max(Pixels::ZERO)).max(left);
        let bottom = (viewport.height - insets.bottom.max(Pixels::ZERO)).max(top);
        let safe_bounds = Bounds::from_corners(point(left, top), point(right, bottom));
        let mut visible = safe_bounds.intersect(&self.visual_viewport_bounds());
        visible.size.width = visible.size.width.max(Pixels::ZERO);
        visible.size.height = visible.size.height.max(Pixels::ZERO);
        visible
    }

    /// Requests the virtual keyboard for the currently focused text input.
    ///
    /// Call from a user gesture on platforms that require one. The platform may
    /// decline the request; this does not change focus or the layout viewport.
    pub fn request_virtual_keyboard(&self) {
        self.platform_window.show_soft_keyboard();
    }

    /// Requests dismissal of the virtual keyboard without changing GPUI focus.
    pub fn dismiss_virtual_keyboard(&self) {
        self.platform_window.hide_soft_keyboard();
    }

    /// Returns whether this window is focused by the operating system (receiving key events).
    pub fn is_window_active(&self) -> bool {
        self.active.get()
    }

    /// Returns whether this window is considered to be the window
    /// that currently owns the mouse cursor.
    /// On mac, this is equivalent to `is_window_active`.
    pub fn is_window_hovered(&self) -> bool {
        if cfg!(any(
            target_os = "windows",
            target_os = "linux",
            target_os = "freebsd"
        )) {
            self.hovered.get()
        } else {
            self.is_window_active()
        }
    }

    /// Toggle zoom on the window.
    pub fn zoom_window(&self) {
        self.platform_window.zoom();
    }

    /// Opens the native title bar context menu, useful when implementing client side decorations (Wayland and X11)
    pub fn show_window_menu(&self, position: Point<Pixels>) {
        self.platform_window.show_window_menu(position)
    }

    /// Handle window movement for Linux and macOS.
    /// Tells the compositor to take control of window movement (Wayland and X11)
    ///
    /// Events may not be received during a move operation.
    pub fn start_window_move(&self) {
        self.platform_window.start_window_move()
    }

    /// When using client side decorations, set this to the width of the invisible decorations (Wayland and X11)
    pub fn set_client_inset(&mut self, inset: Pixels) {
        self.client_inset = Some(inset);
        self.platform_window.set_client_inset(inset);
    }

    /// Returns the client_inset value by [`Self::set_client_inset`].
    pub fn client_inset(&self) -> Option<Pixels> {
        self.client_inset
    }

    /// Returns whether the title bar window controls need to be rendered by the application (Wayland and X11)
    pub fn window_decorations(&self) -> Decorations {
        self.platform_window.window_decorations()
    }

    /// Returns whether this window is resizable.
    pub fn is_resizable(&self) -> bool {
        self.is_resizable
    }

    /// Returns whether this window is minimizable.
    pub fn is_minimizable(&self) -> bool {
        self.is_minimizable
    }

    /// Returns the controls supported by the platform.
    pub fn window_controls(&self) -> WindowControls {
        self.platform_window.window_controls()
    }

    /// Updates the window's title at the platform level.
    pub fn set_window_title(&mut self, title: &str) {
        self.platform_window.set_title(title);
        self.a11y.set_window_title(title.to_string());
    }

    /// Sets the position of the macOS traffic light buttons.
    #[cfg(target_os = "macos")]
    pub fn set_traffic_light_position(&self, position: Point<Pixels>) {
        self.platform_window.set_traffic_light_position(position);
    }

    /// Sets the application identifier.
    pub fn set_app_id(&mut self, app_id: &str) {
        self.platform_window.set_app_id(app_id);
    }

    /// Sets the window background appearance.
    pub fn set_background_appearance(&self, background_appearance: WindowBackgroundAppearance) {
        self.platform_window
            .set_background_appearance(background_appearance);
    }

    /// Pins the window's system appearance (macOS `NSWindow.appearance`) to
    /// the given value, or restores following the system when `None`. System
    /// materials embedded in the window follow it — notably the glass/blur
    /// background view, so a dark-themed window over a light system keeps a
    /// dark glass material. No-op on platforms without per-window appearance.
    pub fn set_appearance_override(&self, appearance: Option<WindowAppearance>) {
        self.platform_window.set_appearance_override(appearance);
    }

    /// Tints the system glass backdrop (macOS 26+ `NSGlassEffectView`) with
    /// the given color, or restores the untinted adaptive material when
    /// `None`. The tint replaces the material's adaptive brightening wash
    /// while keeping the backdrop translucent. No-op on platforms without a
    /// tintable glass backdrop.
    pub fn set_background_glass_tint(&self, tint: Option<Rgba>) {
        self.platform_window.set_background_glass_tint(tint);
    }

    /// Selects the system glass backdrop style (macOS 26+
    /// `NSGlassEffectView`): the standard adaptive material, or the clearer
    /// variant that composites far less wash over the backdrop. No-op on
    /// platforms without a styleable glass backdrop.
    pub fn set_background_glass_style(&self, style: WindowGlassStyle) {
        self.platform_window.set_background_glass_style(style);
    }

    /// Mark the window as dirty at the platform level.
    pub fn set_window_edited(&mut self, edited: bool) {
        self.platform_window.set_edited(edited);
    }

    /// Set the path of the file this window represents.
    /// On macOS, this sets the window's accessibility document property (AXDocument).
    pub fn set_document_path(&self, path: Option<&std::path::Path>) {
        self.platform_window.set_document_path(path);
    }

    /// Determine the display on which the window is visible.
    pub fn display(&self, cx: &App) -> Option<Rc<dyn PlatformDisplay>> {
        cx.platform
            .displays()
            .into_iter()
            .find(|display| Some(display.id()) == self.display_id)
    }

    /// Show the platform character palette.
    pub fn show_character_palette(&self) {
        self.platform_window.show_character_palette();
    }

    /// Whether the platform can present a native (OS-drawn) context menu for this
    /// window. Currently macOS only; callers should fall back to a GPUI-drawn menu
    /// when this returns `false`.
    pub fn can_show_native_context_menu(&self) -> bool {
        self.platform_window.can_show_native_context_menu()
    }

    /// Presents a native (OS-drawn) context menu at `position`, in window content
    /// coordinates. Entry handlers run inside this window's update context. On
    /// platforms without native context menus nothing is shown; check
    /// [`Self::can_show_native_context_menu`] first.
    pub fn show_native_context_menu(
        &self,
        mut menu: Vec<NativeMenuItem>,
        position: Point<Pixels>,
        cx: &mut App,
    ) {
        fn take_handlers(
            items: &mut [NativeMenuItem],
            handlers: &mut Vec<Option<Box<dyn FnOnce(&mut Window, &mut App)>>>,
        ) {
            for item in items {
                match item {
                    NativeMenuItem::Entry(entry) => handlers.push(entry.handler.take()),
                    NativeMenuItem::Submenu { items, .. } => take_handlers(items, handlers),
                    NativeMenuItem::Separator => {}
                }
            }
        }

        let mut handlers = Vec::new();
        take_handlers(&mut menu, &mut handlers);
        let handle = self.handle;
        let mut async_cx = cx.to_async();
        let keymap = cx.keymap.clone();
        self.platform_window.show_native_context_menu(
            menu,
            position,
            &keymap.borrow(),
            Box::new(move |selected| {
                let Some(handler) = selected
                    .and_then(|index| handlers.get_mut(index))
                    .and_then(|handler| handler.take())
                else {
                    return;
                };
                handle
                    .update(&mut async_cx, |_, window, cx| handler(window, cx))
                    .log_err();
            }),
        );
    }

    /// The scale factor of the display associated with the window. For example, it could
    /// return 2.0 for a "retina" display, indicating that each logical pixel should actually
    /// be rendered as two pixels on screen.
    pub fn scale_factor(&self) -> f32 {
        self.scale_factor
    }

    /// Overrides the display scale factor for tests.
    #[cfg(any(test, feature = "test-support"))]
    pub fn set_scale_factor(&mut self, scale_factor: f32) {
        self.scale_factor = scale_factor;
        self.refresh();
    }

    /// The size of an em for the base font of the application. Adjusting this value allows the
    /// UI to scale, just like zooming a web page.
    pub fn rem_size(&self) -> Pixels {
        self.rem_size_override_stack
            .last()
            .copied()
            .unwrap_or(self.rem_size)
    }

    /// Sets the size of an em for the base font of the application. Adjusting this value allows the
    /// UI to scale, just like zooming a web page.
    pub fn set_rem_size(&mut self, rem_size: impl Into<Pixels>) {
        self.rem_size = rem_size.into();
    }

    /// Acquire a globally unique identifier for the given ElementId.
    /// Only valid for the duration of the provided closure.
    pub fn with_global_id<R>(
        &mut self,
        element_id: ElementId,
        f: impl FnOnce(&GlobalElementId, &mut Self) -> R,
    ) -> R {
        self.with_id(element_id, |this| {
            let global_id = this.global_element_ids.get(&this.element_id_stack);

            f(&global_id, this)
        })
    }

    /// Calls the provided closure with the element ID pushed on the stack.
    #[inline]
    pub fn with_id<R>(
        &mut self,
        element_id: impl Into<ElementId>,
        f: impl FnOnce(&mut Self) -> R,
    ) -> R {
        self.element_id_stack.push(element_id.into());
        let result = f(self);
        self.element_id_stack.pop();
        result
    }

    /// Executes the provided function with the specified rem size.
    ///
    /// This method must only be called as part of element drawing.
    // This function is called in a highly recursive manner in editor
    // prepainting, make sure its inlined to reduce the stack burden
    #[inline]
    pub fn with_rem_size<F, R>(&mut self, rem_size: Option<impl Into<Pixels>>, f: F) -> R
    where
        F: FnOnce(&mut Self) -> R,
    {
        self.invalidator.debug_assert_paint_or_prepaint();

        if let Some(rem_size) = rem_size {
            self.rem_size_override_stack.push(rem_size.into());
            let result = f(self);
            self.rem_size_override_stack.pop();
            result
        } else {
            f(self)
        }
    }

    /// The line height associated with the current text style.
    pub fn line_height(&self) -> Pixels {
        self.text_style().line_height_in_pixels(self.rem_size())
    }

    /// Rounds a logical value to the nearest device pixel.
    #[inline]
    pub fn pixel_snap(&self, value: Pixels) -> Pixels {
        px(round_to_device_pixel(value.0, self.scale_factor()) / self.scale_factor())
    }

    /// f64 variant of [`Self::pixel_snap`].
    #[inline]
    pub fn pixel_snap_f64(&self, value: f64) -> f64 {
        let scale_factor = f64::from(self.scale_factor());
        round_half_toward_zero_f64(value * scale_factor) / scale_factor
    }

    /// Snaps a bounds' origin and size to the nearest device pixel.
    #[inline]
    pub fn pixel_snap_bounds(&self, bounds: Bounds<Pixels>) -> Bounds<Pixels> {
        bounds.map(|c| self.pixel_snap(c))
    }

    /// Snaps a point's coordinates to the nearest device pixel.
    #[inline]
    pub fn pixel_snap_point(&self, position: Point<Pixels>) -> Point<Pixels> {
        position.map(|c| self.pixel_snap(c))
    }

    /// Returns the snapped device-space bounds used to paint an underline.
    pub fn underline_bounds(
        &self,
        origin: Point<Pixels>,
        width: Pixels,
        style: &UnderlineStyle,
    ) -> Bounds<ScaledPixels> {
        let scale_factor = self.scale_factor();
        let thickness = self.snap_stroke(style.thickness);
        let height = if style.wavy {
            ScaledPixels(thickness.0 * 3.)
        } else {
            thickness
        };
        Bounds {
            origin: origin.map(|c| ScaledPixels(round_to_device_pixel(c.0, scale_factor))),
            size: size(self.snap_stroke(width), height),
        }
    }

    /// Paints an underline excluding absolute device-space horizontal spans.
    pub fn paint_underline_with_exclusions(
        &mut self,
        origin: Point<Pixels>,
        width: Pixels,
        style: &UnderlineStyle,
        exclusions: &[Range<ScaledPixels>],
    ) {
        self.invalidator.debug_assert_paint();
        let underline = self.underline(origin, width, style);
        if exclusions.is_empty() {
            self.next_frame.scene.insert_primitive(underline);
            return;
        }

        let bounds = underline.bounds.intersect(&underline.content_mask.bounds);
        if bounds.is_empty() {
            return;
        }

        let mut exclusions = exclusions
            .iter()
            .filter_map(|span| {
                let start = span.start.max(bounds.left());
                let end = span.end.min(bounds.right());
                (start < end).then_some(start..end)
            })
            .collect::<SmallVec<[_; 4]>>();
        if exclusions.is_empty() {
            self.next_frame.scene.insert_primitive(underline);
            return;
        }
        exclusions.sort_unstable_by_key(|span| span.start);

        let mut paint_span = |start, end| {
            self.next_frame.scene.insert_primitive(Underline {
                content_mask: ContentMask {
                    bounds: Bounds::from_corners(
                        point(start, bounds.top()),
                        point(end, bounds.bottom()),
                    ),
                },
                ..underline
            });
        };
        let mut start = bounds.left();
        for exclusion in exclusions {
            if start < exclusion.start {
                paint_span(start, exclusion.start);
            }
            start = start.max(exclusion.end);
        }
        if start < bounds.right() {
            paint_span(start, bounds.right());
        }
    }

    fn underline(&self, origin: Point<Pixels>, width: Pixels, style: &UnderlineStyle) -> Underline {
        Underline {
            order: 0,
            pad: 0,
            bounds: self.underline_bounds(origin, width, style),
            content_mask: self.snapped_content_mask(),
            color: style
                .color
                .unwrap_or_default()
                .opacity(self.element_opacity()),
            thickness: self.snap_stroke(style.thickness),
            wavy: style.wavy.into(),
        }
    }

    #[inline]
    fn snap_bounds(&self, bounds: Bounds<Pixels>) -> Bounds<ScaledPixels> {
        let scale_factor = self.scale_factor();
        let left = round_to_device_pixel(bounds.left().0, scale_factor);
        let top = round_to_device_pixel(bounds.top().0, scale_factor);
        let right = round_to_device_pixel(bounds.right().0, scale_factor).max(left);
        let bottom = round_to_device_pixel(bounds.bottom().0, scale_factor).max(top);
        Bounds::from_corners(
            point(ScaledPixels(left), ScaledPixels(top)),
            point(ScaledPixels(right), ScaledPixels(bottom)),
        )
    }

    /// Rounds half-to-zero but clamps any non-zero input up to 1 dp so thin strokes do not disappear.
    #[inline]
    fn snap_stroke(&self, value: Pixels) -> ScaledPixels {
        ScaledPixels(round_stroke_to_device_pixel(value.0, self.scale_factor()))
    }

    #[inline]
    fn snap_border_widths(&self, edges: Edges<Pixels>) -> Edges<ScaledPixels> {
        edges.map(|e| self.snap_stroke(*e))
    }

    /// Floors the near edge and ceils the far edge, producing a strict superset of the raw region.
    #[inline]
    fn cover_bounds(&self, bounds: Bounds<Pixels>) -> Bounds<ScaledPixels> {
        let scale_factor = self.scale_factor();
        let left = floor_to_device_pixel(bounds.left().0, scale_factor);
        let top = floor_to_device_pixel(bounds.top().0, scale_factor);
        let right = ceil_to_device_pixel(bounds.right().0, scale_factor).max(left);
        let bottom = ceil_to_device_pixel(bounds.bottom().0, scale_factor).max(top);
        Bounds::from_corners(
            point(ScaledPixels(left), ScaledPixels(top)),
            point(ScaledPixels(right), ScaledPixels(bottom)),
        )
    }

    #[inline]
    fn snapped_content_mask(&self) -> ContentMask<ScaledPixels> {
        ContentMask {
            bounds: self.cover_bounds(self.content_mask().bounds),
        }
    }

    /// Call to prevent the default action of an event. Currently only used to prevent
    /// parent elements from becoming focused on mouse down.
    pub fn prevent_default(&mut self) {
        self.default_prevented = true;
    }

    /// Obtain whether default has been prevented for the event currently being dispatched.
    pub fn default_prevented(&self) -> bool {
        self.default_prevented
    }

    fn note_actions_read(&self) {
        self.view_retention
            .ambient_reads
            .note::<view_retention::dependencies::ambient::Actions>();
    }

    /// Determine whether the given action is available along the dispatch path to the currently focused element.
    pub fn is_action_available(&self, action: &dyn Action, cx: &App) -> bool {
        self.note_actions_read();
        let node_id =
            self.focus_node_id_in_rendered_frame(self.focused(cx).map(|handle| handle.id));
        self.rendered_frame
            .dispatch_tree
            .is_action_available(action, node_id)
    }

    /// Determine whether the given action is available along the dispatch path to the given focus_handle.
    pub fn is_action_available_in(&self, action: &dyn Action, focus_handle: &FocusHandle) -> bool {
        self.note_actions_read();
        let node_id = self.focus_node_id_in_rendered_frame(Some(focus_handle.id));
        self.rendered_frame
            .dispatch_tree
            .is_action_available(action, node_id)
    }

    /// The position of the mouse relative to the window.
    pub fn mouse_position(&self) -> Point<Pixels> {
        self.view_retention
            .ambient_reads
            .note::<view_retention::dependencies::ambient::Pointer>();
        self.mouse_position
    }

    /// Captures the pointer for the given hitbox. While captured, all mouse move and mouse up
    /// events will be routed to listeners that check this hitbox's `is_hovered` status,
    /// regardless of actual hit testing. This enables drag operations that continue
    /// even when the pointer moves outside the element's bounds.
    ///
    /// The capture is automatically released on mouse up.
    pub fn capture_pointer(&mut self, hitbox_id: HitboxId) {
        self.captured_hitbox = Some(hitbox_id);
    }

    /// Releases any active pointer capture.
    pub fn release_pointer(&mut self) {
        self.captured_hitbox = None;
    }

    /// Returns the hitbox that has captured the pointer, if any.
    pub fn captured_hitbox(&self) -> Option<HitboxId> {
        self.captured_hitbox
    }

    /// Captures the current long press for the given entity.
    ///
    /// The capture is released when the gesture ends or is cancelled, or when
    /// a replacement touch begins. A listener must also call
    /// [`Self::prevent_default`] on the started event to claim the gesture.
    pub fn capture_long_press<T: 'static>(&mut self, entity: &Entity<T>) {
        self.long_press_capture = Some(entity.entity_id());
    }

    /// Returns whether the given entity has captured the current long press.
    pub fn has_long_press_capture<T: 'static>(&self, entity: &Entity<T>) -> bool {
        self.long_press_capture == Some(entity.entity_id())
    }

    /// The current state of the keyboard's modifiers
    pub fn modifiers(&self) -> Modifiers {
        self.view_retention
            .ambient_reads
            .note::<view_retention::dependencies::ambient::Keys>();
        self.modifiers
    }

    /// Returns true if the last input event was keyboard-based (key press, tab navigation, etc.)
    /// This is used for focus-visible styling to show focus indicators only for keyboard navigation.
    pub fn last_input_was_keyboard(&self) -> bool {
        self.last_input_modality == InputModality::Keyboard
    }

    pub(crate) fn last_input_was_touch(&self) -> bool {
        self.last_input_modality == InputModality::Touch
    }

    /// The current state of the keyboard's capslock
    pub fn capslock(&self) -> Capslock {
        self.view_retention
            .ambient_reads
            .note::<view_retention::dependencies::ambient::Keys>();
        self.capslock
    }

    /// Produces a new frame and assigns it to `rendered_frame`. To actually show
    /// the contents of the new [`Scene`], use [`Self::present`].
    pub fn draw(&mut self, cx: &mut App) -> ArenaClearNeeded {
        let arena_clear_needed = self.draw_frame(cx);
        if cx.view_retention() {
            return self.verify_retained_frame(arena_clear_needed, cx);
        }
        arena_clear_needed
    }

    #[profiling::function]
    fn draw_frame(&mut self, cx: &mut App) -> ArenaClearNeeded {
        // Drain every draw in profiler builds so a previous frame's
        // first-invalidation timestamp can't be attributed to this one.
        #[cfg(feature = "profiler")]
        let frame_dirty = self.invalidator.take_frame_dirty();
        #[cfg(feature = "profiler")]
        self.begin_draw_profile(cx);

        // Set up the per-App arena for element allocation during this draw.
        // This ensures that multiple test Apps have isolated arenas.
        let arena_scope = ElementArenaScope::enter(&cx.element_arena);

        if self.platform_window.prepare_frame() {
            self.refresh();
        }
        self.invalidate_entities(cx);
        cx.entities.clear_accessed();
        debug_assert!(self.rendered_entity_stack.is_empty());
        if self.rendered_scene_may_reference_retired_tiles() {
            // Cached views replay last frame's primitives, tiles included, without
            // going back to the atlas. If that frame is older than the atlas's idle
            // window those tiles may be gone, so bypass reuse for this draw.
            self.refresh();
            self.line_glyph_cache.forget_previous();
        }
        self.line_glyph_cache.start_draw(self.sprite_atlas.generation());
        self.invalidator.set_dirty(false);
        self.requested_autoscroll = None;

        // Restore the previously-used input handler.
        // Place it back into a None slot (left by a previous .take()) so that
        // cached paint_range indices in reuse_paint find the handler at the
        // expected position.
        if let Some(input_handler) = self.platform_window.take_input_handler() {
            if let Some(slot) = self
                .rendered_frame
                .input_handlers
                .iter_mut()
                .rev()
                .find(|h| h.is_none())
            {
                *slot = Some(input_handler);
            } else {
                self.rendered_frame.input_handlers.push(Some(input_handler));
            }
        }
        if !cx.mode.skip_drawing() {
            self.frame_work.stats.frames += 1;
            self.draw_roots(cx);
            #[cfg(feature = "profiler")]
            {
                let viewport_size = self.viewport_size;
                let scale_factor = self.scale_factor();
                self.debug_frame_overlay.paint(
                    &mut self.next_frame.scene,
                    viewport_size,
                    scale_factor,
                );
            }
        }
        // Drawing marks this at the end of paint already; a draw that skips
        // drawing has only its finish left.
        #[cfg(feature = "profiler")]
        self.mark_draw_phase(draw_profile::DrawClockPhase::Finish);
        self.dirty_views.clear();
        self.next_frame.window_active = self.active.get();

        // Register requested input handler with the platform window.
        // Use .take() instead of .pop() to preserve Vec length, so that cached
        // paint_range indices remain valid for reuse_paint on the next frame.
        // Search backwards to find the last Some entry, since reuse_paint may
        // have copied None slots from the previous frame. (Fixes #50456)
        let focused_text_input_active = if let Some(mut input_handler) = self
            .next_frame
            .input_handlers
            .iter_mut()
            .rev()
            .find_map(|h| h.take())
        {
            let accepts_text_input = input_handler.accepts_text_input(self, cx);
            self.platform_window.set_input_handler(input_handler);
            accepts_text_input
        } else {
            false
        };
        self.apply_text_input_configuration(cx);
        if focused_text_input_active != self.focused_text_input_active {
            self.focused_text_input_active = focused_text_input_active;
            self.platform_window
                .text_input_state_changed(if focused_text_input_active {
                    TextInputStateChange::FocusGained
                } else {
                    TextInputStateChange::FocusLost
                });
        }

        self.finish_retained_views_frame(cx);
        self.layout_engine.as_mut().unwrap().clear();
        self.layout_keys.end_frame();
        self.text_system().finish_frame();
        self.glyph_raster_cache.finish_draw();
        self.line_glyph_cache.finish_draw();
        self.global_element_ids.finish_frame();
        self.next_frame.finish(&mut self.rendered_frame);

        self.invalidator.set_phase(DrawPhase::Focus);
        let previous_focus_path = self.rendered_frame.focus_path();
        let previous_window_active = self.rendered_frame.window_active;
        mem::swap(&mut self.rendered_frame, &mut self.next_frame);
        self.next_frame.clear();
        self.scene_animates
            .set(self.rendered_frame.scene.has_time_animations());
        self.scene_transitioning
            .set(self.rendered_frame.scene.transitions_in_flight());
        #[cfg(feature = "profiler")]
        self.mark_draw_phase(draw_profile::DrawClockPhase::Focus);
        let current_focus_path = self.rendered_frame.focus_path();
        let current_window_active = self.rendered_frame.window_active;
        let mut focus_before_listeners = self.focus;

        if previous_focus_path != current_focus_path
            || previous_window_active != current_window_active
        {
            if !previous_focus_path.is_empty() && current_focus_path.is_empty() {
                self.focus_lost_path = previous_focus_path.clone();
                self.focus_lost_listeners
                    .clone()
                    .retain(&(), |listener| listener(self, cx));
                self.focus_lost_path = SmallVec::new();
                // The focus-lost fallback (e.g. a workspace refocusing itself) may target
                // an element that isn't part of the element tree, in which case scheduling
                // a redraw below would dispatch focus-lost again, looping forever. Only
                // track focus movement caused by the focus listeners.
                focus_before_listeners = self.focus;
            }

            let event = WindowFocusEvent {
                previous_focus_path: if previous_window_active {
                    previous_focus_path
                } else {
                    Default::default()
                },
                current_focus_path: if current_window_active {
                    current_focus_path
                } else {
                    Default::default()
                },
            };
            self.focus_listeners
                .clone()
                .retain(&(), |listener| listener(&event, self, cx));
        }
        #[cfg(feature = "profiler")]
        self.mark_draw_phase(draw_profile::DrawClockPhase::Other);

        debug_assert!(self.rendered_entity_stack.is_empty());
        self.record_entities_accessed(cx);
        self.reset_cursor_style(cx);
        self.refreshing = false;
        self.invalidator.set_phase(DrawPhase::None);
        // Focus listeners may move focus (e.g. a dock forwarding focus to its active
        // panel). `Window::focus` suppresses `refresh` while a draw is in progress, so
        // schedule another frame here to render the new focus state and dispatch the
        // resulting focus events.
        if self.focus != focus_before_listeners {
            self.refresh();
        }
        self.needs_present.set(true);

        self.last_draw_at = cx.background_executor().now();
        if self.idle_capacity_reclaim.is_none() {
            self.schedule_idle_capacity_reclaim(SHRINK_AFTER_DURATION, cx);
        }

        #[cfg(feature = "profiler")]
        {
            let draw_duration =
                self.end_draw_profile(frame_dirty.dirty_at, frame_dirty.invalidations, cx);
            self.debug_frame_overlay.record_frame(draw_duration);
        }

        // Exit the scope to obtain the arena-clear token this draw owes; the
        // scope's teardown itself happens in `ElementArenaScope::drop`.
        arena_scope.exit(&cx.element_arena)
    }

    fn schedule_idle_capacity_reclaim(&mut self, delay: Duration, cx: &mut App) {
        self.idle_capacity_reclaim = Some(self.spawn(cx, async move |cx| {
            cx.background_executor.timer(delay).await;
            cx.update(|window, cx| window.reclaim_idle_capacity(cx))
                .log_err();
        }));
    }

    /// Frees the per-frame capacity a window that has stopped drawing no
    /// longer uses.
    ///
    /// The shrink policies behind [`CapacityShrink`], the element arena and
    /// [`TaffyLayoutEngine`] all advance on draws, so a heavy scene followed
    /// by a quiet or hidden window — a long transcript whose panels were then
    /// hidden, a window moved behind another — kept the capacity of the
    /// largest frame it ever drew for as long as it stayed quiet:
    /// `SHRINK_AFTER_FRAMES` frames is not two seconds idle. This runs the
    /// same shrink from a timer once no draw has finished for
    /// `SHRINK_AFTER_DURATION`, keeping twice the on-screen frame's use so the
    /// next draw of that scene does not regrow everything.
    ///
    /// It runs as a foreground task, so no draw is in flight, and it touches
    /// only the retired frame's storage, the cleared layout tree and arena
    /// chunks nothing points into; the rendered frame that dispatch and
    /// presentation still read is left alone. Rather than re-arming on every
    /// draw, the timer checks how long ago the last draw finished and, if a
    /// draw landed since it was armed, waits out the remainder; an animating
    /// window costs one timer per quiet period instead of one per frame. It
    /// never draws: reclaiming is not a reason to redraw.
    fn reclaim_idle_capacity(&mut self, cx: &mut App) {
        self.idle_capacity_reclaim = None;
        let now = cx.background_executor().now();
        let quiet_for = now.saturating_duration_since(self.last_draw_at);
        if quiet_for < SHRINK_AFTER_DURATION {
            self.schedule_idle_capacity_reclaim(SHRINK_AFTER_DURATION - quiet_for, cx);
            return;
        }
        self.next_frame.shrink_idle(&self.rendered_frame);
        if let Some(layout_engine) = self.layout_engine.as_mut()
            && layout_engine.reclaim_idle_capacity()
        {
            // The retained views' records name nodes of the tree just
            // replaced; drawn again from them, a view would hand its parent
            // a node that is gone.
            self.rendered_frame.retained_views.forget_layouts();
        }
        cx.element_arena.borrow_mut().release_idle_chunks(now);
    }

    fn record_entities_accessed(&mut self, cx: &mut App) {
        let mut entities_ref = cx.entities.accessed_entities.get_mut();
        let mut entities = mem::take(entities_ref.deref_mut());
        let handle = self.handle;
        cx.record_entities_accessed(
            handle,
            // Try moving window invalidator into the Window
            self.invalidator.clone(),
            &entities,
        );
        let mut entities_ref = cx.entities.accessed_entities.get_mut();
        mem::swap(&mut entities, entities_ref.deref_mut());
    }

    fn invalidate_entities(&mut self, cx: &App) {
        let mut views = self.invalidator.take_views();
        if cx.view_retention() {
            self.begin_retained_views_frame(&views);
        }
        for entity in views.drain() {
            self.mark_view_dirty(entity);
        }
        self.invalidator.replace_views(views);
    }

    #[profiling::function]
    fn present(&mut self) {
        #[cfg(feature = "profiler")]
        let _foreground_turn = profiler::journal::foreground_turn();
        #[cfg(feature = "profiler")]
        let present_start = Instant::now();
        let atlas_frame_before_draw = self.sprite_atlas.frame_index();
        self.rendered_frame.scene.advance_time_animations();
        // A transition that has landed stops asking for frames here, since
        // nothing draws the scene again to say so.
        self.scene_transitioning
            .set(self.rendered_frame.scene.transitions_in_flight());
        self.scene_animates
            .set(self.rendered_frame.scene.has_time_animations());
        let previous_present_at = self.last_present_at.replace(Some(Instant::now()));
        let report = self.platform_window.draw_layered(
            &self.rendered_frame.scene,
            self.rendered_frame.overlay_scene_start,
        );
        // A draw that bailed before rendering (no drawable, a render error)
        // marked nothing, so the scene's tiles are no newer than they were.
        // The atlas frame decides this rather than the outcome: a present
        // that rendered part of the scene before reporting a failure still
        // marked those tiles in use.
        let atlas_frame_after_draw = self.sprite_atlas.frame_index();
        if atlas_frame_after_draw > atlas_frame_before_draw {
            self.atlas_frame_at_last_present = atlas_frame_after_draw;
        }
        if report.outcome == PresentOutcome::Deferred {
            // Nothing reached the screen, so the frame stays owed, even when
            // this present was asked for without a new draw (a required
            // presentation, a time animation's tick): `needs_present` makes
            // the frame loop re-arm and the next request present again
            // (without drawing, unless the window was invalidated meanwhile),
            // and the time-animation cadence still measures from the last
            // present that landed.
            self.needs_present.set(true);
            self.last_present_at.set(previous_present_at);
            #[cfg(feature = "profiler")]
            self.window_profiler
                .record_deferred_present(present_start, Instant::now(), report);
            return;
        }
        self.retired_tile_redraw_deferred = false;
        #[cfg(feature = "profiler")]
        self.window_profiler.record_present(
            present_start,
            Instant::now(),
            self.active.get(),
            !self.next_frame_callbacks.borrow().is_empty(),
            report,
        );
        self.needs_present.set(false);
        profiling::finish_frame!();
    }

    /// Has the window draw with `atlas` from now on, as if it last presented
    /// at the atlas's current frame.
    #[cfg(test)]
    pub(crate) fn replace_sprite_atlas(&mut self, atlas: Arc<dyn PlatformAtlas>) {
        self.atlas_frame_at_last_present = atlas.frame_index();
        self.sprite_atlas = atlas;
    }

    /// What [`Self::present`] records once the platform has drawn the
    /// rendered scene, marking its tiles in the atlas.
    #[cfg(test)]
    pub(crate) fn note_rendered_scene_presented(&mut self) {
        self.atlas_frame_at_last_present = self.sprite_atlas.frame_index();
    }

    /// Whether the retained scene was last presented so long ago, in sprite-atlas
    /// frames, that glyph or SVG tiles it references may since have been retired
    /// by [`PlatformAtlas::retire_unused`]. The atlas can be shared by several
    /// windows, so another window's frames age this one's scene too.
    fn rendered_scene_may_reference_retired_tiles(&self) -> bool {
        self.sprite_atlas
            .frame_index()
            .saturating_sub(self.atlas_frame_at_last_present)
            >= crate::ATLAS_TILE_MAX_IDLE_FRAMES
    }

    /// Presents the most recently drawn frame if it hasn't been presented yet.
    ///
    /// Benchmarks built on `TestAppContext` drive drawing synchronously rather
    /// than through a platform frame-request loop, so they call this after
    /// each measured update to submit the frame like production presentation
    /// would.
    #[cfg(any(feature = "bench-support", all(test, feature = "profiler")))]
    pub fn present_if_needed(&mut self) {
        if self.needs_present.get() {
            self.present();
        }
    }

    /// Returns a snapshot of the current input-latency histograms.
    #[cfg(feature = "profiler")]
    pub fn input_latency_snapshot(&self) -> profiler::InputLatencySnapshot {
        self.window_profiler.input_latency_snapshot()
    }

    /// Returns a snapshot of the current frame-duration histograms.
    #[cfg(feature = "profiler")]
    pub fn frame_duration_snapshot(&self) -> profiler::FrameDurationSnapshot {
        self.window_profiler.frame_duration_snapshot()
    }

    /// Returns the current mode of the debug frame overlay.
    #[cfg(feature = "profiler")]
    pub fn debug_frame_overlay_mode(&self) -> DebugFrameOverlayMode {
        self.debug_frame_overlay.mode()
    }

    /// Sets the mode of the debug frame overlay and schedules a redraw.
    #[cfg(feature = "profiler")]
    pub fn set_debug_frame_overlay_mode(&mut self, mode: DebugFrameOverlayMode) {
        self.debug_frame_overlay.set_mode(mode);
        self.refresh();
    }

    /// Advances the debug frame overlay through its hidden, frame-time-only,
    /// and detailed modes.
    #[cfg(feature = "profiler")]
    pub fn cycle_debug_frame_overlay_mode(&mut self) {
        self.set_debug_frame_overlay_mode(self.debug_frame_overlay.mode().next());
    }

    /// Clears the debug frame overlay's frame-time statistics, except for the
    /// total frame count, and schedules a redraw.
    #[cfg(feature = "profiler")]
    pub fn reset_debug_frame_overlay_stats(&mut self) {
        self.debug_frame_overlay.reset_stats();
        self.refresh();
    }

    fn draw_roots(&mut self, cx: &mut App) {
        self.invalidator.set_phase(DrawPhase::Prepaint);
        self.tooltip_bounds.take();

        self.a11y.sync_active_flag();
        if self.a11y.is_active() {
            self.a11y.begin_frame();
        }

        let _inspector_width: Pixels = rems(30.0).to_pixels(self.rem_size());
        let root_size = {
            #[cfg(any(feature = "inspector", debug_assertions))]
            {
                if self.inspector.is_some() {
                    let mut size = self.viewport_size;
                    size.width = (size.width - _inspector_width).max(px(0.0));
                    size
                } else {
                    self.viewport_size
                }
            }
            #[cfg(not(any(feature = "inspector", debug_assertions)))]
            {
                self.viewport_size
            }
        };

        // Layout all root elements. Like the root element on the web, which
        // stretches to fill the viewport unless explicitly sized, window roots
        // fill the window when their size is `auto`.
        let scale_factor = self.scale_factor();
        let build_started_at = self.frame_work.clock();
        let mut root_element = self.root.as_ref().unwrap().clone().into_any_element();
        #[cfg(feature = "profiler")]
        self.mark_draw_phase(draw_profile::DrawClockPhase::RequestLayout);
        let root_layout_id = root_element.request_layout(self, cx);
        #[cfg(feature = "profiler")]
        self.mark_draw_phase(draw_profile::DrawClockPhase::Prepaint);
        frame_work::add_elapsed(&mut self.frame_work.stats.build_time, build_started_at);
        let prepaint_started_at = self.frame_work.clock();
        self.layout_engine
            .as_mut()
            .unwrap()
            .stretch_auto_size_to_fill(root_layout_id, root_size, scale_factor);
        root_element.prepaint_as_root(Point::default(), root_size.into(), self, cx);

        #[cfg(any(feature = "inspector", debug_assertions))]
        let inspector_element = self.prepaint_inspector(_inspector_width, cx);

        self.prepaint_deferred_draws(cx);

        let mut prompt_element = None;
        let mut active_drag_element = None;
        let mut tooltip_element = None;
        if let Some(prompt) = self.prompt.take() {
            let mut element = prompt.view.any_view().into_any_element();
            let prompt_layout_id = element.request_layout(self, cx);
            self.layout_engine
                .as_mut()
                .unwrap()
                .stretch_auto_size_to_fill(prompt_layout_id, root_size, scale_factor);
            element.prepaint_as_root(Point::default(), root_size.into(), self, cx);
            prompt_element = Some(element);
            self.prompt = Some(prompt);
        } else if let Some(active_drag) = cx.active_drag.take() {
            let mut element = active_drag.view.clone().into_any_element();
            let offset = self.mouse_position() - active_drag.cursor_offset;
            element.prepaint_as_root(offset, AvailableSpace::min_size(), self, cx);
            active_drag_element = Some(element);
            cx.active_drag = Some(active_drag);
        } else {
            tooltip_element = self.prepaint_tooltip(cx);
        }

        self.mouse_hit_test = self.next_frame.hit_test(self.mouse_position);
        frame_work::add_elapsed(&mut self.frame_work.stats.prepaint_time, prepaint_started_at);

        // Now actually paint the elements.
        #[cfg(feature = "profiler")]
        self.mark_draw_phase(draw_profile::DrawClockPhase::Paint);
        let paint_started_at = self.frame_work.clock();
        self.invalidator.set_phase(DrawPhase::Paint);
        root_element.paint(self, cx);

        #[cfg(any(feature = "inspector", debug_assertions))]
        self.paint_inspector(inspector_element, cx);

        // Records `overlay_scene_start`: native surfaces are composited after
        // the root scene and the deferred draws that stay beneath them, and
        // before every other deferred draw and window-level overlay. Platform
        // backends with layered scene support use this boundary to render the
        // remainder on a transparent surface above native children such as
        // WebViews.
        self.paint_deferred_draws(cx);

        if let Some(mut prompt_element) = prompt_element {
            prompt_element.paint(self, cx);
        } else if let Some(mut drag_element) = active_drag_element {
            drag_element.paint(self, cx);
        } else if let Some(mut tooltip_element) = tooltip_element {
            tooltip_element.paint(self, cx);
        }

        #[cfg(any(feature = "inspector", debug_assertions))]
        self.paint_inspector_hitbox(cx);
        frame_work::add_elapsed(&mut self.frame_work.stats.paint_time, paint_started_at);

        #[cfg(feature = "profiler")]
        self.mark_draw_phase(draw_profile::DrawClockPhase::Finish);

        // a11y may have been activated/deactivated halfway through the frame
        let a11y_active_start_of_frame = self.a11y.is_active();
        self.a11y.sync_active_flag();
        let a11y_active_end_of_frame = self.a11y.is_active();

        let should_send_a11y_update = a11y_active_start_of_frame && a11y_active_end_of_frame;

        if a11y_active_start_of_frame {
            // Harvest frame metadata for the debug dump while the live window
            // and frame are still in scope.
            let frame_info = crate::window::a11y::debug::FrameDebugInfo {
                viewport_size: self.viewport_size,
                scale_factor: self.scale_factor,
                tab_stop_count: self.next_frame.tab_stops.tab_stop_count(),
            };
            // clear the builder state regardless
            let tree_update = self.a11y.end_frame(frame_info);

            if should_send_a11y_update {
                log::debug!(
                    "Sending a11y tree update: {} nodes",
                    tree_update.nodes.len()
                );
                self.platform_window.a11y_tree_update(tree_update);
            }
        }
    }

    fn prepaint_tooltip(&mut self, cx: &mut App) -> Option<AnyElement> {
        // Use indexing instead of iteration to avoid borrowing self for the duration of the loop.
        for tooltip_request_index in (0..self.next_frame.tooltip_requests.len()).rev() {
            let Some(Some(tooltip_request)) = self
                .next_frame
                .tooltip_requests
                .get(tooltip_request_index)
                .cloned()
            else {
                log::error!("Unexpectedly absent TooltipRequest");
                continue;
            };
            let mut element = tooltip_request.tooltip.view.clone().into_any_element();
            let mouse_position = tooltip_request.tooltip.mouse_position;
            let tooltip_size = element.layout_as_root(AvailableSpace::min_size(), self, cx);

            let mut tooltip_bounds =
                Bounds::new(mouse_position + point(px(1.), px(1.)), tooltip_size);
            let window_bounds = Bounds {
                origin: Point::default(),
                size: self.viewport_size(),
            };

            if tooltip_bounds.right() > window_bounds.right() {
                let new_x = mouse_position.x - tooltip_bounds.size.width - px(1.);
                if new_x >= Pixels::ZERO {
                    tooltip_bounds.origin.x = new_x;
                } else {
                    tooltip_bounds.origin.x = cmp::max(
                        Pixels::ZERO,
                        tooltip_bounds.origin.x - tooltip_bounds.right() - window_bounds.right(),
                    );
                }
            }

            if tooltip_bounds.bottom() > window_bounds.bottom() {
                let new_y = mouse_position.y - tooltip_bounds.size.height - px(1.);
                if new_y >= Pixels::ZERO {
                    tooltip_bounds.origin.y = new_y;
                } else {
                    tooltip_bounds.origin.y = cmp::max(
                        Pixels::ZERO,
                        tooltip_bounds.origin.y - tooltip_bounds.bottom() - window_bounds.bottom(),
                    );
                }
            }

            // It's possible for an element to have an active tooltip while not being painted (e.g.
            // via the `visible_on_hover` method). Since mouse listeners are not active in this
            // case, instead update the tooltip's visibility here.
            let is_visible =
                (tooltip_request.tooltip.check_visible_and_update)(tooltip_bounds, self, cx);
            if !is_visible {
                continue;
            }

            self.with_absolute_element_offset(tooltip_bounds.origin, |window| {
                element.prepaint(window, cx)
            });

            self.tooltip_bounds = Some(TooltipBounds {
                id: tooltip_request.id,
                bounds: tooltip_bounds,
            });
            return Some(element);
        }
        None
    }

    fn prepaint_deferred_draws(&mut self, cx: &mut App) {
        assert_eq!(self.element_id_stack.len(), 0);

        // Process deferred draws in multiple rounds to support nesting.
        // Each round processes all current deferred draws, which may push new ones.
        //
        // The draws are processed in place rather than being moved out of
        // `next_frame.deferred_draws`: `prepaint_index` snapshots that vector's
        // length, so any prepaint range recorded during a round (view caches,
        // nested deferred draws) must index the same vector `reuse_prepaint`
        // slices on the next frame. Moving the draws out and re-appending them
        // shifts the indices of nested draws, causing reused subtrees to graft
        // the wrong deferred draws and panic in the dispatch tree.
        let mut round_start = 0;
        let mut depth = 0;
        loop {
            let round_end = self.next_frame.deferred_draws.len();
            if round_start == round_end {
                break;
            }
            // Limit maximum nesting depth to prevent infinite loops.
            assert!(depth < 10, "Exceeded maximum (10) deferred depth");
            depth += 1;

            // Sort this round the way `paint_deferred_draws` will paint, so
            // hitboxes are registered in draw order.
            let mut traversal_order = (round_start..round_end).collect::<SmallVec<[usize; 8]>>();
            traversal_order.sort_by_key(|ix| {
                let deferred_draw = &self.next_frame.deferred_draws[*ix];
                (!deferred_draw.beneath_native_surfaces, deferred_draw.priority)
            });

            for deferred_draw_ix in traversal_order {
                let (
                    element,
                    parent_node,
                    current_view,
                    rem_size,
                    absolute_offset,
                    prepaint_range,
                    beneath_native_surfaces,
                    enclosing_views,
                ) = {
                    let deferred_draw = &mut self.next_frame.deferred_draws[deferred_draw_ix];
                    self.element_id_stack
                        .clone_from(&deferred_draw.element_id_stack);
                    self.text_style_stack
                        .clone_from(&deferred_draw.text_style_stack);
                    (
                        deferred_draw.element.take(),
                        deferred_draw.parent_node,
                        deferred_draw.current_view,
                        deferred_draw.rem_size,
                        deferred_draw.absolute_offset,
                        deferred_draw.prepaint_range.clone(),
                        deferred_draw.beneath_native_surfaces,
                        deferred_draw.enclosing_views.clone(),
                    )
                };
                self.next_frame.dispatch_tree.set_active_node(parent_node);

                let prepaint_start = self.prepaint_index();
                let records_start = self.retained_records_len();
                let retained_records = if let Some(mut element) = element {
                    self.prepainting_deferred_draw_beneath_native_surfaces =
                        Some(beneath_native_surfaces);
                    let recording = self.begin_deferred_view(&enclosing_views, cx);
                    self.with_rendered_view(current_view, |window| {
                        window.with_rem_size(Some(rem_size), |window| {
                            window.with_absolute_element_offset(absolute_offset, |window| {
                                element.prepaint(window, cx);
                            });
                        });
                    });
                    self.finish_deferred_view(recording, cx);
                    self.prepainting_deferred_draw_beneath_native_surfaces = None;
                    self.next_frame.deferred_draws[deferred_draw_ix].element = Some(element);
                    records_start..self.retained_records_len()
                } else {
                    self.reuse_prepaint(prepaint_range.clone());
                    let records = self.next_frame.deferred_draws[deferred_draw_ix]
                        .retained_records
                        .clone();
                    self.copy_deferred_records(records, &prepaint_range.start, &prepaint_start, cx)
                };
                let prepaint_end = self.prepaint_index();
                let deferred_draw = &mut self.next_frame.deferred_draws[deferred_draw_ix];
                deferred_draw.prepaint_range = prepaint_start..prepaint_end;
                deferred_draw.retained_records = retained_records;
            }

            self.element_id_stack.clear();
            self.text_style_stack.clear();
            round_start = round_end;
        }
    }

    fn paint_deferred_draws(&mut self, cx: &mut App) {
        assert_eq!(self.element_id_stack.len(), 0);

        // Paint all deferred draws in priority order, those kept beneath
        // native surfaces first. Since prepaint has already processed nested
        // deferreds, we just paint them all.
        //
        // The overlay plane starts at the first draw that is not kept beneath
        // native surfaces; a frame with none leaves the boundary at the end of
        // the scene, so only the prompt, drag and tooltip elements painted
        // after this land on the overlay.
        let mut overlay_scene_started = false;
        let traversal_order = self.deferred_draw_traversal_order();
        let mut deferred_draws = mem::take(&mut self.next_frame.deferred_draws);
        for deferred_draw_ix in traversal_order {
            let mut deferred_draw = &mut deferred_draws[deferred_draw_ix];
            if !overlay_scene_started && !deferred_draw.beneath_native_surfaces {
                self.next_frame.overlay_scene_start = self.next_frame.scene.len();
                overlay_scene_started = true;
            }
            self.element_id_stack
                .clone_from(&deferred_draw.element_id_stack);
            self.next_frame
                .dispatch_tree
                .set_active_node(deferred_draw.parent_node);

            let paint_start = self.paint_index();
            let content_mask = deferred_draw.content_mask;
            if let Some(element) = deferred_draw.element.as_mut() {
                let recording = self.begin_deferred_view(&deferred_draw.enclosing_views, cx);
                self.with_rendered_view(deferred_draw.current_view, |window| {
                    window.with_content_mask(content_mask, |window| {
                        window.with_rem_size(Some(deferred_draw.rem_size), |window| {
                            element.paint(window, cx);
                        });
                    })
                });
                self.finish_deferred_view(recording, cx);
            } else {
                self.reuse_paint(deferred_draw.paint_range.clone());
                let records = deferred_draw.retained_records.clone();
                let painted_from = deferred_draw.paint_range.start.clone();
                self.paint_deferred_records(records, &painted_from, &paint_start);
                deferred_draw = &mut deferred_draws[deferred_draw_ix];
            }
            let paint_end = self.paint_index();
            deferred_draw.paint_range = paint_start..paint_end;
        }
        self.next_frame.deferred_draws = deferred_draws;
        self.element_id_stack.clear();
        if !overlay_scene_started {
            self.next_frame.overlay_scene_start = self.next_frame.scene.len();
        }
    }

    fn deferred_draw_traversal_order(&mut self) -> SmallVec<[usize; 8]> {
        let deferred_count = self.next_frame.deferred_draws.len();
        let mut sorted_indices = (0..deferred_count).collect::<SmallVec<[_; 8]>>();
        sorted_indices.sort_by_key(|ix| {
            let deferred_draw = &self.next_frame.deferred_draws[*ix];
            (!deferred_draw.beneath_native_surfaces, deferred_draw.priority)
        });
        sorted_indices
    }

    pub(crate) fn prepaint_index(&self) -> PrepaintStateIndex {
        PrepaintStateIndex {
            hitboxes_index: self.next_frame.hitboxes.len(),
            tooltips_index: self.next_frame.tooltip_requests.len(),
            deferred_draws_index: self.next_frame.deferred_draws.len(),
            positioned_states_index: self.next_frame.positioned_states.len(),
            autoscroll_requests_index: self.next_frame.autoscroll_requests.len(),
            dispatch_tree_index: self.next_frame.dispatch_tree.len(),
            accessed_element_states_index: self.next_frame.accessed_element_states.len(),
            line_layout_index: self.text_system.layout_index(),
        }
    }

    pub(crate) fn reuse_prepaint(&mut self, range: Range<PrepaintStateIndex>) {
        self.reuse_prepaint_moved(range, None);
    }

    /// Reuses `range` of the last frame's prepaint, as
    /// [`Self::reuse_prepaint`] does, `moved` as a view drawn again elsewhere
    /// is: see [`view_retention::moving`]. A range moved defers nothing.
    pub(crate) fn reuse_prepaint_moved(
        &mut self,
        range: Range<PrepaintStateIndex>,
        moved: Option<&view_retention::ViewMove>,
    ) {
        let hitboxes =
            &self.rendered_frame.hitboxes[range.start.hitboxes_index..range.end.hitboxes_index];
        match moved {
            Some(moved) => self
                .next_frame
                .hitboxes
                .extend(hitboxes.iter().map(|hitbox| moved.hitbox(hitbox))),
            None => self.next_frame.hitboxes.extend(hitboxes.iter().cloned()),
        }
        self.next_frame.tooltip_requests.extend(
            self.rendered_frame.tooltip_requests
                [range.start.tooltips_index..range.end.tooltips_index]
                .iter_mut()
                .map(|request| request.take()),
        );
        self.next_frame.accessed_element_states.extend(
            self.rendered_frame.accessed_element_states[range.start.accessed_element_states_index
                ..range.end.accessed_element_states_index]
                .iter()
                .map(|(id, type_id)| (id.clone(), *type_id)),
        );
        self.text_system
            .reuse_layouts(range.start.line_layout_index..range.end.line_layout_index);
        // Copied so the ranges of the records copied along stay in step; a
        // view that asked to be scrolled into view is not drawn again.
        self.next_frame.autoscroll_requests.extend_from_slice(
            &self.rendered_frame.autoscroll_requests
                [range.start.autoscroll_requests_index..range.end.autoscroll_requests_index],
        );
        let moved_by = moved.map_or(Point::default(), |moved| moved.delta);
        self.next_frame.positioned_states.extend(
            self.rendered_frame.positioned_states
                [range.start.positioned_states_index..range.end.positioned_states_index]
                .iter()
                .map(|(state, _)| {
                    if moved_by != Point::default() {
                        state.translate(moved_by);
                    }
                    (state.clone(), moved_by)
                }),
        );

        let reused_subtree = self.next_frame.dispatch_tree.reuse_subtree(
            range.start.dispatch_tree_index..range.end.dispatch_tree_index,
            &mut self.rendered_frame.dispatch_tree,
            self.focus,
        );

        if reused_subtree.contains_focus() {
            self.next_frame.focus = self.focus;
        }

        self.next_frame.deferred_draws.extend(
            self.rendered_frame.deferred_draws
                [range.start.deferred_draws_index..range.end.deferred_draws_index]
                .iter()
                .map(|deferred_draw| DeferredDraw {
                    current_view: deferred_draw.current_view,
                    parent_node: reused_subtree.refresh_node_id(deferred_draw.parent_node),
                    element_id_stack: deferred_draw.element_id_stack.clone(),
                    text_style_stack: deferred_draw.text_style_stack.clone(),
                    content_mask: deferred_draw.content_mask,
                    rem_size: deferred_draw.rem_size,
                    priority: deferred_draw.priority,
                    beneath_native_surfaces: deferred_draw.beneath_native_surfaces,
                    element: None,
                    absolute_offset: deferred_draw.absolute_offset,
                    prepaint_range: deferred_draw.prepaint_range.clone(),
                    paint_range: deferred_draw.paint_range.clone(),
                    // Drawn from the last frame: what it read is part of the
                    // records copied along with the views it came from.
                    enclosing_views: Default::default(),
                    retained_records: deferred_draw.retained_records.clone(),
                }),
        );
    }

    pub(crate) fn paint_index(&self) -> PaintIndex {
        PaintIndex {
            scene_index: self.next_frame.scene.len(),
            window_control_hitboxes_index: self.next_frame.window_control_hitboxes.len(),
            #[cfg(any(test, feature = "test-support"))]
            debug_bounds_index: self.next_frame.debug_bounds_records.len(),
            mouse_listeners_index: self.next_frame.mouse_listeners.len(),
            input_handlers_index: self.next_frame.input_handlers.len(),
            cursor_styles_index: self.next_frame.cursor_styles.len(),
            accessed_element_states_index: self.next_frame.accessed_element_states.len(),
            tab_handle_index: self.next_frame.tab_stops.paint_index(),
            painted_positions_index: self.next_frame.painted_positions.len(),
            line_layout_index: self.text_system.layout_index(),
        }
    }

    pub(crate) fn reuse_paint(&mut self, range: Range<PaintIndex>) {
        self.reuse_paint_inside(range, None, None);
    }

    /// Reuses `range` of the last frame's paint, as [`Self::reuse_paint`]
    /// does, rebasing its primitives from the time transition they were
    /// painted inside to the one current now (see [`Scene::replay_inside`]),
    /// and `moved` as a view drawn again elsewhere is (see
    /// [`view_retention::moving`]). Mouse listeners are copied as they are; a
    /// range moved holds no input handler.
    pub(crate) fn reuse_paint_moved(
        &mut self,
        range: Range<PaintIndex>,
        painted_inside: u32,
        replayed_inside: u32,
        moved: Option<&view_retention::ViewMove>,
    ) {
        self.reuse_paint_inside(range, Some((painted_inside, replayed_inside)), moved);
    }

    fn reuse_paint_inside(
        &mut self,
        range: Range<PaintIndex>,
        rebase: Option<(u32, u32)>,
        moved: Option<&view_retention::ViewMove>,
    ) {
        // Cached elements still exist in the frame even when their paint methods don't run.
        #[cfg(any(test, feature = "test-support"))]
        for (selector, bounds) in &self.rendered_frame.debug_bounds_records
            [range.start.debug_bounds_index..range.end.debug_bounds_index]
        {
            let bounds = match moved {
                Some(moved) => Bounds {
                    origin: bounds.origin + moved.delta,
                    size: bounds.size,
                },
                None => *bounds,
            };
            self.next_frame.record_debug_bounds(selector.clone(), bounds);
        }
        self.next_frame.cursor_styles.extend(
            self.rendered_frame.cursor_styles
                [range.start.cursor_styles_index..range.end.cursor_styles_index]
                .iter()
                .cloned(),
        );
        // Window controls (the caption, drag strips, minimize, maximize and
        // close buttons) are hit-tested against the rendered frame's list, so
        // a view reused without painting would otherwise lose them.
        self.next_frame.window_control_hitboxes.extend(
            self.rendered_frame.window_control_hitboxes[range.start.window_control_hitboxes_index
                ..range.end.window_control_hitboxes_index]
                .iter()
                .map(|(area, hitbox)| match moved {
                    Some(moved) => (*area, moved.hitbox(hitbox)),
                    None => (*area, hitbox.clone()),
                }),
        );
        self.next_frame.input_handlers.extend(
            self.rendered_frame.input_handlers
                [range.start.input_handlers_index..range.end.input_handlers_index]
                .iter_mut()
                .map(|handler| handler.take()),
        );
        self.next_frame.mouse_listeners.extend(
            self.rendered_frame.mouse_listeners
                [range.start.mouse_listeners_index..range.end.mouse_listeners_index]
                .iter_mut()
                .map(|listener| listener.take()),
        );
        self.next_frame.accessed_element_states.extend(
            self.rendered_frame.accessed_element_states[range.start.accessed_element_states_index
                ..range.end.accessed_element_states_index]
                .iter()
                .map(|(id, type_id)| (id.clone(), *type_id)),
        );
        self.next_frame.tab_stops.replay(
            &self.rendered_frame.tab_stops.insertion_history
                [range.start.tab_handle_index..range.end.tab_handle_index],
        );

        self.text_system
            .reuse_layouts(range.start.line_layout_index..range.end.line_layout_index);
        let moved_by = moved.map_or(Point::default(), |moved| moved.delta);
        self.next_frame.painted_positions.extend(
            self.rendered_frame.painted_positions
                [range.start.painted_positions_index..range.end.painted_positions_index]
                .iter()
                .map(|state| {
                    if moved_by != Point::default() {
                        state.translate(moved_by);
                    }
                    state.clone()
                }),
        );
        let moved = moved.map(|moved| moved.scaled(self));
        self.next_frame.scene.replay_inside(
            range.start.scene_index..range.end.scene_index,
            &self.rendered_frame.scene,
            rebase,
            moved.as_ref(),
        );
    }

    /// Push a text style onto the stack, and call a function with that style active.
    /// Use [`Window::text_style`] to get the current, combined text style. This method
    /// should only be called as part of element drawing.
    pub fn with_text_style<F, R>(&mut self, style: Option<TextStyleRefinement>, f: F) -> R
    where
        F: FnOnce(&mut Self) -> R,
    {
        self.invalidator.debug_assert_paint_or_prepaint();
        if let Some(style) = style {
            self.text_style_stack.push(style);
            let result = f(self);
            self.text_style_stack.pop();
            result
        } else {
            f(self)
        }
    }

    /// Updates the cursor style at the platform level. This method should only be called
    /// during the paint phase of element drawing.
    pub fn set_cursor_style(&mut self, style: CursorStyle, hitbox: &Hitbox) {
        self.invalidator.debug_assert_paint();
        self.next_frame.cursor_styles.push(CursorStyleRequest {
            hitbox_id: Some(hitbox.id),
            style,
        });
    }

    /// Updates the cursor style for the entire window at the platform level. A cursor
    /// style using this method will have precedence over any cursor style set using
    /// `set_cursor_style`. This method should only be called during the paint
    /// phase of element drawing.
    pub fn set_window_cursor_style(&mut self, style: CursorStyle) {
        self.invalidator.debug_assert_paint();
        self.next_frame.cursor_styles.push(CursorStyleRequest {
            hitbox_id: None,
            style,
        })
    }

    /// Sets a tooltip to be rendered for the upcoming frame. This method should only be called
    /// during the paint phase of element drawing.
    pub fn set_tooltip(&mut self, tooltip: AnyTooltip) -> TooltipId {
        self.invalidator.debug_assert_prepaint();
        let id = TooltipId(post_inc(&mut self.next_tooltip_id.0));
        self.next_frame
            .tooltip_requests
            .push(Some(TooltipRequest { id, tooltip }));
        id
    }

    /// Invoke the given function with the given content mask after intersecting it
    /// with the current mask. This method should only be called during element drawing.
    // This function is called in a highly recursive manner in editor
    // prepainting, make sure its inlined to reduce the stack burden
    #[inline]
    pub fn with_content_mask<R>(
        &mut self,
        mask: Option<ContentMask<Pixels>>,
        f: impl FnOnce(&mut Self) -> R,
    ) -> R {
        self.invalidator.debug_assert_paint_or_prepaint();
        if let Some(mask) = mask {
            let mask = mask.intersect(&self.content_mask());
            self.content_mask_stack.push(mask);
            let result = f(self);
            self.content_mask_stack.pop();
            result
        } else {
            f(self)
        }
    }

    pub(crate) fn with_text_shimmer<R>(
        &mut self,
        mut shimmer: TextShimmerStyle,
        sweep: Option<TextShimmerSweep>,
        f: impl FnOnce(&mut Self) -> R,
    ) -> R {
        self.invalidator.debug_assert_paint_or_prepaint();
        if let Some(sweep) = sweep
            && !text_shimmer_disabled()
        {
            let scale_factor = self.scale_factor();
            shimmer.animation =
                self.next_frame
                    .scene
                    .push_shimmer_animation(crate::scene::ShimmerAnimation {
                        band_start: sweep.band_start.0 * scale_factor,
                        travel: sweep.travel.0 * scale_factor,
                        period: sweep.period,
                        hold: sweep.hold,
                    });
        }
        self.text_shimmer_stack.push(shimmer);
        let result = f(self);
        self.text_shimmer_stack.pop();
        result
    }

    /// Fades every quad painted inside `f` with `cycle`, driven by the window
    /// rather than by drawing again: the scene sets each quad's opacity before
    /// every present, and keeps presenting while such a quad is on screen.
    /// For a looping decorative animation (a pulsing loader) that would
    /// otherwise redraw its whole window at its frame rate.
    ///
    /// The painted colors are the ones at full cycle opacity. Nested cycles do
    /// not compose; the innermost applies.
    pub fn with_opacity_cycle<R>(
        &mut self,
        cycle: OpacityCycle,
        f: impl FnOnce(&mut Self) -> R,
    ) -> R {
        self.invalidator.debug_assert_paint();
        self.opacity_cycle_stack.push(cycle);
        let result = f(self);
        self.opacity_cycle_stack.pop();
        result
    }

    /// Moves and fades everything painted inside `f` with `transition`,
    /// driven by the window rather than by drawing again: the scene sets each
    /// primitive's position and opacity before every present, and the window
    /// presents on every frame until the transition lands. For a short
    /// one-shot swap (a line rolling out of a slot as its successor rolls in)
    /// that would otherwise redraw its whole window for every frame of it.
    ///
    /// Paint the content at rest; the transition's offsets are relative to
    /// it, and clipping stays where it was painted. Hitboxes do not move.
    /// Paths and surfaces are not moved. A transition nested inside another
    /// composes with it: the offsets add and the opacities multiply.
    pub fn with_time_transition<R>(
        &mut self,
        transition: TimeTransition,
        f: impl FnOnce(&mut Self) -> R,
    ) -> R {
        self.invalidator.debug_assert_paint();
        let parent = self.next_frame.scene.current_transition();
        let Some(id) = self.next_frame.scene.push_transition(crate::scene::SceneTransition {
            transition,
            scale_factor: self.scale_factor(),
            parent,
        }) else {
            return f(self);
        };
        let previous = self.next_frame.scene.set_current_transition(id);
        let result = f(self);
        self.next_frame.scene.set_current_transition(previous);
        result
    }

    fn current_text_effect(&self) -> SpriteEffect {
        if self.text_shimmer_stack.is_empty() || text_shimmer_disabled() {
            return SpriteEffect::default();
        }
        self.text_shimmer_stack
            .last()
            .copied()
            .map(|shimmer| shimmer.scale(self.scale_factor()))
            .unwrap_or_default()
    }

    /// Updates the global element offset relative to the current offset. This is used to implement
    /// scrolling. This method should only be called during the prepaint phase of element drawing.
    pub fn with_element_offset<R>(
        &mut self,
        offset: Point<Pixels>,
        f: impl FnOnce(&mut Self) -> R,
    ) -> R {
        self.invalidator.debug_assert_prepaint();

        if offset.is_zero() {
            return f(self);
        };

        let abs_offset = self.element_offset() + offset;
        self.with_absolute_element_offset(abs_offset, f)
    }

    /// Updates the global element offset based on the given offset. This is used to implement
    /// drag handles and other manual painting of elements. This method should only be called during
    /// the prepaint phase of element drawing.
    pub fn with_absolute_element_offset<R>(
        &mut self,
        offset: Point<Pixels>,
        f: impl FnOnce(&mut Self) -> R,
    ) -> R {
        self.invalidator.debug_assert_prepaint();
        self.element_offset_stack.push(offset);
        let result = f(self);
        self.element_offset_stack.pop();
        result
    }

    pub(crate) fn with_element_opacity<R>(
        &mut self,
        opacity: Option<f32>,
        f: impl FnOnce(&mut Self) -> R,
    ) -> R {
        self.invalidator.debug_assert_paint_or_prepaint();

        let Some(opacity) = opacity else {
            return f(self);
        };

        let previous_opacity = self.element_opacity;
        self.element_opacity = previous_opacity * opacity;
        let result = f(self);
        self.element_opacity = previous_opacity;
        result
    }

    /// Perform prepaint on child elements in a "retryable" manner, so that any side effects
    /// of prepaints can be discarded before prepainting again. This is used to support autoscroll
    /// where we need to prepaint children to detect the autoscroll bounds, then adjust the
    /// element offset and prepaint again. See [`crate::List`] for an example. This method should only be
    /// called during the prepaint phase of element drawing.
    pub fn transact<T, U>(&mut self, f: impl FnOnce(&mut Self) -> Result<T, U>) -> Result<T, U> {
        self.invalidator.debug_assert_prepaint();
        let index = self.prepaint_index();
        let layout_transaction = self
            .layout_engine
            .as_mut()
            .map(|engine| engine.begin_transaction());
        let retained_transaction = self.begin_retained_transaction();
        let result = f(self);
        if let Some(start) = layout_transaction
            && let Some(engine) = self.layout_engine.as_mut()
        {
            engine.end_transaction(start, result.is_err());
        }
        if result.is_err() {
            self.truncate_prepaint(&index);
            // The retained views recorded since point into what was truncated.
            self.roll_back_retained_transaction(retained_transaction);
        }
        result
    }

    /// Forgets what was prepainted since `index`, as a rolled-back
    /// transaction does.
    pub(crate) fn truncate_prepaint(&mut self, index: &PrepaintStateIndex) {
        {
            self.next_frame.hitboxes.truncate(index.hitboxes_index);
            self.next_frame
                .tooltip_requests
                .truncate(index.tooltips_index);
            self.next_frame
                .deferred_draws
                .truncate(index.deferred_draws_index);
            self.next_frame
                .autoscroll_requests
                .truncate(index.autoscroll_requests_index);
            // Positions moved with a view drawn again elsewhere are moved
            // back: the prepaint tried again may move it by another amount.
            for (state, moved_by) in self
                .next_frame
                .positioned_states
                .drain(index.positioned_states_index..)
            {
                if moved_by != Point::default() {
                    state.translate(-moved_by);
                }
            }
            self.next_frame
                .dispatch_tree
                .truncate(index.dispatch_tree_index);
            self.next_frame
                .accessed_element_states
                .truncate(index.accessed_element_states_index);
            self.text_system.truncate_layouts(index.line_layout_index.clone());
        }
    }

    /// When you call this method during [`Element::prepaint`], containing elements will attempt to
    /// scroll to cause the specified bounds to become visible. When they decide to autoscroll, they will call
    /// [`Element::prepaint`] again with a new set of bounds. See [`crate::List`] for an example of an element
    /// that supports this method being called on the elements it contains. This method should only be
    /// called during the prepaint phase of element drawing.
    pub fn request_autoscroll(&mut self, bounds: Bounds<Pixels>) {
        self.invalidator.debug_assert_prepaint();
        self.requested_autoscroll = Some(bounds);
        if !self.view_retention.view_stack_is_empty() {
            self.next_frame.autoscroll_requests.push(bounds);
        }
    }

    /// This method can be called from a containing element such as [`crate::List`] to support the autoscroll behavior
    /// described in [`Self::request_autoscroll`].
    pub fn take_autoscroll(&mut self) -> Option<Bounds<Pixels>> {
        self.invalidator.debug_assert_prepaint();
        self.requested_autoscroll.take()
    }

    /// Asynchronously load an asset, if the asset hasn't finished loading this will return None.
    /// Your view will be re-drawn once the asset has finished loading.
    ///
    /// Note that the multiple calls to this method will only result in one `Asset::load` call at a
    /// time.
    pub fn use_asset<A: Asset>(&mut self, source: &A::Source, cx: &mut App) -> Option<A::Output> {
        cx.asset_entry::<A>(source).use_by(self.current_view())
    }

    /// Asynchronously load an asset, if the asset hasn't finished loading or doesn't exist this will return None.
    /// Your view will not be re-drawn once the asset has finished loading.
    ///
    /// Note that the multiple calls to this method will only result in one `Asset::load` call at a
    /// time.
    pub fn get_asset<A: Asset>(&mut self, source: &A::Source, cx: &mut App) -> Option<A::Output> {
        cx.fetch_asset::<A>(source)
    }
    /// Obtain the current element offset. This method should only be called during the
    /// prepaint phase of element drawing.
    pub fn element_offset(&self) -> Point<Pixels> {
        self.invalidator.debug_assert_prepaint();
        self.element_offset_stack
            .last()
            .copied()
            .unwrap_or_default()
    }

    /// Obtain the current element opacity. This method should only be called during the
    /// prepaint phase of element drawing.
    #[inline]
    pub(crate) fn element_opacity(&self) -> f32 {
        self.invalidator.debug_assert_paint_or_prepaint();
        self.element_opacity
    }

    /// Obtain the current content mask. This method should only be called during element drawing.
    pub fn content_mask(&self) -> ContentMask<Pixels> {
        self.invalidator.debug_assert_paint_or_prepaint();
        self.content_mask_stack
            .last()
            .cloned()
            .unwrap_or_else(|| ContentMask {
                bounds: Bounds {
                    origin: Point::default(),
                    size: self.viewport_size,
                },
            })
    }

    /// Provide elements in the called function with a new namespace in which their identifiers must be unique.
    /// This can be used within a custom element to distinguish multiple sets of child elements.
    pub fn with_element_namespace<R>(
        &mut self,
        element_id: impl Into<ElementId>,
        f: impl FnOnce(&mut Self) -> R,
    ) -> R {
        self.element_id_stack.push(element_id.into());
        let result = f(self);
        self.element_id_stack.pop();
        result
    }

    /// Use a piece of state that exists as long this element is being rendered in consecutive frames.
    pub fn use_keyed_state<S: 'static>(
        &mut self,
        key: impl Into<ElementId>,
        cx: &mut App,
        init: impl FnOnce(&mut Self, &mut Context<S>) -> S,
    ) -> Entity<S> {
        let current_view = self.current_view();
        self.with_global_id(key.into(), |global_id, window| {
            window.with_element_state(global_id, |state: Option<Entity<S>>, window| {
                if let Some(state) = state {
                    (state.clone(), state)
                } else {
                    let new_state = cx.new(|cx| init(window, cx));
                    Self::observe_keyed_state(&new_state, current_view, cx);
                    (new_state.clone(), new_state)
                }
            })
        })
    }

    /// Use a piece of state that exists as long this element is being rendered in consecutive frames, without needing to specify a key
    ///
    /// NOTE: This method uses the location of the caller to generate an ID for this state.
    ///       If this is not sufficient to identify your state (e.g. you're rendering a list item),
    ///       you can provide a custom ElementID using the `use_keyed_state` method.
    #[track_caller]
    pub fn use_state<S: 'static>(
        &mut self,
        cx: &mut App,
        init: impl FnOnce(&mut Self, &mut Context<S>) -> S,
    ) -> Entity<S> {
        self.use_keyed_state(
            ElementId::CodeLocation(*core::panic::Location::caller()),
            cx,
            init,
        )
    }

    /// Updates or initializes state for an element with the given id that lives across multiple
    /// frames. If an element with this ID existed in the rendered frame, its state will be passed
    /// to the given closure. The state returned by the closure will be stored so it can be referenced
    /// when drawing the next frame. This method should only be called as part of element drawing.
    #[inline(always)]
    pub fn with_element_state<S, R>(
        &mut self,
        global_id: &GlobalElementId,
        f: impl FnOnce(Option<S>, &mut Self) -> (R, S),
    ) -> R
    where
        S: 'static,
    {
        self.invalidator.debug_assert_paint_or_prepaint();

        let (key, state) = self.take_element_state(global_id, TypeId::of::<S>());

        if let Some(any) = state {
            let ElementStateBox {
                inner,
                #[cfg(debug_assertions)]
                type_name,
            } = any;
            // Using the extra inner option to avoid needing to reallocate a new box.
            let mut state_box = inner
                .downcast::<Option<S>>()
                .map_err(|_| {
                    #[cfg(debug_assertions)]
                    {
                        anyhow::anyhow!(
                            "invalid element state type for id, requested {:?}, actual: {:?}",
                            std::any::type_name::<S>(),
                            type_name
                        )
                    }

                    #[cfg(not(debug_assertions))]
                    {
                        anyhow::anyhow!(
                            "invalid element state type for id, requested {:?}",
                            std::any::type_name::<S>(),
                        )
                    }
                })
                .unwrap();

            let state = state_box.take().expect(
                "reentrant call to with_element_state for the same state type and element id",
            );
            let (result, state) = f(Some(state), self);
            state_box.replace(state);
            self.insert_element_state(
                key,
                ElementStateBox {
                    inner: state_box,
                    #[cfg(debug_assertions)]
                    type_name,
                },
            );
            result
        } else {
            let (result, state) = f(None, self);
            self.insert_element_state(
                key,
                ElementStateBox {
                    inner: Box::new(Some(state)),
                    #[cfg(debug_assertions)]
                    type_name: std::any::type_name::<S>(),
                },
            );
            result
        }
    }

    /// A variant of `with_element_state` that allows the element's id to be optional. This is a convenience
    /// method for elements where the element id may or may not be assigned. Prefer using `with_element_state`
    /// when the element is guaranteed to have an id.
    ///
    /// The first option means 'no ID provided'
    /// The second option means 'not yet initialized'
    pub fn with_optional_element_state<S, R>(
        &mut self,
        global_id: Option<&GlobalElementId>,
        f: impl FnOnce(Option<Option<S>>, &mut Self) -> (R, Option<S>),
    ) -> R
    where
        S: 'static,
    {
        self.invalidator.debug_assert_paint_or_prepaint();

        if let Some(global_id) = global_id {
            self.with_element_state(global_id, |state, cx| {
                let (result, state) = f(Some(state), cx);
                let state =
                    state.expect("you must return some state when you pass some element id");
                (result, state)
            })
        } else {
            let (result, state) = f(None, self);
            debug_assert!(
                state.is_none(),
                "you must not return an element state when passing None for the global id"
            );
            result
        }
    }

    /// Executes the given closure within the context of a tab group.
    #[inline]
    pub fn with_tab_group<R>(&mut self, index: Option<isize>, f: impl FnOnce(&mut Self) -> R) -> R {
        if let Some(index) = index {
            self.next_frame.tab_stops.begin_group(index);
            let result = f(self);
            self.next_frame.tab_stops.end_group();
            result
        } else {
            f(self)
        }
    }

    /// Defers the drawing of the given element, scheduling it to be painted on top of the currently-drawn tree
    /// at a later time. The `priority` parameter determines the drawing order relative to other deferred elements,
    /// with higher values being drawn on top.
    ///
    /// When `content_mask` is provided, the deferred element will be clipped to that region during
    /// both prepaint and paint. When `None`, no additional clipping is applied.
    ///
    /// This method should only be called as part of the prepaint phase of element drawing.
    pub fn defer_draw(
        &mut self,
        element: AnyElement,
        absolute_offset: Point<Pixels>,
        priority: usize,
        content_mask: Option<ContentMask<Pixels>>,
    ) {
        self.defer_draw_on_plane(element, absolute_offset, priority, content_mask, false);
    }

    /// Like [`Self::defer_draw`], but keeps the element on the window's base
    /// scene plane, beneath any native child surface, when a scene overlay is
    /// enabled ([`Self::enable_scene_overlay`]). Such draws are painted before
    /// every overlay-plane deferred draw regardless of `priority`, ordered by
    /// `priority` among themselves, and never count as overlay content.
    ///
    /// A draw registered while an overlay-plane deferred draw is being
    /// prepainted stays on the overlay plane: content nested in a popup must
    /// not paint beneath the popup.
    ///
    /// This method should only be called as part of the prepaint phase of element drawing.
    pub fn defer_draw_beneath_native_surfaces(
        &mut self,
        element: AnyElement,
        absolute_offset: Point<Pixels>,
        priority: usize,
        content_mask: Option<ContentMask<Pixels>>,
    ) {
        let beneath_native_surfaces = self
            .prepainting_deferred_draw_beneath_native_surfaces
            .unwrap_or(true);
        self.defer_draw_on_plane(
            element,
            absolute_offset,
            priority,
            content_mask,
            beneath_native_surfaces,
        );
    }

    fn defer_draw_on_plane(
        &mut self,
        element: AnyElement,
        absolute_offset: Point<Pixels>,
        priority: usize,
        content_mask: Option<ContentMask<Pixels>>,
        beneath_native_surfaces: bool,
    ) {
        self.invalidator.debug_assert_prepaint();
        let parent_node = self.next_frame.dispatch_tree.active_node_id().unwrap();
        self.next_frame.deferred_draws.push(DeferredDraw {
            current_view: self.current_view(),
            parent_node,
            element_id_stack: self.element_id_stack.clone(),
            text_style_stack: self.text_style_stack.clone(),
            content_mask,
            rem_size: self.rem_size(),
            priority,
            beneath_native_surfaces,
            element: Some(element),
            absolute_offset,
            prepaint_range: PrepaintStateIndex::default()..PrepaintStateIndex::default(),
            paint_range: PaintIndex::default()..PaintIndex::default(),
            enclosing_views: self.enclosing_views(),
            retained_records: 0..0,
        });
    }

    /// Creates a new painting layer for the specified bounds. A "layer" is a batch
    /// of geometry that are non-overlapping and have the same draw order. This is typically used
    /// for performance reasons.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    pub fn paint_layer<R>(&mut self, bounds: Bounds<Pixels>, f: impl FnOnce(&mut Self) -> R) -> R {
        self.invalidator.debug_assert_paint();

        let content_mask = self.content_mask();
        let clipped_bounds = bounds.intersect(&content_mask.bounds);
        if !clipped_bounds.is_empty() {
            let scale_factor = self.scale_factor();
            let covered = self.cover_bounds(clipped_bounds);
            // The mask as primitives keep theirs, so that a move tells the
            // mask around what moved from the masks inside it alike.
            let mask = self.snapped_content_mask().bounds;
            self.next_frame
                .scene
                .push_clipped_layer(covered, bounds.scale(scale_factor), mask);
        }

        let result = f(self);

        if !clipped_bounds.is_empty() {
            self.next_frame.scene.pop_layer();
        }

        result
    }

    /// Paint the drop (non-inset) shadows from `shadows` into the scene at the current
    /// z-index. Inset shadows are skipped; paint those with [`Self::paint_inset_shadows`]
    /// after the element's background so they layer on top of the fill.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    pub fn paint_drop_shadows(
        &mut self,
        bounds: Bounds<Pixels>,
        corner_radii: Corners<Pixels>,
        shadows: &[BoxShadow],
    ) {
        self.invalidator.debug_assert_paint();

        let scale_factor = self.scale_factor();
        let content_mask = self.snapped_content_mask();
        let opacity = self.element_opacity();
        let element_bounds = self.cover_bounds(bounds);
        let element_corner_radii = corner_radii.scale(scale_factor);
        for shadow in shadows {
            if shadow.inset {
                continue;
            }
            let shadow_bounds = (bounds + shadow.offset).dilate(shadow.spread_radius);
            self.next_frame.scene.insert_primitive(Shadow {
                order: 0,
                blur_radius: shadow.blur_radius.scale(scale_factor),
                bounds: self.cover_bounds(shadow_bounds),
                content_mask,
                corner_radii: corner_radii.scale(scale_factor),
                color: shadow.color.opacity(opacity),
                element_bounds,
                element_corner_radii,
                inset: 0,
                pad: 0,
            });
        }
    }

    /// Paint the inset shadows from `shadows` into the scene at the current z-index. Should
    /// be called after the element's background so the shadow layers on top of the fill.
    /// Drop shadows are skipped; paint those with [`Self::paint_drop_shadows`] before the background.
    pub fn paint_inset_shadows(
        &mut self,
        bounds: Bounds<Pixels>,
        corner_radii: Corners<Pixels>,
        shadows: &[BoxShadow],
    ) {
        self.invalidator.debug_assert_paint();

        let scale_factor = self.scale_factor();
        let content_mask = self.snapped_content_mask();
        let opacity = self.element_opacity();
        let element_bounds = self.cover_bounds(bounds);
        let element_corner_radii = corner_radii.scale(scale_factor);
        for shadow in shadows {
            if !shadow.inset {
                continue;
            }
            let hole = (bounds + shadow.offset).dilate(-shadow.spread_radius);
            // Clamp at zero so a large spread can't produce negative radii, which would
            // break the SDF in the shader.
            let zero = Pixels::ZERO;
            let hole_corner_radii = Corners {
                top_left: (corner_radii.top_left - shadow.spread_radius).max(zero),
                top_right: (corner_radii.top_right - shadow.spread_radius).max(zero),
                bottom_right: (corner_radii.bottom_right - shadow.spread_radius).max(zero),
                bottom_left: (corner_radii.bottom_left - shadow.spread_radius).max(zero),
            };
            self.next_frame.scene.insert_primitive(Shadow {
                order: 0,
                blur_radius: shadow.blur_radius.scale(scale_factor),
                bounds: self.cover_bounds(hole),
                content_mask,
                corner_radii: hole_corner_radii.scale(scale_factor),
                color: shadow.color.opacity(opacity),
                element_bounds,
                element_corner_radii,
                inset: 1,
                pad: 0,
            });
        }
    }

    fn largest_border_interior(quad: &Quad) -> Bounds<ScaledPixels> {
        let radii = &quad.corner_radii;
        let widths = &quad.border_widths;
        let edge_radii = Edges {
            top: radii.top_left.max(radii.top_right),
            right: radii.top_right.max(radii.bottom_right),
            bottom: radii.bottom_left.max(radii.bottom_right),
            left: radii.top_left.max(radii.bottom_left),
        };

        let antialias_inset = point(ScaledPixels(1.0), ScaledPixels(1.0));
        let inset_bounds = |top_left_inset, bottom_right_inset| {
            Bounds::from_corners(
                quad.bounds.origin + top_left_inset + antialias_inset,
                quad.bounds.bottom_right() - bottom_right_inset - antialias_inset,
            )
        };

        // Rounded corners need only be excluded on one axis. Either candidate
        // is empty of border pixels, so use the larger interior.
        let horizontal_band = inset_bounds(
            point(widths.left, widths.top.max(edge_radii.top)),
            point(widths.right, widths.bottom.max(edge_radii.bottom)),
        );
        let vertical_band = inset_bounds(
            point(widths.left.max(edge_radii.left), widths.top),
            point(widths.right.max(edge_radii.right), widths.bottom),
        );

        let area = |bounds: &Bounds<ScaledPixels>| {
            bounds.size.width.0.max(0.) * bounds.size.height.0.max(0.)
        };
        if area(&horizontal_band) >= area(&vertical_band) {
            horizontal_band
        } else {
            vertical_band
        }
    }

    /// Paint one or more quads into the scene for the next frame at the current stacking context.
    /// Quads are colored rectangular regions with an optional background, border, and corner radius.
    /// see [`fill`], [`outline`], and [`quad`] to construct this type.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    ///
    /// Note that the `quad.corner_radii` are allowed to exceed the bounds, creating sharp corners
    /// where the circular arcs meet. This will not display well when combined with dashed borders.
    /// Use `Corners::clamp_radii_for_quad_size` if the radii should fit within the bounds.
    pub fn paint_quad(&mut self, quad: PaintQuad) {
        self.invalidator.debug_assert_paint();

        let opacity = self.element_opacity();
        let mut background = quad.background.opacity(opacity);
        if self.glass_content {
            background = background.glass_content();
        }
        let snapped_bounds = self.snap_bounds(quad.bounds);
        let snapped_border_widths = self.snap_border_widths(quad.border_widths);
        let quad = Quad {
            order: 0,
            bounds: snapped_bounds,
            content_mask: self.snapped_content_mask(),
            background,
            border_color: quad.border_color.opacity(opacity),
            corner_radii: quad.corner_radii.scale(self.scale_factor()),
            border_widths: snapped_border_widths,
            border_style: quad.border_style,
        };

        if let Some(cycle) = self.opacity_cycle_stack.last().copied() {
            let animation =
                self.next_frame
                    .scene
                    .push_quad_animation(crate::scene::QuadOpacityAnimation {
                        cycle,
                        background: quad.background,
                        border_color: quad.border_color,
                    });
            let opacity = cycle.current_opacity();
            self.next_frame.scene.insert_primitive(Quad {
                background: quad
                    .background
                    .opacity(opacity)
                    .with_time_animation(animation),
                border_color: quad.border_color.opacity(opacity),
                ..quad
            });
            return;
        }

        if !quad.background.is_transparent() {
            self.next_frame.scene.insert_primitive(quad);
            return;
        }

        // Splitting a border-only quad around its empty interior avoids shading
        // every transparent pixel inside large outlines.
        let outer_bounds = quad.bounds;
        let inner_bounds = Self::largest_border_interior(&quad);

        if inner_bounds.is_empty() {
            self.next_frame.scene.insert_primitive(quad);
            return;
        }

        let strips = [
            // Top
            Bounds::from_corners(
                outer_bounds.origin,
                point(outer_bounds.right(), inner_bounds.top()),
            ),
            // Bottom
            Bounds::from_corners(
                point(outer_bounds.left(), inner_bounds.bottom()),
                outer_bounds.bottom_right(),
            ),
            // Left
            Bounds::from_corners(
                point(outer_bounds.left(), inner_bounds.top()),
                inner_bounds.bottom_left(),
            ),
            // Right
            Bounds::from_corners(
                inner_bounds.top_right(),
                point(outer_bounds.right(), inner_bounds.bottom()),
            ),
        ];

        for strip in strips {
            let content_mask_bounds = quad.content_mask.bounds.intersect(&strip);
            if !content_mask_bounds.is_empty() {
                self.next_frame.scene.insert_primitive(Quad {
                    content_mask: ContentMask {
                        bounds: content_mask_bounds,
                    },
                    ..quad
                });
            }
        }
    }

    /// Paint the given `Path` into the scene for the next frame at the current z-index.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    pub fn paint_path(&mut self, mut path: Path<Pixels>, color: impl Into<Background>) {
        self.invalidator.debug_assert_paint();

        let scale_factor = self.scale_factor();
        let content_mask = self.content_mask();
        let opacity = self.element_opacity();
        path.content_mask = content_mask;
        let color: Background = color.into();
        path.color = color.opacity(opacity);
        self.next_frame
            .scene
            .insert_primitive(path.scale(scale_factor));
    }

    /// Paint an underline into the scene for the next frame at the current z-index.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    pub fn paint_underline(
        &mut self,
        origin: Point<Pixels>,
        width: Pixels,
        style: &UnderlineStyle,
    ) {
        self.invalidator.debug_assert_paint();
        let underline = self.underline(origin, width, style);
        self.next_frame.scene.insert_primitive(underline);
    }

    /// Paint a strikethrough into the scene for the next frame at the current z-index.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    pub fn paint_strikethrough(
        &mut self,
        origin: Point<Pixels>,
        width: Pixels,
        style: &StrikethroughStyle,
    ) {
        self.invalidator.debug_assert_paint();

        let scale_factor = self.scale_factor();
        let height = style.thickness;
        let bounds = Bounds {
            origin: origin.map(|c| ScaledPixels(round_to_device_pixel(c.0, scale_factor))),
            size: size(self.snap_stroke(width), self.snap_stroke(height)),
        };
        let opacity = self.element_opacity();

        self.next_frame.scene.insert_primitive(Underline {
            order: 0,
            pad: 0,
            bounds,
            content_mask: self.snapped_content_mask(),
            thickness: self.snap_stroke(style.thickness),
            color: style.color.unwrap_or_default().opacity(opacity),
            wavy: false.into(),
        });
    }

    /// Paints a monochrome (non-emoji) glyph into the scene for the next frame at the current z-index.
    ///
    /// The y component of the origin is the baseline of the glyph.
    /// You should generally prefer to use the [`ShapedLine::paint`](crate::ShapedLine::paint) or
    /// [`WrappedLine::paint`](crate::WrappedLine::paint) methods in the [`TextSystem`](crate::TextSystem).
    /// This method is only useful if you need to paint a single glyph that has already been shaped.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    pub fn paint_glyph(
        &mut self,
        origin: Point<Pixels>,
        font_id: FontId,
        glyph_id: GlyphId,
        font_size: Pixels,
        color: Hsla,
    ) -> Result<()> {
        LineGlyphPainter::new(self).paint_glyph(self, origin, font_id, glyph_id, font_size, color)
    }

    /// Paints an emoji glyph into the scene for the next frame at the current z-index.
    ///
    /// The y component of the origin is the baseline of the glyph.
    /// You should generally prefer to use the [`ShapedLine::paint`](crate::ShapedLine::paint) or
    /// [`WrappedLine::paint`](crate::WrappedLine::paint) methods in the [`TextSystem`](crate::TextSystem).
    /// This method is only useful if you need to paint a single emoji that has already been shaped.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    pub fn paint_emoji(
        &mut self,
        origin: Point<Pixels>,
        font_id: FontId,
        glyph_id: GlyphId,
        font_size: Pixels,
    ) -> Result<()> {
        self.invalidator.debug_assert_paint();

        let scale_factor = self.scale_factor();
        let glyph_origin = origin.scale(scale_factor);
        let integer_origin = glyph_origin.map(|c| ScaledPixels(round_half_toward_zero(c.0)));
        let params = RenderGlyphParams {
            font_id,
            glyph_id,
            font_size,
            subpixel_variant: Default::default(),
            scale_factor,
            is_emoji: true,
            subpixel_rendering: false,
            dilation: 0,
        };

        let raster_bounds = self.text_system().raster_bounds(&params)?;
        if !raster_bounds.is_zero() {
            let tile = self
                .sprite_atlas
                .get_or_insert_with(params.clone().into(), &mut || {
                    let (size, bytes) = self.text_system().rasterize_glyph(&params)?;
                    Ok(Some((size, Cow::Owned(bytes))))
                })?
                .expect("Callback above only errors or returns Some");

            let bounds = Bounds {
                origin: integer_origin + raster_bounds.origin.map(Into::into),
                size: tile.bounds.size.map(Into::into),
            };
            let content_mask = self.snapped_content_mask();
            let opacity = self.element_opacity();

            self.next_frame.scene.insert_primitive(PolychromeSprite {
                order: 0,
                pad: 0,
                grayscale: false.into(),
                bounds,
                corner_radii: Default::default(),
                content_mask,
                tile,
                opacity,
            });
        }
        Ok(())
    }

    /// Paint a monochrome SVG into the scene for the next frame at the current stacking context.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    pub fn paint_svg(
        &mut self,
        bounds: Bounds<Pixels>,
        path: SharedString,
        mut data: Option<&[u8]>,
        transformation: TransformationMatrix,
        color: Hsla,
        cx: &App,
    ) -> Result<()> {
        self.invalidator.debug_assert_paint();

        let element_opacity = self.element_opacity();
        let bounds = self.snap_bounds(bounds);

        let params = RenderSvgParams {
            path,
            size: bounds.size.map(|pixels| {
                DevicePixels::from((pixels.0 * SMOOTH_SVG_SCALE_FACTOR).ceil() as i32)
            }),
        };

        let Some(tile) =
            self.sprite_atlas
                .get_or_insert_with(params.clone().into(), &mut || {
                    let Some((size, bytes)) = cx.svg_renderer.render_alpha_mask(&params, data)?
                    else {
                        return Ok(None);
                    };
                    Ok(Some((size, Cow::Owned(bytes))))
                })?
        else {
            return Ok(());
        };
        let content_mask = self.snapped_content_mask();
        let svg_bounds = Bounds {
            origin: bounds.center()
                - Point::new(
                    ScaledPixels(tile.bounds.size.width.0 as f32 / SMOOTH_SVG_SCALE_FACTOR / 2.),
                    ScaledPixels(tile.bounds.size.height.0 as f32 / SMOOTH_SVG_SCALE_FACTOR / 2.),
                ),
            size: tile
                .bounds
                .size
                .map(|value| ScaledPixels(value.0 as f32 / SMOOTH_SVG_SCALE_FACTOR)),
        };
        let final_bounds = svg_bounds
            .map_origin(|value| ScaledPixels(round_half_toward_zero(value.0)))
            .map_size(|size| size.ceil());

        self.next_frame.scene.insert_primitive(MonochromeSprite {
            order: 0,
            pad: 0,
            bounds: final_bounds,
            content_mask,
            color: color.opacity(element_opacity),
            effect: SpriteEffect::default(),
            tile,
            transformation,
        });

        Ok(())
    }

    /// Paint an image into the scene for the next frame at the current z-index.
    /// This method will panic if the frame_index is not valid
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    /// Paint an image into `bounds`, positioning and scaling it according to `image_bounds`.
    ///
    /// The visible region rendered is `bounds.intersect(&image_bounds)`, with `corner_radii`
    /// applied to `bounds`.
    pub fn paint_image(
        &mut self,
        bounds: Bounds<Pixels>,
        image_bounds: Bounds<Pixels>,
        corner_radii: Corners<Pixels>,
        data: Arc<RenderImage>,
        frame_index: usize,
        grayscale: bool,
    ) -> Result<()> {
        self.invalidator.debug_assert_paint();

        let visible_bounds = bounds.intersect(&image_bounds);
        if visible_bounds.size.width <= Pixels::ZERO || visible_bounds.size.height <= Pixels::ZERO {
            return Ok(());
        }
        if image_bounds.size.width <= Pixels::ZERO || image_bounds.size.height <= Pixels::ZERO {
            return Ok(());
        }

        let params = RenderImageParams {
            image_id: data.id,
            frame_index,
        };

        let tile = self
            .sprite_atlas
            .get_or_insert_with(params.into(), &mut || {
                Ok(Some((
                    data.size(frame_index),
                    Cow::Borrowed(
                        data.as_bytes(frame_index)
                            .expect("It's the caller's job to pass a valid frame index"),
                    ),
                )))
            })?
            .expect("Callback above only returns Some");

        let visible_bounds_snapped = self.snap_bounds(visible_bounds);

        let sub_tile = if visible_bounds == image_bounds {
            tile
        } else {
            let x_offset_ratio =
                (visible_bounds.origin.x - image_bounds.origin.x) / image_bounds.size.width;
            let y_offset_ratio =
                (visible_bounds.origin.y - image_bounds.origin.y) / image_bounds.size.height;
            let width_ratio = visible_bounds.size.width / image_bounds.size.width;
            let height_ratio = visible_bounds.size.height / image_bounds.size.height;

            let tile_origin_x = tile.bounds.origin.x.0;
            let tile_origin_y = tile.bounds.origin.y.0;
            let tile_width = tile.bounds.size.width.0;
            let tile_height = tile.bounds.size.height.0;

            let sub_origin_x = tile_origin_x + (x_offset_ratio * tile_width as f32).round() as i32;
            let sub_origin_y = tile_origin_y + (y_offset_ratio * tile_height as f32).round() as i32;
            let sub_width = (width_ratio * tile_width as f32).round() as i32;
            let sub_height = (height_ratio * tile_height as f32).round() as i32;

            let max_x = tile_origin_x + tile_width;
            let max_y = tile_origin_y + tile_height;

            let clamped_origin_x = sub_origin_x.clamp(tile_origin_x, max_x);
            let clamped_origin_y = sub_origin_y.clamp(tile_origin_y, max_y);
            let clamped_width = sub_width.min(max_x - clamped_origin_x).max(0);
            let clamped_height = sub_height.min(max_y - clamped_origin_y).max(0);

            AtlasTile {
                bounds: Bounds {
                    origin: point(
                        DevicePixels(clamped_origin_x),
                        DevicePixels(clamped_origin_y),
                    ),
                    size: size(DevicePixels(clamped_width), DevicePixels(clamped_height)),
                },
                ..tile
            }
        };

        let content_mask = self.snapped_content_mask();
        let corner_radii = corner_radii
            .clamp_radii_for_quad_size(visible_bounds.size)
            .scale(self.scale_factor());
        let opacity = self.element_opacity();

        self.next_frame.scene.insert_primitive(PolychromeSprite {
            order: 0,
            pad: 0,
            grayscale: grayscale.into(),
            bounds: visible_bounds_snapped,
            content_mask,
            corner_radii,
            tile: sub_tile,
            opacity,
        });
        Ok(())
    }

    /// Paint a surface into the scene for the next frame at the current z-index.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    #[cfg(target_os = "macos")]
    pub fn paint_surface(&mut self, bounds: Bounds<Pixels>, image_buffer: CVPixelBuffer) {
        use crate::PaintSurface;

        self.invalidator.debug_assert_paint();

        let bounds = self.snap_bounds(bounds);
        let content_mask = self.snapped_content_mask();
        self.next_frame.scene.insert_primitive(PaintSurface {
            order: 0,
            bounds,
            content_mask,
            image_buffer,
        });
    }

    /// Removes an image from the sprite atlas.
    pub fn drop_image(&mut self, data: Arc<RenderImage>) -> Result<()> {
        for frame_index in 0..data.frame_count() {
            let params = RenderImageParams {
                image_id: data.id,
                frame_index,
            };

            self.sprite_atlas.remove(&params.clone().into());
        }

        Ok(())
    }

    /// Returns whether every frame of an image is present in the sprite atlas.
    #[cfg(any(test, feature = "test-support"))]
    pub fn has_image_atlas_entry(&self, data: &RenderImage) -> bool {
        data.frame_count() > 0
            && (0..data.frame_count()).all(|frame_index| {
                self.sprite_atlas.contains(
                    &RenderImageParams {
                        image_id: data.id,
                        frame_index,
                    }
                    .into(),
                )
            })
    }

    /// Add a node to the layout tree for the current frame. Takes the `Style` of the element for which
    /// layout is being requested, along with the layout ids of any children. This method is called during
    /// calls to the [`Element::request_layout`] trait method and enables any element to participate in layout.
    ///
    /// This method should only be called as part of the request_layout or prepaint phase of element drawing.
    #[must_use]
    pub fn request_layout(
        &mut self,
        style: Style,
        children: impl IntoIterator<Item = LayoutId>,
        cx: &mut App,
    ) -> LayoutId {
        self.invalidator.debug_assert_prepaint();

        cx.layout_id_buffer.clear();
        cx.layout_id_buffer.extend(children);
        let rem_size = self.rem_size();
        let scale_factor = self.scale_factor();
        self.frame_work.stats.layout_nodes += 1;

        let key = self.layout_keys.current();
        self.layout_engine.as_mut().unwrap().request_keyed_layout(
            key,
            &style,
            rem_size,
            scale_factor,
            &cx.layout_id_buffer,
        )
    }

    /// Add a node to the layout tree for the current frame. Instead of taking a `Style` and children,
    /// this variant takes a function that is invoked during layout so you can use arbitrary logic to
    /// determine the element's size. One place this is used internally is when measuring text.
    ///
    /// The given closure is invoked at layout time with the known dimensions and available space and
    /// returns a `Size`.
    ///
    /// This method should only be called as part of the request_layout or prepaint phase of element drawing.
    pub fn request_measured_layout<F>(&mut self, style: Style, measure: F) -> LayoutId
    where
        F: Fn(Size<Option<Pixels>>, Size<AvailableSpace>, &mut Window, &mut App) -> Size<Pixels>
            + 'static,
    {
        self.invalidator.debug_assert_prepaint();

        let rem_size = self.rem_size();
        let scale_factor = self.scale_factor();
        self.frame_work.stats.layout_nodes += 1;
        let key = self.layout_keys.current();
        self.layout_engine.as_mut().unwrap().request_keyed_measured_layout(
            key,
            Some(&style),
            rem_size,
            scale_factor,
            Box::new(measure),
        )
    }

    /// Adds a self-measuring leaf, as [`Self::request_measured_layout`] does,
    /// with a `key` saying what the measurement depends on, so that layout
    /// kept from the last frame can be kept on this one.
    ///
    /// A layout node kept across frames that is given a new measurement
    /// closure has to be measured again, and everything above it laid out
    /// again, unless something says the new closure measures what the old one
    /// did. `key` says so: when the element that took this node last frame
    /// asked for it with the same key (and a closure of the same type), the
    /// node is left clean, and the layout engine keeps what it computed for
    /// it and for the nodes above it. The new closure is still the one called
    /// if the engine measures the node under constraints it has not seen.
    ///
    /// When the key changed, the new closure is called here, under every
    /// constraint the engine measured the node under since it was last
    /// dirtied; if it gives every size it gave then, the node is still left
    /// clean. Only a change in size lays out the nodes above it again.
    ///
    /// The key has to cover everything the closure's result depends on: a
    /// closure returning a fixed extent can use a hash of that extent. Two
    /// closures given the same key that would measure differently leave the
    /// layout wrong; when in doubt, use [`Self::request_measured_layout`],
    /// which measures every frame.
    ///
    /// This method should only be called as part of the request_layout or prepaint phase of element drawing.
    pub fn request_measured_layout_with_key<F>(
        &mut self,
        style: Style,
        key: u64,
        measure: F,
        cx: &mut App,
    ) -> LayoutId
    where
        F: Fn(Size<Option<Pixels>>, Size<AvailableSpace>, &mut Window, &mut App) -> Size<Pixels>
            + 'static,
    {
        self.request_carried_measured_layout(
            Some(&style),
            KeyedMeasurement {
                key,
                closure: std::any::TypeId::of::<F>(),
                measure: Box::new(measure),
            },
            |measurement, previous| {
                match previous.downcast_ref::<KeyedMeasurement>() {
                    Some(previous)
                        if previous.key == measurement.key
                            && previous.closure == measurement.closure =>
                    {
                        crate::taffy::Adopted::Measurement
                    }
                    _ => crate::taffy::Adopted::No,
                }
            },
            |_| {},
            |measurement, known, available, window, cx| {
                (measurement.measure)(known, available, window, cx)
            },
            cx,
        )
    }

    /// Adds a self-measuring leaf in `style`, the default one if `None`, as
    /// [`Self::request_measured_layout`] does, whose measurement can be carried
    /// over from the element that measured the same node last frame.
    ///
    /// `adopt` is given `state` and what that element left, and takes its
    /// measurement over when it still stands; the node then stays clean, and
    /// Taffy keeps what it cached for it and the nodes above it. When the node
    /// is given `state` along with the measurement, `bind` is given it as the
    /// node will share it. Otherwise `measure` may run here, under the constraints Taffy measured the node
    /// under, to tell whether it still measures the same.
    pub(crate) fn request_carried_measured_layout<S: 'static>(
        &mut self,
        style: Option<&Style>,
        state: S,
        adopt: impl FnOnce(&S, &Rc<dyn std::any::Any>) -> crate::taffy::Adopted,
        bind: impl FnOnce(&Rc<S>),
        measure: impl Fn(&Rc<S>, Size<Option<Pixels>>, Size<AvailableSpace>, &mut Window, &mut App) -> Size<Pixels>
        + 'static,
        cx: &mut App,
    ) -> LayoutId {
        self.invalidator.debug_assert_prepaint();
        let rem_size = self.rem_size();
        let scale_factor = self.scale_factor();
        self.frame_work.stats.layout_nodes += 1;
        let key = self.layout_keys.current();
        let mut layout_engine = self.layout_engine.take().unwrap();
        let id = layout_engine.request_carried_measured_layout(
            key,
            style,
            rem_size,
            scale_factor,
            state,
            adopt,
            bind,
            measure,
            self,
            cx,
        );
        self.layout_engine = Some(layout_engine);
        id
    }

    /// Starts recording the layout nodes claimed from here on, for a view to
    /// keep them on frames it is drawn from the last one without being laid
    /// out. Returns where the recording begins; recordings nest.
    pub(crate) fn record_claimed_layout_keys(&mut self) -> usize {
        self.layout_engine
            .as_mut()
            .map_or(0, |engine| engine.record_claimed_keys())
    }

    /// Ends the recording begun at `start`, returning the keys of the layout
    /// nodes claimed while it was open.
    pub(crate) fn finish_recording_claimed_layout_keys(&mut self, start: usize) -> Vec<u64> {
        self.layout_engine
            .as_mut()
            .map(|engine| engine.finish_recording_claimed_keys(start))
            .unwrap_or_default()
    }

    /// Keeps the layout nodes under `keys` through this frame without laying
    /// them out, for the frame that lays them out again.
    pub(crate) fn keep_layout_keys(&mut self, keys: &[u64]) {
        if let Some(engine) = self.layout_engine.as_mut() {
            engine.keep_retained(keys);
        }
    }

    /// Compute the layout for the given id within the given available space.
    /// This method is called for its side effect, typically by the framework prior to painting.
    /// After calling it, you can request the bounds of the given layout node id or any descendant.
    ///
    /// This method should only be called as part of the prepaint phase of element drawing.
    pub fn compute_layout(
        &mut self,
        layout_id: LayoutId,
        available_space: Size<AvailableSpace>,
        cx: &mut App,
    ) {
        self.invalidator.debug_assert_prepaint();

        #[cfg(feature = "profiler")]
        let layout_started_at = self.draw_clock.begin_layout();
        let started_at = self.frame_work.clock();
        let mut layout_engine = self.layout_engine.take().unwrap();
        if cx.view_retention() {
            layout_engine.note_root_space(layout_id, available_space);
        }
        layout_engine.compute_layout(layout_id, available_space, self, cx);
        self.layout_engine = Some(layout_engine);
        self.frame_work.stats.compute_layout_calls += 1;
        frame_work::add_elapsed(&mut self.frame_work.stats.compute_layout_time, started_at);
        #[cfg(feature = "profiler")]
        self.end_draw_layout(layout_started_at);
    }

    /// Obtain the bounds computed for the given LayoutId relative to the window. This method will usually be invoked by
    /// GPUI itself automatically in order to pass your element its `Bounds` automatically.
    ///
    /// This method should only be called as part of element drawing.
    pub fn layout_bounds(&mut self, layout_id: LayoutId) -> Bounds<Pixels> {
        self.invalidator.debug_assert_prepaint();

        let scale_factor = self.scale_factor();
        let mut bounds = self
            .layout_engine
            .as_mut()
            .unwrap()
            .layout_bounds(layout_id, scale_factor)
            .map(Into::into);
        let snapped_offset = self.pixel_snap_point(self.element_offset());
        bounds.origin += snapped_offset;
        bounds
    }

    /// This method should be called during `prepaint`. You can use
    /// the returned [Hitbox] during `paint` or in an event handler
    /// to determine whether the inserted hitbox was the topmost.
    ///
    /// This method should only be called as part of the prepaint phase of element drawing.
    pub fn insert_hitbox(&mut self, bounds: Bounds<Pixels>, behavior: HitboxBehavior) -> Hitbox {
        self.invalidator.debug_assert_prepaint();

        let content_mask = self.content_mask();
        let mut id = self.next_hitbox_id;
        self.next_hitbox_id = self.next_hitbox_id.next();
        let hitbox = Hitbox {
            id,
            bounds,
            content_mask,
            behavior,
        };
        self.next_frame.hitboxes.push(hitbox.clone());
        hitbox
    }

    /// Set a hitbox which will act as a control area of the platform window.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    pub fn insert_window_control_hitbox(&mut self, area: WindowControlArea, hitbox: Hitbox) {
        self.invalidator.debug_assert_paint();
        self.next_frame.window_control_hitboxes.push((area, hitbox));
    }

    /// Sets the key context for the current element. This context will be used to translate
    /// keybindings into actions.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    pub fn set_key_context(&mut self, context: KeyContext) {
        self.invalidator.debug_assert_paint();
        self.next_frame.dispatch_tree.set_key_context(context);
    }

    /// Sets the focus handle for the current element. This handle will be used to manage focus state
    /// and keyboard event dispatch for the element.
    ///
    /// This method should only be called as part of the prepaint phase of element drawing.
    pub fn set_focus_handle(&mut self, focus_handle: &FocusHandle, _: &App) {
        self.invalidator.debug_assert_prepaint();
        if focus_handle.is_focused(self) {
            self.next_frame.focus = Some(focus_handle.id);
        }
        self.next_frame.dispatch_tree.set_focus_id(focus_handle.id);
    }

    /// Sets the view id for the current element, which will be used to manage view caching.
    ///
    /// This method should only be called as part of element prepaint. We plan on removing this
    /// method eventually when we solve some issues that require us to construct editor elements
    /// directly instead of always using editors via views.
    pub fn set_view_id(&mut self, view_id: EntityId) {
        self.invalidator.debug_assert_prepaint();
        self.next_frame.dispatch_tree.set_view_id(view_id);
    }

    /// Get the entity ID for the currently rendering view
    pub fn current_view(&self) -> EntityId {
        self.invalidator.debug_assert_paint_or_prepaint();
        self.rendered_entity_stack.last().copied().unwrap()
    }

    #[inline]
    pub(crate) fn with_rendered_view<R>(
        &mut self,
        id: EntityId,
        f: impl FnOnce(&mut Self) -> R,
    ) -> R {
        self.with_named_view(id, Default::default(), f)
    }

    /// Like [`Self::with_rendered_view`], naming the view for the profiler.
    #[inline]
    #[cfg_attr(not(feature = "profiler"), allow(unused_variables))]
    pub(crate) fn with_named_view<R>(
        &mut self,
        id: EntityId,
        view_name: crate::view::ViewName,
        f: impl FnOnce(&mut Self) -> R,
    ) -> R {
        self.rendered_entity_stack.push(id);
        #[cfg(feature = "profiler")]
        self.view_timer.enter();
        let result = f(self);
        #[cfg(feature = "profiler")]
        self.view_timer.exit(id, view_name);
        self.rendered_entity_stack.pop();
        result
    }

    /// Executes the provided function with the specified image cache.
    pub fn with_image_cache<F, R>(&mut self, image_cache: Option<AnyImageCache>, f: F) -> R
    where
        F: FnOnce(&mut Self) -> R,
    {
        if let Some(image_cache) = image_cache {
            self.image_cache_stack.push(image_cache);
            let result = f(self);
            self.image_cache_stack.pop();
            result
        } else {
            f(self)
        }
    }

    /// Sets an input handler, such as [`ElementInputHandler`][element_input_handler], which interfaces with the
    /// platform to receive textual input with proper integration with concerns such
    /// as IME interactions. This handler will be active for the upcoming frame until the following frame is
    /// rendered.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    ///
    /// [element_input_handler]: crate::ElementInputHandler
    pub fn handle_input(
        &mut self,
        focus_handle: &FocusHandle,
        input_handler: impl InputHandler,
        cx: &App,
    ) {
        self.invalidator.debug_assert_paint();

        if focus_handle.is_focused(self) {
            let cx = self.to_async(cx);
            self.next_frame
                .input_handlers
                .push(Some(PlatformInputHandler::new(cx, Box::new(input_handler))));
        }
    }

    /// Forwards the focused input handler's [`TextInputConfiguration`] to the
    /// platform window when it differs from the last forwarded value. With no
    /// input handler the default configuration applies, so a field's
    /// preferences don't outlive its focus.
    fn apply_text_input_configuration(&mut self, cx: &mut App) {
        let configuration = match self.platform_window.take_input_handler() {
            Some(mut input_handler) => {
                let configuration = input_handler.text_input_configuration(self, cx);
                self.platform_window.set_input_handler(input_handler);
                configuration
            }
            None => TextInputConfiguration::default(),
        };
        if self.last_text_input_configuration.as_ref() != Some(&configuration) {
            self.platform_window
                .set_text_input_configuration(configuration.clone());
            self.last_text_input_configuration = Some(configuration);
        }
    }

    /// Register a mouse event listener on the window for the next frame. The type of event
    /// is determined by the first parameter of the given listener. When the next frame is rendered
    /// the listener will be cleared.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    pub fn on_mouse_event<Event: MouseEvent>(
        &mut self,
        mut listener: impl FnMut(&Event, DispatchPhase, &mut Window, &mut App) + 'static,
    ) {
        self.invalidator.debug_assert_paint();

        self.next_frame
            .mouse_listeners
            .push(Some(MouseListener::Any(Box::new(
                move |event: &dyn Any, phase: DispatchPhase, window: &mut Window, cx: &mut App| {
                    if let Some(event) = event.downcast_ref() {
                        listener(event, phase, window, cx)
                    }
                },
            ))));
    }

    /// Register a [`HoverListener`] for the next frame, which dispatches in
    /// order with the listeners [`Self::on_mouse_event`] registers.
    pub(crate) fn on_hover_transition(&mut self, listener: HoverListener) {
        self.invalidator.debug_assert_paint();
        self.next_frame
            .mouse_listeners
            .push(Some(MouseListener::Hover(listener)));
    }

    /// Register an [`ActiveListener`] for the next frame, which dispatches in
    /// order with the listeners [`Self::on_mouse_event`] registers.
    pub(crate) fn on_press_transition(&mut self, listener: ActiveListener) {
        self.invalidator.debug_assert_paint();
        self.next_frame
            .mouse_listeners
            .push(Some(MouseListener::Active(listener)));
    }

    /// Register a key event listener on this node for the next frame. The type of event
    /// is determined by the first parameter of the given listener. When the next frame is rendered
    /// the listener will be cleared.
    ///
    /// This is a fairly low-level method, so prefer using event handlers on elements unless you have
    /// a specific need to register a listener yourself.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    pub fn on_key_event<Event: KeyEvent>(
        &mut self,
        listener: impl Fn(&Event, DispatchPhase, &mut Window, &mut App) + 'static,
    ) {
        self.invalidator.debug_assert_paint();

        self.next_frame.dispatch_tree.on_key_event(Rc::new(
            move |event: &dyn Any, phase, window: &mut Window, cx: &mut App| {
                if let Some(event) = event.downcast_ref::<Event>() {
                    listener(event, phase, window, cx)
                }
            },
        ));
    }

    /// Register a modifiers changed event listener on the window for the next frame.
    ///
    /// This is a fairly low-level method, so prefer using event handlers on elements unless you have
    /// a specific need to register a global listener.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    pub fn on_modifiers_changed(
        &mut self,
        listener: impl Fn(&ModifiersChangedEvent, &mut Window, &mut App) + 'static,
    ) {
        self.invalidator.debug_assert_paint();

        self.next_frame.dispatch_tree.on_modifiers_changed(Rc::new(
            move |event: &ModifiersChangedEvent, window: &mut Window, cx: &mut App| {
                listener(event, window, cx)
            },
        ));
    }

    /// Register a listener to be called when the given focus handle or one of its descendants receives focus.
    /// This does not fire if the given focus handle - or one of its descendants - was previously focused.
    /// Returns a subscription and persists until the subscription is dropped.
    pub fn on_focus_in(
        &mut self,
        handle: &FocusHandle,
        cx: &mut App,
        mut listener: impl FnMut(&mut Window, &mut App) + 'static,
    ) -> Subscription {
        let focus_id = handle.id;
        let (subscription, activate) =
            self.new_focus_listener(Box::new(move |event, window, cx| {
                if event.is_focus_in(focus_id) {
                    listener(window, cx);
                }
                true
            }));
        cx.defer(move |_| activate());
        subscription
    }

    /// Register a listener to be called when the given focus handle or one of its descendants loses focus.
    /// Returns a subscription and persists until the subscription is dropped.
    pub fn on_focus_out(
        &mut self,
        handle: &FocusHandle,
        cx: &mut App,
        mut listener: impl FnMut(FocusOutEvent, &mut Window, &mut App) + 'static,
    ) -> Subscription {
        let focus_id = handle.id;
        let (subscription, activate) =
            self.new_focus_listener(Box::new(move |event, window, cx| {
                if let Some(blurred_id) = event.previous_focus_path.last().copied()
                    && event.is_focus_out(focus_id)
                {
                    let event = FocusOutEvent {
                        blurred: WeakFocusHandle {
                            id: blurred_id,
                            handles: Arc::downgrade(&cx.focus_handles),
                        },
                    };
                    listener(event, window, cx)
                }
                true
            }));
        cx.defer(move |_| activate());
        subscription
    }

    fn reset_cursor_style(&self, cx: &mut App) {
        // Set the cursor only if we're the active window.
        if self.is_window_hovered() {
            let style = self
                .rendered_frame
                .cursor_style(self)
                .unwrap_or(CursorStyle::Arrow);
            cx.platform.set_cursor_style(style);
        }
    }

    /// Dispatch a given keystroke as though the user had typed it.
    /// You can create a keystroke with Keystroke::parse("").
    pub fn dispatch_keystroke(&mut self, keystroke: Keystroke, cx: &mut App) -> bool {
        let keystroke = keystroke.with_simulated_ime();
        let result = self.dispatch_event(
            PlatformInput::KeyDown(KeyDownEvent {
                keystroke: keystroke.clone(),
                is_held: false,
                prefer_character_input: false,
            }),
            cx,
        );
        if !result.propagate {
            return true;
        }

        if let Some(input) = keystroke.key_char
            && let Some(mut input_handler) = self.platform_window.take_input_handler()
        {
            input_handler.dispatch_input(&input, self, cx);
            self.platform_window.set_input_handler(input_handler);
            return true;
        }

        false
    }

    /// Return a key binding string for an action, to display in the UI. Uses the highest precedence
    /// binding for the action (last binding added to the keymap).
    pub fn keystroke_text_for(&self, action: &dyn Action) -> String {
        self.highest_precedence_binding_for_action(action)
            .map(|binding| {
                binding
                    .keystrokes()
                    .iter()
                    .map(ToString::to_string)
                    .collect::<Vec<_>>()
                    .join(" ")
            })
            .unwrap_or_else(|| action.name().to_string())
    }

    /// Dispatch a mouse, keyboard, or touch event on the window.
    #[profiling::function]
    pub fn dispatch_event(&mut self, event: PlatformInput, cx: &mut App) -> DispatchEventResult {
        #[cfg(feature = "profiler")]
        self.window_profiler.begin_input(event.kind_name());
        let update_count_before = self.invalidator.update_count();
        let ambient_before = view_retention::dependencies::AmbientInput::of(self);
        // Track input modality for focus-visible styling and hover suppression.
        // Hover is suppressed during keyboard modality so that keyboard navigation
        // doesn't show hover highlights on the item under the mouse cursor.
        let old_modality = self.last_input_modality;
        self.last_input_modality = match &event {
            PlatformInput::KeyDown(_) => InputModality::Keyboard,
            PlatformInput::MouseMove(_) | PlatformInput::MouseDown(_) => InputModality::Mouse,
            PlatformInput::Touch(_) => InputModality::Touch,
            _ => self.last_input_modality,
        };
        if self.last_input_modality != old_modality {
            self.refresh();
        }

        // Handlers may set this to false by calling `stop_propagation`.
        cx.propagate_event = true;
        // Handlers may set this to true by calling `prevent_default`.
        self.default_prevented = false;

        let event = match event {
            // Track the mouse position with our own state, since accessing the platform
            // API for the mouse position can only occur on the main thread.
            PlatformInput::MouseMove(mouse_move) => {
                self.mouse_position = mouse_move.position;
                self.modifiers = mouse_move.modifiers;
                PlatformInput::MouseMove(mouse_move)
            }
            PlatformInput::MouseDown(mouse_down) => {
                self.mouse_position = mouse_down.position;
                self.modifiers = mouse_down.modifiers;
                PlatformInput::MouseDown(mouse_down)
            }
            PlatformInput::MouseUp(mouse_up) => {
                self.mouse_position = mouse_up.position;
                self.modifiers = mouse_up.modifiers;
                PlatformInput::MouseUp(mouse_up)
            }
            PlatformInput::MousePressure(mouse_pressure) => {
                PlatformInput::MousePressure(mouse_pressure)
            }
            PlatformInput::MouseExited(mouse_exited) => {
                self.modifiers = mouse_exited.modifiers;
                PlatformInput::MouseExited(mouse_exited)
            }
            PlatformInput::ModifiersChanged(modifiers_changed) => {
                self.modifiers = modifiers_changed.modifiers;
                self.capslock = modifiers_changed.capslock;
                PlatformInput::ModifiersChanged(modifiers_changed)
            }
            PlatformInput::ScrollWheel(scroll_wheel) => {
                self.mouse_position = scroll_wheel.position;
                self.modifiers = scroll_wheel.modifiers;
                PlatformInput::ScrollWheel(scroll_wheel)
            }
            PlatformInput::Pinch(pinch) => {
                self.mouse_position = pinch.position;
                self.modifiers = pinch.modifiers;
                PlatformInput::Pinch(pinch)
            }
            // Translate dragging and dropping of external files from the operating system
            // to internal drag and drop events.
            PlatformInput::FileDrop(file_drop) => match file_drop {
                FileDropEvent::Entered { position, paths } => {
                    self.mouse_position = position;
                    let source_window = self.handle.window_id();
                    if !cx.restore_platform_drag(source_window) && cx.active_drag.is_none() {
                        cx.active_drag = Some(AnyDrag {
                            value: Arc::new(paths.clone()),
                            view: cx.new(|_| paths).into(),
                            cursor_offset: position,
                            cursor_style: None,
                            external_payload_source: None,
                        });
                    }
                    PlatformInput::MouseMove(MouseMoveEvent {
                        position,
                        pressed_button: Some(MouseButton::Left),
                        modifiers: Modifiers::default(),
                    })
                }
                FileDropEvent::Pending { position } => {
                    self.mouse_position = position;
                    PlatformInput::MouseMove(MouseMoveEvent {
                        position,
                        pressed_button: Some(MouseButton::Left),
                        modifiers: Modifiers::default(),
                    })
                }
                FileDropEvent::Submit { position } => {
                    cx.activate(true);
                    self.mouse_position = position;
                    PlatformInput::MouseUp(MouseUpEvent {
                        button: MouseButton::Left,
                        position,
                        modifiers: Modifiers::default(),
                        click_count: 1,
                    })
                }
                FileDropEvent::Exited => {
                    if !cx.hand_restored_drag_to_platform(self.handle.window_id()) {
                        cx.active_drag.take();
                    }
                    self.refresh();
                    PlatformInput::FileDrop(FileDropEvent::Exited)
                }
                FileDropEvent::Ended => {
                    cx.end_platform_drag(self.handle.window_id());
                    self.refresh();
                    PlatformInput::FileDrop(FileDropEvent::Ended)
                }
            },
            PlatformInput::Touch(touch) => PlatformInput::Touch(touch),
            PlatformInput::LongPress(long_press) => {
                self.mouse_position = if long_press.phase == crate::TouchPhase::Started {
                    long_press.start_position
                } else {
                    long_press.position
                };
                if long_press.phase == crate::TouchPhase::Started {
                    self.long_press_capture = None;
                }
                PlatformInput::LongPress(long_press)
            }
            PlatformInput::TouchDrag(touch_drag) => {
                self.mouse_position = touch_drag.start_position;
                PlatformInput::TouchDrag(touch_drag)
            }
            PlatformInput::KeyDown(_) | PlatformInput::KeyUp(_) => event,
        };
        ambient_before.stamp_changes(self, cx);

        // Views drawn again moved since they were built still have their
        // mouse listeners answer for where they were: they are built before
        // anything but a wheel or a key reaches them.
        if !matches!(
            event,
            PlatformInput::ScrollWheel(_) | PlatformInput::KeyDown(_) | PlatformInput::KeyUp(_)
        ) {
            self.settle_moved_views(cx);
        }

        if let Some(any_mouse_event) = event.mouse_event() {
            self.dispatch_mouse_event(any_mouse_event, cx);
        } else if let Some(any_key_event) = event.keyboard_event() {
            self.dispatch_key_event(any_key_event, cx);
        } else if let Some(touch_event) = event.touch_event() {
            self.dispatch_touch_event(touch_event, cx);
        }
        if let PlatformInput::LongPress(long_press) = &event {
            match long_press.phase {
                crate::TouchPhase::Started if !self.default_prevented => {
                    self.long_press_capture = None;
                }
                crate::TouchPhase::Ended | crate::TouchPhase::Cancelled => {
                    self.long_press_capture = None;
                }
                crate::TouchPhase::Started | crate::TouchPhase::Moved => {}
            }
        }

        // Must run after the move is dispatched: the platform owns the gesture afterwards, so this
        // is the last chance for drag listeners to see the pointer leave and reset their state.
        self.promote_external_drag_to_platform(&event, cx);

        let caused_invalidation = self.invalidator.update_count() > update_count_before;
        if caused_invalidation {
            self.input_rate_tracker.borrow_mut().record_input();
        }
        #[cfg(feature = "profiler")]
        self.window_profiler.end_input(caused_invalidation);

        DispatchEventResult {
            propagate: cx.propagate_event,
            default_prevented: self.default_prevented,
        }
    }

    fn promote_external_drag_to_platform(&mut self, event: &PlatformInput, cx: &mut App) {
        let PlatformInput::MouseMove(mouse_move) = event else {
            return;
        };
        if mouse_move.pressed_button != Some(MouseButton::Left) {
            return;
        }
        if Bounds::new(Point::default(), self.viewport_size).contains(&mouse_move.position) {
            return;
        }
        if !self.platform_window.can_start_external_drag() {
            return;
        }
        let Some(payload_source) = cx
            .active_drag
            .as_mut()
            .and_then(|drag| drag.external_payload_source.take())
        else {
            return;
        };
        let Some(payload) = payload_source(self, cx) else {
            return;
        };
        if self.platform_window.start_external_drag(&payload)
            && cx.hand_active_drag_to_platform(self.handle.window_id())
        {
            self.refresh();
        }
    }

    /// Whether recognized touch pans may use the platform's predicted touch
    /// positions ([`TouchEvent::predicted_position`]) to compensate for input
    /// latency. Defaults to true.
    pub fn touch_prediction_enabled(&self) -> bool {
        self.touch_prediction_enabled
    }

    /// Sets whether recognized touch pans may use the platform's predicted
    /// touch positions. Disabling drops [`TouchEvent::predicted_position`]
    /// before gesture recognition, so pans track only raw touch positions.
    pub fn set_touch_prediction_enabled(&mut self, enabled: bool) {
        self.touch_prediction_enabled = enabled;
    }

    /// Runs the portable gesture recognizer over a raw touch event and
    /// dispatches whatever it resolves (scroll steps, synthesized taps)
    /// through the ordinary mouse-event path.
    fn dispatch_touch_event(&mut self, event: &TouchEvent, cx: &mut App) {
        let mut event = event.clone();
        if !self.touch_prediction_enabled {
            event.predicted_position = None;
        }
        let recognized_gestures = self.touch_gestures.handle_event(&event);
        if event.phase == crate::TouchPhase::Started
            && let Some(touch_drag) = self.touch_gestures.offer_touch_drag(event.id)
        {
            self.dispatch_recognized_touch_gesture(touch_drag, cx);
        }
        if event.phase == crate::TouchPhase::Started
            && self.touch_gestures.pending_long_press().is_some()
        {
            self.long_press_capture = None;
        }
        let mut tapped = false;
        for gesture in recognized_gestures {
            tapped |= matches!(gesture, RecognizedTouchGesture::Tap { .. });
            self.dispatch_recognized_touch_gesture(gesture, cx);
        }
        if event.phase == crate::TouchPhase::Started {
            self.schedule_long_press_timer(cx);
        } else if self.touch_gestures.pending_long_press().is_none() {
            self.long_press_timer.take();
        }
        // The platform's touch-release handler may inspect the input handler
        // as soon as this dispatch returns (the web platform decides virtual
        // keyboard visibility there, inside the user gesture). Input handlers
        // are registered during draw, so draw now to make them reflect any
        // focus change the tap just caused.
        if tapped && self.invalidator.is_dirty() {
            self.draw(cx).clear(cx);
            // This draw is presented by the next frame request.
            self.invalidator.wake_platform();
        }
        if self.touch_gestures.has_momentum() {
            self.schedule_touch_momentum_tick();
        }
    }

    fn dispatch_recognized_touch_gesture(&mut self, gesture: RecognizedTouchGesture, cx: &mut App) {
        match gesture {
            RecognizedTouchGesture::Scroll(scroll_wheel) => {
                self.mouse_position = scroll_wheel.position;
                cx.propagate_event = true;
                self.dispatch_mouse_event(&scroll_wheel, cx);
            }
            RecognizedTouchGesture::Tap { down, up } => {
                self.mouse_position = up.position;
                cx.propagate_event = true;
                self.dispatch_mouse_event(&down, cx);
                cx.propagate_event = true;
                self.dispatch_mouse_event(&up, cx);
            }
            RecognizedTouchGesture::TouchDrag(touch_drag) => {
                self.mouse_position = touch_drag.start_position;
                cx.propagate_event = true;
                self.default_prevented = false;
                let started = touch_drag.phase == crate::TouchPhase::Started;
                self.dispatch_mouse_event(&touch_drag, cx);
                if started {
                    self.touch_gestures
                        .resolve_touch_drag(self.default_prevented);
                }
            }
            RecognizedTouchGesture::LongPress(long_press) => {
                self.mouse_position = if long_press.phase == crate::TouchPhase::Started {
                    long_press.start_position
                } else {
                    long_press.position
                };
                cx.propagate_event = true;
                self.default_prevented = false;
                let started = long_press.phase == crate::TouchPhase::Started;
                let ended = matches!(
                    long_press.phase,
                    crate::TouchPhase::Ended | crate::TouchPhase::Cancelled
                );
                self.dispatch_mouse_event(&long_press, cx);
                if started {
                    let claimed = self.default_prevented;
                    self.touch_gestures.resolve_long_press(claimed);
                    if !claimed {
                        self.long_press_capture = None;
                    }
                }
                if ended {
                    self.long_press_capture = None;
                }
            }
        }
    }

    fn schedule_long_press_timer(&mut self, cx: &mut App) {
        self.long_press_timer.take();
        let Some((touch_id, duration)) = self.touch_gestures.pending_long_press() else {
            return;
        };
        self.long_press_timer = Some(self.spawn(cx, async move |cx| {
            cx.background_executor.timer(duration).await;
            cx.update(move |window, cx| {
                window.long_press_timer.take();
                if let Some(gesture) = window.touch_gestures.offer_long_press(touch_id) {
                    window.dispatch_recognized_touch_gesture(gesture, cx);
                }
            })
            .log_err();
        }));
    }

    fn schedule_touch_momentum_tick(&mut self) {
        self.on_next_frame(|window, cx| {
            if let Some(gesture) = window.touch_gestures.tick_momentum() {
                window.dispatch_recognized_touch_gesture(gesture, cx);
            }
            if window.touch_gestures.has_momentum() {
                window.schedule_touch_momentum_tick();
            }
        });
    }

    fn dispatch_mouse_event(&mut self, event: &dyn Any, cx: &mut App) {
        let hit_test = self.rendered_frame.hit_test(self.mouse_position());
        if hit_test != self.mouse_hit_test {
            self.mouse_hit_test = hit_test;
            self.reset_cursor_style(cx);
        }

        #[cfg(any(feature = "inspector", debug_assertions))]
        if self.is_inspector_picking(cx) {
            self.handle_inspector_mouse_event(event, cx);
            // When inspector is picking, all other mouse handling is skipped.
            return;
        }

        let mut mouse_listeners = mem::take(&mut self.rendered_frame.mouse_listeners);

        // Capture phase, events bubble from back to front. Handlers for this phase are used for
        // special purposes, such as detecting events outside of a given Bounds.
        for listener in &mut mouse_listeners {
            let listener = listener.as_mut().unwrap();
            listener.dispatch(event, DispatchPhase::Capture, self, cx);
            if !cx.propagate_event {
                break;
            }
        }

        // Bubble phase, where most normal handlers do their work.
        if cx.propagate_event {
            for listener in mouse_listeners.iter_mut().rev() {
                let listener = listener.as_mut().unwrap();
                listener.dispatch(event, DispatchPhase::Bubble, self, cx);
                if !cx.propagate_event {
                    break;
                }
            }
        }

        self.rendered_frame.mouse_listeners = mouse_listeners;

        if cx.has_active_drag() {
            if event.is::<MouseMoveEvent>() {
                // If this was a mouse move event, redraw the window so that the
                // active drag can follow the mouse cursor.
                self.refresh();
            } else if event.is::<MouseUpEvent>() {
                // If this was a mouse up event, cancel the active drag and redraw
                // the window.
                cx.active_drag = None;
                self.refresh();
            }
        }

        // Auto-release pointer capture on mouse up
        if event.is::<MouseUpEvent>() && self.captured_hitbox.is_some() {
            self.captured_hitbox = None;
        }
    }

    fn dispatch_key_event(&mut self, event: &dyn Any, cx: &mut App) {
        if self.invalidator.is_dirty() {
            self.draw(cx).clear(cx);
            // This draw is presented by the next frame request.
            self.invalidator.wake_platform();
        }

        let node_id = self.focus_node_id_in_rendered_frame(self.focus);
        let dispatch_path = self.rendered_frame.dispatch_tree.dispatch_path(node_id);

        let mut keystroke: Option<Keystroke> = None;

        if let Some(event) = event.downcast_ref::<ModifiersChangedEvent>() {
            if event.modifiers.number_of_modifiers() == 0
                && self.pending_modifier.modifiers.number_of_modifiers() == 1
                && !self.pending_modifier.saw_other_input
            {
                let key = match self.pending_modifier.modifiers {
                    modifiers if modifiers.shift => Some("shift"),
                    modifiers if modifiers.control => Some("control"),
                    modifiers if modifiers.alt => Some("alt"),
                    modifiers if modifiers.platform => Some("platform"),
                    modifiers if modifiers.function => Some("function"),
                    _ => None,
                };
                if let Some(key) = key {
                    keystroke = Some(Keystroke {
                        key: key.to_string(),
                        key_char: None,
                        modifiers: Modifiers::default(),
                    });
                }
            }

            if self.pending_modifier.modifiers.number_of_modifiers() == 0
                && event.modifiers.number_of_modifiers() == 1
            {
                self.pending_modifier.saw_other_input = false
            } else if event.modifiers.number_of_modifiers() > 1 {
                self.pending_modifier.saw_other_input = true
            }
            self.pending_modifier.modifiers = event.modifiers
        } else if let Some(key_down_event) = event.downcast_ref::<KeyDownEvent>() {
            self.pending_modifier.saw_other_input = true;
            keystroke = Some(key_down_event.keystroke.clone());
            if key_down_event.keystroke.key_char.is_some()
                && matches!(
                    cx.cursor_hide_mode,
                    CursorHideMode::OnTyping | CursorHideMode::OnTypingAndAction
                )
            {
                cx.platform.hide_cursor_until_mouse_moves();
            }
        }

        let Some(keystroke) = keystroke else {
            self.finish_dispatch_key_event(event, None, dispatch_path, self.context_stack(), cx);
            return;
        };

        cx.propagate_event = true;
        self.dispatch_keystroke_interceptors(&keystroke, self.context_stack(), cx);
        if !cx.propagate_event {
            self.finish_dispatch_key_event(
                event,
                Some(&keystroke),
                dispatch_path,
                self.context_stack(),
                cx,
            );
            return;
        }

        let mut currently_pending = self.pending_input.take().unwrap_or_default();
        if currently_pending.focus.is_some() && currently_pending.focus != self.focus {
            currently_pending = PendingInput::default();
        }

        let match_result = self.rendered_frame.dispatch_tree.dispatch_key(
            currently_pending.keystrokes,
            keystroke.clone(),
            &dispatch_path,
        );

        if !match_result.to_replay.is_empty() {
            self.replay_pending_input(match_result.to_replay, cx);
            cx.propagate_event = true;
        }

        if !match_result.pending.is_empty() {
            let previous_timeout = currently_pending.timeout.take();
            currently_pending.keystrokes = match_result.pending;
            currently_pending.focus = self.focus;

            let text_input_requires_timeout = event
                .downcast_ref::<KeyDownEvent>()
                .filter(|key_down| key_down.keystroke.key_char.is_some())
                .and_then(|_| self.platform_window.take_input_handler())
                .map_or(false, |mut input_handler| {
                    let accepts = input_handler.accepts_text_input(self, cx);
                    self.platform_window.set_input_handler(input_handler);
                    accepts
                });

            let needs_timeout = previous_timeout.is_some()
                || match_result.pending_has_binding
                || text_input_requires_timeout;
            currently_pending.timeout = if needs_timeout {
                match previous_timeout {
                    Some(mut timeout) if timeout.is_paused() => {
                        timeout.reset_duration(PENDING_INPUT_TIMEOUT);
                        Some(timeout)
                    }
                    previous_timeout => {
                        drop(previous_timeout);
                        Some(self.new_pending_input_timeout(PENDING_INPUT_TIMEOUT, cx))
                    }
                }
            } else {
                None
            };
            self.pending_input = Some(currently_pending);
            self.pending_input_changed(cx);
            cx.propagate_event = false;
            return;
        }

        let skip_bindings = event
            .downcast_ref::<KeyDownEvent>()
            .filter(|key_down_event| key_down_event.prefer_character_input)
            .map(|_| {
                self.platform_window
                    .take_input_handler()
                    .map_or(false, |mut input_handler| {
                        let accepts = input_handler.accepts_text_input(self, cx);
                        self.platform_window.set_input_handler(input_handler);
                        // If modifiers are not excessive (e.g. AltGr), and the input handler is accepting text input,
                        // we prefer the text input over bindings.
                        accepts
                    })
            })
            .unwrap_or(false);

        if !skip_bindings {
            for binding in match_result.bindings {
                self.dispatch_action_on_node(node_id, binding.action.as_ref(), cx);
                if !cx.propagate_event {
                    self.dispatch_keystroke_observers(
                        &keystroke,
                        Some(binding.action.as_ref()),
                        match_result.context_stack,
                        cx,
                    );
                    self.pending_input_changed(cx);
                    return;
                }
            }
        }

        self.finish_dispatch_key_event(
            event,
            Some(&keystroke),
            dispatch_path,
            match_result.context_stack,
            cx,
        );
        self.pending_input_changed(cx);
    }

    fn new_pending_input_timeout(&self, duration: Duration, cx: &App) -> PendingInputTimeout {
        let (started_at, task) = self.start_pending_input_timeout(duration, cx);
        PendingInputTimeout {
            duration,
            remaining: duration,
            state: PendingInputTimeoutState::Running { started_at, task },
        }
    }

    fn start_pending_input_timeout(&self, remaining: Duration, cx: &App) -> (Instant, Task<()>) {
        let started_at = cx.background_executor().now();
        let task = self.spawn(cx, async move |cx| {
            cx.background_executor.timer(remaining).await;
            cx.update(move |window, cx| {
                let Some(currently_pending) = window
                    .pending_input
                    .take()
                    .filter(|pending| pending.focus == window.focus)
                else {
                    return;
                };

                let node_id = window.focus_node_id_in_rendered_frame(window.focus);
                let dispatch_path = window.rendered_frame.dispatch_tree.dispatch_path(node_id);

                let to_replay = window
                    .rendered_frame
                    .dispatch_tree
                    .flush_dispatch(currently_pending.keystrokes, &dispatch_path);

                window.pending_input_changed(cx);
                window.replay_pending_input(to_replay, cx)
            })
            .log_err();
        });
        (started_at, task)
    }

    fn finish_dispatch_key_event(
        &mut self,
        event: &dyn Any,
        recognized_keystroke: Option<&Keystroke>,
        dispatch_path: SmallVec<[DispatchNodeId; 32]>,
        context_stack: Vec<KeyContext>,
        cx: &mut App,
    ) {
        self.dispatch_key_down_up_event(event, &dispatch_path, cx);
        if !cx.propagate_event {
            return;
        }

        self.dispatch_modifiers_changed_event(event, &dispatch_path, cx);
        if !cx.propagate_event {
            return;
        }

        if let Some(keystroke) = recognized_keystroke {
            self.dispatch_keystroke_observers(keystroke, None, context_stack, cx);
        }
    }

    pub(crate) fn pending_input_changed(&mut self, cx: &mut App) {
        self.pending_input_observers
            .clone()
            .retain(&(), |callback| callback(self, cx));
    }

    fn defer_pending_input_changed(&self, cx: &mut App) {
        // Avoid re-entrant entity updates by deferring observer notifications to the end of the
        // current effect cycle, and only for this window.
        let window_handle = self.handle;
        cx.defer(move |cx| {
            window_handle
                .update(cx, |_, window, cx| {
                    window.pending_input_changed(cx);
                })
                .ok();
        });
    }

    fn dispatch_key_down_up_event(
        &mut self,
        event: &dyn Any,
        dispatch_path: &SmallVec<[DispatchNodeId; 32]>,
        cx: &mut App,
    ) {
        // Capture phase
        for node_id in dispatch_path {
            let node = self.rendered_frame.dispatch_tree.node(*node_id);

            for key_listener in node.key_listeners.clone() {
                key_listener(event, DispatchPhase::Capture, self, cx);
                if !cx.propagate_event {
                    return;
                }
            }
        }

        // Bubble phase
        for node_id in dispatch_path.iter().rev() {
            // Handle low level key events
            let node = self.rendered_frame.dispatch_tree.node(*node_id);
            for key_listener in node.key_listeners.clone() {
                key_listener(event, DispatchPhase::Bubble, self, cx);
                if !cx.propagate_event {
                    return;
                }
            }
        }
    }

    fn dispatch_modifiers_changed_event(
        &mut self,
        event: &dyn Any,
        dispatch_path: &SmallVec<[DispatchNodeId; 32]>,
        cx: &mut App,
    ) {
        let Some(event) = event.downcast_ref::<ModifiersChangedEvent>() else {
            return;
        };
        for node_id in dispatch_path.iter().rev() {
            let node = self.rendered_frame.dispatch_tree.node(*node_id);
            for listener in node.modifiers_changed_listeners.clone() {
                listener(event, self, cx);
                if !cx.propagate_event {
                    return;
                }
            }
        }
    }

    /// Determine whether a potential multi-stroke key binding is in progress on this window.
    pub fn has_pending_keystrokes(&self) -> bool {
        self.pending_input().is_some()
    }

    #[cfg(test)]
    pub(crate) fn pending_input_is_none(&self) -> bool {
        self.pending_input.is_none()
    }

    pub(crate) fn clear_pending_keystrokes(&mut self, cx: &mut App) {
        if self.pending_input.take().is_some() {
            self.defer_pending_input_changed(cx);
        }
    }

    /// Returns pending input that can still complete a multi-stroke key binding. Input left over
    /// from a previous focus can never complete one.
    pub fn pending_input(&self) -> Option<PendingInputStatus<'_>> {
        self.pending_input
            .as_ref()
            .filter(|pending_input| pending_input.focus == self.focus)
            .map(|pending_input| PendingInputStatus {
                keystrokes: pending_input.keystrokes.as_slice(),
                timeout: pending_input
                    .timeout
                    .as_ref()
                    .map(PendingInputTimeout::status),
            })
    }

    /// Pauses or resumes the current pending input timeout on behalf of `owner`.
    ///
    /// A paused timeout resumes automatically if `owner` is released. Returns whether the timeout
    /// state changed. A timeout paused by one owner cannot be resumed by another.
    pub fn set_pending_input_timeout_paused<T: 'static>(
        &mut self,
        owner: &Entity<T>,
        paused: bool,
        cx: &mut App,
    ) -> bool {
        let owner_id = owner.entity_id();
        if !paused {
            return self.resume_pending_input_timeout(owner_id, cx);
        }

        let timeout = self
            .pending_input
            .as_ref()
            .filter(|pending_input| pending_input.focus == self.focus)
            .and_then(|pending_input| pending_input.timeout.as_ref());
        let Some(timeout) = timeout else {
            return false;
        };
        if timeout.is_paused() {
            return false;
        }

        let release_subscription = self.observe_release(owner, cx, move |_, window, cx| {
            window.resume_pending_input_timeout(owner_id, cx);
        });
        let now = cx.background_executor().now();
        let changed = self
            .pending_input
            .as_mut()
            .filter(|pending_input| pending_input.focus == self.focus)
            .and_then(|pending_input| pending_input.timeout.as_mut())
            .is_some_and(|timeout| {
                timeout.pause(
                    PendingInputTimeoutPause {
                        owner_id,
                        _release_subscription: release_subscription,
                    },
                    now,
                )
            });

        if changed {
            self.defer_pending_input_changed(cx);
        }
        changed
    }

    fn resume_pending_input_timeout(&mut self, owner_id: EntityId, cx: &mut App) -> bool {
        let Some(remaining) = self
            .pending_input
            .as_ref()
            .and_then(|pending_input| pending_input.timeout.as_ref())
            .filter(|timeout| timeout.pause_owner_id() == Some(owner_id))
            .map(|timeout| timeout.remaining)
        else {
            return false;
        };

        let (started_at, task) = self.start_pending_input_timeout(remaining, cx);
        let changed = self
            .pending_input
            .as_mut()
            .and_then(|pending_input| pending_input.timeout.as_mut())
            .is_some_and(|timeout| timeout.resume(owner_id, started_at, task));

        if changed {
            self.defer_pending_input_changed(cx);
        }
        changed
    }

    /// Returns the currently pending input keystrokes that might result in a multi-stroke key binding.
    pub fn pending_input_keystrokes(&self) -> Option<&[Keystroke]> {
        self.pending_input()
            .map(|pending_input| pending_input.keystrokes())
    }

    fn replay_pending_input(&mut self, replays: SmallVec<[Replay; 1]>, cx: &mut App) {
        let node_id = self.focus_node_id_in_rendered_frame(self.focus);
        let dispatch_path = self.rendered_frame.dispatch_tree.dispatch_path(node_id);

        'replay: for replay in replays {
            let event = KeyDownEvent {
                keystroke: replay.keystroke.clone(),
                is_held: false,
                prefer_character_input: true,
            };

            cx.propagate_event = true;
            for binding in replay.bindings {
                self.dispatch_action_on_node(node_id, binding.action.as_ref(), cx);
                if !cx.propagate_event {
                    self.dispatch_keystroke_observers(
                        &replay.keystroke,
                        Some(binding.action.as_ref()),
                        Vec::default(),
                        cx,
                    );
                    continue 'replay;
                }
            }

            self.dispatch_key_down_up_event(&event, &dispatch_path, cx);
            if !cx.propagate_event {
                continue 'replay;
            }
            if let Some(input) = replay.keystroke.key_char.as_ref().cloned()
                && let Some(mut input_handler) = self.platform_window.take_input_handler()
            {
                input_handler.dispatch_input(&input, self, cx);
                self.platform_window.set_input_handler(input_handler)
            }
        }
    }

    fn focus_node_id_in_rendered_frame(&self, focus_id: Option<FocusId>) -> DispatchNodeId {
        focus_id
            .and_then(|focus_id| {
                self.rendered_frame
                    .dispatch_tree
                    .focusable_node_id(focus_id)
            })
            .unwrap_or_else(|| self.rendered_frame.dispatch_tree.root_node_id())
    }

    fn dispatch_action_on_node(
        &mut self,
        node_id: DispatchNodeId,
        action: &dyn Action,
        cx: &mut App,
    ) {
        self.dispatch_action_on_node_inner(node_id, action, cx);

        if !cx.propagate_event
            && cx.cursor_hide_mode == CursorHideMode::OnTypingAndAction
            && self.last_input_was_keyboard()
        {
            cx.platform.hide_cursor_until_mouse_moves();
        }
    }

    fn dispatch_action_on_node_inner(
        &mut self,
        node_id: DispatchNodeId,
        action: &dyn Action,
        cx: &mut App,
    ) {
        let dispatch_path = self.rendered_frame.dispatch_tree.dispatch_path(node_id);

        // Capture phase for global actions.
        cx.propagate_event = true;
        if let Some(mut global_listeners) = cx
            .global_action_listeners
            .remove(&action.as_any().type_id())
        {
            for listener in &global_listeners {
                #[cfg(feature = "profiler")]
                self.window_profiler.begin_action_handler(action, cx);
                listener(action.as_any(), DispatchPhase::Capture, cx);
                #[cfg(feature = "profiler")]
                self.window_profiler.end_action_handler();
                if !cx.propagate_event {
                    break;
                }
            }

            global_listeners.extend(
                cx.global_action_listeners
                    .remove(&action.as_any().type_id())
                    .unwrap_or_default(),
            );

            cx.global_action_listeners
                .insert(action.as_any().type_id(), global_listeners);
        }

        if !cx.propagate_event {
            return;
        }

        // Capture phase for window actions.
        for node_id in &dispatch_path {
            let node = self.rendered_frame.dispatch_tree.node(*node_id);
            for DispatchActionListener {
                action_type,
                listener,
            } in node.action_listeners.clone()
            {
                let any_action = action.as_any();
                if action_type == any_action.type_id() {
                    #[cfg(feature = "profiler")]
                    self.window_profiler.begin_action_handler(action, cx);
                    listener(any_action, DispatchPhase::Capture, self, cx);
                    #[cfg(feature = "profiler")]
                    self.window_profiler.end_action_handler();

                    if !cx.propagate_event {
                        return;
                    }
                }
            }
        }

        // Bubble phase for window actions.
        for node_id in dispatch_path.iter().rev() {
            let node = self.rendered_frame.dispatch_tree.node(*node_id);
            for DispatchActionListener {
                action_type,
                listener,
            } in node.action_listeners.clone()
            {
                let any_action = action.as_any();
                if action_type == any_action.type_id() {
                    cx.propagate_event = false; // Actions stop propagation by default during the bubble phase
                    #[cfg(feature = "profiler")]
                    self.window_profiler.begin_action_handler(action, cx);
                    listener(any_action, DispatchPhase::Bubble, self, cx);
                    #[cfg(feature = "profiler")]
                    self.window_profiler.end_action_handler();

                    if !cx.propagate_event {
                        return;
                    }
                }
            }
        }

        // Bubble phase for global actions.
        if let Some(mut global_listeners) = cx
            .global_action_listeners
            .remove(&action.as_any().type_id())
        {
            for listener in global_listeners.iter().rev() {
                cx.propagate_event = false; // Actions stop propagation by default during the bubble phase

                #[cfg(feature = "profiler")]
                self.window_profiler.begin_action_handler(action, cx);
                listener(action.as_any(), DispatchPhase::Bubble, cx);
                #[cfg(feature = "profiler")]
                self.window_profiler.end_action_handler();
                if !cx.propagate_event {
                    break;
                }
            }

            global_listeners.extend(
                cx.global_action_listeners
                    .remove(&action.as_any().type_id())
                    .unwrap_or_default(),
            );

            cx.global_action_listeners
                .insert(action.as_any().type_id(), global_listeners);
        }
    }

    /// Register the given handler to be invoked whenever the global of the given type
    /// is updated.
    pub fn observe_global<G: Global>(
        &mut self,
        cx: &mut App,
        f: impl Fn(&mut Window, &mut App) + 'static,
    ) -> Subscription {
        let window_handle = self.handle;
        let (subscription, activate) = cx.global_observers.insert(
            TypeId::of::<G>(),
            Box::new(move |cx| {
                window_handle
                    .update(cx, |_, window, cx| f(window, cx))
                    .is_ok()
            }),
        );
        cx.defer(move |_| activate());
        subscription
    }

    /// Focus the current window and bring it to the foreground at the platform level.
    pub fn activate_window(&self) {
        self.platform_window.activate();
    }

    /// Requests that the operating system draw attention to this window.
    pub fn request_attention(&self) {
        self.platform_window.request_attention();
    }

    /// Minimize the current window at the platform level.
    pub fn minimize_window(&self) {
        self.platform_window.minimize();
    }

    /// Toggle full screen status on the current window at the platform level.
    pub fn toggle_fullscreen(&self) {
        self.platform_window.toggle_fullscreen();
    }

    /// Toggle simple (borderless) fullscreen, where the window covers the entire
    /// screen including the menu bar and, on notched displays, the area around the
    /// notch. Unlike [`Window::toggle_fullscreen`], this does not move the window
    /// into its own Mission Control space. Only has an effect on macOS.
    pub fn toggle_simple_fullscreen(&self) {
        self.platform_window.toggle_simple_fullscreen();
    }

    /// Updates the IME panel position suggestions for languages like japanese, chinese.
    pub fn invalidate_character_coordinates(&self) {
        self.on_next_frame(|window, cx| {
            if let Some(mut input_handler) = window.platform_window.take_input_handler() {
                if let Some(bounds) = input_handler.selected_bounds(window, cx) {
                    window.platform_window.update_ime_position(bounds);
                }
                window.platform_window.set_input_handler(input_handler);
            }
        });
    }

    /// Present a platform dialog.
    /// The provided message will be presented, along with buttons for each answer.
    /// When a button is clicked, the returned Receiver will receive the index of the clicked button.
    pub fn prompt<T>(
        &mut self,
        level: PromptLevel,
        message: &str,
        detail: Option<&str>,
        answers: &[T],
        cx: &mut App,
    ) -> oneshot::Receiver<usize>
    where
        T: Clone + Into<PromptButton>,
    {
        let prompt_builder = cx.prompt_builder.take();
        let Some(prompt_builder) = prompt_builder else {
            unreachable!("Re-entrant window prompting is not supported by GPUI");
        };

        let answers = answers
            .iter()
            .map(|answer| answer.clone().into())
            .collect::<Vec<_>>();

        let receiver = match &prompt_builder {
            PromptBuilder::Default => self
                .platform_window
                .prompt(level, message, detail, &answers)
                .unwrap_or_else(|| {
                    self.build_custom_prompt(&prompt_builder, level, message, detail, &answers, cx)
                }),
            PromptBuilder::Custom(_) => {
                self.build_custom_prompt(&prompt_builder, level, message, detail, &answers, cx)
            }
        };

        cx.prompt_builder = Some(prompt_builder);

        receiver
    }

    fn build_custom_prompt(
        &mut self,
        prompt_builder: &PromptBuilder,
        level: PromptLevel,
        message: &str,
        detail: Option<&str>,
        answers: &[PromptButton],
        cx: &mut App,
    ) -> oneshot::Receiver<usize> {
        let (sender, receiver) = oneshot::channel();
        let handle = PromptHandle::new(sender);
        let handle = (prompt_builder)(level, message, detail, answers, handle, self, cx);
        self.prompt = Some(handle);
        receiver
    }

    /// Returns whether a prompt rendered by GPUI is currently active in this window.
    ///
    /// This is only true for prompts rendered in the window (see
    /// [`App::set_prompt_builder`]), not for platform-native prompt dialogs.
    pub fn has_active_prompt(&self) -> bool {
        self.prompt.is_some()
    }

    /// Returns the current context stack.
    pub fn context_stack(&self) -> Vec<KeyContext> {
        self.note_actions_read();
        let node_id = self.focus_node_id_in_rendered_frame(self.focus);
        let dispatch_tree = &self.rendered_frame.dispatch_tree;
        dispatch_tree
            .dispatch_path(node_id)
            .iter()
            .filter_map(move |&node_id| dispatch_tree.node(node_id).context.clone())
            .collect()
    }

    /// Returns all available actions for the focused element.
    pub fn available_actions(&self, cx: &App) -> Vec<Box<dyn Action>> {
        self.note_actions_read();
        let node_id = self.focus_node_id_in_rendered_frame(self.focus);
        let mut actions = self.rendered_frame.dispatch_tree.available_actions(node_id);
        for action_type in cx.global_action_listeners.keys() {
            if let Err(ix) = actions.binary_search_by_key(action_type, |a| a.as_any().type_id()) {
                let action = cx.actions.build_action_type(action_type).ok();
                if let Some(action) = action {
                    actions.insert(ix, action);
                }
            }
        }
        actions
    }

    /// Returns key bindings that invoke an action on the currently focused element. Bindings are
    /// returned in the order they were added. For display, the last binding should take precedence.
    pub fn bindings_for_action(&self, action: &dyn Action) -> Vec<KeyBinding> {
        self.note_actions_read();
        self.rendered_frame
            .dispatch_tree
            .bindings_for_action(action, &self.rendered_frame.dispatch_tree.context_stack)
    }

    /// Returns the highest precedence key binding that invokes an action on the currently focused
    /// element. This is more efficient than getting the last result of `bindings_for_action`.
    pub fn highest_precedence_binding_for_action(&self, action: &dyn Action) -> Option<KeyBinding> {
        self.note_actions_read();
        self.rendered_frame
            .dispatch_tree
            .highest_precedence_binding_for_action(
                action,
                &self.rendered_frame.dispatch_tree.context_stack,
            )
    }

    /// Returns the key bindings for an action in a context.
    pub fn bindings_for_action_in_context(
        &self,
        action: &dyn Action,
        context: KeyContext,
    ) -> Vec<KeyBinding> {
        self.note_actions_read();
        let dispatch_tree = &self.rendered_frame.dispatch_tree;
        dispatch_tree.bindings_for_action(action, &[context])
    }

    /// Returns the highest precedence key binding for an action in a context. This is more
    /// efficient than getting the last result of `bindings_for_action_in_context`.
    pub fn highest_precedence_binding_for_action_in_context(
        &self,
        action: &dyn Action,
        context: KeyContext,
    ) -> Option<KeyBinding> {
        self.note_actions_read();
        let dispatch_tree = &self.rendered_frame.dispatch_tree;
        dispatch_tree.highest_precedence_binding_for_action(action, &[context])
    }

    /// Returns any bindings that would invoke an action on the given focus handle if it were
    /// focused. Bindings are returned in the order they were added. For display, the last binding
    /// should take precedence.
    pub fn bindings_for_action_in(
        &self,
        action: &dyn Action,
        focus_handle: &FocusHandle,
    ) -> Vec<KeyBinding> {
        self.note_actions_read();
        let dispatch_tree = &self.rendered_frame.dispatch_tree;
        let Some(context_stack) = self.context_stack_for_focus_handle(focus_handle) else {
            return vec![];
        };
        dispatch_tree.bindings_for_action(action, &context_stack)
    }

    /// Returns the highest precedence key binding that would invoke an action on the given focus
    /// handle if it were focused. This is more efficient than getting the last result of
    /// `bindings_for_action_in`.
    pub fn highest_precedence_binding_for_action_in(
        &self,
        action: &dyn Action,
        focus_handle: &FocusHandle,
    ) -> Option<KeyBinding> {
        self.note_actions_read();
        let dispatch_tree = &self.rendered_frame.dispatch_tree;
        let context_stack = self.context_stack_for_focus_handle(focus_handle)?;
        dispatch_tree.highest_precedence_binding_for_action(action, &context_stack)
    }

    /// Find the bindings that can follow the current input sequence for the current context stack.
    pub fn possible_bindings_for_input(&self, input: &[Keystroke]) -> Vec<KeyBinding> {
        self.note_actions_read();
        self.rendered_frame
            .dispatch_tree
            .possible_next_bindings_for_input(input, &self.context_stack())
    }

    fn context_stack_for_focus_handle(
        &self,
        focus_handle: &FocusHandle,
    ) -> Option<Vec<KeyContext>> {
        let dispatch_tree = &self.rendered_frame.dispatch_tree;
        let node_id = dispatch_tree.focusable_node_id(focus_handle.id)?;
        let context_stack: Vec<_> = dispatch_tree
            .dispatch_path(node_id)
            .into_iter()
            .filter_map(|node_id| dispatch_tree.node(node_id).context.clone())
            .collect();
        Some(context_stack)
    }

    /// Returns a generic event listener that invokes the given listener with the view and context associated with the given view handle.
    pub fn listener_for<T: 'static, E>(
        &self,
        view: &Entity<T>,
        f: impl Fn(&mut T, &E, &mut Window, &mut Context<T>) + 'static,
    ) -> impl Fn(&E, &mut Window, &mut App) + 'static {
        let view = view.downgrade();
        move |e: &E, window: &mut Window, cx: &mut App| {
            view.update(cx, |view, cx| f(view, e, window, cx)).ok();
        }
    }

    /// Returns a generic handler that invokes the given handler with the view and context associated with the given view handle.
    pub fn handler_for<E: 'static, Callback: Fn(&mut E, &mut Window, &mut Context<E>) + 'static>(
        &self,
        entity: &Entity<E>,
        f: Callback,
    ) -> impl Fn(&mut Window, &mut App) + 'static {
        let entity = entity.downgrade();
        move |window: &mut Window, cx: &mut App| {
            entity.update(cx, |entity, cx| f(entity, window, cx)).ok();
        }
    }

    /// Register a callback that can interrupt the closing of the current window based the returned boolean.
    /// If the callback returns false, the window won't be closed.
    pub fn on_window_should_close(
        &self,
        cx: &App,
        f: impl Fn(&mut Window, &mut App) -> bool + 'static,
    ) {
        let mut cx = self.to_async(cx);
        self.platform_window.on_should_close(Box::new(move || {
            cx.update(|window, cx| f(window, cx)).unwrap_or(true)
        }))
    }

    /// Register an action listener on this node for the next frame. The type of action
    /// is determined by the first parameter of the given listener. When the next frame is rendered
    /// the listener will be cleared.
    ///
    /// This is a fairly low-level method, so prefer using action handlers on elements unless you have
    /// a specific need to register a listener yourself.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    pub fn on_action(
        &mut self,
        action_type: TypeId,
        listener: impl Fn(&dyn Any, DispatchPhase, &mut Window, &mut App) + 'static,
    ) {
        self.invalidator.debug_assert_paint();

        self.next_frame
            .dispatch_tree
            .on_action(action_type, Rc::new(listener));
    }

    /// Register a capturing action listener on this node for the next frame if the condition is true.
    /// The type of action is determined by the first parameter of the given listener. When the next
    /// frame is rendered the listener will be cleared.
    ///
    /// This is a fairly low-level method, so prefer using action handlers on elements unless you have
    /// a specific need to register a listener yourself.
    ///
    /// This method should only be called as part of the paint phase of element drawing.
    pub fn on_action_when(
        &mut self,
        condition: bool,
        action_type: TypeId,
        listener: impl Fn(&dyn Any, DispatchPhase, &mut Window, &mut App) + 'static,
    ) {
        self.invalidator.debug_assert_paint();

        if condition {
            self.next_frame
                .dispatch_tree
                .on_action(action_type, Rc::new(listener));
        }
    }

    /// Read information about the GPU backing this window.
    /// Currently returns None on Mac and Windows.
    pub fn gpu_specs(&self) -> Option<GpuSpecs> {
        self.platform_window.gpu_specs()
    }

    /// Perform titlebar double-click action.
    /// This is macOS specific.
    pub fn titlebar_double_click(&self) {
        self.platform_window
            .titlebar_double_click(self.is_resizable, self.is_minimizable);
    }

    /// Gets the window's title at the platform level.
    /// This is macOS specific.
    pub fn window_title(&self) -> String {
        self.platform_window.get_title()
    }

    /// Returns a list of all tabbed windows and their titles.
    /// This is macOS specific.
    pub fn tabbed_windows(&self) -> Option<Vec<SystemWindowTab>> {
        self.platform_window.tabbed_windows()
    }

    /// Returns the tab bar visibility.
    /// This is macOS specific.
    pub fn tab_bar_visible(&self) -> bool {
        self.platform_window.tab_bar_visible()
    }

    /// Merges all open windows into a single tabbed window.
    /// This is macOS specific.
    pub fn merge_all_windows(&self) {
        self.platform_window.merge_all_windows()
    }

    /// Moves the tab to a new containing window.
    /// This is macOS specific.
    pub fn move_tab_to_new_window(&self) {
        self.platform_window.move_tab_to_new_window()
    }

    /// Shows or hides the window tab overview.
    /// This is macOS specific.
    pub fn toggle_window_tab_overview(&self) {
        self.platform_window.toggle_window_tab_overview()
    }

    /// Sets the tabbing identifier for the window.
    /// This is macOS specific.
    pub fn set_tabbing_identifier(&self, tabbing_identifier: Option<String>) {
        self.platform_window
            .set_tabbing_identifier(tabbing_identifier)
    }

    /// Request the OS to play an alert sound. On some platforms this is associated
    /// with the window, for others it's just a simple global function call.
    pub fn play_system_bell(&self) {
        self.platform_window.play_system_bell()
    }

    /// Returns whether accessibility support is enabled for this window.
    ///
    /// This is false when the app was created with [`crate::Application::new_inaccessible`].
    /// Unlike [`Self::is_a11y_active`], this does not depend on whether assistive
    /// technology is currently connected, so it can be used to gate subscriptions
    /// that are only needed for accessibility.
    pub fn is_a11y_enabled(&self) -> bool {
        self.a11y.is_enabled()
    }

    /// Returns whether accessibility features are active for this frame,
    /// i.e. whether assistive technology (such as a screen reader) is
    /// connected and an accessibility tree is being built.
    ///
    /// Use this to skip computing data during rendering that is only
    /// observable through the accessibility tree. When accessibility is
    /// activated, a redraw is forced, so gated work is recomputed before the
    /// next tree update is sent to the platform.
    ///
    /// See the [accessibility guide](crate::_accessibility) for an overview.
    pub fn is_a11y_active(&self) -> bool {
        self.a11y.is_active()
    }

    /// Debug representation of the last frame's accessibility information.
    pub fn debug_a11y_tree_json(&self) -> Option<String> {
        self.a11y.debug_tree_json()
    }

    /// Register a listener for an accessibility action on a specific node.
    /// The listener will be called when a screen reader requests the given
    /// action on the node identified by `node_id`.
    ///
    /// See the [accessibility guide](crate::_accessibility) for an overview.
    pub fn on_a11y_action(
        &mut self,
        node_id: accesskit::NodeId,
        action: accesskit::Action,
        listener: impl FnMut(Option<&accesskit::ActionData>, &mut Window, &mut App) + 'static,
    ) {
        self.a11y
            .action_listeners
            .entry(node_id)
            .or_default()
            .push((action, Box::new(listener)));
    }

    #[cfg(not(target_family = "wasm"))]
    pub(crate) fn handle_a11y_action(&mut self, request: accesskit::ActionRequest, cx: &mut App) {
        // Take listeners out temporarily so the closures can borrow Window
        // mutably, then restore them afterward.
        if let Some(mut listeners) = self.a11y.action_listeners.remove(&request.target_node) {
            let extra_data = request.data.as_ref();
            let mut matched = false;
            for (action, listener) in &mut listeners {
                if *action == request.action {
                    listener(extra_data, self, cx);
                    matched = true;
                }
            }
            self.a11y
                .action_listeners
                .insert(request.target_node, listeners);
            if matched {
                return;
            }
        }

        // Fall back to built-in action handling.
        match request.action {
            accesskit::Action::Click => {
                if let Some(bounds) = self.a11y.node_bounds.get(&request.target_node).copied() {
                    let center = bounds.center();
                    let mouse_down = PlatformInput::MouseDown(crate::MouseDownEvent {
                        button: MouseButton::Left,
                        position: center,
                        modifiers: Modifiers::default(),
                        click_count: 1,
                        first_mouse: false,
                    });
                    let mouse_up = PlatformInput::MouseUp(MouseUpEvent {
                        button: MouseButton::Left,
                        position: center,
                        modifiers: Modifiers::default(),
                        click_count: 1,
                    });
                    self.dispatch_event(mouse_down, cx);
                    self.dispatch_event(mouse_up, cx);
                }
            }
            accesskit::Action::Focus => {
                if let Some(focus_id) = self.a11y.focus_ids.get(&request.target_node).copied()
                    && let Some(handle) = FocusHandle::for_id(focus_id, &cx.focus_handles)
                {
                    self.focus(&handle, cx);
                }
            }
            accesskit::Action::Blur => {
                self.blur(cx);
            }
            _ => {
                log::debug!(
                    "Unhandled a11y action: {:?} on {:?}",
                    request.action,
                    request.target_node
                );
            }
        }
    }

    /// Toggles the inspector mode on this window.
    #[cfg(any(feature = "inspector", debug_assertions))]
    pub fn toggle_inspector(&mut self, cx: &mut App) {
        self.inspector = match self.inspector {
            None => Some(cx.new(|_| Inspector::new())),
            Some(_) => {
                self.rendered_frame.next_inspector_instance_ids = FxHashMap::default();
                self.rendered_frame.inspector_hitboxes = FxHashMap::default();
                self.next_frame.next_inspector_instance_ids = FxHashMap::default();
                self.next_frame.inspector_hitboxes = FxHashMap::default();
                None
            }
        };
        self.refresh();
    }

    /// Returns true if the window is in inspector mode.
    pub fn is_inspector_picking(&self, _cx: &App) -> bool {
        #[cfg(any(feature = "inspector", debug_assertions))]
        {
            if let Some(inspector) = &self.inspector {
                return inspector.read(_cx).is_picking();
            }
        }
        false
    }

    /// Executes the provided function with mutable access to an inspector state.
    #[cfg(any(feature = "inspector", debug_assertions))]
    pub fn with_inspector_state<T: 'static, R>(
        &mut self,
        inspector_id: Option<&crate::InspectorElementId>,
        cx: &mut App,
        f: impl FnOnce(&mut Option<T>, &mut Self) -> R,
    ) -> Option<R> {
        let inspector_id = inspector_id?;
        let inspector = self.inspector.as_ref()?;
        if inspector.read(cx).active_element_id() != Some(inspector_id) {
            return None;
        }
        let inspector = inspector.clone();
        Some(inspector.update(cx, |inspector, _cx| {
            inspector.with_active_element_state(self, f)
        }))
    }

    #[cfg(any(feature = "inspector", debug_assertions))]
    pub(crate) fn inspector_enabled(&self) -> bool {
        self.inspector.is_some()
    }

    #[cfg(any(feature = "inspector", debug_assertions))]
    pub(crate) fn build_inspector_element_id(
        &mut self,
        path: crate::InspectorElementPath,
    ) -> crate::InspectorElementId {
        self.invalidator.debug_assert_paint_or_prepaint();
        let path = Rc::new(path);
        let next_instance_id = self
            .next_frame
            .next_inspector_instance_ids
            .entry(path.clone())
            .or_insert(0);
        let instance_id = *next_instance_id;
        *next_instance_id += 1;
        crate::InspectorElementId { path, instance_id }
    }

    #[cfg(any(feature = "inspector", debug_assertions))]
    fn prepaint_inspector(&mut self, inspector_width: Pixels, cx: &mut App) -> Option<AnyElement> {
        if let Some(inspector) = self.inspector.take() {
            let mut inspector_element = AnyView::from(inspector.clone()).into_any_element();
            inspector_element.prepaint_as_root(
                point(self.viewport_size.width - inspector_width, px(0.0)),
                size(inspector_width, self.viewport_size.height).into(),
                self,
                cx,
            );
            self.inspector = Some(inspector);
            Some(inspector_element)
        } else {
            None
        }
    }

    #[cfg(any(feature = "inspector", debug_assertions))]
    fn paint_inspector(&mut self, mut inspector_element: Option<AnyElement>, cx: &mut App) {
        if let Some(mut inspector_element) = inspector_element {
            inspector_element.paint(self, cx);
        };
    }

    /// Registers a hitbox that can be used for inspector picking mode, allowing users to select and
    /// inspect UI elements by clicking on them.
    #[cfg(any(feature = "inspector", debug_assertions))]
    pub fn insert_inspector_hitbox(
        &mut self,
        hitbox_id: HitboxId,
        inspector_id: Option<&crate::InspectorElementId>,
        cx: &App,
    ) {
        self.invalidator.debug_assert_paint_or_prepaint();
        if !self.is_inspector_picking(cx) {
            return;
        }
        if let Some(inspector_id) = inspector_id {
            self.next_frame
                .inspector_hitboxes
                .insert(hitbox_id, inspector_id.clone());
        }
    }

    #[cfg(any(feature = "inspector", debug_assertions))]
    fn paint_inspector_hitbox(&mut self, cx: &App) {
        if let Some(inspector) = self.inspector.as_ref() {
            let inspector = inspector.read(cx);
            if let Some((hitbox_id, _)) = self.hovered_inspector_hitbox(inspector, &self.next_frame)
                && let Some(hitbox) = self
                    .next_frame
                    .hitboxes
                    .iter()
                    .find(|hitbox| hitbox.id == hitbox_id)
            {
                self.paint_quad(crate::fill(hitbox.bounds, crate::rgba(0x61afef4d)));
            }
        }
    }

    #[cfg(any(feature = "inspector", debug_assertions))]
    fn handle_inspector_mouse_event(&mut self, event: &dyn Any, cx: &mut App) {
        let Some(inspector) = self.inspector.clone() else {
            return;
        };
        if event.downcast_ref::<MouseMoveEvent>().is_some() {
            inspector.update(cx, |inspector, _cx| {
                if let Some((_, inspector_id)) =
                    self.hovered_inspector_hitbox(inspector, &self.rendered_frame)
                {
                    inspector.hover(inspector_id, self);
                }
            });
        } else if event.downcast_ref::<crate::MouseDownEvent>().is_some() {
            inspector.update(cx, |inspector, _cx| {
                if let Some((_, inspector_id)) =
                    self.hovered_inspector_hitbox(inspector, &self.rendered_frame)
                {
                    inspector.select(inspector_id, self);
                }
            });
        } else if let Some(event) = event.downcast_ref::<crate::ScrollWheelEvent>() {
            // This should be kept in sync with SCROLL_LINES in x11 platform.
            const SCROLL_LINES: f32 = 3.0;
            const SCROLL_PIXELS_PER_LAYER: f32 = 36.0;
            let delta_y = event
                .delta
                .pixel_delta(px(SCROLL_PIXELS_PER_LAYER / SCROLL_LINES))
                .y;
            if let Some(inspector) = self.inspector.clone() {
                inspector.update(cx, |inspector, _cx| {
                    if let Some(depth) = inspector.pick_depth.as_mut() {
                        *depth += f32::from(delta_y) / SCROLL_PIXELS_PER_LAYER;
                        let max_depth = self.mouse_hit_test.ids.len() as f32 - 0.5;
                        if *depth < 0.0 {
                            *depth = 0.0;
                        } else if *depth > max_depth {
                            *depth = max_depth;
                        }
                        if let Some((_, inspector_id)) =
                            self.hovered_inspector_hitbox(inspector, &self.rendered_frame)
                        {
                            inspector.set_active_element_id(inspector_id, self);
                        }
                    }
                });
            }
        }
    }

    #[cfg(any(feature = "inspector", debug_assertions))]
    fn hovered_inspector_hitbox(
        &self,
        inspector: &Inspector,
        frame: &Frame,
    ) -> Option<(HitboxId, crate::InspectorElementId)> {
        if let Some(pick_depth) = inspector.pick_depth {
            let depth = (pick_depth as i64).try_into().unwrap_or(0);
            let max_skipped = self.mouse_hit_test.ids.len().saturating_sub(1);
            let skip_count = (depth as usize).min(max_skipped);
            for hitbox_id in self.mouse_hit_test.ids.iter().skip(skip_count) {
                if let Some(inspector_id) = frame.inspector_hitboxes.get(hitbox_id) {
                    return Some((*hitbox_id, inspector_id.clone()));
                }
            }
        }
        None
    }

    /// For testing: set the current modifier keys state.
    /// This does not generate any events.
    #[cfg(any(test, feature = "test-support"))]
    pub fn set_modifiers(&mut self, modifiers: Modifiers) {
        self.modifiers = modifiers;
    }

    /// For testing: set the cursor position without generating input events.
    #[cfg(any(test, feature = "test-support"))]
    pub fn set_mouse_position(&mut self, position: Point<Pixels>) {
        self.mouse_position = position;
    }

    /// For testing: simulate a mouse move event to the given position.
    /// This dispatches the event through the normal event handling path,
    /// which will trigger hover states and tooltips.
    #[cfg(any(test, feature = "test-support"))]
    pub fn simulate_mouse_move(&mut self, position: Point<Pixels>, cx: &mut App) {
        let event = PlatformInput::MouseMove(MouseMoveEvent {
            position,
            modifiers: self.modifiers,
            pressed_button: None,
        });
        let _ = self.dispatch_event(event, cx);
    }

    #[inline(never)]
    fn take_element_state(
        &mut self,
        global_id: &GlobalElementId,
        state_type: TypeId,
    ) -> ((GlobalElementId, TypeId), Option<ElementStateBox>) {
        let key = (global_id.clone(), state_type);
        self.next_frame.accessed_element_states.push(key.clone());
        let state = self
            .next_frame
            .element_states
            .remove(&key)
            .or_else(|| self.rendered_frame.element_states.remove(&key));
        (key, state)
    }

    #[inline(never)]
    fn insert_element_state(
        &mut self,
        key: (GlobalElementId, TypeId),
        state: ElementStateBox,
    ) -> Option<ElementStateBox> {
        self.next_frame.element_states.insert(key, state)
    }

    #[inline(never)]
    fn observe_keyed_state<S: 'static>(state: &Entity<S>, current_view: EntityId, cx: &mut App) {
        cx.observe(state, move |_, cx| {
            cx.notify(current_view);
        })
        .detach();
    }
}

// #[derive(Clone, Copy, Eq, PartialEq, Hash)]
slotmap::new_key_type! {
    /// A unique identifier for a window.
    pub struct WindowId;
}

impl WindowId {
    /// Converts this window ID to a `u64`.
    pub fn as_u64(&self) -> u64 {
        self.0.as_ffi()
    }
}

impl From<u64> for WindowId {
    fn from(value: u64) -> Self {
        WindowId(slotmap::KeyData::from_ffi(value))
    }
}

/// A handle to a window with a specific root view type.
/// Note that this does not keep the window alive on its own.
#[derive(Deref, DerefMut)]
pub struct WindowHandle<V> {
    #[deref]
    #[deref_mut]
    pub(crate) any_handle: AnyWindowHandle,
    state_type: PhantomData<fn(V) -> V>,
}

impl<V> Debug for WindowHandle<V> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("WindowHandle")
            .field("any_handle", &self.any_handle.id.as_u64())
            .finish()
    }
}

impl<V: 'static + Render> WindowHandle<V> {
    /// Creates a new handle from a window ID.
    /// This does not check if the root type of the window is `V`.
    pub fn new(id: WindowId) -> Self {
        WindowHandle {
            any_handle: AnyWindowHandle {
                id,
                state_type: TypeId::of::<V>(),
                root_entity_type_name: std::any::type_name::<V>(),
            },
            state_type: PhantomData,
        }
    }

    /// Get the root view out of this window.
    ///
    /// This will fail if the window is closed or if the root view's type does not match `V`.
    #[cfg(any(test, feature = "test-support"))]
    pub fn root<C>(&self, cx: &mut C) -> Result<Entity<V>>
    where
        C: AppContext,
    {
        cx.update_window(self.any_handle, |root_view, _, _| {
            root_view
                .downcast::<V>()
                .map_err(|_| anyhow!("the type of the window's root view has changed"))
        })?
    }

    /// Updates the root view of this window.
    ///
    /// This will fail if the window has been closed or if the root view's type does not match
    pub fn update<C, R>(
        &self,
        cx: &mut C,
        update: impl FnOnce(&mut V, &mut Window, &mut Context<V>) -> R,
    ) -> Result<R>
    where
        C: AppContext,
    {
        cx.update_window(self.any_handle, |root_view, window, cx| {
            let view = root_view
                .downcast::<V>()
                .map_err(|_| anyhow!("the type of the window's root view has changed"))?;

            Ok(view.update(cx, |view, cx| update(view, window, cx)))
        })?
    }

    /// Read the root view out of this window.
    ///
    /// This will fail if the window is closed or if the root view's type does not match `V`.
    pub fn read<'a>(&self, cx: &'a App) -> Result<&'a V> {
        let x = cx
            .windows
            .get(self.id)
            .and_then(|window| {
                window
                    .as_deref()
                    .and_then(|window| window.root.clone())
                    .map(|root_view| root_view.downcast::<V>())
            })
            .context("window not found")?
            .map_err(|_| anyhow!("the type of the window's root view has changed"))?;

        Ok(x.read(cx))
    }

    /// Read the root view out of this window, with a callback
    ///
    /// This will fail if the window is closed or if the root view's type does not match `V`.
    pub fn read_with<C, R>(&self, cx: &C, read_with: impl FnOnce(&V, &App) -> R) -> Result<R>
    where
        C: AppContext,
    {
        cx.read_window(self, |root_view, cx| read_with(root_view.read(cx), cx))
    }

    /// Read the root view pointer off of this window.
    ///
    /// This will fail if the window is closed or if the root view's type does not match `V`.
    pub fn entity<C>(&self, cx: &C) -> Result<Entity<V>>
    where
        C: AppContext,
    {
        cx.read_window(self, |root_view, _cx| root_view)
    }

    /// Check if this window is 'active'.
    ///
    /// Will return `None` if the window is closed or currently
    /// borrowed.
    pub fn is_active(&self, cx: &mut App) -> Option<bool> {
        cx.update_window(self.any_handle, |_, window, _| window.is_window_active())
            .ok()
    }
}

impl<V> Copy for WindowHandle<V> {}

impl<V> Clone for WindowHandle<V> {
    fn clone(&self) -> Self {
        *self
    }
}

impl<V> PartialEq for WindowHandle<V> {
    fn eq(&self, other: &Self) -> bool {
        self.any_handle == other.any_handle
    }
}

impl<V> Eq for WindowHandle<V> {}

impl<V> Hash for WindowHandle<V> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.any_handle.hash(state);
    }
}

impl<V: 'static> From<WindowHandle<V>> for AnyWindowHandle {
    fn from(val: WindowHandle<V>) -> Self {
        val.any_handle
    }
}

/// A handle to a window with any root view type, which can be downcast to a window with a specific root view type.
#[derive(Copy, Clone, PartialEq, Eq, Hash, Debug)]
pub struct AnyWindowHandle {
    pub(crate) id: WindowId,
    state_type: TypeId,
    root_entity_type_name: &'static str,
}

impl AnyWindowHandle {
    /// Get the ID of this window.
    pub fn window_id(&self) -> WindowId {
        self.id
    }

    /// Returns the name of the window's declared root entity type.
    pub fn root_entity_type_name(&self) -> &'static str {
        self.root_entity_type_name
    }

    /// Attempt to convert this handle to a window handle with a specific root view type.
    /// If the types do not match, this will return `None`.
    pub fn downcast<T: 'static>(&self) -> Option<WindowHandle<T>> {
        if TypeId::of::<T>() == self.state_type {
            Some(WindowHandle {
                any_handle: *self,
                state_type: PhantomData,
            })
        } else {
            None
        }
    }

    /// Updates the state of the root view of this window.
    ///
    /// This will fail if the window has been closed.
    pub fn update<C, R>(
        self,
        cx: &mut C,
        update: impl FnOnce(AnyView, &mut Window, &mut App) -> R,
    ) -> Result<R>
    where
        C: AppContext,
    {
        cx.update_window(self, update)
    }

    /// Read the state of the root view of this window.
    ///
    /// This will fail if the window has been closed.
    pub fn read<T, C, R>(self, cx: &C, read: impl FnOnce(Entity<T>, &App) -> R) -> Result<R>
    where
        C: AppContext,
        T: 'static,
    {
        let view = self
            .downcast::<T>()
            .context("the type of the window's root view has changed")?;

        cx.read_window(&view, read)
    }
}

impl HasWindowHandle for Window {
    fn window_handle(&self) -> Result<raw_window_handle::WindowHandle<'_>, HandleError> {
        self.platform_window.window_handle()
    }
}

impl HasDisplayHandle for Window {
    fn display_handle(
        &self,
    ) -> std::result::Result<raw_window_handle::DisplayHandle<'_>, HandleError> {
        self.platform_window.display_handle()
    }
}

/// An identifier for an [`Element`].
///
/// Can be constructed with a string, a number, or both, as well
/// as other internal representations.
#[derive(Clone, Debug, Eq, PartialEq, Hash)]
pub enum ElementId {
    /// The ID of a View element
    View(EntityId),
    /// An integer ID.
    Integer(u64),
    /// A string based ID.
    Name(SharedString),
    /// A UUID.
    Uuid(Uuid),
    /// An ID that's equated with a focus handle.
    FocusHandle(FocusId),
    /// A combination of a name and an integer.
    NamedInteger(SharedString, u64),
    /// A path.
    Path(Arc<std::path::Path>),
    /// A code location.
    CodeLocation(core::panic::Location<'static>),
    /// A labeled child of an element.
    NamedChild(Arc<ElementId>, SharedString),
    /// A byte array ID (used for text-anchors)
    OpaqueId([u8; 20]),
}

impl ElementId {
    /// Constructs an `ElementId::NamedInteger` from a name and `usize`.
    pub fn named_usize(name: impl Into<SharedString>, integer: usize) -> ElementId {
        Self::NamedInteger(name.into(), integer as u64)
    }
}

impl Display for ElementId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            ElementId::View(entity_id) => write!(f, "view-{}", entity_id)?,
            ElementId::Integer(ix) => write!(f, "{}", ix)?,
            ElementId::Name(name) => write!(f, "{}", name)?,
            ElementId::FocusHandle(_) => write!(f, "FocusHandle")?,
            ElementId::NamedInteger(s, i) => write!(f, "{}-{}", s, i)?,
            ElementId::Uuid(uuid) => write!(f, "{}", uuid)?,
            ElementId::Path(path) => write!(f, "{}", path.display())?,
            ElementId::CodeLocation(location) => write!(f, "{}", location)?,
            ElementId::NamedChild(id, name) => write!(f, "{}-{}", id, name)?,
            ElementId::OpaqueId(opaque_id) => write!(f, "{:x?}", opaque_id)?,
        }

        Ok(())
    }
}

impl TryInto<SharedString> for ElementId {
    type Error = anyhow::Error;

    fn try_into(self) -> anyhow::Result<SharedString> {
        if let ElementId::Name(name) = self {
            Ok(name)
        } else {
            anyhow::bail!("element id is not string")
        }
    }
}

impl From<u64> for ElementId {
    fn from(id: u64) -> Self {
        ElementId::Integer(id)
    }
}

impl From<usize> for ElementId {
    fn from(id: usize) -> Self {
        ElementId::Integer(id as u64)
    }
}

impl From<i32> for ElementId {
    fn from(id: i32) -> Self {
        Self::Integer(id as u64)
    }
}

impl From<SharedString> for ElementId {
    fn from(name: SharedString) -> Self {
        ElementId::Name(name)
    }
}

impl From<String> for ElementId {
    fn from(name: String) -> Self {
        ElementId::Name(name.into())
    }
}

impl From<Arc<str>> for ElementId {
    fn from(name: Arc<str>) -> Self {
        ElementId::Name(name.into())
    }
}

impl From<Arc<std::path::Path>> for ElementId {
    fn from(path: Arc<std::path::Path>) -> Self {
        ElementId::Path(path)
    }
}

impl From<&'static str> for ElementId {
    fn from(name: &'static str) -> Self {
        ElementId::Name(SharedString::new_static(name))
    }
}

impl<'a> From<&'a FocusHandle> for ElementId {
    fn from(handle: &'a FocusHandle) -> Self {
        ElementId::FocusHandle(handle.id)
    }
}

impl From<(&'static str, EntityId)> for ElementId {
    fn from((name, id): (&'static str, EntityId)) -> Self {
        ElementId::NamedInteger(SharedString::new_static(name), id.as_u64())
    }
}

impl From<(&'static str, usize)> for ElementId {
    fn from((name, id): (&'static str, usize)) -> Self {
        ElementId::NamedInteger(SharedString::new_static(name), id as u64)
    }
}

impl From<(SharedString, usize)> for ElementId {
    fn from((name, id): (SharedString, usize)) -> Self {
        ElementId::NamedInteger(name, id as u64)
    }
}

impl From<(&'static str, u64)> for ElementId {
    fn from((name, id): (&'static str, u64)) -> Self {
        ElementId::NamedInteger(SharedString::new_static(name), id)
    }
}

impl From<Uuid> for ElementId {
    fn from(value: Uuid) -> Self {
        Self::Uuid(value)
    }
}

impl From<(&'static str, u32)> for ElementId {
    fn from((name, id): (&'static str, u32)) -> Self {
        ElementId::NamedInteger(SharedString::new_static(name), u64::from(id))
    }
}

impl<T: Into<SharedString>> From<(ElementId, T)> for ElementId {
    fn from((id, name): (ElementId, T)) -> Self {
        ElementId::NamedChild(Arc::new(id), name.into())
    }
}

impl From<&'static core::panic::Location<'static>> for ElementId {
    fn from(location: &'static core::panic::Location<'static>) -> Self {
        ElementId::CodeLocation(*location)
    }
}

impl From<[u8; 20]> for ElementId {
    fn from(opaque_id: [u8; 20]) -> Self {
        ElementId::OpaqueId(opaque_id)
    }
}

/// A rectangle to be rendered in the window at the given position and size.
/// Passed as an argument [`Window::paint_quad`].
#[derive(Clone)]
pub struct PaintQuad {
    /// The bounds of the quad within the window.
    pub bounds: Bounds<Pixels>,
    /// The radii of the quad's corners.
    pub corner_radii: Corners<Pixels>,
    /// The background color of the quad.
    pub background: Background,
    /// The widths of the quad's borders.
    pub border_widths: Edges<Pixels>,
    /// The color of the quad's borders.
    pub border_color: Hsla,
    /// The style of the quad's borders.
    pub border_style: BorderStyle,
}

impl PaintQuad {
    /// Sets the corner radii of the quad.
    pub fn corner_radii(self, corner_radii: impl Into<Corners<Pixels>>) -> Self {
        PaintQuad {
            corner_radii: corner_radii.into(),
            ..self
        }
    }

    /// Sets the border widths of the quad.
    pub fn border_widths(self, border_widths: impl Into<Edges<Pixels>>) -> Self {
        PaintQuad {
            border_widths: border_widths.into(),
            ..self
        }
    }

    /// Sets the border color of the quad.
    pub fn border_color(self, border_color: impl Into<Hsla>) -> Self {
        PaintQuad {
            border_color: border_color.into(),
            ..self
        }
    }

    /// Sets the background color of the quad.
    pub fn background(self, background: impl Into<Background>) -> Self {
        PaintQuad {
            background: background.into(),
            ..self
        }
    }
}

/// Creates a quad with the given parameters.
pub fn quad(
    bounds: Bounds<Pixels>,
    corner_radii: impl Into<Corners<Pixels>>,
    background: impl Into<Background>,
    border_widths: impl Into<Edges<Pixels>>,
    border_color: impl Into<Hsla>,
    border_style: BorderStyle,
) -> PaintQuad {
    PaintQuad {
        bounds,
        corner_radii: corner_radii.into(),
        background: background.into(),
        border_widths: border_widths.into(),
        border_color: border_color.into(),
        border_style,
    }
}

/// Creates a filled quad with the given bounds and background color.
pub fn fill(bounds: impl Into<Bounds<Pixels>>, background: impl Into<Background>) -> PaintQuad {
    PaintQuad {
        bounds: bounds.into(),
        corner_radii: (0.).into(),
        background: background.into(),
        border_widths: (0.).into(),
        border_color: transparent_black(),
        border_style: BorderStyle::default(),
    }
}

/// Creates a rectangle outline with the given bounds, border color, and a 1px border width
pub fn outline(
    bounds: impl Into<Bounds<Pixels>>,
    border_color: impl Into<Hsla>,
    border_style: BorderStyle,
) -> PaintQuad {
    PaintQuad {
        bounds: bounds.into(),
        corner_radii: (0.).into(),
        background: transparent_black().into(),
        border_widths: (1.).into(),
        border_color: border_color.into(),
        border_style,
    }
}

#[inline(never)]
fn with_element_arena_erased(callback: &mut dyn FnMut(&mut Arena)) -> Result<(), AccessError> {
    if let Some(arena_pointer) = CURRENT_ELEMENT_ARENA.try_with(Cell::get)? {
        // SAFETY: The pointer is valid for the duration of the draw operation
        // that set it, and we're being called during that same draw.
        let arena_cell = unsafe { &*arena_pointer };
        callback(&mut arena_cell.borrow_mut());
        Ok(())
    } else {
        ELEMENT_ARENA.try_with(|arena| callback(&mut arena.borrow_mut()))
    }
}

/// Splits a device-space glyph origin into the integer pixel the sprite is placed at and the
/// subpixel variant the glyph should be rasterized for.
///
/// Both halves have to agree: the variant selects the fractional offset DirectWrite/CoreText
/// rasterizes at, and the integer origin is where that bitmap is painted. If they disagree the
/// glyph lands on the wrong pixel with the wrong shape.
///
/// `f32::fract` keeps the sign of its input, so taking the fractional part relative to
/// `floor` matters at negative device coordinates (content scrolled past the left edge, or a
/// window straddling x = 0): a negative fraction cast to `u8` saturates to variant 0, and
/// `trunc` rounds toward zero rather than down. For non-negative coordinates — every ordinary
/// layout — this is exactly what the straightforward `fract`/`trunc` version computes.
fn quantize_glyph_origin(glyph_origin: Point<ScaledPixels>) -> (Point<ScaledPixels>, Point<u8>) {
    let (x, variant_x) = quantize_glyph_coordinate::<SUBPIXEL_VARIANTS_X>(glyph_origin.x.0);
    let (y, variant_y) = quantize_glyph_coordinate::<SUBPIXEL_VARIANTS_Y>(glyph_origin.y.0);
    (
        Point::new(ScaledPixels(x), ScaledPixels(y)),
        Point::new(variant_x, variant_y),
    )
}

/// One coordinate of [`quantize_glyph_origin`]: rounded half toward zero to a whole number of
/// `1 / VARIANTS` steps, then split into the pixel at or below it and the step within it.
///
/// Every glyph painted comes through here, and without SSE4.1 (the default x86-64 target)
/// `f32::ceil` and `f32::floor` are libm calls. While the step count fits an `i32` exactly it
/// is worked out in integers instead: `magnitude` is at least -0.5, so truncating it is its
/// ceiling unless it has a positive fraction, and with `VARIANTS` a power of two the float
/// quotient and floor are exact, so they are the Euclidean quotient and remainder. That gives
/// the same numbers as the float path, except a zero origin is never `-0.0`, which adding the
/// glyph's integer raster offset erases anyway. Larger coordinates, infinities and NaN take
/// the float path.
#[inline]
fn quantize_glyph_coordinate<const VARIANTS: u8>(coordinate: f32) -> (f32, u8) {
    const { assert!(VARIANTS.is_power_of_two()) };
    const EXACT_LIMIT: f32 = (1u32 << (f32::MANTISSA_DIGITS - 1)) as f32;
    let scaled = coordinate * VARIANTS as f32;
    let magnitude = scaled.abs() - 0.5;
    if magnitude < EXACT_LIMIT {
        // SAFETY: `magnitude` is finite and within [-0.5, 2^23), which truncates into an
        // `i32`; the checked `as` cast costs every glyph its saturation and NaN tests.
        let truncated: i32 = unsafe { magnitude.to_int_unchecked() };
        let ceiling = truncated + ((truncated as f32) < magnitude) as i32;
        let steps = if scaled.is_sign_negative() {
            -ceiling
        } else {
            ceiling
        };
        // An arithmetic shift is the Euclidean quotient by a power of two, and the low bits
        // its remainder.
        return (
            (steps >> VARIANTS.trailing_zeros()) as f32,
            (steps & (VARIANTS as i32 - 1)) as u8,
        );
    }
    let quantized = round_half_toward_zero(scaled) / VARIANTS as f32;
    let floor = quantized.floor();
    (floor, ((quantized - floor) * VARIANTS as f32) as u8)
}

#[cfg(test)]
mod glyph_quantization_tests {
    use super::quantize_glyph_origin;
    use crate::{Point, SUBPIXEL_VARIANTS_X, ScaledPixels};

    fn quantize(x: f32) -> (f32, u8) {
        let (origin, variant) = quantize_glyph_origin(Point::new(ScaledPixels(x), ScaledPixels(0.)));
        (origin.x.0, variant.x)
    }

    #[test]
    fn quantizes_positive_origins_to_the_pixel_below_and_its_fraction() {
        assert_eq!(quantize(10.0), (10.0, 0));
        assert_eq!(quantize(10.25), (10.0, 1));
        assert_eq!(quantize(10.5), (10.0, 2));
        assert_eq!(quantize(10.75), (10.0, 3));
        // Rounds to the nearest quarter before splitting.
        assert_eq!(quantize(10.24), (10.0, 1));
        assert_eq!(quantize(10.99), (11.0, 0));
    }

    /// The regression: a negative fraction used to saturate to variant 0 and `trunc` rounded
    /// the origin up, so glyphs left of the origin were placed a pixel off and rasterized for
    /// the wrong subpixel offset.
    #[test]
    fn quantizes_negative_origins_downward_rather_than_toward_zero() {
        assert_eq!(quantize(-10.0), (-10.0, 0));
        assert_eq!(quantize(-9.75), (-10.0, 1));
        assert_eq!(quantize(-9.5), (-10.0, 2));
        assert_eq!(quantize(-9.25), (-10.0, 3));
    }

    /// The two halves have to agree: painting at `origin` a bitmap rasterized for `variant`
    /// must land within half a quantization step of the position that was asked for, and the
    /// variant must be a real index or the rasterizer is asked for an offset that lookup
    /// tables do not have. Swept across zero, where the sign handling used to be wrong.
    #[test]
    fn origin_and_variant_reconstruct_the_requested_position() {
        let step = 1.0 / SUBPIXEL_VARIANTS_X as f32;
        let tolerance = step / 2.0 + 1e-4;

        let mut coordinate = -50.0f32;
        while coordinate < 50.0 {
            let (origin, variant) = quantize(coordinate);
            assert!(
                variant < SUBPIXEL_VARIANTS_X,
                "variant {variant} out of range at {coordinate}"
            );
            let reconstructed = origin + variant as f32 * step;
            assert!(
                (reconstructed - coordinate).abs() <= tolerance,
                "{coordinate} quantized to origin {origin} + variant {variant} = \
                 {reconstructed}, which is more than {tolerance} away"
            );
            coordinate += 0.05;
        }
    }

    /// The integer path gives the numbers the float formula does, on both sides of zero, at
    /// every quarter and the ties between them, and on either side of where it hands over to
    /// the float path.
    #[test]
    fn integer_path_matches_the_float_formula() {
        fn float_formula(x: f32) -> (f32, u8) {
            let variants = SUBPIXEL_VARIANTS_X as f32;
            let quantized = crate::util::round_half_toward_zero(x * variants) / variants;
            (
                quantized.floor(),
                ((quantized - quantized.floor()) * variants) as u8,
            )
        }

        let mut coordinates = vec![0.0f32, -0.0, 0.125, -0.125, 0.124, -0.126, f32::MIN_POSITIVE];
        for whole in -300..300 {
            for eighth in 0..8 {
                let coordinate = whole as f32 + eighth as f32 / 8.0;
                coordinates.extend([
                    coordinate,
                    coordinate.next_up(),
                    coordinate.next_down(),
                    coordinate * 1.37,
                ]);
            }
        }
        let limit = (1u32 << (f32::MANTISSA_DIGITS - 1)) as f32 / SUBPIXEL_VARIANTS_X as f32;
        for edge in [limit, limit * 2.0, 1.0e9, f32::MAX] {
            for coordinate in [edge, edge.next_up(), edge.next_down()] {
                coordinates.extend([coordinate, -coordinate]);
            }
        }

        for coordinate in coordinates {
            let (origin, variant) = quantize(coordinate);
            let (expected_origin, expected_variant) = float_formula(coordinate);
            assert!(
                origin == expected_origin && variant == expected_variant,
                "{coordinate}: got ({origin}, {variant}), float formula gives \
                 ({expected_origin}, {expected_variant})"
            );
        }

        let (origin, variant) = quantize(f32::NAN);
        assert!(origin.is_nan());
        assert_eq!(variant, 0);
    }
}

#[cfg(test)]
mod tests {
    use std::{
        cell::{Cell, RefCell},
        path::PathBuf,
        rc::Rc,
        time::Duration,
    };

    use crate::{
        AnyWindowHandle, AppContext as _, Bounds, ContentMask, Context, DispatchPhase,
        DragMoveEvent, Empty, ExternalDragPayload, ExternalPaths, FileDragPaths, FileDropEvent,
        FocusHandle, InputEvent as _, InteractiveElement as _, IntoElement, KeyDownEvent,
        Keystroke, LongPressEvent, MouseButton, MouseDownEvent, MouseMoveEvent, ParentElement,
        Pixels, PlatformInput, Point, PresentOutcome, Render, RequestFrameOptions, ScaledPixels,
        StatefulInteractiveElement as _, Styled, TestAppContext, TestWindow, TouchDragEvent,
        TouchEvent, TouchId, TouchPhase, Underline, UnderlineStyle, Window, WindowAppearance,
        WindowHandle, WindowOptions,
        canvas, div, hsla, point, px, rgb, size, util::MIN_RETAINED_CAPACITY,
    };
    use crate::arena::SHRINK_AFTER_DURATION;

    /// Visibility transitions reach observers exactly once each, with the new
    /// state already stored on the window, and never wake the platform for a
    /// frame: the platform requests one itself when it resumes presenting.
    #[gpui::test]
    fn test_window_visibility(cx: &mut TestAppContext) {
        use crate::WindowVisibility;

        let window = cx.add_window(|_, _| EmptyView);
        let observed = Rc::new(RefCell::new(Vec::new()));
        let _subscription = window
            .update(cx, {
                let observed = observed.clone();
                move |_, window, _| {
                    assert_eq!(window.visibility(), WindowVisibility::Visible);
                    assert!(window.is_visible());
                    window.observe_window_visibility(move |visibility, window, _| {
                        assert_eq!(window.visibility(), visibility);
                        observed.borrow_mut().push(visibility);
                    })
                }
            })
            .unwrap();
        let test_window = cx.test_window(window.into());
        let frame_wake_count = test_window.frame_wake_count();

        test_window.simulate_visibility_change(WindowVisibility::Hidden);
        assert_eq!(*observed.borrow(), [WindowVisibility::Hidden]);
        window
            .update(cx, |_, window, _| assert!(!window.is_visible()))
            .unwrap();

        // Platforms may report the same state again; observers only see changes.
        test_window.simulate_visibility_change(WindowVisibility::Hidden);
        assert_eq!(observed.borrow().len(), 1);

        test_window.simulate_visibility_change(WindowVisibility::Visible);
        assert_eq!(
            *observed.borrow(),
            [WindowVisibility::Hidden, WindowVisibility::Visible]
        );
        window
            .update(cx, |_, window, _| assert!(window.is_visible()))
            .unwrap();
        assert_eq!(test_window.frame_wake_count(), frame_wake_count);
    }

    #[gpui::test]
    fn test_fully_visible_bounds_preserve_layout_viewport(cx: &mut TestAppContext) {
        let window = cx.add_window(|_, _| EmptyView);
        let mut platform_window = cx.test_window(window.into());
        platform_window.simulate_resize(size(px(400.), px(800.)));
        window
            .update(cx, |_, window, _| {
                assert_eq!(
                    window.visual_viewport_bounds(),
                    Bounds::new(Point::default(), size(px(400.), px(800.)))
                );
                assert_eq!(
                    window.fully_visible_bounds(),
                    window.visual_viewport_bounds()
                );
            })
            .unwrap();

        platform_window.simulate_frame_request(RequestFrameOptions::default());
        let wakes = platform_window.frame_wake_count();
        let visual_bounds = Bounds::new(point(px(10.), px(40.)), size(px(380.), px(460.)));
        platform_window.simulate_visual_viewport_change(visual_bounds);
        assert!(platform_window.frame_wake_count() > wakes);
        platform_window.simulate_frame_request(RequestFrameOptions::default());
        let wakes = platform_window.frame_wake_count();
        platform_window.simulate_insets_change(crate::WindowInsets {
            safe_area: crate::Edges {
                top: px(60.),
                right: px(20.),
                bottom: px(30.),
                left: px(-10.),
            },
            ime: crate::Edges {
                bottom: px(350.),
                ..Default::default()
            },
        });
        assert!(platform_window.frame_wake_count() > wakes);
        window
            .update(cx, |_, window, _| {
                assert_eq!(window.viewport_size(), size(px(400.), px(800.)));
                assert_eq!(window.visual_viewport_bounds(), visual_bounds);
                assert_eq!(
                    window.fully_visible_bounds(),
                    Bounds::new(point(px(10.), px(60.)), size(px(370.), px(390.)))
                );
                window.request_virtual_keyboard();
                window.dismiss_virtual_keyboard();
                assert_eq!(window.viewport_size(), size(px(400.), px(800.)));
            })
            .unwrap();
        assert_eq!(platform_window.virtual_keyboard_requests(), 1);
        assert_eq!(platform_window.virtual_keyboard_dismissals(), 1);

        platform_window.simulate_insets_change(crate::WindowInsets {
            safe_area: crate::Edges {
                top: px(900.),
                left: px(500.),
                ..Default::default()
            },
            ..Default::default()
        });
        window
            .update(cx, |_, window, _| {
                assert_eq!(
                    window.fully_visible_bounds().size,
                    size(Pixels::ZERO, Pixels::ZERO)
                );
            })
            .unwrap();
    }

    struct EmptyView;

    impl Render for EmptyView {
        fn render(&mut self, _window: &mut Window, _cx: &mut Context<Self>) -> impl IntoElement {
            div()
        }
    }

    struct OpensWindowOnPaint {
        opened: Rc<Cell<bool>>,
    }

    impl Render for OpensWindowOnPaint {
        fn render(&mut self, _window: &mut Window, _cx: &mut Context<Self>) -> impl IntoElement {
            let opened = self.opened.clone();
            div()
                .size_full()
                .child(canvas(
                    |_, _, _| {},
                    move |_, _, _window, cx| {
                        if !opened.replace(true) {
                            cx.open_window(WindowOptions::default(), |_, cx| cx.new(|_| EmptyView))
                                .unwrap();
                        }
                    },
                ))
                // Siblings painted after the canvas: their elements were
                // allocated in the arena before the nested draw, so they detect
                // a mid-draw arena clear when painted afterwards.
                .child(div().child("after"))
        }
    }

    /// Opening a window synchronously draws it and requests an element arena
    /// clear. When that happens from within another window's draw (here: from
    /// an element's paint), the clear must be deferred until the outer draw
    /// finishes, or the outer draw's arena-allocated elements would be freed
    /// out from under it.
    #[test]
    fn test_window_opened_during_draw_defers_arena_clear() {
        let mut cx = TestAppContext::single();

        let opened = Rc::new(Cell::new(false));
        // add_window draws once, which runs the nested open_window mid-draw.
        let window = cx.add_window({
            let opened = opened.clone();
            move |_, _| OpensWindowOnPaint { opened }
        });

        assert!(opened.get());
        assert_eq!(cx.windows().len(), 2);

        // The deferred clear must actually run once the outer draw unwinds:
        // subsequent draws of both windows work against a fresh arena.
        cx.update_window(window.into(), |_, window, cx| window.draw(cx).clear(cx))
            .unwrap();
    }

    #[test]
    fn test_scale_factor_change_preserves_bounds_and_survives_resize() {
        let mut cx = TestAppContext::single();
        let window = cx.add_window(|_, _| EmptyView);
        let handle: AnyWindowHandle = window.into();
        let window_state = |cx: &mut TestAppContext| {
            cx.update_window(handle, |_, window, _| {
                (
                    window.scale_factor(),
                    window.bounds(),
                    window.viewport_size(),
                )
            })
            .unwrap()
        };

        let (scale_factor, mut expected_bounds, _) = window_state(&mut cx);
        assert_eq!(scale_factor, 2.0);

        for (scale_factor, resized_size) in [
            (1.0, size(px(800.), px(600.))),
            (1.25, size(px(640.), px(480.))),
            (2.0, size(px(1024.), px(768.))),
        ] {
            cx.simulate_window_scale_factor_change(handle, scale_factor);
            assert_eq!(
                window_state(&mut cx),
                (scale_factor, expected_bounds, expected_bounds.size)
            );

            cx.simulate_window_resize(handle, resized_size);
            expected_bounds.size = resized_size;
            assert_eq!(
                window_state(&mut cx),
                (scale_factor, expected_bounds, resized_size)
            );
        }
    }

    /// A root that paints `quads` one-pixel quads. Each child is a layout
    /// node, an arena-allocated element and a scene quad, so the count sizes
    /// every per-frame store the idle reclaim covers; 20,000 is the order of
    /// a dozen long chat transcripts drawn side by side.
    struct QuadGrid {
        quads: Rc<Cell<usize>>,
    }

    impl Render for QuadGrid {
        fn render(&mut self, _window: &mut Window, _cx: &mut Context<Self>) -> impl IntoElement {
            div()
                .size_full()
                .flex()
                .flex_wrap()
                .children((0..self.quads.get()).map(|_| div().size(px(1.)).bg(rgb(0xff0000))))
        }
    }

    fn draw_window(cx: &mut TestAppContext, window: AnyWindowHandle) {
        cx.update_window(window, |_, window, cx| window.draw(cx).clear(cx))
            .unwrap();
    }

    /// What the window holds for its next draw: the retired frame's quad
    /// vector capacity and the element arena's capacity.
    fn retained_capacity(cx: &mut TestAppContext, window: AnyWindowHandle) -> (usize, usize) {
        cx.update_window(window, |_, window, cx| {
            (
                window.next_frame.scene.quads.capacity(),
                cx.element_arena.borrow().capacity(),
            )
        })
        .unwrap()
    }

    /// The draw-driven shrink policies only advance on draws, so a heavy
    /// scene followed by a quiet window kept its high-water capacity for as
    /// long as it stayed quiet. A window that has not drawn for the shrink
    /// duration must give it back without being drawn.
    #[gpui::test]
    fn test_quiet_window_reclaims_idle_capacity(cx: &mut TestAppContext) {
        const HEAVY: usize = 20_000;
        let quads = Rc::new(Cell::new(HEAVY));
        let window = cx.add_window({
            let quads = quads.clone();
            move |_, _| QuadGrid { quads }
        });
        // add_window drew once; a second draw puts the heavy scene through
        // the other frame lineage too.
        draw_window(cx, window.into());
        let (heavy_quads, heavy_arena) = retained_capacity(cx, window.into());
        assert!(heavy_quads >= HEAVY);
        assert!(
            heavy_arena > 1024 * 1024,
            "the heavy scene must grow the arena past its first chunk"
        );

        // Far fewer small frames than the draw-driven policy needs.
        quads.set(1);
        draw_window(cx, window.into());
        draw_window(cx, window.into());
        assert_eq!(
            retained_capacity(cx, window.into()),
            (heavy_quads, heavy_arena)
        );

        cx.executor().advance_clock(Duration::from_secs(3));
        cx.run_until_parked();
        let (idle_quads, idle_arena) = retained_capacity(cx, window.into());
        assert!(
            idle_quads <= MIN_RETAINED_CAPACITY,
            "quad capacity {idle_quads} was not reclaimed from {heavy_quads}"
        );
        assert_eq!(
            idle_arena,
            1024 * 1024,
            "the arena kept {heavy_arena} bytes for a one-quad scene"
        );

        // The window still draws, and regrows what the next scene needs.
        quads.set(HEAVY);
        draw_window(cx, window.into());
        let rendered_quads = cx
            .update_window(window.into(), |_, window, _| {
                window.rendered_frame.scene.quads.len()
            })
            .unwrap();
        assert!(rendered_quads >= HEAVY);
    }

    /// A window that keeps drawing is never reclaimed: a timer that fires
    /// within the shrink duration of a draw waits out the remainder.
    #[gpui::test]
    fn test_idle_reclaim_waits_for_a_full_quiet_period(cx: &mut TestAppContext) {
        let quads = Rc::new(Cell::new(20_000));
        let window = cx.add_window({
            let quads = quads.clone();
            move |_, _| QuadGrid { quads }
        });
        draw_window(cx, window.into());
        let heavy = retained_capacity(cx, window.into());
        quads.set(1);
        draw_window(cx, window.into());

        cx.executor()
            .advance_clock(SHRINK_AFTER_DURATION * 3 / 4);
        draw_window(cx, window.into());
        cx.executor()
            .advance_clock(SHRINK_AFTER_DURATION * 3 / 4);
        cx.run_until_parked();
        assert_eq!(
            retained_capacity(cx, window.into()),
            heavy,
            "a window drawn within the shrink duration must keep its capacity"
        );

        cx.executor()
            .advance_clock(SHRINK_AFTER_DURATION / 2);
        cx.run_until_parked();
        let (quads_after, arena_after) = retained_capacity(cx, window.into());
        assert!(quads_after < heavy.0);
        assert!(arena_after < heavy.1);
    }

    /// A window that went quiet on its heavy scene, with no other window
    /// drawing, kept every chunk of that scene's arena for as long as the app
    /// sat idle. The idle reclaim gives the arena back down to one chunk.
    #[gpui::test]
    fn test_idle_app_releases_the_last_heavy_draws_arena(cx: &mut TestAppContext) {
        let quads = Rc::new(Cell::new(20_000));
        let window = cx.add_window(move |_, _| QuadGrid { quads });
        draw_window(cx, window.into());
        let arena_retained = |cx: &mut TestAppContext| {
            cx.update(|cx| {
                let arena = cx.element_arena.borrow();
                (
                    arena.capacity(),
                    arena.element_list_capacity() * 2 * std::mem::size_of::<usize>(),
                )
            })
        };
        let (heavy_chunks, heavy_elements) = arena_retained(cx);
        assert!(heavy_elements > 0);
        assert!(heavy_chunks > 1024 * 1024);

        cx.executor().advance_clock(Duration::from_secs(3));
        cx.run_until_parked();
        let (idle_chunks, idle_elements) = arena_retained(cx);
        assert_eq!(idle_chunks, 1024 * 1024);
        assert_eq!(idle_elements, 0);

        draw_window(cx, window.into());
        assert_eq!(arena_retained(cx).0, heavy_chunks);
    }

    #[gpui::test]
    fn test_closing_a_window_before_its_reclaim_still_frees_its_arena(cx: &mut TestAppContext) {
        let idle_window = cx.add_window(|_, _| QuadGrid {
            quads: Rc::new(Cell::new(1)),
        });
        draw_window(cx, idle_window.into());
        cx.executor().advance_clock(Duration::from_secs(3));
        cx.run_until_parked();

        let heavy_window = cx.add_window(|_, _| QuadGrid {
            quads: Rc::new(Cell::new(20_000)),
        });
        draw_window(cx, heavy_window.into());
        assert!(cx.update(|cx| cx.element_arena.borrow().capacity()) > 1024 * 1024);
        heavy_window
            .update(cx, |_, window, _| window.remove_window())
            .unwrap();

        cx.executor().advance_clock(Duration::from_secs(3));
        cx.run_until_parked();
        assert_eq!(
            cx.update(|cx| cx.element_arena.borrow().capacity()),
            1024 * 1024
        );
    }

    /// Prints how long the first heavy draw after an idle reclaim takes next
    /// to the same draw with the high-water capacity still retained, three
    /// runs each. Run with `--release -- --ignored --nocapture`.
    #[test]
    #[ignore]
    fn regrow_after_idle_reclaim_timing() {
        const HEAVY: usize = 20_000;
        let mut cx = TestAppContext::single();
        let quads = Rc::new(Cell::new(HEAVY));
        let window = cx.add_window({
            let quads = quads.clone();
            move |_, _| QuadGrid { quads }
        });
        let mut retained = Vec::new();
        let mut regrown = Vec::new();
        for _ in 0..3 {
            quads.set(HEAVY);
            draw_window(&mut cx, window.into());
            quads.set(1);
            draw_window(&mut cx, window.into());
            quads.set(HEAVY);
            let start = std::time::Instant::now();
            draw_window(&mut cx, window.into());
            retained.push(start.elapsed());

            quads.set(1);
            draw_window(&mut cx, window.into());
            cx.executor().advance_clock(Duration::from_secs(3));
            cx.run_until_parked();
            let (quads_capacity, arena_capacity) = retained_capacity(&mut cx, window.into());
            assert!(quads_capacity <= MIN_RETAINED_CAPACITY && arena_capacity == 1024 * 1024);
            quads.set(HEAVY);
            let start = std::time::Instant::now();
            draw_window(&mut cx, window.into());
            regrown.push(start.elapsed());
        }
        println!("first heavy draw with capacity retained: {retained:?}");
        println!("first heavy draw after idle reclaim:     {regrown:?}");
    }

    /// Platforms that stop requesting frames for idle windows (currently web)
    /// rely on the frame waker firing whenever frame demand arises; a demand
    /// source that skips the waker shows up there as a window that silently
    /// stops repainting until unrelated activity wakes it.
    #[gpui::test]
    fn test_frame_waker_fires_on_frame_demand(cx: &mut TestAppContext) {
        let window = cx.add_window(|_, _| EmptyView);
        let test_window = cx.test_window(window.into());

        // Windows start dirty, and that can predate waker installation;
        // installing the waker must deliver the pending wake or the first
        // frame would never be requested.
        assert!(
            test_window.frame_wake_count() >= 1,
            "opening a window must wake the frame source for the initial frame"
        );

        // Serve outstanding demand (present the frame drawn by `add_window`).
        test_window.simulate_frame_request(RequestFrameOptions::default());

        // An idle window must not wake on clean frames or plain updates, or
        // the frame source could never stop.
        let baseline = test_window.frame_wake_count();
        test_window.simulate_frame_request(RequestFrameOptions::default());
        window.update(cx, |_, _, _| {}).unwrap();
        assert_eq!(
            test_window.frame_wake_count(),
            baseline,
            "clean frames and non-notifying updates must not wake the frame source"
        );

        // Notifying a view in an idle window is the core demand signal.
        window.update(cx, |_, _, cx| cx.notify()).unwrap();
        assert!(
            test_window.frame_wake_count() > baseline,
            "notifying a view in an idle window must wake the frame source"
        );

        // Serving that demand returns to idle without further wakes.
        test_window.simulate_frame_request(RequestFrameOptions::default());
        let baseline = test_window.frame_wake_count();
        test_window.simulate_frame_request(RequestFrameOptions::default());
        assert_eq!(
            test_window.frame_wake_count(),
            baseline,
            "serving demand must return the window to idle"
        );

        // Next-frame callbacks create demand without dirtying the window.
        window
            .update(cx, |_, window, _| window.on_next_frame(|_, _| {}))
            .unwrap();
        assert!(
            test_window.frame_wake_count() > baseline,
            "scheduling a next-frame callback in an idle window must wake the frame source"
        );
    }

    /// Demand that is not a dirty window must still re-arm the frame source
    /// after a frame, or platforms that stop requesting frames for idle
    /// windows (macOS, Windows, X11) stop presenting while GPUI still wants
    /// presentation: high-rate input sustains presentation for a while after
    /// it stops.
    #[gpui::test]
    fn test_frame_waker_rearms_for_non_dirty_demand(cx: &mut TestAppContext) {
        let window = cx.add_window(|_, _| EmptyView);
        let test_window = cx.test_window(window.into());
        test_window.simulate_frame_request(RequestFrameOptions::default());
        test_window.simulate_frame_request(RequestFrameOptions::default());

        // Record a burst of input fast enough to count as high-rate.
        window
            .update(cx, |_, window, _| {
                let mut tracker = window.input_rate_tracker.borrow_mut();
                for _ in 0..64 {
                    tracker.record_input();
                }
                assert!(tracker.is_high_rate());
            })
            .unwrap();
        let baseline = test_window.frame_wake_count();
        test_window.simulate_frame_request(RequestFrameOptions::default());
        assert!(
            test_window.frame_wake_count() > baseline,
            "sustained presentation after high-rate input must re-arm the frame source"
        );

        // Once the sustain period ends, a clean frame returns to idle.
        window
            .update(cx, |_, window, _| {
                window.input_rate_tracker.borrow_mut().sustain_until = std::time::Instant::now();
            })
            .unwrap();
        test_window.simulate_frame_request(RequestFrameOptions::default());
        let baseline = test_window.frame_wake_count();
        test_window.simulate_frame_request(RequestFrameOptions::default());
        assert_eq!(
            test_window.frame_wake_count(),
            baseline,
            "a clean frame after high-rate input ends must return to idle"
        );
    }

    /// A frame request that arrives while next-frame callbacks are pending
    /// must never strand them: either the frame runs them, or (when the
    /// inactive-window frame-rate throttle defers the frame) the waker fires
    /// so another request is delivered.
    #[gpui::test]
    fn test_pending_next_frame_callbacks_are_not_stranded(cx: &mut TestAppContext) {
        let window = cx.add_window(|_, _| EmptyView);
        let test_window = cx.test_window(window.into());
        // Establish a recent last-frame time so the inactive-window throttle
        // can engage on the next request.
        test_window.simulate_frame_request(RequestFrameOptions::default());

        let callback_ran = Rc::new(Cell::new(false));
        window
            .update(cx, {
                let callback_ran = callback_ran.clone();
                move |_, window, _| {
                    window.on_next_frame(move |_, _| callback_ran.set(true));
                }
            })
            .unwrap();

        let baseline = test_window.frame_wake_count();
        test_window.simulate_frame_request(RequestFrameOptions::default());
        // The test window is inactive, so this request throttles to ~30fps
        // when it lands within the throttle interval of the previous frame
        // (the common case here, but timing-dependent): the callback is
        // deferred and the waker must re-arm the frame source. On a slow run
        // the request instead lands outside the interval and runs the
        // callback directly.
        assert!(
            test_window.frame_wake_count() > baseline || callback_ran.get(),
            "a frame request with pending next-frame callbacks must either run them or re-arm the frame source"
        );
    }

    struct CountsRenders(Rc<Cell<usize>>);

    impl Render for CountsRenders {
        fn render(&mut self, _window: &mut Window, _cx: &mut Context<Self>) -> impl IntoElement {
            self.0.set(self.0.get() + 1);
            div()
        }
    }

    /// An unfocused window that is dirty only because a view notified, with
    /// no next-frame callback pending, is held to the inactive frame interval
    /// like an animating one, and the deferred redraw is not lost.
    #[gpui::test]
    fn test_inactive_window_throttles_notify_driven_redraws(cx: &mut TestAppContext) {
        let renders = Rc::new(Cell::new(0));
        let window = cx.update(|cx| {
            cx.open_window(
                WindowOptions {
                    inactive_frame_interval: Some(Duration::from_secs(3600)),
                    ..Default::default()
                },
                {
                    let renders = renders.clone();
                    move |_, cx| cx.new(|_| CountsRenders(renders))
                },
            )
            .unwrap()
        });
        let test_window = cx.test_window(window.into());
        test_window.simulate_frame_request(RequestFrameOptions::default());
        // Dirtied from outside an update: in tests an effect flush draws
        // every dirty window itself, and the frame request would find a
        // clean one.
        let invalidator = window
            .update(cx, |_, window, _| window.invalidator.clone())
            .unwrap();
        invalidator.set_dirty(true);
        let baseline = test_window.frame_wake_count();
        test_window.simulate_frame_request(RequestFrameOptions::default());
        // Only the deferral re-arms the frame source. The render count cannot
        // tell the two apart here: deferring schedules a frame through an
        // update, and the test harness draws on that flush.
        assert!(
            test_window.frame_wake_count() > baseline,
            "the redraw waits out the inactive interval and re-arms the frame source"
        );

        test_window.simulate_active_status_change(true);
        let drawn = renders.get();
        invalidator.set_dirty(true);
        let baseline = test_window.frame_wake_count();
        test_window.simulate_frame_request(RequestFrameOptions::default());
        assert!(renders.get() > drawn, "an active window redraws at once");
        assert_eq!(test_window.frame_wake_count(), baseline, "and defers nothing");
    }

    #[gpui::test]
    fn test_window_reports_no_raw_handle_instead_of_panicking(cx: &mut TestAppContext) {
        use raw_window_handle::{HandleError, HasDisplayHandle as _, HasWindowHandle as _};

        let window = cx.add_window(|_, _| EmptyView);
        window
            .update(cx, |_, window, _| {
                assert!(matches!(
                    window.window_handle(),
                    Err(HandleError::NotSupported)
                ));
                assert!(matches!(
                    window.display_handle(),
                    Err(HandleError::NotSupported)
                ));
            })
            .unwrap();
    }

    #[gpui::test]
    fn test_appearance_change_runs_after_app_update(cx: &mut TestAppContext) {
        let window = cx.add_window(|_, _| EmptyView);
        let observed_appearance = Rc::new(Cell::new(None));
        let _subscription = window
            .update(cx, {
                let observed_appearance = observed_appearance.clone();
                move |_, window, _| {
                    window.observe_window_appearance(move |window, _| {
                        observed_appearance.set(Some(window.appearance()));
                    })
                }
            })
            .unwrap();
        let test_window = cx.test_window(window.into());

        cx.update(|_| {
            test_window.simulate_appearance_change(WindowAppearance::Dark);
            assert_eq!(observed_appearance.get(), None);
        });
        cx.run_until_parked();

        assert_eq!(observed_appearance.get(), Some(WindowAppearance::Dark));
    }

    #[gpui::test]
    fn queued_frame_callback_wakes_a_parked_render_loop(cx: &mut TestAppContext) {
        let window = cx.add_window(|_, _| Empty);
        let test_window = cx.test_window(window.into());

        assert!(test_window.simulate_scheduled_frame());
        assert!(test_window.simulate_scheduled_frame());
        assert!(!test_window.frame_scheduled());

        cx.update_window(window.into(), |_, window, _| {
            window.active.set(true);
            window.on_next_frame(|_, _| {});
        })
        .unwrap();
        assert!(
            test_window.frame_scheduled(),
            "queuing work on a parked window must wake the render loop"
        );

        assert!(test_window.simulate_scheduled_frame());
        assert!(
            test_window.frame_scheduled(),
            "presenting the frame must await one compositor callback"
        );
        assert!(test_window.simulate_scheduled_frame());
        assert!(!test_window.frame_scheduled());
    }

    #[gpui::test]
    fn pending_presentation_wakes_a_parked_render_loop(cx: &mut TestAppContext) {
        let window = cx.add_window(|_, _| Empty);
        let test_window = cx.test_window(window.into());

        assert!(test_window.simulate_scheduled_frame());
        assert!(test_window.simulate_scheduled_frame());
        assert!(!test_window.frame_scheduled());

        cx.update_window(window.into(), |_, window, cx| window.draw(cx).clear(cx))
            .unwrap();

        assert!(
            test_window.frame_scheduled(),
            "a rendered scene awaiting presentation must wake the render loop"
        );
    }

    fn open_render_counting_window(
        cx: &mut TestAppContext,
    ) -> (WindowHandle<CountsRenders>, TestWindow, Rc<Cell<usize>>) {
        let renders = Rc::new(Cell::new(0));
        let window = cx.update(|cx| {
            cx.open_window(WindowOptions::default(), {
                let renders = renders.clone();
                move |_, cx| cx.new(|_| CountsRenders(renders))
            })
            .unwrap()
        });
        let test_window = cx.test_window(window.into());
        test_window.simulate_active_status_change(true);
        test_window.simulate_frame_request(RequestFrameOptions::default());
        (window, test_window, renders)
    }

    const PRESENT_ONLY: RequestFrameOptions = RequestFrameOptions {
        require_presentation: true,
        force_render: false,
    };

    /// A present the platform deferred (no surface to render into) keeps its
    /// frame owed: the window stays marked for presentation, the frame
    /// source is re-armed, the last present is not moved, and the next
    /// request presents the retained scene without rendering it again.
    #[gpui::test]
    fn a_deferred_present_keeps_the_frame_owed(cx: &mut TestAppContext) {
        let (window, test_window, renders) = open_render_counting_window(cx);
        let presented_at = window
            .update(cx, |_, window, _| {
                assert!(!window.needs_present.get(), "the first frame presented");
                window.last_present_at.get()
            })
            .unwrap();
        assert!(presented_at.is_some());

        test_window.queue_present_outcomes([PresentOutcome::Deferred]);
        let drawn = renders.get();
        let wakes = test_window.frame_wake_count();
        test_window.simulate_frame_request(PRESENT_ONLY);
        window
            .update(cx, |_, window, _| {
                assert!(
                    window.needs_present.get(),
                    "a deferred present leaves the frame owed"
                );
                assert_eq!(
                    window.last_present_at.get(),
                    presented_at,
                    "and does not count as a present"
                );
            })
            .unwrap();
        assert_eq!(
            test_window.frame_wake_count(),
            wakes + 1,
            "the frame source is re-armed once for the retry"
        );

        test_window.simulate_frame_request(RequestFrameOptions::default());
        window
            .update(cx, |_, window, _| {
                assert!(
                    !window.needs_present.get(),
                    "the retry presented the owed frame"
                );
                assert_ne!(window.last_present_at.get(), presented_at);
            })
            .unwrap();
        assert_eq!(
            renders.get(),
            drawn,
            "the retry re-presents the retained scene without rendering it"
        );
        assert_eq!(
            test_window.frame_wake_count(),
            wakes + 1,
            "and once it lands nothing re-arms the frame source"
        );
    }

    /// An atlas that has run far enough ahead of every window's last present
    /// that each retained scene may name retired tiles.
    struct AgedAtlas(crate::HeadlessAtlas);

    impl crate::PlatformAtlas for AgedAtlas {
        fn get_or_insert_with<'a>(
            &self,
            key: crate::AtlasKey,
            build: &mut dyn FnMut() -> anyhow::Result<
                Option<(crate::Size<crate::DevicePixels>, std::borrow::Cow<'a, [u8]>)>,
            >,
        ) -> anyhow::Result<Option<crate::AtlasTile>> {
            self.0.get_or_insert_with(key, build)
        }

        fn remove(&self, key: &crate::AtlasKey) {
            self.0.remove(key);
        }

        fn frame_index(&self) -> u64 {
            crate::ATLAS_TILE_MAX_IDLE_FRAMES
        }
    }

    /// A deferral does not advance the window's last-presented atlas frame,
    /// so a stale scene's owed frame still looks stale on every retry. The
    /// scene is rebuilt once for the run of deferrals, not once per retry,
    /// and the next stale present after one lands rebuilds it again.
    #[gpui::test]
    fn retries_of_a_deferred_present_rebuild_a_stale_scene_once(cx: &mut TestAppContext) {
        let (window, test_window, renders) = open_render_counting_window(cx);
        window
            .update(cx, |_, window, _| {
                window.sprite_atlas =
                    std::sync::Arc::new(AgedAtlas(crate::HeadlessAtlas::default()));
                assert!(window.rendered_scene_may_reference_retired_tiles());
            })
            .unwrap();

        test_window.queue_present_outcomes([
            PresentOutcome::Deferred,
            PresentOutcome::Deferred,
            PresentOutcome::Deferred,
        ]);
        let drawn = renders.get();
        for _ in 0..3 {
            test_window.simulate_frame_request(PRESENT_ONLY);
        }
        assert_eq!(
            renders.get(),
            drawn + 1,
            "the first retry rebuilds the stale scene and the rest present it"
        );

        test_window.simulate_frame_request(PRESENT_ONLY);
        assert_eq!(renders.get(), drawn + 1, "the landing present draws nothing");
        window
            .update(cx, |_, window, _| assert!(!window.needs_present.get()))
            .unwrap();

        test_window.simulate_frame_request(PRESENT_ONLY);
        assert_eq!(
            renders.get(),
            drawn + 2,
            "a stale present after one landed rebuilds the scene again"
        );
    }

    /// The frame loop re-arms while a present is owed, which is only safe
    /// because presented and dropped frames both clear it: a platform whose
    /// every present failed would otherwise be asked for a frame on every
    /// request. Errors must stay `Dropped`, never `Deferred`.
    #[gpui::test]
    fn presented_and_dropped_frames_do_not_re_arm_the_frame_source(cx: &mut TestAppContext) {
        let (window, test_window, _renders) = open_render_counting_window(cx);

        for outcome in [PresentOutcome::Presented, PresentOutcome::Dropped] {
            test_window.queue_present_outcomes([outcome]);
            let wakes = test_window.frame_wake_count();
            test_window.simulate_frame_request(PRESENT_ONLY);
            window
                .update(cx, |_, window, _| {
                    assert!(
                        !window.needs_present.get(),
                        "a {outcome:?} present clears the owed frame"
                    );
                })
                .unwrap();
            assert_eq!(
                test_window.frame_wake_count(),
                wakes,
                "a {outcome:?} present does not re-arm the frame source"
            );
        }
    }

    #[gpui::test]
    fn callback_queued_during_a_frame_requests_a_follow_up(cx: &mut TestAppContext) {
        let window = cx.add_window(|_, _| Empty);
        let test_window = cx.test_window(window.into());

        let callback_ran = Rc::new(Cell::new(false));
        cx.update_window(window.into(), |_, window, _| {
            // Inactive windows are frame-rate throttled, which would defer the
            // ticks this test drives manually.
            window.active.set(true);
            let callback_ran = callback_ran.clone();
            window.on_next_frame(move |window, _| {
                window.on_next_frame(move |_, _| callback_ran.set(true));
            });
        })
        .unwrap();

        assert!(test_window.simulate_scheduled_frame());
        assert!(!callback_ran.get());
        assert!(
            test_window.frame_scheduled(),
            "a callback queued mid-frame must schedule a follow-up before the loop parks"
        );

        assert!(test_window.simulate_scheduled_frame());
        assert!(callback_ran.get());
    }

    struct RootView {
        explicit_size: bool,
        child_bounds: Rc<Cell<Bounds<Pixels>>>,
    }

    impl Render for RootView {
        fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
            let child_bounds = self.child_bounds.clone();
            let root = div().flex().flex_col().child(
                canvas(
                    move |bounds, _, _| child_bounds.set(bounds),
                    |_, _, _, _| {},
                )
                .size_full(),
            );
            if self.explicit_size {
                root.w(px(300.)).h(px(200.))
            } else {
                root
            }
        }
    }

    #[test]
    fn auto_sized_window_root_fills_the_window() {
        let mut cx = TestAppContext::single();
        let child_bounds = Rc::new(Cell::new(Bounds::default()));
        let window = cx.add_window({
            let child_bounds = child_bounds.clone();
            move |_, _| RootView {
                explicit_size: false,
                child_bounds,
            }
        });

        let viewport_size = cx
            .update_window(window.into(), |_, window, cx| {
                window.draw(cx).clear(cx);
                window.viewport_size()
            })
            .unwrap();

        assert_eq!(child_bounds.get().size, viewport_size);
    }

    #[test]
    fn explicitly_sized_window_root_keeps_its_size() {
        let mut cx = TestAppContext::single();
        let child_bounds = Rc::new(Cell::new(Bounds::default()));
        let window = cx.add_window({
            let child_bounds = child_bounds.clone();
            move |_, _| RootView {
                explicit_size: true,
                child_bounds,
            }
        });

        cx.update_window(window.into(), |_, window, cx| {
            window.draw(cx).clear(cx);
        })
        .unwrap();

        assert_eq!(child_bounds.get().size, size(px(300.), px(200.)));
    }

    struct FileDragView {
        path: PathBuf,
        observed_drag_moves: Rc<RefCell<Vec<Point<Pixels>>>>,
        observed_drops: Rc<RefCell<Vec<PathBuf>>>,
    }

    struct FileDropExitView(Rc<Cell<usize>>);

    impl Render for FileDropExitView {
        fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
            div().size_full().on_file_drop_exit({
                let observed_file_drop_exit = self.0.clone();
                move |_, _, _| observed_file_drop_exit.set(observed_file_drop_exit.get() + 1)
            })
        }
    }

    impl Render for FileDragView {
        fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
            div()
                .id("file-drag")
                .size_full()
                .on_drag(self.path.clone(), |_, _, _, cx| cx.new(|_| Empty))
                .external_drag_payload(|path: &PathBuf, _, _| {
                    Some(ExternalDragPayload::Files(FileDragPaths::new([(
                        path.clone(),
                        true,
                    )])))
                })
                .on_drag_move({
                    let observed_drag_moves = self.observed_drag_moves.clone();
                    move |event: &DragMoveEvent<PathBuf>, _, _| {
                        observed_drag_moves.borrow_mut().push(event.event.position);
                    }
                })
                .on_drop({
                    let observed_drops = self.observed_drops.clone();
                    move |path: &PathBuf, _, _| observed_drops.borrow_mut().push(path.clone())
                })
        }
    }

    #[gpui::test]
    fn file_drag_is_promoted_once_and_restored_in_source_window(cx: &mut TestAppContext) {
        struct Drag {
            window: AnyWindowHandle,
            observed_drag_moves: Rc<RefCell<Vec<Point<Pixels>>>>,
            observed_drops: Rc<RefCell<Vec<PathBuf>>>,
        }

        fn start_drag(cx: &mut TestAppContext, path: PathBuf, platform_result: bool) -> Drag {
            let observed_drag_moves = Rc::new(RefCell::new(Vec::new()));
            let observed_drops = Rc::new(RefCell::new(Vec::new()));
            let window: AnyWindowHandle = cx
                .add_window({
                    let observed_drag_moves = observed_drag_moves.clone();
                    let observed_drops = observed_drops.clone();
                    move |_, _| FileDragView {
                        path,
                        observed_drag_moves,
                        observed_drops,
                    }
                })
                .into();
            cx.test_window(window)
                .set_start_external_drag_result(platform_result);

            let update_result = cx.update_window(window, |_, window, cx| {
                window.draw(cx).clear(cx);
                window.dispatch_event(
                    MouseDownEvent {
                        position: point(px(10.), px(10.)),
                        button: MouseButton::Left,
                        modifiers: Default::default(),
                        click_count: 1,
                        first_mouse: false,
                    }
                    .to_platform_input(),
                    cx,
                );
                window.dispatch_event(
                    MouseMoveEvent {
                        position: point(px(20.), px(20.)),
                        pressed_button: Some(MouseButton::Left),
                        modifiers: Default::default(),
                    }
                    .to_platform_input(),
                    cx,
                );
                assert!(cx.active_drag.is_some());
            });
            assert!(
                update_result.is_ok(),
                "failed to start drag: {update_result:?}"
            );

            assert!(cx.test_window(window).external_drag_files().is_empty());
            Drag {
                window,
                observed_drag_moves,
                observed_drops,
            }
        }

        let successful_path = PathBuf::from("/tmp/successful-drag");
        let successful = start_drag(cx, successful_path.clone(), true);
        let outside_position = point(px(-1.), px(20.));
        let update_result = cx.update_window(successful.window, |_, window, cx| {
            window.dispatch_event(
                MouseMoveEvent {
                    position: outside_position,
                    pressed_button: Some(MouseButton::Left),
                    modifiers: Default::default(),
                }
                .to_platform_input(),
                cx,
            );
            assert!(cx.active_drag.is_none());
        });
        assert!(
            update_result.is_ok(),
            "failed to promote drag: {update_result:?}"
        );
        assert_eq!(
            cx.test_window(successful.window).external_drag_files(),
            [(successful_path.clone(), true)]
        );
        // Views must still see the move that leaves the window, otherwise they never learn to tear
        // down the drag state they built up while the pointer was inside.
        assert_eq!(
            successful.observed_drag_moves.borrow().last(),
            Some(&outside_position)
        );

        let first_destination_exit_count = Rc::new(Cell::new(0));
        let first_destination: AnyWindowHandle = cx
            .add_window({
                let first_destination_exit_count = first_destination_exit_count.clone();
                move |_, _| FileDropExitView(first_destination_exit_count)
            })
            .into();
        let second_destination_exit_count = Rc::new(Cell::new(0));
        let second_destination: AnyWindowHandle = cx
            .add_window({
                let second_destination_exit_count = second_destination_exit_count.clone();
                move |_, _| FileDropExitView(second_destination_exit_count)
            })
            .into();
        let reentry_position = point(px(30.), px(30.));
        let external_paths = || ExternalPaths([successful_path.clone()].into_iter().collect());
        let update_result = cx.update_window(first_destination, |_, window, cx| {
            window.draw(cx).clear(cx);
            window.dispatch_event(
                FileDropEvent::Entered {
                    position: reentry_position,
                    paths: external_paths(),
                }
                .to_platform_input(),
                cx,
            );
            assert!(
                cx.active_drag
                    .as_ref()
                    .is_some_and(|drag| drag.value.downcast_ref::<ExternalPaths>().is_some())
            );
            window.dispatch_event(FileDropEvent::Exited.to_platform_input(), cx);
            assert!(cx.active_drag.is_none());
            assert_eq!(first_destination_exit_count.get(), 1);
            assert_eq!(second_destination_exit_count.get(), 0);
        });
        assert!(
            update_result.is_ok(),
            "failed to handle drag in first destination window: {update_result:?}"
        );

        let update_result = cx.update_window(second_destination, |_, window, cx| {
            window.draw(cx).clear(cx);
            window.dispatch_event(
                PlatformInput::KeyDown(KeyDownEvent {
                    keystroke: Keystroke::parse("down").expect("valid keystroke"),
                    is_held: false,
                    prefer_character_input: false,
                }),
                cx,
            );
            window.dispatch_event(
                FileDropEvent::Entered {
                    position: reentry_position,
                    paths: external_paths(),
                }
                .to_platform_input(),
                cx,
            );
            assert!(
                cx.active_drag
                    .as_ref()
                    .is_some_and(|drag| drag.value.downcast_ref::<ExternalPaths>().is_some())
            );
            assert_eq!(first_destination_exit_count.get(), 1);
            assert_eq!(second_destination_exit_count.get(), 0);

            window.dispatch_event(FileDropEvent::Exited.to_platform_input(), cx);
            assert!(cx.active_drag.is_none());
            assert_eq!(first_destination_exit_count.get(), 1);
            assert_eq!(second_destination_exit_count.get(), 1);
        });
        assert!(
            update_result.is_ok(),
            "failed to handle drag in second destination window: {update_result:?}"
        );

        let update_result = cx.update_window(successful.window, |_, window, cx| {
            window.dispatch_event(
                FileDropEvent::Entered {
                    position: reentry_position,
                    paths: external_paths(),
                }
                .to_platform_input(),
                cx,
            );
            assert!(
                cx.active_drag
                    .as_ref()
                    .is_some_and(|drag| drag.value.downcast_ref::<PathBuf>().is_some())
            );
            assert_eq!(
                successful.observed_drag_moves.borrow().last(),
                Some(&reentry_position)
            );

            window.dispatch_event(FileDropEvent::Exited.to_platform_input(), cx);
            assert!(cx.active_drag.is_none());

            window.dispatch_event(
                FileDropEvent::Entered {
                    position: reentry_position,
                    paths: external_paths(),
                }
                .to_platform_input(),
                cx,
            );
            assert!(
                cx.active_drag
                    .as_ref()
                    .is_some_and(|drag| drag.value.downcast_ref::<PathBuf>().is_some())
            );

            window.dispatch_event(
                FileDropEvent::Submit {
                    position: reentry_position,
                }
                .to_platform_input(),
                cx,
            );
            assert_eq!(
                successful.observed_drops.borrow().as_slice(),
                std::slice::from_ref(&successful_path)
            );
            assert!(cx.active_drag.is_none());

            window.dispatch_event(FileDropEvent::Exited.to_platform_input(), cx);
            assert!(cx.active_drag.is_none());
            window.dispatch_event(FileDropEvent::Ended.to_platform_input(), cx);
            assert!(cx.active_drag.is_none());

            window.dispatch_event(
                FileDropEvent::Entered {
                    position: reentry_position,
                    paths: external_paths(),
                }
                .to_platform_input(),
                cx,
            );
            assert!(
                cx.active_drag
                    .as_ref()
                    .is_some_and(|drag| drag.value.downcast_ref::<ExternalPaths>().is_some())
            );
            window.dispatch_event(FileDropEvent::Exited.to_platform_input(), cx);
        });
        assert!(
            update_result.is_ok(),
            "failed to restore drag in source window: {update_result:?}"
        );

        let cancelled_path = PathBuf::from("/tmp/cancelled-drag");
        let cancelled = start_drag(cx, cancelled_path.clone(), true);
        let update_result = cx.update_window(cancelled.window, |_, window, cx| {
            window.dispatch_event(
                MouseMoveEvent {
                    position: outside_position,
                    pressed_button: Some(MouseButton::Left),
                    modifiers: Default::default(),
                }
                .to_platform_input(),
                cx,
            );
            assert!(cx.active_drag.is_none());

            window.dispatch_event(
                FileDropEvent::Entered {
                    position: reentry_position,
                    paths: ExternalPaths([cancelled_path].into_iter().collect()),
                }
                .to_platform_input(),
                cx,
            );
            assert!(
                cx.active_drag
                    .as_ref()
                    .is_some_and(|drag| drag.value.downcast_ref::<PathBuf>().is_some())
            );
            assert!(cx.stop_active_drag(window));
            assert!(cx.active_drag.is_none());
        });
        assert!(
            update_result.is_ok(),
            "failed to cancel restored drag: {update_result:?}"
        );
        assert!(!cx.update(|cx| cx.end_platform_drag(cancelled.window.window_id())));

        let removed_path = PathBuf::from("/tmp/removed-window-drag");
        let removed = start_drag(cx, removed_path, true);
        let removed_window_id = removed.window.window_id();
        let update_result = cx.update_window(removed.window, |_, window, cx| {
            window.dispatch_event(
                MouseMoveEvent {
                    position: outside_position,
                    pressed_button: Some(MouseButton::Left),
                    modifiers: Default::default(),
                }
                .to_platform_input(),
                cx,
            );
            assert!(cx.active_drag.is_none());
            window.remove_window();
        });
        assert!(
            update_result.is_ok(),
            "failed to remove drag source window: {update_result:?}"
        );
        assert!(!cx.update(|cx| cx.end_platform_drag(removed_window_id)));

        let failed_path = PathBuf::from("/tmp/failed-drag");
        let failed = start_drag(cx, failed_path.clone(), false);
        let update_result = cx.update_window(failed.window, |_, window, cx| {
            for x_position in [-1., -2.] {
                window.dispatch_event(
                    MouseMoveEvent {
                        position: point(px(x_position), px(20.)),
                        pressed_button: Some(MouseButton::Left),
                        modifiers: Default::default(),
                    }
                    .to_platform_input(),
                    cx,
                );
            }
            assert!(cx.active_drag.is_some());
        });
        assert!(
            update_result.is_ok(),
            "failed to retain drag after platform failure: {update_result:?}"
        );
        assert_eq!(
            cx.test_window(failed.window).external_drag_files(),
            [(failed_path, true)]
        );
    }

    struct FocusForwarder {
        a: FocusHandle,
        b: FocusHandle,
    }

    impl Render for FocusForwarder {
        fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
            div()
                .size_full()
                .child(div().w(px(50.)).h(px(50.)).track_focus(&self.a))
                .child(div().w(px(50.)).h(px(50.)).track_focus(&self.b))
        }
    }

    /// When a focus listener moves focus again (e.g. a dock forwarding focus to its
    /// active panel), the resulting focus events must be dispatched without waiting
    /// for an unrelated redraw of the window.
    #[gpui::test]
    fn test_focus_moved_by_focus_listener_is_dispatched(cx: &mut TestAppContext) {
        let b_focus_count = Rc::new(Cell::new(0));
        let window = cx.add_window({
            let b_focus_count = b_focus_count.clone();
            move |window, cx| {
                let a = cx.focus_handle();
                let b = cx.focus_handle();
                cx.on_focus(&a, window, |this: &mut FocusForwarder, window, cx| {
                    let b = this.b.clone();
                    window.focus(&b, cx);
                })
                .detach();
                cx.on_focus(&b, window, move |_, _, _| {
                    b_focus_count.set(b_focus_count.get() + 1);
                })
                .detach();
                FocusForwarder { a, b }
            }
        });

        window
            .update(cx, |_, window, _| window.activate_window())
            .unwrap();
        cx.executor().run_until_parked();

        window
            .update(cx, |this, window, cx| {
                let a = this.a.clone();
                window.focus(&a, cx);
            })
            .unwrap();
        cx.executor().run_until_parked();

        window
            .update(cx, |this, window, _| {
                assert!(this.b.is_focused(window));
            })
            .unwrap();
        assert_eq!(b_focus_count.get(), 1);
    }

    #[gpui::test]
    fn claimed_touch_drag_receives_movement_and_release(cx: &mut TestAppContext) {
        let events = Rc::new(RefCell::new(Vec::new()));
        let window = cx.add_window({
            let events = events.clone();
            move |_, _| TouchDragListener { events }
        });
        let touch = TouchId(1);

        dispatch_touch(window, cx, touch, TouchPhase::Started, 10.);
        dispatch_touch(window, cx, touch, TouchPhase::Moved, 30.);
        dispatch_touch(window, cx, touch, TouchPhase::Ended, 40.);

        assert_eq!(
            events.borrow().as_slice(),
            [
                (TouchPhase::Started, px(10.)),
                (TouchPhase::Moved, px(30.)),
                (TouchPhase::Ended, px(40.)),
            ]
        );
    }

    struct TouchDragListener {
        events: Rc<RefCell<Vec<(TouchPhase, Pixels)>>>,
    }

    impl Render for TouchDragListener {
        fn render(&mut self, _window: &mut Window, _cx: &mut Context<Self>) -> impl IntoElement {
            let events = self.events.clone();
            canvas(
                |_, _, _| {},
                move |_, _, window, _| {
                    window.on_mouse_event(move |event: &TouchDragEvent, phase, window, _cx| {
                        if phase != DispatchPhase::Bubble {
                            return;
                        }
                        events.borrow_mut().push((event.phase, event.position.x));
                        if event.phase == TouchPhase::Started {
                            window.prevent_default();
                        }
                    });
                },
            )
        }
    }

    #[gpui::test]
    fn long_press_is_claimed_only_when_started_prevents_default(cx: &mut TestAppContext) {
        for response in [
            LongPressResponse::PreventDefault,
            LongPressResponse::StopPropagation,
            LongPressResponse::None,
        ] {
            let phases = Rc::new(RefCell::new(Vec::new()));
            let window = cx.add_window({
                let phases = phases.clone();
                move |_, _| LongPressListener { phases, response }
            });
            dispatch_touch(window, cx, TouchId(1), TouchPhase::Started, 0.);
            cx.executor().advance_clock(Duration::from_millis(501));
            cx.executor().run_until_parked();
            window
                .update(cx, |_, window, _| {
                    assert_eq!(
                        window.long_press_capture.is_some(),
                        response == LongPressResponse::PreventDefault
                    );
                })
                .unwrap();
            dispatch_touch(window, cx, TouchId(1), TouchPhase::Moved, 2.);
            dispatch_touch(window, cx, TouchId(1), TouchPhase::Ended, 2.);
            window
                .update(cx, |_, window, _| {
                    assert!(window.long_press_capture.is_none());
                })
                .unwrap();

            let phases = phases.borrow();
            if response == LongPressResponse::PreventDefault {
                assert_eq!(
                    phases.as_slice(),
                    [TouchPhase::Started, TouchPhase::Moved, TouchPhase::Ended]
                );
            } else {
                assert_eq!(phases.as_slice(), [TouchPhase::Started]);
            }
        }
    }

    #[gpui::test]
    fn stale_default_prevention_does_not_claim_long_press(cx: &mut TestAppContext) {
        let phases = Rc::new(RefCell::new(Vec::new()));
        let window = cx.add_window({
            let phases = phases.clone();
            move |_, _| LongPressListener {
                phases,
                response: LongPressResponse::None,
            }
        });
        window
            .update(cx, |_, window, _| {
                window.prevent_default();
            })
            .unwrap();

        dispatch_touch(window, cx, TouchId(1), TouchPhase::Started, 0.);
        cx.executor().advance_clock(Duration::from_millis(501));
        cx.executor().run_until_parked();
        dispatch_touch(window, cx, TouchId(1), TouchPhase::Moved, 2.);

        assert_eq!(phases.borrow().as_slice(), [TouchPhase::Started]);
    }

    #[gpui::test]
    fn resolved_touch_cancels_scheduled_long_press(cx: &mut TestAppContext) {
        for (phase, position) in [
            (TouchPhase::Ended, 0.),
            (TouchPhase::Cancelled, 0.),
            (TouchPhase::Moved, 20.),
        ] {
            let phases = Rc::new(RefCell::new(Vec::new()));
            let window = cx.add_window({
                let phases = phases.clone();
                move |_, _| LongPressListener {
                    phases,
                    response: LongPressResponse::PreventDefault,
                }
            });
            dispatch_touch(window, cx, TouchId(1), TouchPhase::Started, 0.);
            dispatch_touch(window, cx, TouchId(1), phase, position);
            cx.executor().advance_clock(Duration::from_millis(501));
            cx.executor().run_until_parked();

            assert!(phases.borrow().is_empty(), "{phase:?} allowed long press");
        }
    }

    #[gpui::test]
    fn stale_long_press_timer_cannot_affect_replacement_touch(cx: &mut TestAppContext) {
        let phases = Rc::new(RefCell::new(Vec::new()));
        let window = cx.add_window({
            let phases = phases.clone();
            move |_, _| LongPressListener {
                phases,
                response: LongPressResponse::PreventDefault,
            }
        });
        let first_touch = TouchId(1);
        dispatch_touch(window, cx, first_touch, TouchPhase::Started, 0.);
        cx.executor().advance_clock(Duration::from_millis(250));
        dispatch_touch(window, cx, first_touch, TouchPhase::Cancelled, 0.);
        dispatch_touch(window, cx, TouchId(2), TouchPhase::Started, 10.);

        cx.executor().advance_clock(Duration::from_millis(251));
        cx.executor().run_until_parked();
        assert!(phases.borrow().is_empty());

        cx.executor().advance_clock(Duration::from_millis(250));
        cx.executor().run_until_parked();
        assert_eq!(phases.borrow().as_slice(), [TouchPhase::Started]);
    }

    #[gpui::test]
    fn test_underline_exclusions_preserve_device_geometry(cx: &mut TestAppContext) {
        test_underline_paint_at_scales(cx, |window| {
            let (numerator, denominator) = match window.scale_factor() {
                1.0 => (1, 1),
                1.25 => (5, 4),
                1.5 => (3, 2),
                2.0 => (2, 1),
                3.0 => (3, 1),
                scale => panic!("unexpected scale {scale}"),
            };
            let snap = |quarters: i32| {
                let scaled = quarters * numerator;
                let divisor = 4 * denominator;
                let rounded =
                    scaled.abs() / divisor + i32::from(2 * (scaled.abs() % divisor) > divisor);
                ScaledPixels((scaled.signum() * rounded) as f32)
            };
            let stroke = |quarters| {
                if quarters == 0 {
                    ScaledPixels(0.)
                } else {
                    snap(quarters).max(ScaledPixels(1.))
                }
            };

            for origin in [-101, -3, -2, -1, 0, 1, 2, 3, 101] {
                for width in [0, 1, 3, 84] {
                    for thickness in [0, 1, 4, 7] {
                        for wavy in [false, true] {
                            let style = UnderlineStyle {
                                thickness: px(thickness as f32 / 4.),
                                color: Some(hsla(0.25, 0.5, 0.75, 0.5)),
                                wavy,
                            };
                            let bounds = Bounds::new(
                                point(snap(origin), snap(-origin)),
                                size(
                                    stroke(width),
                                    stroke(thickness) * if wavy { 3. } else { 1. },
                                ),
                            );
                            let origin = point(px(origin as f32 / 4.), px(-origin as f32 / 4.));
                            let width = px(width as f32 / 4.);
                            assert_eq!(window.underline_bounds(origin, width, &style), bounds);
                            let original = paint_test_underlines(window, |window| {
                                window.paint_underline(origin, width, &style);
                            })
                            .to_vec();
                            assert_eq!(original.len(), usize::from(!bounds.is_empty()));
                            if let Some(underline) = original.first() {
                                assert_eq!(underline.bounds, bounds);
                                assert_eq!(underline.thickness, stroke(thickness));
                                assert_eq!(underline.wavy, wavy.into());
                                assert_eq!(underline.color, hsla(0.25, 0.5, 0.75, 0.5));
                            }

                            let underlines = paint_test_underlines(window, |window| {
                                window.paint_underline_with_exclusions(origin, width, &style, &[]);
                            });
                            assert_eq!(underlines.len(), original.len());
                            for (actual, original) in underlines.iter().zip(&original) {
                                assert_same_underline_geometry(actual, original);
                                assert_eq!(actual.content_mask, original.content_mask);
                            }

                            let left = bounds.left().0 as i32;
                            let right = bounds.right().0 as i32;
                            let exclusions = [
                                (15, 25),
                                (3, 7),
                                (5, 10),
                                (10, 12),
                                (0, 0),
                                (4, 2),
                                (-50, -1),
                                (70, 100),
                            ]
                            .map(|(start, end)| {
                                ScaledPixels((left + start) as f32)
                                    ..ScaledPixels((left + end) as f32)
                            });
                            let underlines = paint_test_underlines(window, |window| {
                                window.paint_underline_with_exclusions(
                                    origin,
                                    width,
                                    &style,
                                    &exclusions,
                                );
                            });
                            let expected = (left..right)
                                .filter(|column| {
                                    !bounds.is_empty()
                                        && !exclusions.iter().any(|span| {
                                            span.contains(&ScaledPixels(*column as f32))
                                        })
                                })
                                .collect::<Vec<_>>();
                            assert_eq!(underline_device_columns(underlines), expected);
                            for underline in underlines {
                                assert_same_underline_geometry(underline, &original[0]);
                            }
                        }
                    }
                }
            }
        });
    }

    #[gpui::test]
    fn test_underline_exclusions_preserve_helvetica_warning_edge(cx: &mut TestAppContext) {
        test_underline_paint_at_scales(cx, |window| {
            if window.scale_factor() != 2.0 {
                return;
            }
            let style = UnderlineStyle {
                thickness: px(1.),
                color: None,
                wavy: true,
            };
            let origin = point(px(2.888_183_8), px(15.357_917));
            let width = px(23.848_145) - origin.x;
            let original = paint_test_underlines(window, |window| {
                window.paint_underline(origin, width, &style);
            })[0];
            assert_eq!(original.bounds.left(), ScaledPixels(6.));
            assert_eq!(original.bounds.right(), ScaledPixels(48.));
            let point_bounds = window.underline_bounds(origin, px(10.829_102), &style);
            assert_eq!(point_bounds.left(), ScaledPixels(6.));
            assert_eq!(point_bounds.right(), ScaledPixels(28.));

            let underlines = paint_test_underlines(window, |window| {
                window.paint_underline_with_exclusions(
                    origin,
                    width,
                    &style,
                    &[point_bounds.left()..point_bounds.right()],
                );
            });
            assert_eq!(underlines.len(), 1);
            assert_same_underline_geometry(&underlines[0], &original);
            assert_eq!(
                underline_device_columns(underlines),
                (28..48).collect::<Vec<_>>()
            );
        });
    }

    #[gpui::test]
    fn test_underline_exclusions_preserve_content_mask_and_opacity(cx: &mut TestAppContext) {
        test_underline_paint_at_scales(cx, |window| {
            let scale = window.scale_factor();
            let original_mask = window.content_mask();
            let original_opacity = window.element_opacity();
            let mask = ContentMask {
                bounds: Bounds::from_corners(point(px(4.), px(10.)), point(px(16.), px(12.))),
            };
            let style = UnderlineStyle {
                thickness: px(2.),
                color: Some(hsla(0.25, 0.5, 0.75, 0.5)),
                wavy: true,
            };
            let origin = point(px(-1.25), px(9.25));
            let width = px(24.);
            window.with_content_mask(Some(mask), |window| {
                window.with_element_opacity(Some(0.5), |window| {
                    window.with_element_opacity(Some(0.5), |window| {
                        let original = paint_test_underlines(window, |window| {
                            window.paint_underline(origin, width, &style);
                        })[0];
                        assert_eq!(original.color, hsla(0.25, 0.5, 0.75, 0.125));
                        let underlines = paint_test_underlines(window, |window| {
                            window.paint_underline_with_exclusions(
                                origin,
                                width,
                                &style,
                                &[ScaledPixels(6. * scale)..ScaledPixels(8. * scale)],
                            );
                        });
                        assert_eq!(underlines.len(), 2);
                        let expected = [(4. * scale, 6. * scale), (8. * scale, 16. * scale)].map(
                            |(left, right)| {
                                Bounds::from_corners(
                                    point(ScaledPixels(left), ScaledPixels((10. * scale).floor())),
                                    point(ScaledPixels(right), ScaledPixels((12. * scale).ceil())),
                                )
                            },
                        );
                        assert_eq!(
                            underlines
                                .iter()
                                .map(|underline| underline.content_mask.bounds)
                                .collect::<Vec<_>>(),
                            expected
                        );
                        for underline in underlines {
                            assert_same_underline_geometry(underline, &original);
                        }
                    });
                });
            });
            assert_eq!(window.content_mask(), original_mask);
            assert_eq!(window.element_opacity(), original_opacity);
        });
    }

    #[gpui::test]
    fn test_underline_exclusions_adversarial_permutations(cx: &mut TestAppContext) {
        test_underline_paint_at_scales(cx, |window| {
            let style = UnderlineStyle {
                thickness: px(1.),
                color: None,
                wavy: true,
            };
            let origin = point(px(-4.), px(-1.));
            let width = px(8.);
            let left = (-4. * window.scale_factor()) as i32;
            let right = (4. * window.scale_factor()) as i32;
            let endpoints = [-16, -8, -1, 0, 1, 8, 16];
            for first_start in endpoints {
                for first_end in endpoints {
                    for second_start in endpoints {
                        for second_end in endpoints {
                            let exclusions = [first_start..first_end, second_start..second_end];
                            let expected = (left..right)
                                .filter(|column| {
                                    !exclusions.iter().any(|span| span.contains(column))
                                })
                                .collect::<Vec<_>>();
                            let exclusions = exclusions.map(|span| {
                                ScaledPixels(span.start as f32)..ScaledPixels(span.end as f32)
                            });
                            let underlines = paint_test_underlines(window, |window| {
                                window.paint_underline_with_exclusions(
                                    origin,
                                    width,
                                    &style,
                                    &exclusions,
                                );
                            });
                            assert_eq!(
                                underline_device_columns(underlines),
                                expected,
                                "{exclusions:?}"
                            );
                        }
                    }
                }
            }
        });
    }

    #[derive(Clone, Copy, PartialEq)]
    enum LongPressResponse {
        PreventDefault,
        StopPropagation,
        None,
    }

    struct LongPressListener {
        phases: Rc<RefCell<Vec<TouchPhase>>>,
        response: LongPressResponse,
    }

    impl Render for LongPressListener {
        fn render(&mut self, _window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
            let entity = cx.entity();
            let phases = self.phases.clone();
            let response = self.response;
            canvas(
                |_, _, _| {},
                move |_, _, window, _| {
                    window.on_mouse_event(move |event: &LongPressEvent, phase, window, cx| {
                        if phase != DispatchPhase::Bubble {
                            return;
                        }
                        phases.borrow_mut().push(event.phase);
                        match response {
                            LongPressResponse::PreventDefault => {
                                window.capture_long_press(&entity);
                                window.prevent_default();
                            }
                            LongPressResponse::StopPropagation => cx.stop_propagation(),
                            LongPressResponse::None => {}
                        }
                    });
                },
            )
        }
    }

    struct UnderlineTestView(Rc<dyn Fn(&mut Window)>);

    impl Render for UnderlineTestView {
        fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
            let paint = self.0.clone();
            canvas(
                |_, _, _| {},
                move |_, _, window, _| {
                    window.content_mask_stack.push(ContentMask {
                        bounds: Bounds::from_corners(
                            point(px(-1000.), px(-1000.)),
                            point(px(1000.), px(1000.)),
                        ),
                    });
                    paint(window);
                    window.content_mask_stack.pop();
                },
            )
            .size_full()
        }
    }

    fn test_underline_paint_at_scales(
        cx: &mut TestAppContext,
        paint: impl Fn(&mut Window) + 'static,
    ) {
        let window = cx.add_window(move |_, _| UnderlineTestView(Rc::new(paint)));
        for scale in [1., 1.25, 1.5, 2., 3.] {
            cx.simulate_window_scale_factor_change(window.into(), scale);
            cx.update_window(window.into(), |_, window, cx| window.draw(cx).clear(cx))
                .unwrap();
        }
    }

    fn paint_test_underlines(window: &mut Window, paint: impl FnOnce(&mut Window)) -> &[Underline] {
        window.next_frame.scene.clear();
        paint(window);
        &window.next_frame.scene.underlines
    }

    fn assert_same_underline_geometry(actual: &Underline, expected: &Underline) {
        assert_eq!(actual.bounds, expected.bounds);
        assert_eq!(actual.thickness, expected.thickness);
        assert_eq!(actual.wavy, expected.wavy);
        assert_eq!(actual.color, expected.color);
        assert_eq!(actual.pad, expected.pad);
    }

    fn underline_device_columns(underlines: &[Underline]) -> Vec<i32> {
        underlines
            .iter()
            .flat_map(|underline| {
                let bounds = underline.bounds.intersect(&underline.content_mask.bounds);
                bounds.left().0 as i32..bounds.right().0 as i32
            })
            .collect()
    }

    fn dispatch_touch<T: 'static>(
        window: crate::WindowHandle<T>,
        cx: &mut TestAppContext,
        id: TouchId,
        phase: TouchPhase,
        x: f32,
    ) {
        window
            .update(cx, |_, window, cx| {
                window.dispatch_event(
                    TouchEvent {
                        id,
                        phase,
                        position: point(px(x), px(0.)),
                        predicted_position: None,
                        force: None,
                    }
                    .to_platform_input(),
                    cx,
                );
            })
            .unwrap();
    }
}

#[cfg(all(test, any(feature = "inspector", debug_assertions)))]
mod inspector_tests {
    use super::*;
    use crate::{
        DivInspectorState, InspectorElementId, MouseDownEvent, StyleRefinement, TestAppContext, div,
    };

    #[gpui::test]
    fn inspector_only_tracks_its_open_window(cx: &mut TestAppContext) {
        let windows = [
            cx.add_window(|_, cx| InspectorTestRoot {
                child: cx.new(|_| InspectorTestView::default()),
            }),
            cx.add_window(|_, cx| InspectorTestRoot {
                child: cx.new(|_| InspectorTestView::default()),
            }),
        ];
        for window in windows {
            assert_closed_inspector(window.into(), cx);
        }
        for _ in 0..2 {
            cx.update_window(windows[0].into(), |root, window, cx| {
                let root = root.downcast::<InspectorTestRoot>().expect("test root");
                let child_widths = root.read(cx).child.read(cx).child_widths.clone();
                window.toggle_inspector(cx);
                window.draw(cx).clear(cx);
                assert_eq!(child_widths.borrow().as_slice(), &[px(10.); 3]);
                let path = window
                    .rendered_frame
                    .next_inspector_instance_ids
                    .iter()
                    .find_map(|(path, count)| (*count == 3).then(|| path.clone()))
                    .expect("anonymous siblings share an inspector path");
                let selected_id = InspectorElementId {
                    path,
                    instance_id: 1,
                };
                let position = window
                    .rendered_frame
                    .hitboxes
                    .iter()
                    .find(|hitbox| {
                        window.rendered_frame.inspector_hitboxes.get(&hitbox.id)
                            == Some(&selected_id)
                    })
                    .expect("middle sibling is pickable")
                    .bounds
                    .center();
                window.simulate_mouse_move(position, cx);
                window.dispatch_event(
                    PlatformInput::MouseDown(MouseDownEvent {
                        position,
                        button: MouseButton::Left,
                        modifiers: Modifiers::default(),
                        click_count: 1,
                        first_mouse: false,
                    }),
                    cx,
                );
                window.dispatch_event(
                    PlatformInput::MouseUp(MouseUpEvent {
                        position,
                        button: MouseButton::Left,
                        modifiers: Modifiers::default(),
                        click_count: 1,
                    }),
                    cx,
                );
                assert!(!window.is_inspector_picking(cx));
                assert_eq!(
                    window
                        .inspector
                        .as_ref()
                        .expect("open inspector")
                        .read(cx)
                        .active_element_id(),
                    Some(&selected_id)
                );
                window.draw(cx).clear(cx);
                window.with_inspector_state::<DivInspectorState, _>(
                    Some(&selected_id),
                    cx,
                    |state, _| {
                        let state = state.as_mut().expect("selected div has style state");
                        assert_eq!(
                            state.base_style.size.width,
                            Some(crate::Length::from(px(10.)))
                        );
                        state.base_style.size.width = Some(crate::Length::from(px(25.)));
                    },
                );
                window.refresh();
                window.draw(cx).clear(cx);
                assert_eq!(
                    child_widths.borrow().as_slice(),
                    &[px(10.), px(25.), px(10.)]
                );
            })
            .expect("pick and edit a cached child");
            assert_closed_inspector(windows[1].into(), cx);
            windows[0]
                .update(cx, |_, window, cx| window.toggle_inspector(cx))
                .expect("close inspector");
            assert_closed_inspector(windows[0].into(), cx);
        }
    }

    struct InspectorTestRoot {
        child: Entity<InspectorTestView>,
    }

    impl Render for InspectorTestRoot {
        fn render(&mut self, _window: &mut Window, _cx: &mut Context<Self>) -> impl IntoElement {
            self.child
                .clone()
                .cached(StyleRefinement::default().size(px(100.)))
        }
    }

    #[derive(Default)]
    struct InspectorTestView {
        child_widths: Rc<RefCell<Vec<Pixels>>>,
    }

    impl Render for InspectorTestView {
        fn render(&mut self, _window: &mut Window, _cx: &mut Context<Self>) -> impl IntoElement {
            let child_widths = self.child_widths.clone();
            div()
                .on_children_prepainted(move |bounds, _, _| {
                    *child_widths.borrow_mut() =
                        bounds.iter().map(|bounds| bounds.size.width).collect();
                })
                .with_dynamic_prepaint_order(|_, _| SmallVec::from_iter([2, 0, 1]))
                .id("inspector-root")
                .flex()
                .children((0..3).map(|_| div().size(px(10.)).flex_shrink_0()))
        }
    }

    fn assert_closed_inspector(window: AnyWindowHandle, cx: &mut TestAppContext) {
        cx.update_window(window, |root, window, cx| {
            window.draw(cx).clear(cx);
            window.draw(cx).clear(cx);
            let root = root.downcast::<InspectorTestRoot>().expect("test root");
            assert_eq!(
                root.read(cx)
                    .child
                    .read(cx)
                    .child_widths
                    .borrow()
                    .as_slice(),
                &[px(10.); 3]
            );
            for frame in [&window.rendered_frame, &window.next_frame] {
                assert_eq!(frame.next_inspector_instance_ids.capacity(), 0);
                assert_eq!(frame.inspector_hitboxes.capacity(), 0);
            }
        })
        .expect("closed inspector has no bookkeeping and no style overrides");
    }
}
