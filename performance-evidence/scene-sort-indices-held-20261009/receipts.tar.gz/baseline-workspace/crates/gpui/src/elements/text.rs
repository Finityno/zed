use crate::{
    ActiveTooltip, AnyView, App, Bounds, DispatchPhase, Element, ElementId, GlobalElementId,
    HighlightStyle, Hitbox, HitboxBehavior, InspectorElementId, IntoElement, LayoutId,
    MouseDownEvent, MouseMoveEvent, MouseUpEvent, Pixels, Point, SharedString, Size, TextAlign,
    TextRun, TextStyle, TooltipId, Window, WrappedLine,
    WrappedLineLayout, px, register_tooltip_mouse_handlers, set_tooltip_on_window,
};
use anyhow::Context as _;
use gpui_util::ResultExt;
use itertools::Itertools;
use smallvec::SmallVec;
use std::{
    borrow::Cow,
    cell::{Cell, RefCell},
    mem,
    ops::{Deref, DerefMut, Range},
    rc::Rc,
    sync::Arc,
    sync::LazyLock,
    time::{Duration, Instant},
};

mod measurement;

static SHIMMER_EPOCH: LazyLock<Instant> = LazyLock::new(Instant::now);

/// Sweep angle of the shimmer highlight, in CSS `linear-gradient` degrees
/// (0 = upward, growing clockwise). 120° matches the diagonal sheen used by
/// the web `linear-gradient(120deg, ...)` shiny-text idiom.
pub const DEFAULT_SHIMMER_ANGLE: f32 = 120.0;

/// Progress of the band across its travel, in `0..=1`. `hold` reserves a
/// fraction of the cycle for the band to sit off the end of the text, which
/// reads as a pause between sweeps.
pub(crate) fn shimmer_delta(period: Duration, hold: f32) -> f32 {
    let period = period.as_secs_f64();
    if period <= 0.0 {
        return 0.0;
    }
    // Uptime in f32 loses about 8 ms per ulp after a day and 62 ms after a
    // week and a half, which quantizes the sweep into visible steps; only
    // the unit phase is narrowed.
    let phase = (SHIMMER_EPOCH.elapsed().as_secs_f64() / period).rem_euclid(1.0) as f32;
    let sweep = 1.0 - hold.clamp(0.0, 0.95);
    (phase / sweep).min(1.0)
}

/// Unit sweep vector for a CSS gradient angle, in y-down screen space.
fn shimmer_direction(angle_degrees: f32) -> [f32; 2] {
    let (sin, cos) = angle_degrees.to_radians().sin_cos();
    [sin, -cos]
}

/// How wide a [`ShimmerText`] highlight band is, measured along the sweep.
#[derive(Copy, Clone, Debug, PartialEq)]
pub enum ShimmerSpread {
    /// A multiple of the laid-out text's own width, so the band keeps the same
    /// proportion of the label whatever it says. `1.0` lights roughly half the
    /// label at once.
    TextWidths(f32),
    /// A multiple of the average character width, so the band scales with the
    /// font rather than with how much text there is.
    CharWidths(f32),
    /// An absolute width in logical pixels.
    Pixels(Pixels),
}

/// Everything about a [`ShimmerText`] sweep except the text and its colors.
///
/// The defaults describe a wide, soft band whose peak sits past its middle:
/// a glyph brightens quickly as the leading edge arrives and dims slowly
/// behind it, which reads as a sheen travelling over the label rather than a
/// hard bar crossing it.
#[derive(Copy, Clone, Debug, PartialEq)]
pub struct ShimmerStyle {
    /// Width of the highlight band.
    pub spread: ShimmerSpread,
    /// Where the band reaches full strength, as a fraction of its width
    /// measured from the trailing edge. `0.5` is symmetric; higher values leave
    /// a longer tail behind the sweep.
    pub peak: f32,
    /// Exponent applied to each side's smoothstep ramp. `1.0` is the plain
    /// smoothstep; larger values concentrate the light near the peak, smaller
    /// values flatten the band out towards its edges.
    pub falloff: f32,
    /// Fraction of the highlight withheld from the band's shoulders, so only
    /// its core reaches the full highlight color. `0.0` lights the whole band
    /// evenly; `0.5` halves everything outside the core.
    pub core_gain: f32,
    /// Half-width of that core, as a fraction of the band width.
    pub core_spread: f32,
    /// Sweep angle in CSS `linear-gradient` degrees (0 = upward, growing
    /// clockwise). `90` gives a vertical, unslanted band.
    pub angle: f32,
    /// Duration of one full cycle, sweep plus hold.
    pub period: Duration,
    /// Fraction of the cycle the band spends parked past the end of the text,
    /// i.e. the pause between sweeps.
    pub hold: f32,
    /// Scales the highlight color's alpha, so the same color can shimmer
    /// harder or softer without picking a new one.
    pub intensity: f32,
}

impl Default for ShimmerStyle {
    /// Measured off a reference recording of the look this is meant to match:
    /// a band as wide as the label itself, peaking two thirds of the way along
    /// so the trailing ramp is twice the leading one, on a one second cycle
    /// with a tenth of it spent parked past the end.
    fn default() -> Self {
        Self {
            spread: ShimmerSpread::TextWidths(1.0),
            peak: 0.66,
            falloff: 1.0,
            core_gain: 0.0,
            core_spread: 0.35,
            angle: DEFAULT_SHIMMER_ANGLE,
            period: Duration::from_millis(1000),
            hold: 0.1,
            intensity: 1.0,
        }
    }
}

impl ShimmerStyle {
    /// Width of the band in logical pixels, for text of the given width.
    fn band_width(&self, text_width: Pixels, average_char_width: Pixels) -> Pixels {
        let width = match self.spread {
            ShimmerSpread::TextWidths(ratio) => text_width * ratio.max(0.0),
            ShimmerSpread::CharWidths(chars) => average_char_width * chars.max(0.0),
            // Absolute by definition, so only the zero-width guard applies.
            ShimmerSpread::Pixels(width) => return width.max(px(1.0)),
        };
        width.max(average_char_width.max(px(1.0)))
    }
}

/// An [`Element`] that renders text.
///
/// In general, [`Text`] objects should be created via the [`text`] macro:
/// ```rust
/// # use gpui::*;
/// # fn render() -> impl IntoElement {
/// div().child(text!("hello"))
/// # }
/// ```
/// ## IDs and Accessibility
///
/// [`Text`] elements have an ID. This ID is primarily used to produce nodes in
/// the accessibility tree, which allows the text to be visible to screen
/// readers and other assistive technologies.
///
/// This ID is stable across frames. If the same text, with the same ID, is
/// present in two consecutive frames, no updates are reported to the screen
/// reader. If the text changes, but the ID stays the same, then the screen
/// reader will be notified that a text node's content has changed. **However**,
/// if the ID changes, then the screen reader will be notified that a node has
/// been removed, and a new node has been added.
///
/// When using the [`text`] macro, each invocation of the macro will get a
/// unique ID, derived from its position in the source code (filename, line, and
/// column). For example:
/// ```rust
/// # use gpui::*;
/// let x = text!("hello");
/// let y = text!("hello");
/// // not equal, because different `text!` invocations produced them
/// assert_ne!(x.id(), y.id());
///
/// fn make_text(s: &str) -> Text { text!(s) }
/// let x = make_text("hello");
/// let y = make_text("hello");
/// // equal, because the same `text!` invocation produced them
/// assert_eq!(x.id(), y.id());
/// ```
/// When the contents of an invocation of [`text`] do not change, this
/// distinction is less relevant (with the caveat that you still need to take
/// care to ensure that duplicate IDs do not appear).
///
/// However, when a [`text`] invocation's argument *does* change, you should
/// consider whether this change should be reported as a node "updating its
/// contents", or an old node being destroyed and a new node being created.
#[derive(Debug, Clone)]
pub struct Text {
    id: Option<ElementId>,
    text: SharedString,
}

impl Text {
    /// Create a new [`Text`] element with a specific ID.
    ///
    /// If you want a unique ID to be assigned automatically, use the [`text`]
    /// macro. The docs for [`Text`] have more detail about choosing IDs.
    #[inline]
    pub const fn new(id: ElementId, text: SharedString) -> Self {
        Self { id: Some(id), text }
    }

    /// Create a new [`Text`] element that is inaccessible to screen readers.
    ///
    /// In order for text to be accessible to screen readers, it must have an ID
    /// provided. If you want text to be accessible, either use [`text`] to have
    /// an ID automatically assigned, or use [`Text::new`] to manually assign an
    /// ID.
    ///
    /// This function is intended for use inside custom UI components, where
    /// accessible properties may be set on parent containers.
    #[inline]
    pub const fn new_inaccessible(text: SharedString) -> Self {
        Self { id: None, text }
    }

    /// The ID of this [`Text`] element.
    #[inline]
    pub const fn id(&self) -> Option<&ElementId> {
        self.id.as_ref()
    }

    /// Produce a new [`Text`] with the given `id`.
    pub fn with_id(mut self, id: impl Into<ElementId>) -> Self {
        self.id = Some(id.into());
        self
    }

    /// The text that this [`Text`] element will display.
    #[inline]
    pub const fn text(&self) -> &SharedString {
        &self.text
    }
}

impl Deref for Text {
    type Target = SharedString;
    fn deref(&self) -> &Self::Target {
        &self.text
    }
}

impl DerefMut for Text {
    fn deref_mut(&mut self) -> &mut Self::Target {
        &mut self.text
    }
}

/// Trivial hash function for the location information produced by the [`text`]
/// macro. Not covered by semver guarantees. Performance is not particularly
/// significant because it's only used on small strings in const contexts.
#[doc(hidden)]
pub const fn __hash_text_macro_location_unstable_do_not_use(s: &'static str) -> u64 {
    const BASIS: u64 = 0xcbf29ce484222325;
    const PRIME: u64 = 0x100000001b3;

    let bytes = s.as_bytes();
    let mut hash = BASIS;
    let mut i = 0;
    while i < bytes.len() {
        hash ^= bytes[i] as u64;
        hash = hash.wrapping_mul(PRIME);
        i += 1;
    }
    hash
}

/// Create a new [`Text`] element.
///
/// ```rust
/// # use gpui::*;
/// let a = text!("hello");
/// let b = text!(id = "farewell-message", "hello");
///
/// ```
///
/// Text created with this macro is *accessible*. The macro generates an ID
/// based on the source location. See the docs for [`Text`] for a more in-depth
/// explanation of the significance of the ID of a [`Text`] element.
#[macro_export]
macro_rules! text {
    (id = $id:expr, $text:expr) => {{ $crate::Text::new($id.into(), $text.into()) }};
    ($text:expr) => {{
        const ID: &'static str = concat!(file!(), "/", line!(), ":", column!());
        const HASH: u64 = $crate::__hash_text_macro_location_unstable_do_not_use(ID);
        $crate::Text::new($crate::ElementId::Integer(HASH), $text.into())
    }};
}

impl IntoElement for Text {
    type Element = Self;
    #[inline]
    fn into_element(self) -> Self::Element {
        self
    }
}

impl Element for Text {
    type RequestLayoutState = TextLayout;
    type PrepaintState = ();

    fn id(&self) -> Option<ElementId> {
        self.id.clone()
    }

    fn source_location(&self) -> Option<&'static std::panic::Location<'static>> {
        None
    }

    fn a11y_role(&self) -> Option<accesskit::Role> {
        if self.id.is_some() {
            Some(accesskit::Role::Label)
        } else {
            None
        }
    }

    fn write_a11y_info(&self, node: &mut accesskit::Node) {
        node.set_value(self.text.to_string());
    }

    fn request_layout(
        &mut self,
        id: Option<&GlobalElementId>,
        inspector_id: Option<&InspectorElementId>,
        window: &mut Window,
        cx: &mut App,
    ) -> (LayoutId, Self::RequestLayoutState) {
        <SharedString as Element>::request_layout(&mut self.text, id, inspector_id, window, cx)
    }

    fn prepaint(
        &mut self,
        id: Option<&GlobalElementId>,
        inspector_id: Option<&InspectorElementId>,
        bounds: Bounds<Pixels>,
        request_layout: &mut Self::RequestLayoutState,
        window: &mut Window,
        cx: &mut App,
    ) -> Self::PrepaintState {
        <SharedString as Element>::prepaint(
            &mut self.text,
            id,
            inspector_id,
            bounds,
            request_layout,
            window,
            cx,
        )
    }

    fn paint(
        &mut self,
        id: Option<&GlobalElementId>,
        inspector_id: Option<&InspectorElementId>,
        bounds: Bounds<Pixels>,
        request_layout: &mut Self::RequestLayoutState,
        prepaint: &mut Self::PrepaintState,
        window: &mut Window,
        cx: &mut App,
    ) {
        <SharedString as Element>::paint(
            &mut self.text,
            id,
            inspector_id,
            bounds,
            request_layout,
            prepaint,
            window,
            cx,
        );
    }
}

impl Element for &'static str {
    type RequestLayoutState = TextLayout;
    type PrepaintState = ();

    fn id(&self) -> Option<ElementId> {
        None
    }

    fn source_location(&self) -> Option<&'static core::panic::Location<'static>> {
        None
    }

    fn request_layout(
        &mut self,
        _id: Option<&GlobalElementId>,
        _inspector_id: Option<&InspectorElementId>,
        window: &mut Window,
        cx: &mut App,
    ) -> (LayoutId, Self::RequestLayoutState) {
        let mut state = TextLayout::default();
        let layout_id = state.layout(SharedString::from(*self), None, window, cx);
        (layout_id, state)
    }

    fn prepaint(
        &mut self,
        _id: Option<&GlobalElementId>,
        _inspector_id: Option<&InspectorElementId>,
        bounds: Bounds<Pixels>,
        text_layout: &mut Self::RequestLayoutState,
        window: &mut Window,
        cx: &mut App,
    ) {
        measurement::fit_to_width(text_layout, bounds.size.width, window, cx);
        text_layout.prepaint(bounds, self, window.text_style().text_align);
        text_layout.note_position(window);
        text_layout.hold_carried_lines(window);
    }

    fn paint(
        &mut self,
        _id: Option<&GlobalElementId>,
        _inspector_id: Option<&InspectorElementId>,
        _bounds: Bounds<Pixels>,
        text_layout: &mut TextLayout,
        _: &mut (),
        window: &mut Window,
        cx: &mut App,
    ) {
        text_layout.paint(self, window, cx)
    }
}

impl IntoElement for &'static str {
    type Element = Self;

    fn into_element(self) -> Self::Element {
        self
    }
}

impl IntoElement for String {
    type Element = SharedString;

    fn into_element(self) -> Self::Element {
        self.into()
    }
}

impl IntoElement for Cow<'static, str> {
    type Element = SharedString;

    fn into_element(self) -> Self::Element {
        self.into()
    }
}

impl Element for SharedString {
    type RequestLayoutState = TextLayout;
    type PrepaintState = ();

    fn id(&self) -> Option<ElementId> {
        None
    }

    fn source_location(&self) -> Option<&'static core::panic::Location<'static>> {
        None
    }

    fn request_layout(
        &mut self,
        _id: Option<&GlobalElementId>,
        _inspector_id: Option<&InspectorElementId>,
        window: &mut Window,
        cx: &mut App,
    ) -> (LayoutId, Self::RequestLayoutState) {
        let mut state = TextLayout::default();
        let layout_id = state.layout(self.clone(), None, window, cx);
        (layout_id, state)
    }

    fn prepaint(
        &mut self,
        _id: Option<&GlobalElementId>,
        _inspector_id: Option<&InspectorElementId>,
        bounds: Bounds<Pixels>,
        text_layout: &mut Self::RequestLayoutState,
        window: &mut Window,
        cx: &mut App,
    ) {
        measurement::fit_to_width(text_layout, bounds.size.width, window, cx);
        text_layout.prepaint(bounds, self.as_ref(), window.text_style().text_align);
        text_layout.note_position(window);
        text_layout.hold_carried_lines(window);
    }

    fn paint(
        &mut self,
        _id: Option<&GlobalElementId>,
        _inspector_id: Option<&InspectorElementId>,
        _bounds: Bounds<Pixels>,
        text_layout: &mut Self::RequestLayoutState,
        _: &mut Self::PrepaintState,
        window: &mut Window,
        cx: &mut App,
    ) {
        text_layout.paint(self.as_ref(), window, cx)
    }
}

impl IntoElement for SharedString {
    type Element = Self;

    fn into_element(self) -> Self::Element {
        self
    }
}

/// Renders text with runs of different styles.
///
/// Callers are responsible for setting the correct style for each run.
/// For text with a uniform style, you can usually avoid calling this constructor
/// and just pass text directly.
pub struct StyledText {
    text: SharedString,
    runs: Option<Vec<TextRun>>,
    delayed_highlights: Option<Vec<(Range<usize>, HighlightStyle)>>,
    delayed_font_family_overrides: Option<Vec<(Range<usize>, SharedString)>>,
    layout: TextLayout,
}

impl StyledText {
    /// Construct a new styled text element from the given string.
    pub fn new(text: impl Into<SharedString>) -> Self {
        StyledText {
            text: text.into(),
            runs: None,
            delayed_highlights: None,
            delayed_font_family_overrides: None,
            layout: TextLayout::default(),
        }
    }

    /// Get the layout for this element. This can be used to map indices to pixels and vice versa.
    pub fn layout(&self) -> &TextLayout {
        &self.layout
    }

    /// Set the styling attributes for the given text, as well as
    /// as any ranges of text that have had their style customized.
    pub fn with_default_highlights(
        mut self,
        default_style: &TextStyle,
        highlights: impl IntoIterator<Item = (Range<usize>, HighlightStyle)>,
    ) -> Self {
        debug_assert!(
            self.delayed_highlights.is_none(),
            "Can't use `with_default_highlights` and `with_highlights`"
        );
        let runs = Self::compute_runs(&self.text, default_style, highlights);
        self.with_runs(runs)
    }

    /// Set the styling attributes for the given text, as well as
    /// as any ranges of text that have had their style customized.
    pub fn with_highlights(
        mut self,
        highlights: impl IntoIterator<Item = (Range<usize>, HighlightStyle)>,
    ) -> Self {
        debug_assert!(
            self.runs.is_none(),
            "Can't use `with_highlights` and `with_default_highlights`"
        );
        self.delayed_highlights = Some(
            highlights
                .into_iter()
                .inspect(|(run, _)| {
                    debug_assert!(self.text.is_char_boundary(run.start));
                    debug_assert!(self.text.is_char_boundary(run.end));
                })
                .collect::<Vec<_>>(),
        );
        self
    }

    fn compute_runs(
        text: &str,
        default_style: &TextStyle,
        highlights: impl IntoIterator<Item = (Range<usize>, HighlightStyle)>,
    ) -> Vec<TextRun> {
        let highlights = highlights.into_iter();
        // Each highlight yields at most itself and the gap before it, plus one
        // trailing run; sizing for that up front spares the regrowth copies.
        let mut runs = Vec::with_capacity(highlights.size_hint().0 * 2 + 1);
        let mut ix = 0;
        for (range, highlight) in highlights {
            if ix < range.start {
                debug_assert!(text.is_char_boundary(range.start));
                runs.push(default_style.clone().to_run(range.start - ix));
            }
            debug_assert!(text.is_char_boundary(range.end));
            runs.push(
                default_style
                    .clone()
                    .highlight(highlight)
                    .to_run(range.len()),
            );
            ix = range.end;
        }
        if ix < text.len() {
            runs.push(default_style.to_run(text.len() - ix));
        }
        runs
    }

    /// Override the font family for specific byte ranges of the text.
    ///
    /// This is resolved lazily at layout time, so the overrides are applied
    /// on top of the inherited text style from the parent element.
    /// Can be combined with [`with_highlights`](Self::with_highlights).
    ///
    /// The overrides must be sorted by range start and non-overlapping.
    /// Each override range must fall on character boundaries.
    pub fn with_font_family_overrides(
        mut self,
        overrides: impl IntoIterator<Item = (Range<usize>, SharedString)>,
    ) -> Self {
        self.delayed_font_family_overrides = Some(
            overrides
                .into_iter()
                .inspect(|(range, _)| {
                    debug_assert!(self.text.is_char_boundary(range.start));
                    debug_assert!(self.text.is_char_boundary(range.end));
                })
                .collect(),
        );
        self
    }

    fn apply_font_family_overrides(
        runs: &mut [TextRun],
        overrides: &[(Range<usize>, SharedString)],
    ) {
        let mut byte_offset = 0;
        let mut override_idx = 0;
        for run in runs.iter_mut() {
            let run_end = byte_offset + run.len;
            while override_idx < overrides.len() && overrides[override_idx].0.end <= byte_offset {
                override_idx += 1;
            }
            if override_idx < overrides.len() {
                let (ref range, ref family) = overrides[override_idx];
                if byte_offset >= range.start && run_end <= range.end {
                    run.font.family = family.clone();
                }
            }
            byte_offset = run_end;
        }
    }

    /// Set the text runs for this piece of text.
    pub fn with_runs(mut self, runs: Vec<TextRun>) -> Self {
        let mut text = &*self.text;
        for run in &runs {
            text = text.get(run.len..).unwrap_or_else(|| {
                #[cfg(debug_assertions)]
                panic!("invalid text run. Text: '{text}', run: {run:?}");
                #[cfg(not(debug_assertions))]
                panic!("invalid text run");
            });
        }
        assert!(text.is_empty(), "invalid text run");
        self.runs = Some(runs);
        self
    }
}

impl Element for StyledText {
    type RequestLayoutState = ();
    type PrepaintState = ();

    fn id(&self) -> Option<ElementId> {
        None
    }

    fn source_location(&self) -> Option<&'static core::panic::Location<'static>> {
        None
    }

    fn request_layout(
        &mut self,
        _id: Option<&GlobalElementId>,
        _inspector_id: Option<&InspectorElementId>,
        window: &mut Window,
        cx: &mut App,
    ) -> (LayoutId, Self::RequestLayoutState) {
        let font_family_overrides = self.delayed_font_family_overrides.take();
        let mut runs = self.runs.take().or_else(|| {
            self.delayed_highlights.take().map(|delayed_highlights| {
                Self::compute_runs(&self.text, &window.text_style(), delayed_highlights)
            })
        });

        if let Some(ref overrides) = font_family_overrides {
            let runs =
                runs.get_or_insert_with(|| vec![window.text_style().to_run(self.text.len())]);
            Self::apply_font_family_overrides(runs, overrides);
        }

        let layout_id = self.layout.layout(self.text.clone(), runs, window, cx);
        (layout_id, ())
    }

    fn prepaint(
        &mut self,
        _id: Option<&GlobalElementId>,
        _inspector_id: Option<&InspectorElementId>,
        bounds: Bounds<Pixels>,
        _: &mut Self::RequestLayoutState,
        window: &mut Window,
        cx: &mut App,
    ) {
        measurement::fit_to_width(&self.layout, bounds.size.width, window, cx);
        self.layout
            .prepaint(bounds, &self.text, window.text_style().text_align);
        self.layout.note_position(window);
        self.layout.hold_carried_lines(window);
    }

    fn paint(
        &mut self,
        _id: Option<&GlobalElementId>,
        _inspector_id: Option<&InspectorElementId>,
        _bounds: Bounds<Pixels>,
        _: &mut Self::RequestLayoutState,
        _: &mut Self::PrepaintState,
        window: &mut Window,
        cx: &mut App,
    ) {
        self.layout.paint(&self.text, window, cx)
    }
}

impl IntoElement for StyledText {
    type Element = Self;

    fn into_element(self) -> Self::Element {
        self
    }
}

/// Renders text with a moving shimmer highlight using a shared GPUI text layout.
///
/// The element uses the current window text style for layout and font metrics,
/// while `base_color` overrides the text color used for the underlying glyphs.
pub struct ShimmerText {
    text: SharedString,
    base_color: Option<crate::Hsla>,
    highlight_color: Option<crate::Hsla>,
    style: ShimmerStyle,
    layout: TextLayout,
}

impl ShimmerText {
    /// Construct a shimmer text element from the given string.
    pub fn new(text: impl Into<SharedString>) -> Self {
        Self {
            text: text.into(),
            base_color: None,
            highlight_color: None,
            style: ShimmerStyle::default(),
            layout: TextLayout::default(),
        }
    }

    /// Override the base glyph color used for the shimmered text.
    pub fn base_color(mut self, color: crate::Hsla) -> Self {
        self.base_color = Some(color);
        self
    }

    /// Set the highlight color that sweeps across the text.
    pub fn highlight_color(mut self, color: crate::Hsla) -> Self {
        self.highlight_color = Some(color);
        self
    }

    /// Replace the whole sweep description at once.
    pub fn style(mut self, style: ShimmerStyle) -> Self {
        self.style = style;
        self
    }

    /// Set the duration of one full cycle, sweep plus hold.
    pub fn duration(mut self, duration: Duration) -> Self {
        self.style.period = duration;
        self
    }

    /// Set the highlight band width in average character widths. The band is
    /// twice `spread` wide, matching the historical meaning of this knob; use
    /// [`ShimmerText::band`] for the other units.
    pub fn spread(mut self, spread: f32) -> Self {
        self.style.spread = ShimmerSpread::CharWidths(spread.max(1.0) * 2.0);
        self
    }

    /// Set the highlight band width.
    pub fn band(mut self, spread: ShimmerSpread) -> Self {
        self.style.spread = spread;
        self
    }

    /// Set where the band reaches full strength, as a fraction of its width
    /// measured from the trailing edge.
    pub fn peak(mut self, peak: f32) -> Self {
        self.style.peak = peak;
        self
    }

    /// Set the exponent applied to each side's smoothstep ramp.
    pub fn falloff(mut self, falloff: f32) -> Self {
        self.style.falloff = falloff;
        self
    }

    /// Concentrate the highlight into the middle of the band: `gain` is the
    /// fraction held back from the shoulders, `spread` the core's half-width as
    /// a fraction of the band.
    pub fn core(mut self, gain: f32, spread: f32) -> Self {
        self.style.core_gain = gain;
        self.style.core_spread = spread;
        self
    }

    /// Set the fraction of the cycle the band spends parked past the end of the
    /// text, i.e. the pause between sweeps.
    pub fn hold(mut self, hold: f32) -> Self {
        self.style.hold = hold;
        self
    }

    /// Scale the highlight color's alpha.
    pub fn intensity(mut self, intensity: f32) -> Self {
        self.style.intensity = intensity;
        self
    }

    /// Set the sweep angle in CSS `linear-gradient` degrees. Defaults to
    /// [`DEFAULT_SHIMMER_ANGLE`]; 90° gives a vertical (non-slanted) band.
    pub fn angle(mut self, degrees: f32) -> Self {
        self.style.angle = degrees;
        self
    }
}

impl Element for ShimmerText {
    type RequestLayoutState = ();
    type PrepaintState = ();

    fn id(&self) -> Option<ElementId> {
        None
    }

    fn source_location(&self) -> Option<&'static core::panic::Location<'static>> {
        None
    }

    fn request_layout(
        &mut self,
        _id: Option<&GlobalElementId>,
        _inspector_id: Option<&InspectorElementId>,
        window: &mut Window,
        cx: &mut App,
    ) -> (LayoutId, Self::RequestLayoutState) {
        let mut text_style = window.text_style();
        if let Some(base_color) = self.base_color {
            text_style.color = base_color;
        }

        let layout_id = self.layout.layout(
            self.text.clone(),
            Some(vec![text_style.to_run(self.text.len())]),
            window,
            cx,
        );
        (layout_id, ())
    }

    fn prepaint(
        &mut self,
        _id: Option<&GlobalElementId>,
        _inspector_id: Option<&InspectorElementId>,
        bounds: Bounds<Pixels>,
        _: &mut Self::RequestLayoutState,
        window: &mut Window,
        cx: &mut App,
    ) {
        measurement::fit_to_width(&self.layout, bounds.size.width, window, cx);
        self.layout
            .prepaint(bounds, &self.text, window.text_style().text_align);
        self.layout.note_position(window);
        self.layout.hold_carried_lines(window);
    }

    fn paint(
        &mut self,
        _id: Option<&GlobalElementId>,
        _inspector_id: Option<&InspectorElementId>,
        _bounds: Bounds<Pixels>,
        _: &mut Self::RequestLayoutState,
        _: &mut Self::PrepaintState,
        window: &mut Window,
        cx: &mut App,
    ) {
        if let Some(highlight_color) = self.highlight_color {
            self.layout
                .paint_shimmer(&self.text, highlight_color, &self.style, window, cx);
        } else {
            self.layout.paint(&self.text, window, cx);
        }
    }
}

impl IntoElement for ShimmerText {
    type Element = Self;

    fn into_element(self) -> Self::Element {
        self
    }
}

/// The Layout for TextElement. This can be used to map indices to pixels and vice versa.
#[derive(Default, Clone)]
pub struct TextLayout(Rc<RefCell<Option<TextLayoutInner>>>);

impl crate::window::view_retention::PositionedState for RefCell<Option<TextLayoutInner>> {
    fn translate(&self, by: Point<Pixels>) {
        if let Some(inner) = self.borrow_mut().as_mut()
            && let Some(bounds) = inner.bounds.as_mut()
        {
            bounds.origin += by;
        }
    }
}

struct TextLayoutInner {
    text_align: TextAlign,
    len: usize,
    lines: SmallVec<[WrappedLine; 1]>,
    line_height: Pixels,
    wrap_width: Option<Pixels>,
    truncate_width: Option<Pixels>,
    size: Option<Size<Pixels>>,
    bounds: Option<Bounds<Pixels>>,
    /// Whether the lines were carried over from last frame's element rather
    /// than asked of the line layout cache this frame.
    carried: bool,
    measured_by: measurement::MeasuredBy,
}

impl TextLayout {
    fn layout(
        &self,
        text: SharedString,
        runs: Option<Vec<TextRun>>,
        window: &mut Window,
        cx: &mut App,
    ) -> LayoutId {
        measurement::layout_text(self, text, runs, window, cx)
    }

    /// Keeps lines carried over from last frame's element in the line layout
    /// cache, since this frame never asked the cache for them.
    fn hold_carried_lines(&self, window: &Window) {
        if let Some(inner) = self.0.borrow_mut().as_mut()
            && mem::take(&mut inner.carried)
        {
            window.text_system().hold_lines(&inner.lines);
        }
    }

    /// Notes that the layout holds where it was prepainted, for a view drawn
    /// again elsewhere from the last frame to move it along.
    fn note_position(&self, window: &mut Window) {
        window.note_positioned_state(|| self.0.clone());
    }

    fn prepaint(&self, bounds: Bounds<Pixels>, text: &str, text_align: TextAlign) {
        let mut element_state = self.0.borrow_mut();
        let element_state = element_state
            .as_mut()
            .with_context(|| format!("measurement has not been performed on {text}"))
            .unwrap();
        element_state.bounds = Some(bounds);
        element_state.text_align = text_align;
    }

    fn paint(&self, text: &str, window: &mut Window, cx: &mut App) {
        let element_state = self.0.borrow();
        let element_state = element_state
            .as_ref()
            .with_context(|| format!("measurement has not been performed on {text}"))
            .unwrap();
        let bounds = element_state
            .bounds
            .with_context(|| format!("prepaint has not been performed on {text}"))
            .unwrap();

        let line_height = element_state.line_height;
        let mut line_origin = bounds.origin;
        let text_style = window.text_style();
        for line in &element_state.lines {
            line.paint_background(
                line_origin,
                line_height,
                text_style.text_align,
                Some(bounds),
                window,
                cx,
            )
            .log_err();
            line.paint(
                line_origin,
                line_height,
                text_style.text_align,
                Some(bounds),
                window,
                cx,
            )
            .log_err();
            line_origin.y += line.size(line_height).height;
        }
    }

    fn paint_shimmer(
        &self,
        text: &str,
        highlight_color: crate::Hsla,
        style: &ShimmerStyle,
        window: &mut Window,
        cx: &mut App,
    ) {
        let element_state = self.0.borrow();
        let element_state = element_state
            .as_ref()
            .with_context(|| format!("measurement has not been performed on {text}"))
            .unwrap();
        let bounds = element_state
            .bounds
            .with_context(|| format!("prepaint has not been performed on {text}"))
            .unwrap();

        let text_size = element_state.size.unwrap_or(bounds.size);
        let line_height = element_state.line_height;
        let text_style = window.text_style();
        let mut line_origin = bounds.origin;
        if text_size.width <= Pixels::ZERO {
            for line in &element_state.lines {
                line.paint_background(
                    line_origin,
                    line_height,
                    text_style.text_align,
                    Some(bounds),
                    window,
                    cx,
                )
                .log_err();
                line.paint(
                    line_origin,
                    line_height,
                    text_style.text_align,
                    Some(bounds),
                    window,
                    cx,
                )
                .log_err();
                line_origin.y += line.size(line_height).height;
            }
            return;
        }

        let char_count = text.chars().count().max(1) as f32;
        let average_char_width = text_size.width * (1.0 / char_count);
        let band_width = style.band_width(text_size.width, average_char_width);

        // The band sweeps along `direction`, so it has to enter and exit at the
        // projected extremes of the text box, not the horizontal ones —
        // otherwise a slanted band clips in on one corner and out on another.
        let direction = shimmer_direction(style.angle);
        let projected_width = direction[0] * text_size.width.0;
        let projected_height = direction[1] * text_size.height.0;
        let axis_min = projected_width.min(0.0) + projected_height.min(0.0);
        let axis_max = projected_width.max(0.0) + projected_height.max(0.0);
        let travel = px(axis_max - axis_min) + band_width * 2.0;
        let band_start = px(axis_min) - band_width;
        let mut highlight_color = highlight_color;
        // The highlight is painted as a separate overlay from the glyphs, so an
        // ancestor's opacity has to be applied here or the text fades while
        // its shimmer stays at full strength.
        highlight_color.a *= style.intensity.clamp(0.0, 1.0) * window.element_opacity();

        // Lines are aligned inside `bounds` by `text_align`; the band has to
        // follow the glyphs, not the element box. Multi-line text aligns each
        // line by its own width, so this follows the widest. Signed: text
        // wider than its bounds is painted at a negative offset, and the band
        // goes with it.
        let align_offset = match text_style.text_align {
            TextAlign::Left => Pixels::ZERO,
            TextAlign::Center => (bounds.size.width - text_size.width) / 2.0,
            TextAlign::Right => bounds.size.width - text_size.width,
        };
        let shimmer_origin = crate::point(bounds.origin.x + align_offset, bounds.origin.y);

        // The band's position is a function of time. Rather than drawing the
        // view again for every step, the scene carries the sweep and moves the
        // band itself before each present (see `Scene::advance_time_animations`),
        // so an otherwise idle window only re-presents its last frame.
        let sweep = (highlight_color.a > 0.0 && !style.period.is_zero()).then_some(
            crate::window::TextShimmerSweep {
                band_start,
                travel,
                period: style.period,
                hold: style.hold,
            },
        );

        window.with_text_shimmer(
            crate::window::TextShimmerStyle {
                origin: shimmer_origin,
                highlight_color,
                band_origin: band_start + travel * shimmer_delta(style.period, style.hold),
                band_width,
                direction,
                // `pow(0.0, 0.0)` is undefined in the shading languages, and a
                // zero-width core would divide by zero, so both are clamped
                // here rather than in every backend.
                peak: style.peak.clamp(0.01, 0.99),
                falloff: style.falloff.max(0.05),
                core_gain: style.core_gain.clamp(0.0, 1.0),
                core_spread: style.core_spread.clamp(0.01, 1.0),
                animation: 0,
            },
            sweep,
            |window| {
                for line in &element_state.lines {
                    line.paint_background(
                        line_origin,
                        line_height,
                        text_style.text_align,
                        Some(bounds),
                        window,
                        cx,
                    )
                    .log_err();
                    line.paint(
                        line_origin,
                        line_height,
                        text_style.text_align,
                        Some(bounds),
                        window,
                        cx,
                    )
                    .log_err();
                    line_origin.y += line.size(line_height).height;
                }
            },
        );
    }

    /// Get the byte index into the input of the pixel position.
    pub fn index_for_position(&self, mut position: Point<Pixels>) -> Result<usize, usize> {
        let element_state = self.0.borrow();
        let element_state = element_state
            .as_ref()
            .expect("measurement has not been performed");
        let bounds = element_state
            .bounds
            .expect("prepaint has not been performed");

        if position.y < bounds.top() {
            return Err(0);
        }

        let line_height = element_state.line_height;
        let mut line_origin = bounds.origin;
        let mut line_start_ix = 0;
        for line in &element_state.lines {
            let line_bottom = line_origin.y + line.size(line_height).height;
            if position.y > line_bottom {
                line_origin.y = line_bottom;
                line_start_ix += line.len() + 1;
            } else {
                let mut position_within_line = position - line_origin;
                let row_index = (position_within_line.y / line_height) as usize;
                position_within_line.x -= line.alignment_offset(
                    row_index,
                    element_state.text_align,
                    bounds.size.width,
                );
                match line.index_for_position(position_within_line, line_height) {
                    Ok(index_within_line) => return Ok(line_start_ix + index_within_line),
                    Err(index_within_line) => return Err(line_start_ix + index_within_line),
                }
            }
        }

        Err(line_start_ix.saturating_sub(1))
    }

    /// Get the pixel position for the given byte index.
    pub fn position_for_index(&self, index: usize) -> Option<Point<Pixels>> {
        let element_state = self.0.borrow();
        let element_state = element_state
            .as_ref()
            .expect("measurement has not been performed");
        let bounds = element_state
            .bounds
            .expect("prepaint has not been performed");
        let line_height = element_state.line_height;

        let mut line_origin = bounds.origin;
        let mut line_start_ix = 0;

        for line in &element_state.lines {
            let line_end_ix = line_start_ix + line.len();
            if index < line_start_ix {
                break;
            } else if index > line_end_ix {
                line_origin.y += line.size(line_height).height;
                line_start_ix = line_end_ix + 1;
                continue;
            } else {
                let ix_within_line = index - line_start_ix;
                let mut position = line.position_for_index(ix_within_line, line_height)?;
                position.x += line.alignment_offset(
                    (position.y / line_height) as usize,
                    element_state.text_align,
                    bounds.size.width,
                );
                return Some(line_origin + position);
            }
        }

        None
    }

    /// Retrieve the layout for the line containing the given byte index.
    pub fn line_layout_for_index(&self, index: usize) -> Option<Arc<WrappedLineLayout>> {
        let element_state = self.0.borrow();
        let element_state = element_state
            .as_ref()
            .expect("measurement has not been performed");
        let mut line_start_ix = 0;

        for line in &element_state.lines {
            let line_end_ix = line_start_ix + line.len();
            if index < line_start_ix {
                break;
            } else if index > line_end_ix {
                line_start_ix = line_end_ix + 1;
                continue;
            } else {
                return Some(line.layout.clone());
            }
        }

        None
    }

    /// Retrieve all line layouts in source order.
    pub fn line_layouts(&self) -> SmallVec<[Arc<WrappedLineLayout>; 1]> {
        self.0
            .borrow()
            .as_ref()
            .expect("measurement has not been performed")
            .lines
            .iter()
            .map(|line| line.layout.clone())
            .collect()
    }

    /// The alignment used to paint the laid-out text.
    pub fn text_align(&self) -> TextAlign {
        self.0.borrow().as_ref().expect("prepaint has not been performed").text_align
    }

    /// The bounds of this layout.
    pub fn bounds(&self) -> Bounds<Pixels> {
        self.0.borrow().as_ref().unwrap().bounds.unwrap()
    }

    /// The line height for this layout.
    pub fn line_height(&self) -> Pixels {
        self.0.borrow().as_ref().unwrap().line_height
    }

    /// The UTF-8 length of the underlying text.
    pub fn len(&self) -> usize {
        self.0.borrow().as_ref().unwrap().len
    }

    /// The text for this layout.
    pub fn text(&self) -> String {
        self.0
            .borrow()
            .as_ref()
            .unwrap()
            .lines
            .iter()
            .map(|s| &s.text)
            .join("\n")
    }

    /// The text for this layout (with soft-wraps as newlines)
    pub fn wrapped_text(&self) -> String {
        let mut accumulator = String::new();

        for wrapped in self.0.borrow().as_ref().unwrap().lines.iter() {
            let mut seen = 0;
            for boundary in wrapped.layout.wrap_boundaries.iter() {
                let index = wrapped.layout.unwrapped_layout.runs[boundary.run_ix].glyphs
                    [boundary.glyph_ix]
                    .index;

                accumulator.push_str(&wrapped.text[seen..index]);
                accumulator.push('\n');
                seen = index;
            }
            accumulator.push_str(&wrapped.text[seen..]);
            accumulator.push('\n');
        }
        // Remove trailing newline
        accumulator.pop();
        accumulator
    }
}

/// A text element that can be interacted with.
pub struct InteractiveText {
    element_id: ElementId,
    text: StyledText,
    click_listener:
        Option<Box<dyn Fn(&[Range<usize>], InteractiveTextClickEvent, &mut Window, &mut App)>>,
    hover_listener: Option<Box<dyn Fn(Option<usize>, MouseMoveEvent, &mut Window, &mut App)>>,
    tooltip_builder: Option<Rc<dyn Fn(usize, &mut Window, &mut App) -> Option<AnyView>>>,
    tooltip_id: Option<TooltipId>,
    clickable_ranges: Vec<Range<usize>>,
}

struct InteractiveTextClickEvent {
    mouse_down_index: usize,
    mouse_up_index: usize,
}

#[doc(hidden)]
#[derive(Default)]
pub struct InteractiveTextState {
    mouse_down_index: Rc<Cell<Option<usize>>>,
    hovered_index: Rc<Cell<Option<usize>>>,
    active_tooltip: Rc<RefCell<Option<ActiveTooltip>>>,
    long_press_tooltip_active: Rc<Cell<bool>>,
}

/// InteractiveTest is a wrapper around StyledText that adds mouse interactions.
impl InteractiveText {
    /// Creates a new InteractiveText from the given text.
    pub fn new(id: impl Into<ElementId>, text: StyledText) -> Self {
        Self {
            element_id: id.into(),
            text,
            click_listener: None,
            hover_listener: None,
            tooltip_builder: None,
            tooltip_id: None,
            clickable_ranges: Vec::new(),
        }
    }

    /// on_click is called when the user clicks on one of the given ranges, passing the index of
    /// the clicked range.
    pub fn on_click(
        mut self,
        ranges: Vec<Range<usize>>,
        listener: impl Fn(usize, &mut Window, &mut App) + 'static,
    ) -> Self {
        self.click_listener = Some(Box::new(move |ranges, event, window, cx| {
            for (range_ix, range) in ranges.iter().enumerate() {
                if range.contains(&event.mouse_down_index) && range.contains(&event.mouse_up_index)
                {
                    listener(range_ix, window, cx);
                }
            }
        }));
        self.clickable_ranges = ranges;
        self
    }

    /// on_hover is called when the mouse moves over a character within the text, passing the
    /// index of the hovered character, or None if the mouse leaves the text.
    pub fn on_hover(
        mut self,
        listener: impl Fn(Option<usize>, MouseMoveEvent, &mut Window, &mut App) + 'static,
    ) -> Self {
        self.hover_listener = Some(Box::new(listener));
        self
    }

    /// tooltip lets you specify a tooltip for a given character index in the string.
    pub fn tooltip(
        mut self,
        builder: impl Fn(usize, &mut Window, &mut App) -> Option<AnyView> + 'static,
    ) -> Self {
        self.tooltip_builder = Some(Rc::new(builder));
        self
    }
}

impl Element for InteractiveText {
    type RequestLayoutState = ();
    type PrepaintState = Hitbox;

    fn id(&self) -> Option<ElementId> {
        Some(self.element_id.clone())
    }

    fn source_location(&self) -> Option<&'static core::panic::Location<'static>> {
        None
    }

    fn a11y_role(&self) -> Option<accesskit::Role> {
        Some(accesskit::Role::Label)
    }

    fn write_a11y_info(&self, node: &mut accesskit::Node) {
        node.set_value(self.text.text.to_string());
    }

    fn request_layout(
        &mut self,
        _id: Option<&GlobalElementId>,
        inspector_id: Option<&InspectorElementId>,
        window: &mut Window,
        cx: &mut App,
    ) -> (LayoutId, Self::RequestLayoutState) {
        self.text.request_layout(None, inspector_id, window, cx)
    }

    fn prepaint(
        &mut self,
        global_id: Option<&GlobalElementId>,
        inspector_id: Option<&InspectorElementId>,
        bounds: Bounds<Pixels>,
        state: &mut Self::RequestLayoutState,
        window: &mut Window,
        cx: &mut App,
    ) -> Hitbox {
        window.with_optional_element_state::<InteractiveTextState, _>(
            global_id,
            |interactive_state, window| {
                let mut interactive_state = interactive_state
                    .map(|interactive_state| interactive_state.unwrap_or_default());

                if let Some(interactive_state) = interactive_state.as_mut() {
                    if self.tooltip_builder.is_some() {
                        self.tooltip_id =
                            set_tooltip_on_window(&interactive_state.active_tooltip, window);
                    } else {
                        // If there is no longer a tooltip builder, remove the active tooltip.
                        interactive_state.long_press_tooltip_active.set(false);
                        interactive_state.active_tooltip.take();
                    }
                }

                self.text
                    .prepaint(None, inspector_id, bounds, state, window, cx);
                let hitbox = window.insert_hitbox(bounds, HitboxBehavior::Normal);
                (hitbox, interactive_state)
            },
        )
    }

    fn paint(
        &mut self,
        global_id: Option<&GlobalElementId>,
        inspector_id: Option<&InspectorElementId>,
        bounds: Bounds<Pixels>,
        _: &mut Self::RequestLayoutState,
        hitbox: &mut Hitbox,
        window: &mut Window,
        cx: &mut App,
    ) {
        let current_view = window.current_view();
        let text_layout = self.text.layout().clone();
        window.with_element_state::<InteractiveTextState, _>(
            global_id.unwrap(),
            |interactive_state, window| {
                let mut interactive_state = interactive_state.unwrap_or_default();
                if let Some(click_listener) = self.click_listener.take() {
                    let mouse_position = window.mouse_position();
                    if let Ok(ix) = text_layout.index_for_position(mouse_position)
                        && self
                            .clickable_ranges
                            .iter()
                            .any(|range| range.contains(&ix))
                    {
                        window.set_cursor_style(crate::CursorStyle::PointingHand, hitbox)
                    }

                    let text_layout = text_layout.clone();
                    let mouse_down = interactive_state.mouse_down_index.clone();
                    if let Some(mouse_down_index) = mouse_down.get() {
                        let hitbox = hitbox.clone();
                        let clickable_ranges = mem::take(&mut self.clickable_ranges);
                        window.on_mouse_event(
                            move |event: &MouseUpEvent, phase, window: &mut Window, cx| {
                                if phase == DispatchPhase::Bubble && hitbox.is_hovered(window) {
                                    if let Ok(mouse_up_index) =
                                        text_layout.index_for_position(event.position)
                                    {
                                        click_listener(
                                            &clickable_ranges,
                                            InteractiveTextClickEvent {
                                                mouse_down_index,
                                                mouse_up_index,
                                            },
                                            window,
                                            cx,
                                        )
                                    }

                                    mouse_down.take();
                                    window.refresh();
                                }
                            },
                        );
                    } else {
                        let hitbox = hitbox.clone();
                        window.on_mouse_event(move |event: &MouseDownEvent, phase, window, _| {
                            if phase == DispatchPhase::Bubble
                                && hitbox.is_hovered(window)
                                && let Ok(mouse_down_index) =
                                    text_layout.index_for_position(event.position)
                            {
                                mouse_down.set(Some(mouse_down_index));
                                window.refresh();
                            }
                        });
                    }
                }

                window.on_mouse_event({
                    let mut hover_listener = self.hover_listener.take();
                    let hitbox = hitbox.clone();
                    let text_layout = text_layout.clone();
                    let hovered_index = interactive_state.hovered_index.clone();
                    move |event: &MouseMoveEvent, phase, window, cx| {
                        if phase == DispatchPhase::Bubble && hitbox.is_hovered(window) {
                            let current = hovered_index.get();
                            let updated = text_layout.index_for_position(event.position).ok();
                            if current != updated {
                                hovered_index.set(updated);
                                if let Some(hover_listener) = hover_listener.as_ref() {
                                    hover_listener(updated, event.clone(), window, cx);
                                }
                                cx.notify(current_view);
                            }
                        }
                    }
                });

                if let Some(tooltip_builder) = self.tooltip_builder.clone() {
                    let active_tooltip = interactive_state.active_tooltip.clone();
                    let build_tooltip = Rc::new({
                        let tooltip_is_hoverable = false;
                        let text_layout = text_layout.clone();
                        move |window: &mut Window, cx: &mut App| {
                            text_layout
                                .index_for_position(window.mouse_position())
                                .ok()
                                .and_then(|position| tooltip_builder(position, window, cx))
                                .map(|view| (view, tooltip_is_hoverable))
                        }
                    });

                    // Use bounds instead of testing hitbox since this is called during prepaint.
                    let check_is_hovered_during_prepaint = Rc::new({
                        let source_bounds = hitbox.bounds;
                        let text_layout = text_layout.clone();
                        let pending_mouse_down = interactive_state.mouse_down_index.clone();
                        move |window: &Window| {
                            text_layout
                                .index_for_position(window.mouse_position())
                                .is_ok()
                                && source_bounds.contains(&window.mouse_position())
                                && pending_mouse_down.get().is_none()
                        }
                    });

                    let check_is_hovered = Rc::new({
                        let hitbox = hitbox.clone();
                        let text_layout = text_layout.clone();
                        let pending_mouse_down = interactive_state.mouse_down_index.clone();
                        move |window: &Window| {
                            text_layout
                                .index_for_position(window.mouse_position())
                                .is_ok()
                                && hitbox.is_hovered(window)
                                && pending_mouse_down.get().is_none()
                        }
                    });

                    register_tooltip_mouse_handlers(
                        &active_tooltip,
                        self.tooltip_id,
                        build_tooltip,
                        check_is_hovered,
                        check_is_hovered_during_prepaint,
                        interactive_state.long_press_tooltip_active.clone(),
                        None,
                        window,
                    );
                }

                self.text
                    .paint(None, inspector_id, bounds, &mut (), &mut (), window, cx);

                ((), interactive_state)
            },
        );
    }
}

impl IntoElement for InteractiveText {
    type Element = Self;

    fn into_element(self) -> Self::Element {
        self
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn aligned_text_positions_follow_each_visual_row() {
        use crate::{FontId, GlyphId, LineLayout, ShapedGlyph, ShapedRun, WrapBoundary, point, size};

        for (align, first_left, second_left) in [
            (TextAlign::Left, 10.0, 10.0),
            (TextAlign::Center, 50.0, 45.0),
            (TextAlign::Right, 90.0, 80.0),
        ] {
            let line = WrappedLine {
                text: "aβcde".into(),
                layout: Arc::new(WrappedLineLayout {
                    unwrapped_layout: Arc::new(LineLayout {
                        width: px(50.0),
                        len: 6,
                        runs: vec![ShapedRun {
                            font_id: FontId(0),
                            glyphs: [0, 1, 3, 4, 5].into_iter().enumerate().map(|(index, byte)| {
                                ShapedGlyph {
                                    id: GlyphId(index as u32),
                                    position: point(px(index as f32 * 10.0), px(0.0)),
                                    index: byte,
                                    is_emoji: false,
                                }
                            }).collect(),
                        }],
                        ..Default::default()
                    }),
                    wrap_boundaries: smallvec::smallvec![WrapBoundary { run_ix: 0, glyph_ix: 2 }],
                    wrap_width: Some(px(100.0)),
                }),
                ..Default::default()
            };
            let layout = TextLayout(Rc::new(RefCell::new(Some(TextLayoutInner {
                text_align: TextAlign::Left,
                len: 6,
                lines: smallvec::smallvec![line],
                line_height: px(20.0),
                wrap_width: Some(px(100.0)),
                truncate_width: None,
                size: None,
                bounds: None,
                carried: false,
                measured_by: Default::default(),
            }))));
            layout.prepaint(Bounds::new(point(px(10.0), px(30.0)), size(px(100.0), px(40.0))), "aβcde", align);
            assert_eq!(layout.text_align(), align);
            assert_eq!(layout.position_for_index(0), Some(point(px(first_left), px(30.0))));
            assert_eq!(layout.position_for_index(4), Some(point(px(second_left + 10.0), px(50.0))));
            assert_eq!(layout.index_for_position(point(px(first_left + 11.0), px(31.0))), Ok(1));
            assert_eq!(layout.index_for_position(point(px(second_left + 11.0), px(51.0))), Ok(4));
            assert_eq!(layout.index_for_position(point(px(second_left - 1.0), px(51.0))), Err(3));
            assert_eq!(layout.index_for_position(point(px(second_left + 31.0), px(51.0))), Err(6));
        }
    }

    struct ProbedText {
        text: SharedString,
        width: Pixels,
        layout: Rc<RefCell<Option<TextLayout>>>,
    }

    impl crate::Render for ProbedText {
        fn render(
            &mut self,
            _: &mut Window,
            _: &mut crate::Context<Self>,
        ) -> impl IntoElement {
            use crate::{ParentElement as _, Styled as _, div};
            let text = StyledText::new(self.text.clone());
            *self.layout.borrow_mut() = Some(text.layout().clone());
            div()
                .flex()
                .flex_row()
                .w(self.width)
                .child(div().min_w_0().child(text))
        }
    }

    /// Draws `text` in a shrinkable flex item of a row `width` wide, which
    /// Taffy sizes by probing it unconstrained before laying it out at a
    /// definite width, and returns the wrap width its kept layout was shaped
    /// at and how many times it wrapped.
    fn probed_text_layout(text: &'static str, width: Pixels) -> (Option<Pixels>, usize) {
        use crate::AppContext as _;
        let mut cx = crate::TestAppContext::single();
        let layout = Rc::new(RefCell::new(None));
        let window = cx.add_window({
            let layout = layout.clone();
            move |_, _| ProbedText {
                text: text.into(),
                width,
                layout,
            }
        });
        cx.update_window(window.into(), |_, window, cx| window.draw(cx).clear(cx))
            .unwrap();
        let layout = layout.borrow();
        let layout = layout.as_ref().unwrap().0.borrow();
        let layout = layout.as_ref().unwrap();
        let wraps = layout
            .lines
            .iter()
            .map(|line| line.wrap_boundaries().len())
            .sum();
        (layout.wrap_width, wraps)
    }

    /// Text narrower than the width it is laid out at is answered from its
    /// unconstrained shape rather than shaped again, and text the width bites
    /// is still shaped, and wrapped, at that width.
    #[test]
    fn text_that_fits_its_width_is_not_shaped_again() {
        let (wrap_width, wraps) = probed_text_layout("short", px(400.));
        assert_eq!(wrap_width, None, "fitting text keeps its unconstrained shape");
        assert_eq!(wraps, 0);

        let (wrap_width, wraps) = probed_text_layout(
            "a line long enough that forty pixels cannot hold it without wrapping",
            px(40.),
        );
        assert_eq!(wrap_width, Some(px(40.)), "text that does not fit is shaped at its width");
        assert!(wraps > 0);
    }

    #[test]
    fn test_into_element_for() {
        use crate::{ParentElement as _, SharedString, div};
        use std::borrow::Cow;

        let _ = div().child("static str");
        let _ = div().child("String".to_string());
        let _ = div().child(Cow::Borrowed("Cow"));
        let _ = div().child(SharedString::from("SharedString"));
    }

    #[test]
    fn text_macro_id() {
        // one call to `text!` = one id
        fn make_text_stable_id(happy: bool) -> Text {
            text!(if happy { "happy" } else { "sad" })
        }

        // two calls to `text!` = two ids
        fn make_text_unstable_id(happy: bool) -> Text {
            if happy { text!("happy") } else { text!("sad") }
        }

        assert_eq!(make_text_stable_id(false).id, make_text_stable_id(true).id);
        assert_ne!(
            make_text_unstable_id(false).id,
            make_text_unstable_id(true).id
        );
    }
}
