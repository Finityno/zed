use crate::util::SHRINK_AFTER_FRAMES;
// The crate's clock, not `std::time::Instant`: the wasm target has no native
// monotonic clock and `Instant::now()` aborts there.
use scheduler::Instant;
use std::time::Duration;

/// A low-use run has to last this long as well as span `SHRINK_AFTER_FRAMES`
/// clears. The arena is cleared once per window draw, so with several windows
/// drawing the count alone is reached in `SHRINK_AFTER_FRAMES / windows`
/// frames, and a large window that sat still while a small one animated
/// would lose its chunks and regrow them on its next draw.
pub(crate) const SHRINK_AFTER_DURATION: Duration = Duration::from_secs(2);

/// How long the arena must have gone without a clear, from any window, for an
/// idle release to drop the last draw's chunks as well. Half the shrink
/// duration because the release runs from the quiet window's timer, which
/// fires `SHRINK_AFTER_DURATION` after its draw finished and so a hair less
/// than that after the clear which followed it.
const IDLE_AFTER_DURATION: Duration = Duration::from_secs(1);
use std::{
    alloc::{self, handle_alloc_error},
    cell::Cell,
    num::NonZeroUsize,
    ops::{Deref, DerefMut},
    ptr::{self, NonNull},
    rc::Rc,
};

struct ArenaElement {
    value: *mut u8,
    drop: unsafe fn(*mut u8),
}

impl Drop for ArenaElement {
    #[inline(always)]
    fn drop(&mut self) {
        unsafe { (self.drop)(self.value) };
    }
}

struct Chunk {
    start: *mut u8,
    end: *mut u8,
    offset: *mut u8,
}

impl Drop for Chunk {
    fn drop(&mut self) {
        unsafe {
            let chunk_size = self.end.offset_from_unsigned(self.start);
            // SAFETY: This succeeded during allocation.
            let layout = alloc::Layout::from_size_align_unchecked(chunk_size, 1);
            alloc::dealloc(self.start, layout);
        }
    }
}

impl Chunk {
    fn new(chunk_size: NonZeroUsize) -> Self {
        // this only fails if chunk_size is unreasonably huge
        let layout = alloc::Layout::from_size_align(chunk_size.get(), 1).unwrap();
        let start = unsafe { alloc::alloc(layout) };
        if start.is_null() {
            handle_alloc_error(layout);
        }
        let end = unsafe { start.add(chunk_size.get()) };
        Self {
            start,
            end,
            offset: start,
        }
    }

    fn allocate(&mut self, layout: alloc::Layout) -> Option<NonNull<u8>> {
        // Compute the allocation bounds in integer address space so that the
        // bounds check happens before any pointer offsetting. Offsetting a
        // pointer past the end of its allocation is undefined behavior even if
        // the result is never dereferenced (as happens on the chunk-spill
        // path), so `ptr::add` cannot be used until we know the result stays
        // in bounds. `checked_add` also handles the documented case where
        // `align_offset` returns `usize::MAX`.
        let base = self.offset.addr();
        let aligned_addr = base.checked_add(self.offset.align_offset(layout.align()))?;
        let next_addr = aligned_addr.checked_add(layout.size())?;

        if next_addr <= self.end.addr() {
            let aligned = self.offset.with_addr(aligned_addr);
            self.offset = self.offset.with_addr(next_addr);
            NonNull::new(aligned)
        } else {
            None
        }
    }

    fn reset(&mut self) {
        self.offset = self.start;
    }
}

pub struct Arena {
    chunks: Vec<Chunk>,
    elements: Vec<ArenaElement>,
    valid: Rc<Cell<bool>>,
    current_chunk_index: usize,
    chunk_size: NonZeroUsize,
    scope_depth: usize,
    /// Consecutive clears whose draw fit in fewer chunks than are allocated,
    /// and the most chunks any of those draws used. Chunks are never freed
    /// otherwise, so one elaborate draw would pin its whole arena for the life
    /// of the process; see [`Self::force_clear`].
    last_high_use: Instant,
    low_use_clears: u32,
    max_recent_used_chunks: usize,
    /// The most elements any draw of the same low-use run allocated, so the
    /// element list gives back a heavy draw's capacity along with its chunks.
    max_recent_elements: usize,
    /// Chunks the most recent draw used, busy or not; the floor an idle
    /// release keeps so the frame still on screen redraws without regrowing.
    last_used_chunks: usize,
    last_clear: Instant,
}

impl Drop for Arena {
    fn drop(&mut self) {
        self.force_clear();
    }
}

impl Arena {
    pub fn new(chunk_size: usize) -> Self {
        let chunk_size = NonZeroUsize::try_from(chunk_size).unwrap();
        Self {
            chunks: vec![Chunk::new(chunk_size)],
            elements: Vec::new(),
            valid: Rc::new(Cell::new(true)),
            current_chunk_index: 0,
            chunk_size,
            scope_depth: 0,
            last_high_use: Instant::now(),
            low_use_clears: 0,
            max_recent_used_chunks: 0,
            max_recent_elements: 0,
            last_used_chunks: 1,
            last_clear: Instant::now(),
        }
    }

    pub fn capacity(&self) -> usize {
        self.chunks.len() * self.chunk_size.get()
    }

    #[cfg(test)]
    pub(crate) fn element_list_capacity(&self) -> usize {
        self.elements.capacity()
    }

    /// Marks the start of a scope (e.g. a window draw) whose allocations must stay
    /// live until the scope ends, even if `clear` is called by a nested scope in
    /// the meantime.
    pub fn begin_scope(&mut self) {
        self.scope_depth += 1;
    }

    /// Ends the innermost scope started with `begin_scope`.
    ///
    /// Panics if no scope is active: an unbalanced `end_scope` would let `clear`
    /// run while an enclosing scope still references arena memory, which is
    /// exactly the use-after-free this bookkeeping exists to prevent, so failing
    /// loudly here is preferable.
    pub fn end_scope(&mut self) {
        self.scope_depth = self
            .scope_depth
            .checked_sub(1)
            .expect("Arena::end_scope called without a matching begin_scope");
    }

    /// Drops all allocations and resets the arena, unless a scope is still active.
    ///
    /// When a draw triggers a nested draw (e.g. re-entrant window procedure
    /// invocations on Windows, or opening a window from within a draw), the nested
    /// draw's clear must not free memory the outer draw still references, so it is
    /// deferred: the outer draw's own clear will drop both draws' allocations.
    pub fn clear(&mut self) {
        if self.scope_depth == 0 {
            self.force_clear();
        } else {
            log::debug!(
                "deferring arena clear; {} enclosing scope(s) still active",
                self.scope_depth
            );
        }
    }

    fn force_clear(&mut self) {
        self.force_clear_at(Instant::now());
    }

    fn force_clear_at(&mut self, now: Instant) {
        self.valid.set(false);
        self.valid = Rc::new(Cell::new(true));
        let element_count = self.elements.len();
        self.elements.clear();
        for chunk_index in 0..=self.current_chunk_index {
            self.chunks[chunk_index].reset();
        }
        let used_chunks = self.current_chunk_index + 1;
        self.current_chunk_index = 0;
        self.last_used_chunks = used_chunks;
        self.last_clear = now;

        // Same hysteresis as the per-frame collections: a run of draws that
        // all fit in fewer chunks than are allocated frees the surplus, and
        // one draw that needs every chunk restarts the count. Nothing is live
        // here, so any chunk past the largest recent draw can go.
        if used_chunks < self.chunks.len() {
            self.max_recent_used_chunks = self.max_recent_used_chunks.max(used_chunks);
            self.max_recent_elements = self.max_recent_elements.max(element_count);
            self.low_use_clears += 1;
            if self.low_use_clears >= SHRINK_AFTER_FRAMES
                && now.duration_since(self.last_high_use) >= SHRINK_AFTER_DURATION
            {
                self.chunks.truncate(self.max_recent_used_chunks.max(1));
                self.elements.shrink_to(self.max_recent_elements);
                self.low_use_clears = 0;
                self.max_recent_used_chunks = 0;
                self.max_recent_elements = 0;
                log::trace!(
                    "decreased element arena capacity to {}kb",
                    self.capacity() / 1024,
                );
            }
        } else {
            self.last_high_use = now;
            self.low_use_clears = 0;
            self.max_recent_used_chunks = 0;
            self.max_recent_elements = 0;
        }
    }

    /// [`Self::clear`] with the clock supplied by the caller, so the shrink
    /// policy's timing follows the executor's clock (and can be advanced by
    /// tests) instead of the wall clock.
    pub(crate) fn clear_at(&mut self, now: Instant) {
        if self.scope_depth == 0 {
            self.force_clear_at(now);
        } else {
            log::debug!(
                "deferring arena clear; {} enclosing scope(s) still active",
                self.scope_depth
            );
        }
    }

    /// Frees the chunks past what the most recent draws used, for a window
    /// that has stopped drawing. The per-clear policy above only advances on
    /// draws, so a heavy scene followed by a quiet or hidden window kept every
    /// chunk it grew; this applies the same shrink from a timer instead.
    ///
    /// Chunks past `current_chunk_index` hold no live allocation, so the
    /// truncation is sound even mid-scope. While some window still draws, the
    /// floor is the most any draw since the last busy one used, so that
    /// window redraws without regrowing. Once no window has drawn for
    /// `IDLE_AFTER_DURATION` the app is idle and the floor is only the live
    /// chunks (one): the next draw after an idle spell regrows the few chunks
    /// it needs, which is cheaper than pinning the largest on-screen frame's
    /// arena for as long as the app sits idle. The busy-draw guard is the per-clear policy's: a
    /// draw that needed every chunk within `SHRINK_AFTER_DURATION` keeps them,
    /// since the arena is shared by every window and another one may be the
    /// heavy drawer. Returns whether any chunk or element-list capacity was
    /// freed.
    pub(crate) fn release_idle_chunks(&mut self, now: Instant) -> bool {
        if now.saturating_duration_since(self.last_high_use) < SHRINK_AFTER_DURATION {
            return false;
        }
        let live_chunks = self.current_chunk_index + 1;
        let app_idle = now.saturating_duration_since(self.last_clear) >= IDLE_AFTER_DURATION;
        let keep = if app_idle {
            live_chunks
        } else {
            self.max_recent_used_chunks
                .max(self.last_used_chunks)
                .max(live_chunks)
        };
        let frees_chunks = keep < self.chunks.len();
        let frees_elements = app_idle && self.elements.capacity() > self.elements.len();
        if !frees_chunks && !frees_elements {
            return false;
        }
        self.chunks.truncate(keep);
        if app_idle {
            // Nothing points into the list itself, only into the chunks, so
            // reallocating it is sound even mid-scope.
            self.elements.shrink_to_fit();
            self.last_used_chunks = live_chunks;
        }
        self.low_use_clears = 0;
        self.max_recent_used_chunks = 0;
        self.max_recent_elements = 0;
        log::trace!(
            "released idle element arena capacity down to {}kb",
            self.capacity() / 1024,
        );
        true
    }

    #[inline(always)]
    pub fn alloc<T>(&mut self, f: impl FnOnce() -> T) -> ArenaBox<T> {
        #[inline(always)]
        unsafe fn inner_writer<T, F>(ptr: *mut T, f: F)
        where
            F: FnOnce() -> T,
        {
            unsafe { ptr::write(ptr, f()) };
        }

        unsafe fn drop<T>(ptr: *mut u8) {
            unsafe { std::ptr::drop_in_place(ptr.cast::<T>()) };
        }

        let layout = alloc::Layout::new::<T>();
        let current_chunk = &mut self.chunks[self.current_chunk_index];
        let ptr = if let Some(ptr) = current_chunk.allocate(layout) {
            ptr.as_ptr()
        } else {
            self.allocate_next_chunk(layout)
        };

        unsafe { inner_writer(ptr.cast(), f) };
        self.elements.push(ArenaElement {
            value: ptr,
            drop: drop::<T>,
        });

        ArenaBox {
            ptr: ptr.cast(),
            valid: self.valid.clone(),
        }
    }

    #[inline(never)]
    fn allocate_next_chunk(&mut self, layout: alloc::Layout) -> *mut u8 {
        self.current_chunk_index += 1;
        if self.current_chunk_index >= self.chunks.len() {
            self.chunks.push(Chunk::new(self.chunk_size));
            assert_eq!(self.current_chunk_index, self.chunks.len() - 1);
            log::trace!(
                "increased element arena capacity to {}kb",
                self.capacity() / 1024,
            );
        }
        let current_chunk = &mut self.chunks[self.current_chunk_index];
        if let Some(pointer) = current_chunk.allocate(layout) {
            pointer.as_ptr()
        } else {
            panic!(
                "Arena chunk_size of {} is too small to allocate {} bytes",
                self.chunk_size,
                layout.size()
            );
        }
    }
}

pub struct ArenaBox<T: ?Sized> {
    ptr: *mut T,
    valid: Rc<Cell<bool>>,
}

impl<T: ?Sized> ArenaBox<T> {
    #[inline(always)]
    pub fn map<U: ?Sized>(mut self, f: impl FnOnce(&mut T) -> &mut U) -> ArenaBox<U> {
        ArenaBox {
            ptr: f(&mut self),
            valid: self.valid,
        }
    }

    #[track_caller]
    fn validate(&self) {
        assert!(
            self.valid.get(),
            "attempted to dereference an ArenaRef after its Arena was cleared"
        );
    }
}

impl<T: ?Sized> Deref for ArenaBox<T> {
    type Target = T;

    #[inline(always)]
    fn deref(&self) -> &Self::Target {
        self.validate();
        unsafe { &*self.ptr }
    }
}

impl<T: ?Sized> DerefMut for ArenaBox<T> {
    #[inline(always)]
    fn deref_mut(&mut self) -> &mut Self::Target {
        self.validate();
        unsafe { &mut *self.ptr }
    }
}

#[cfg(test)]
mod tests {
    use std::{cell::Cell, rc::Rc};

    use super::*;

    #[test]
    fn test_arena() {
        let mut arena = Arena::new(1024);
        let a = arena.alloc(|| 1u64);
        let b = arena.alloc(|| 2u32);
        let c = arena.alloc(|| 3u16);
        let d = arena.alloc(|| 4u8);
        assert_eq!(*a, 1);
        assert_eq!(*b, 2);
        assert_eq!(*c, 3);
        assert_eq!(*d, 4);

        arena.clear();
        let a = arena.alloc(|| 5u64);
        let b = arena.alloc(|| 6u32);
        let c = arena.alloc(|| 7u16);
        let d = arena.alloc(|| 8u8);
        assert_eq!(*a, 5);
        assert_eq!(*b, 6);
        assert_eq!(*c, 7);
        assert_eq!(*d, 8);

        // Ensure drop gets called.
        let dropped = Rc::new(Cell::new(false));
        struct DropGuard(Rc<Cell<bool>>);
        impl Drop for DropGuard {
            fn drop(&mut self) {
                self.0.set(true);
            }
        }
        arena.alloc(|| DropGuard(dropped.clone()));
        arena.clear();
        assert!(dropped.get());
    }

    #[test]
    fn test_arena_grow() {
        let mut arena = Arena::new(8);
        arena.alloc(|| 1u64);
        arena.alloc(|| 2u64);

        assert_eq!(arena.capacity(), 16);

        arena.alloc(|| 3u32);
        arena.alloc(|| 4u32);

        assert_eq!(arena.capacity(), 24);
    }

    /// One clear per frame at sixty frames a second, counted from an epoch
    /// taken after the arena exists (its construction stamps the last
    /// high-use time), so the count and the duration thresholds line up
    /// exactly on the last clear.
    fn frame_time(epoch: Instant, frame: u32) -> Instant {
        epoch + SHRINK_AFTER_DURATION * frame / SHRINK_AFTER_FRAMES
    }

    #[test]
    fn test_arena_drops_surplus_chunks_after_idle_window() {
        let mut arena = Arena::new(64);
        let epoch = Instant::now();
        for _ in 0..32 {
            arena.alloc(|| [0u8; 16]);
        }
        assert_eq!(arena.capacity(), 8 * 64);
        arena.clear_at(frame_time(epoch, 0));

        for frame in 1..SHRINK_AFTER_FRAMES {
            arena.alloc(|| 1u64);
            arena.clear_at(frame_time(epoch, frame));
            assert_eq!(arena.capacity(), 8 * 64);
        }
        arena.alloc(|| 1u64);
        arena.clear_at(frame_time(epoch, SHRINK_AFTER_FRAMES));
        assert_eq!(arena.capacity(), 64);

        // The arena keeps working, and regrows, after the surplus is gone.
        for _ in 0..8 {
            arena.alloc(|| [0u8; 16]);
        }
        assert_eq!(arena.capacity(), 2 * 64);
    }

    #[test]
    fn test_arena_keeps_chunks_while_big_draws_recur() {
        let mut arena = Arena::new(64);
        let epoch = Instant::now();
        for _ in 0..32 {
            arena.alloc(|| [0u8; 16]);
        }
        arena.clear();
        assert_eq!(arena.capacity(), 8 * 64);

        for clear in 0..SHRINK_AFTER_FRAMES * 4 {
            let allocations = if clear % 30 == 0 { 32 } else { 1 };
            for _ in 0..allocations {
                arena.alloc(|| [0u8; 16]);
            }
            arena.clear_at(frame_time(epoch, clear + 1));
            assert_eq!(arena.capacity(), 8 * 64);
        }
    }

    /// Several windows clear the arena within one frame, so the clear count
    /// runs ahead of wall time; the duration threshold is what keeps a big
    /// window's chunks while it sits still behind an animating small one.
    #[test]
    fn test_arena_keeps_chunks_while_several_windows_clear_it_per_frame() {
        let mut arena = Arena::new(64);
        let epoch = Instant::now();
        for _ in 0..32 {
            arena.alloc(|| [0u8; 16]);
        }
        arena.clear_at(frame_time(epoch, 0));
        assert_eq!(arena.capacity(), 8 * 64);

        // Four windows: four clears per frame, so the count threshold is met
        // after a quarter of the window.
        for clear in 1..=SHRINK_AFTER_FRAMES * 2 {
            arena.alloc(|| 1u64);
            arena.clear_at(frame_time(epoch, clear / 4));
            assert_eq!(arena.capacity(), 8 * 64, "clear {clear} shrank too early");
        }
        for clear in SHRINK_AFTER_FRAMES * 2 + 1..=SHRINK_AFTER_FRAMES * 4 {
            arena.alloc(|| 1u64);
            arena.clear_at(frame_time(epoch, clear / 4));
        }
        assert_eq!(arena.capacity(), 64);
    }

    /// The idle release does what a full low-use window would have, without
    /// waiting for `SHRINK_AFTER_FRAMES` clears that a quiet window never
    /// produces.
    #[test]
    fn test_idle_release_frees_surplus_after_a_few_small_draws() {
        let mut arena = Arena::new(64);
        let epoch = Instant::now();
        for _ in 0..32 {
            arena.alloc(|| [0u8; 16]);
        }
        arena.clear_at(frame_time(epoch, 0));
        assert_eq!(arena.capacity(), 8 * 64);

        for frame in 1..4 {
            arena.alloc(|| 1u64);
            arena.clear_at(frame_time(epoch, frame));
        }
        assert_eq!(arena.capacity(), 8 * 64);

        // Still inside the busy-draw guard: nothing goes yet.
        assert!(!arena.release_idle_chunks(epoch + SHRINK_AFTER_DURATION / 2));
        assert_eq!(arena.capacity(), 8 * 64);

        assert!(arena.release_idle_chunks(epoch + SHRINK_AFTER_DURATION));
        assert_eq!(arena.capacity(), 64);
        assert!(!arena.release_idle_chunks(epoch + SHRINK_AFTER_DURATION * 2));

        for _ in 0..8 {
            arena.alloc(|| [0u8; 16]);
        }
        assert_eq!(arena.capacity(), 2 * 64);
    }

    /// While another window still draws, the last draw's chunks stay: that
    /// window would only allocate them again on its next frame.
    #[test]
    fn test_idle_release_keeps_the_last_draw_while_another_window_draws() {
        let mut arena = Arena::new(64);
        let epoch = Instant::now();
        for _ in 0..32 {
            arena.alloc(|| [0u8; 16]);
        }
        arena.clear_at(epoch);
        assert_eq!(arena.capacity(), 8 * 64);

        // Half the chunks in the last draw: the other half is surplus.
        for _ in 0..16 {
            arena.alloc(|| [0u8; 16]);
        }
        let last_draw = epoch + SHRINK_AFTER_DURATION * 3 / 4;
        arena.clear_at(last_draw);
        assert!(arena.release_idle_chunks(epoch + SHRINK_AFTER_DURATION));
        assert_eq!(arena.capacity(), 4 * 64);

        // Nothing has drawn for a while: the app is idle and the last
        // draw's chunks go too.
        assert!(arena.release_idle_chunks(last_draw + IDLE_AFTER_DURATION));
        assert_eq!(arena.capacity(), 64);
        assert_eq!(arena.element_list_capacity(), 0);
    }

    /// An app that goes idle on a heavy frame used to keep every chunk that
    /// frame grew, and its element list, until it next drew something small.
    #[test]
    fn test_idle_release_frees_the_last_heavy_draw_once_the_app_is_idle() {
        let mut arena = Arena::new(64);
        let epoch = Instant::now();
        for _ in 0..32 {
            arena.alloc(|| [0u8; 16]);
        }
        arena.clear_at(epoch);
        assert_eq!(arena.capacity(), 8 * 64);
        assert!(arena.element_list_capacity() >= 32);

        // Still inside the busy-draw guard: nothing goes yet.
        assert!(!arena.release_idle_chunks(epoch + SHRINK_AFTER_DURATION / 2));
        assert_eq!(arena.capacity(), 8 * 64);

        assert!(arena.release_idle_chunks(epoch + SHRINK_AFTER_DURATION));
        assert_eq!(arena.capacity(), 64);
        assert_eq!(arena.element_list_capacity(), 0);
        assert!(!arena.release_idle_chunks(epoch + SHRINK_AFTER_DURATION * 2));

        for _ in 0..32 {
            arena.alloc(|| [0u8; 16]);
        }
        assert_eq!(arena.capacity(), 8 * 64);
    }

    /// A window drawing steadily, with heavy frames among light ones, and a
    /// quiet window's idle timer firing between them, never frees or
    /// allocates a chunk, and never reallocates the element list.
    #[test]
    fn test_steady_frame_loop_allocates_no_chunks() {
        let mut arena = Arena::new(64);
        let epoch = Instant::now();
        let chunk_starts = |arena: &Arena| -> Vec<*mut u8> {
            arena.chunks.iter().map(|chunk| chunk.start).collect()
        };
        let mut first_frame = None;
        for frame in 0..SHRINK_AFTER_FRAMES * 10 {
            let allocations = if frame % 10 == 0 { 20 } else { 6 };
            for _ in 0..allocations {
                arena.alloc(|| [0u8; 16]);
            }
            let now = frame_time(epoch, frame);
            arena.clear_at(now);
            arena.release_idle_chunks(now);
            let state = (chunk_starts(&arena), arena.element_list_capacity());
            match &first_frame {
                None => first_frame = Some(state),
                Some(first) => assert_eq!(&state, first, "frame {frame} reallocated"),
            }
        }
        assert_eq!(arena.capacity(), 5 * 64);
    }

    /// Live allocations pin their chunks: a release mid-scope only drops
    /// chunks nothing points into.
    #[test]
    fn test_idle_release_never_frees_live_chunks() {
        let mut arena = Arena::new(64);
        let epoch = Instant::now();
        for _ in 0..32 {
            arena.alloc(|| [0u8; 16]);
        }
        arena.clear_at(frame_time(epoch, 0));
        arena.alloc(|| 1u64);
        arena.clear_at(frame_time(epoch, 1));

        arena.begin_scope();
        let live: Vec<_> = (0..12).map(|_| arena.alloc(|| [0u8; 16])).collect();
        assert!(arena.release_idle_chunks(epoch + SHRINK_AFTER_DURATION * 2));
        assert_eq!(arena.capacity(), 3 * 64);
        assert!(live.iter().all(|value| value.iter().all(|byte| *byte == 0)));
        drop(live);
        arena.end_scope();
    }

    #[test]
    fn test_arena_alignment() {
        let mut arena = Arena::new(256);
        let x1 = arena.alloc(|| 1u8);
        let x2 = arena.alloc(|| 2u16);
        let x3 = arena.alloc(|| 3u32);
        let x4 = arena.alloc(|| 4u64);
        let x5 = arena.alloc(|| 5u64);

        assert_eq!(*x1, 1);
        assert_eq!(*x2, 2);
        assert_eq!(*x3, 3);
        assert_eq!(*x4, 4);
        assert_eq!(*x5, 5);

        assert_eq!(x1.ptr.align_offset(std::mem::align_of_val(&*x1)), 0);
        assert_eq!(x2.ptr.align_offset(std::mem::align_of_val(&*x2)), 0);
    }

    #[test]
    #[should_panic(expected = "attempted to dereference an ArenaRef after its Arena was cleared")]
    fn test_arena_use_after_clear() {
        let mut arena = Arena::new(16);
        let value = arena.alloc(|| 1u64);

        arena.clear();
        let _read_value = *value;
    }

    #[test]
    fn test_clear_deferred_while_scope_active() {
        struct DropCounter(Rc<Cell<usize>>);
        impl Drop for DropCounter {
            fn drop(&mut self) {
                self.0.set(self.0.get() + 1);
            }
        }

        let drops = Rc::new(Cell::new(0));
        let mut arena = Arena::new(1024);

        // Outer draw starts and allocates.
        arena.begin_scope();
        let outer = arena.alloc(|| 42u64);
        arena.alloc({
            let drops = drops.clone();
            || DropCounter(drops)
        });

        // Nested draw runs to completion and requests a clear.
        arena.begin_scope();
        let inner = arena.alloc(|| 7u64);
        arena.alloc({
            let drops = drops.clone();
            || DropCounter(drops)
        });
        arena.end_scope();
        arena.clear();

        // The clear must be deferred: the outer draw's allocations are still live.
        assert_eq!(*outer, 42);
        assert_eq!(*inner, 7);
        assert_eq!(drops.get(), 0);

        // Once the outer draw finishes, its clear drops both draws' allocations.
        arena.end_scope();
        arena.clear();
        assert_eq!(drops.get(), 2);
    }

    #[test]
    fn test_clear_without_scope_is_immediate() {
        let mut arena = Arena::new(1024);
        let value = arena.alloc(|| 1u64);
        assert_eq!(*value, 1);
        arena.clear();
        assert!(!value.valid.get());
    }

    #[test]
    #[should_panic(expected = "Arena::end_scope called without a matching begin_scope")]
    fn test_unbalanced_end_scope_panics() {
        let mut arena = Arena::new(1024);
        arena.begin_scope();
        arena.end_scope();
        arena.end_scope();
    }
}
