from pathlib import Path
import json,hashlib,subprocess,os
r=Path(__file__).parent;p=json.loads((r/'diagnostic-method.json').read_text());w=r/'baseline-workspace';binary=r/'baseline-census-artifacts/gpui-ada3fb4d7b1cfe56'
for path,sha in json.loads((r/'baseline-source-inputs.json').read_text())['files'].items():assert hashlib.sha256((w/path).read_bytes()).hexdigest()==sha,path
for v in json.loads((r/'external-dependencies.json').read_text()):assert hashlib.sha256(Path(v['path']).read_bytes()).hexdigest()==v['sha256']
for path,sha in json.loads((r/'native-runtime-identity.json').read_text())['libraries'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==sha,path
binary_sha=hashlib.sha256(binary.read_bytes()).hexdigest();(r/'diagnostic-binary-identity.json').write_text(json.dumps({'path':str(binary),'sha256':binary_sha,'bytes':binary.stat().st_size,'all59_original_externs_verified':True},indent=2)+'\n');out=r/'diagnostic-receipts';out.mkdir();rows=[]
previous=json.loads(Path('/workspace/scratch/gpui-glyph-spans-loop/bare-samples.json').read_text())
for case in p['cases']:
 pattern='profile_colored_transcript' if case.startswith('color-') else 'profile_transcript_paint';env=os.environ|{'TRANSCRIPT_PROFILE_CASE':case,'TRANSCRIPT_PROFILE_ITERATIONS':str(p['iterations']),'COLOR_PROFILE_CASE':case,'COLOR_PROFILE_ITERATIONS':str(p['iterations'])};command=[str(r/'native-run'),'taskset','-c','2',str(binary),pattern,'--ignored','--nocapture','--test-threads=1'];log=out/(case+'.log')
 with log.open('w') as f:result=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=70)
 row={'case':case,'command':command,'exit_code':result.returncode,'raw_log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'binary_sha256':binary_sha,'not_CPU_gain_evidence':True}
 for line in log.read_text().splitlines():
  for marker in ['SCENE_SORT_INPUT ','TRANSCRIPT_PROFILE ','COLOR_PROFILE ','NATIVE_RECEIPT ']:
   if marker in line:row['sort_inputs' if marker=='SCENE_SORT_INPUT ' else 'native' if marker=='NATIVE_RECEIPT ' else 'component']=json.loads(line.split(marker,1)[1])
 assert result.returncode==0 and all(k in row for k in ['sort_inputs','component','native']),log.read_text()
 expected=next(v for v in previous if v['case']==case and v['lane']=='baseline' and v['pair']==0)
 for field in ['signature','frame_hash','state_count','state_box_bytes','frames','nodes','node_high_water']:
  if field in row['component'] or field in expected:assert row['component'][field]==expected[field],(case,field,row['component'].get(field),expected.get(field))
 data=row['sort_inputs'];keys=data['monochrome'];bytes_=data['scratch_owner_bytes'];animated=any(v[3]!=0 or v[4]!=0 for v in keys+data['subpixel']);widths=[]
 for array in [keys,data['subpixel']]:
  if not array:continue
  bits=[0,0,0]
  for key in array:
   for i in range(3):bits[i]|=key[i]
  widths.append(len(array).bit_length()+sum(v.bit_length() for v in bits))
 row['attribution']={'monochrome_glyphs':len(keys),'subpixel_glyphs':len(data['subpixel']),'polychrome_glyphs':len(data['polychrome']),'scratch_bytes':sum(bytes_),'permutation_bytes':bytes_[3],'permutation_fraction_of_scratch':bytes_[3]/sum(bytes_) if sum(bytes_) else 0,'maximum_packed_width':max(widths,default=0),'original_arrival_glyph_keys_preserved':True,'non_glyph_arrays_already_in_finished_order':True,'static_scope':not animated and data['time_animation_quads']==0 and data['transitions']==0 and data['shimmer_animations']==0 and data['quad_animations']==0}
 rows.append(row);(r/'diagnostic-samples.json').write_text(json.dumps(rows,indent=2)+'\n')
for path,sha in json.loads((r/'baseline-source-inputs.json').read_text())['files'].items():assert hashlib.sha256((w/path).read_bytes()).hexdigest()==sha,path
for v in json.loads((r/'external-dependencies.json').read_text()):assert hashlib.sha256(Path(v['path']).read_bytes()).hexdigest()==v['sha256']
assert hashlib.sha256(binary.read_bytes()).hexdigest()==binary_sha
(r/'diagnostic-decision.json').write_text(json.dumps({'children':len(rows),'all_outputs_match_currentmain_complete_baseline':True,'all_inputs_unchanged':True,'production_candidate_exists':False,'not_gain_evidence':True,'rows':[{'case':v['case'],**v['attribution']} for v in rows]},indent=2)+'\n');print(json.dumps({'children':len(rows),'all_outputs_match':True,'rows':[{'case':v['case'],**v['attribution']} for v in rows]}))
