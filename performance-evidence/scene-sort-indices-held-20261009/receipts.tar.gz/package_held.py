from pathlib import Path
import json,hashlib,tarfile,shutil,re,subprocess,os,collections
r=Path(__file__).parent;c=r/'comparison';w=Path('/workspace/zed-sort-indices');d=json.loads((c/'decision.json').read_text());assert d['status']=='HELD_UNMERGED' and len(d['failures'])==83
public=w/'performance-evidence/scene-sort-indices-held-20261009';public.mkdir(parents=True)
files=[]
for p in r.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(r)
 if any(part=='__pycache__' or part.endswith('-artifacts') for part in rel.parts):
  if p.suffix!='.d':continue
 if p.name.endswith('.pyc') or p.name.endswith('.preserved.gz'):continue
 files.append((str(rel),p))
archive=public/'receipts.tar.gz';seen={};linked=0
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for name,p in sorted(files):
  st=p.stat();raw=p.read_bytes();sha=hashlib.sha256(raw).hexdigest();key=(sha,st.st_size,st.st_mode,st.st_mtime_ns);info=t.gettarinfo(str(p),arcname=name)
  if key in seen:
   info.type=tarfile.LNKTYPE;info.linkname=seen[key];info.size=0;t.addfile(info);linked+=1
  else:
   seen[key]=name
   with p.open('rb') as f:t.addfile(info,f)
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(files)
 for name,p in files:assert hashlib.sha256(t.extractfile(name).read()).digest()==hashlib.sha256(p.read_bytes()).digest(),name
sha=hashlib.sha256(archive.read_bytes()).hexdigest();metadata={'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'archive_members':len(files),'byte_exact_roundtrip':True,'identical_member_hardlinks':linked,'hardlink_note':'Tar links deduplicate members only when bytes, size, mode and nanosecond modification time match; all members resolve to original exact bytes. No raw sample/source removed.','held':True,'merged':False,'production_source':'43ea16c93782ee5f2b86cf34c37795b9cbcf4632','baseline':'08d5555709d7afab3936c7afcd9f7f0ff9ecbd65','never_resample_unchanged':True,'no_app_GPU_platform_or_shipped_allocator_gain':True};(r/'archive-verification.json').write_text(json.dumps(metadata,indent=2)+'\n');(public/'evidence.json').write_text(json.dumps(metadata,indent=2)+'\n')
for name in ['decision.json','summary.json','policy.json','policy.sha256','correctness-summary.json','copy-owner-regression-receipts.json','compiler-dependency-identities.json','external-dependencies.json','binary-identities.json','native-runtime-identity.json','candidate-source-receipt.json','lane-source-difference-proof.json']:shutil.copy2(c/name,public/name)
for name in ['diagnostic-method.json','diagnostic-decision.json','diagnostic-binary-identity.json']:shutil.copy2(r/name,public/name)
(public/'README.md').write_text(f"""# Held direct sorted glyph copying

This candidate remains unmerged. All4,060 alternating native children and
326 correctness children are preserved. Sorting copies directly from the
packed64/128-bit source indices instead of filling a second permutation
vector. Stable/equal/wide sorting and in-place reuse remain correct: the
native no-extra-owner regression fails before and passes after.

None of the20 primary complete controlled Scene.finish fixtures reaches the
frozen5% CPU/elapsed target. Thread-CPU median differences range from2.297%
more to1.208% less. No CPU gain is established. All20 scratch owner targets
reduce20%, releasing5,196–18,800 requested bytes. Complete controlledScene
held heap is0.774–0.979% lower; four colored fixtures miss the frozen0.8%
target. All145 held/peak/requested-byte/allocation-call nonincrease controls
pass. Twelve ordinaryCPU/elapsed/wholechildCPU fields and27RSS fields fail.
Together with40 primary timing and four live-target failures,83 frozenfields
fail. No unchanged rerun, weaker gate, PR, merge or consumer adoption is made.

The119 completeWindow workloads match frame-by-frame; all26 controlled
Scene signatures match.620 common native test passes exclude the separately
checked expected-red owner regression. Zero-test filters remain explicit
coverage gaps. The first fixture-only compile failed because libc was not a
GPUI dependency; its exact source, artifacts and logs are preserved. The
clock was corrected to the same existing externTimespec helper before any
paired samples. All59 immutable external objects and exact compiler,
allocator, runtime and source identities match before/after all cohorts.

Source43ea16c93782ee5f2b86cf34c37795b9cbcf4632 starts from owned main
08d5555709d7afab3936c7afcd9f7f0ff9ecbd65. RefreshedFincode main
251866f12140de81510352122bdea5ddab87b007 retains allthree rendering pins
6b18c87dd5f2d1ccbee1ee641054295f2a78390b and component
031f54b627333272a8c157cbe4ca1cf591d16172.

Archive SHA256:{sha}. All{len(files)} members resolve to verified original
bytes. Identical content+metadata members share tar hardlinks. Large native
and dependency objects remain identified and preserved in the managedcloud.

Scope:LinuxGPUI fakeplatform/text, bareSystem and separate requested-counting
System allocator. ControlledScene.finish fixtures reconstruct actual captured
glyphkeys/counts with defaultgeometry/colors; non-glyph arrays were captured
already sorted. Immutable JSON inputs are parsed before requestedcensus;
Scene construction and warmup are counted, only finish loops are timed.
Neither exact application scenes nor physicalGPU/macOS/Windows/shippedallocator
performance is established. No owningClippy/guards are claimed after failed
performance gates. The frozen policy's memory_budget_reason accidentally
mentions a prior append design; its unchanged zeroheap/churn and all stated
primary/control gates are enforced. Continue with line-sized paint records,
retained range boundaries and original immutable sprite ownership.
""")
p=w/'PERFORMANCE_GOAL.md';s=p.read_text();s+='\n\nDirect packed-key glyph copying at `43ea16c93782ee5f2b86cf34c37795b9cbcf4632`\nremains held and unmerged. Across4,060 children no primarycontrolledScene.finish\ncase meets its5%CPU/elapsed target. Scratchowner storage reduces20%; requested\nlive reduces0.774–0.979%, with four coloredcases below frozen0.8%. Twelve\nordinaryCPU/elapsed/wholechildCPU and27RSSfields also fail;83totalfields fail.\nAll145 requestedheap/churn nonincreasecontrols and326native correctnesschildren\npass. Preserve allfailedfields/source/setup failures; never unchangedrerun or\nweaken gates. See `performance-evidence/scene-sort-indices-held-20261009`.\nNo app/GPU/nativeplatform/shippedallocator gain or consumeradoption is claimed.\nContinue with measured line-sized paint-record ownership and retainedindex\nboundaries; preserve allother independentwork.\n';p.write_text(s)
env=os.environ|{'GIT_NO_LAZY_FETCH':'1'};subprocess.run(['git','add','--sparse','PERFORMANCE_GOAL.md',str(public.relative_to(w))],cwd=w,env=env,check=True);subprocess.run(['git','commit','-m','Preserve held direct glyph-copy evidence [skip ci]'],cwd=w,env=env,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,env=env,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=w,env=env,text=True).strip();metadata.update({'held_head':head,'held_tree':tree});(r/'held-final-source-receipt.json').write_text(json.dumps(metadata,indent=2)+'\n')
paths=['crates/gpui/src/scene.rs','PERFORMANCE_GOAL.md']+[str(p.relative_to(w)) for p in public.iterdir() if p.is_file()];manifest=[]
for name in sorted(paths):
 p=w/name;blob=subprocess.check_output(['git','hash-object',name],cwd=w,env=env,text=True).strip();manifest.append({'path':name,'local':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'blob':blob})
(r/'publication-files.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(metadata,indent=2))
