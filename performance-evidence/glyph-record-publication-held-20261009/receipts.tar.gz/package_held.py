from pathlib import Path
import json,hashlib,tarfile,shutil,re,subprocess,os,collections
r=Path(__file__).parent;c=r/'comparison';w=Path('/workspace/zed-record-publication');d=json.loads((c/'decision.json').read_text());assert d['status']=='HELD_UNMERGED' and len(d['failures'])==31
public=w/'performance-evidence/glyph-record-publication-held-20261009';public.mkdir(parents=True,exist_ok=True)
files=[]
for p in r.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(r)
 if any(part=='__pycache__' or part.endswith('-artifacts') for part in rel.parts):
  if p.suffix!='.d':continue
 if p.name.endswith('.pyc') or p.name.endswith('.preserved.gz'):continue
 files.append((str(rel),p))
archive=public/'receipts.tar.gz';seen={};linked=0
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for name,p in sorted(files):
  st=p.stat();raw=p.read_bytes();sha=hashlib.sha256(raw).hexdigest();key=(sha,st.st_size,st.st_mode,st.st_mtime_ns);info=t.gettarinfo(str(p),arcname=name)
  if key in seen:
   info.type=tarfile.LNKTYPE;info.linkname=seen[key];info.size=0;t.addfile(info);linked+=1
  else:
   seen[key]=name
   with p.open('rb') as f:t.addfile(info,f)
expected={name:p for name,p in files};resolved={};members=0
with tarfile.open(archive,'r|gz') as t:
 for member in t:
  p=expected[member.name];wanted=hashlib.sha256(p.read_bytes()).hexdigest()
  if member.islnk():
   assert member.linkname in resolved;actual=resolved[member.linkname]
  else:
   assert member.isfile();actual=hashlib.sha256(t.extractfile(member).read()).hexdigest()
  assert actual==wanted,member.name
  resolved[member.name]=actual;members+=1
assert members==len(files)
sha=hashlib.sha256(archive.read_bytes()).hexdigest();metadata={'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'archive_members':len(files),'byte_exact_roundtrip':True,'identical_member_hardlinks':linked,'hardlink_note':'Tar links deduplicate members only when bytes, size, mode and nanosecond modification time match; all members resolve to original exact bytes. No raw sample/source removed.','held':True,'merged':False,'production_source':'7b351af5175206fb3727cd02fa2eca277f56e249','baseline':'08d5555709d7afab3936c7afcd9f7f0ff9ecbd65','never_resample_unchanged':True,'no_app_GPU_platform_or_shipped_allocator_gain':True};(r/'archive-verification.json').write_text(json.dumps(metadata,indent=2)+'\n');(public/'evidence.json').write_text(json.dumps(metadata,indent=2)+'\n')
for name in ['decision.json','summary.json','policy.json','policy.sha256','correctness-summary.json','window-record-owner-regression-receipts.json','candidate-exact-production-proof.json','empty-owner-correctness-receipts.json','compiler-dependency-identities.json','external-dependencies.json','binary-identities.json','native-runtime-identity.json','candidate-source-receipt.json','lane-source-difference-proof.json']:shutil.copy2(c/name,public/name)
for name in ['diagnostic-decision.json','diagnostic-binary-identity.json']:shutil.copy2(r/name,public/name)
(public/'README.md').write_text(f"""# Held per-record glyph publication

This uniform-range design remains unmerged. All 3,418 alternating native children
across 121 Window and three standalone Scene workloads are preserved. All 20
frozen memory targets pass: complete App/Window held requested heap falls
10.24–28.77% and allocated paint-record capacity falls 75–97.92%, exceeding both
full lane ranges and 5%/50% goals. All requested held/peak/bytes and allocation-call
controls pass with zero fixed-overhead allowance. Native Scene/Window/record
widths stay exactly 1632/12944/184 bytes, and standalone owners release fully.

31 frozen controls fail: ten thread CPU, ten elapsed, nine whole-child CPU and
two current RSS fields (one bare, one census). Panel removal, replacement, growth,
state updates and recoloring regress. No peak RSS control fails. The source is
held without PR, merge, adoption or unchanged resampling. All adverse fields stay.

The publication flag lives inside existing glyph descriptor capacity rather
than the Scene header. Every glyph descriptor is a range, so continuing a run
mutates only its end and no scalar promotion occurs. Scene.len marks only its
last glyph record; generic replay seals only before source glyph records. Its
non-glyph movement/remap/animation/insertion body is exactly the original owned
source. Native renderer, glyph payloads and text/atlas interfaces are unchanged.
The added heap-tail lookup on publication motivates the next distinct design:
track tail state in existing Scene layout padding, with original native widths
required and all zero-overhead controls retained. No benefit is inferred yet.

Final native correctness has 624 common passes, 278 children, 121 exact matched
frame histories, six standalone owner-release children and one expected-red/green
cold-line child per lane. Two legacy zero-test filters remain explicit coverage
gaps. Shared positive-test definition order matches; named private observers
normalize logical overlay indices and preserve raw compact metadata. Both source
files reproduce exactly from the saved owned transformation. Earlier failed
publication designs, their pre-metric correctness defects, source receipts and
owned published evidence remain preserved separately.

Source: 7b351af5175206fb3727cd02fa2eca277f56e249.
Owned baseline: 08d5555709d7afab3936c7afcd9f7f0ff9ecbd65.
Frozen policy SHA256: 4cbc5efac46622c76248b2f1d826e0956729fdcf4fc2c86529f1161d90890bf3.
Frozen consumer source: 781cc8edf512a918bbe684c9e6eb388a3828aeeb,
coherent rendering pin 08d5555709d7afab3936c7afcd9f7f0ff9ecbd65 and component
ab07cd7695af1dfd9f1c6ad06a77660d288e568d. Independent consumer work is preserved.

Bare and counting cohorts run separately, sequentially, and once. All compiler,
59 immutable dependency objects, native runtime, source, binary and policy hashes
pass before/after checks. opt-level=3, 16 codegen units and debug assertions stay
fixed. Host guards precede each child, and no timing overlaps builds, hashing,
compression or other profiling. Counted CPU is not CPU gain evidence. Original
inactive native objects remain losslessly preserved with identity/metadata receipts.

Archive SHA256: {sha}. All {len(files)} members roundtrip to exact original bytes.
Tar hardlinks apply only to identical bytes, sizes, modes and nanosecond mtimes.
Linux fake GPUI platform/text with System/separate counting-System fixtures do
not establish application, physical GPU, macOS, Windows or shipped-allocator gains.
Owning Clippy is not claimed after failed performance gates. Continue a distinct
padding-resident publication design; never repeat this failed source unchanged.
""")
p=w/'PERFORMANCE_GOAL.md';s=p.read_text();s+='\n\nPer-record glyph publication at `7b351af5175206fb3727cd02fa2eca277f56e249`\nremains held. All 3,418 children and 20 memory targets pass with original native\nScene/Window/record widths and zero fixed heap overhead, but 31 CPU/elapsed/\nwhole-child/current-RSS controls fail. All requested heap/churn and peak RSS\ncontrols pass. Native output, retained histories and release contracts pass.\nSee `performance-evidence/glyph-record-publication-held-20261009`. Never repeat\nthis source unchanged or weaken gates. Continue with distinct padding-resident\ntail publication state to avoid heap-tail lookup while preserving exact widths.\nNo adoption or application/GPU gain is claimed.\n';p.write_text(s)
if archive.stat().st_size > 8*1024*1024:
 raw=archive.read_bytes();parts=[]
 for i,offset in enumerate(range(0,len(raw),8*1024*1024)):
  part=public/f'receipts.tar.gz.part-{i:02d}';part.write_bytes(raw[offset:offset+8*1024*1024]);parts.append({'path':part.name,'sha256':hashlib.sha256(part.read_bytes()).hexdigest(),'bytes':part.stat().st_size})
 assert b''.join((public/v['path']).read_bytes() for v in parts)==raw
 shutil.move(str(archive),str(r/'held-original-archive.tar.gz'));(public/'archive-parts.json').write_text(json.dumps({'archive_sha256':sha,'parts':parts,'byte_exact_join_verified':True},indent=2)+'\n')
env=os.environ|{'GIT_NO_LAZY_FETCH':'1'};subprocess.run(['git','add','--sparse','PERFORMANCE_GOAL.md',str(public.relative_to(w))],cwd=w,env=env,check=True);subprocess.run(['git','commit','-m','Preserve held per-record publication evidence [skip ci]'],cwd=w,env=env,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,env=env,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=w,env=env,text=True).strip();metadata.update({'held_head':head,'held_tree':tree});(r/'held-final-source-receipt.json').write_text(json.dumps(metadata,indent=2)+'\n')
paths=list(json.loads((c/'candidate-source-receipt.json').read_text())['files'])+['PERFORMANCE_GOAL.md']+[str(p.relative_to(w)) for p in public.iterdir() if p.is_file()];manifest=[]
for name in sorted(paths):
 p=w/name;blob=subprocess.check_output(['git','hash-object',name],cwd=w,env=env,text=True).strip();manifest.append({'path':name,'local':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'blob':blob})
(r/'publication-files.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(metadata,indent=2))
