from pathlib import Path
import hashlib, json, os, shutil, subprocess

root = Path(__file__).parent
comparison = root / 'comparison'
comparison.mkdir()
old = Path('/workspace/scratch/gpui-in-place-ranges-loop/comparison')
worktree = Path('/workspace/zed-record-publication')
environment = os.environ | {'GIT_NO_LAZY_FETCH': '1'}
baseline = '08d5555709d7afab3936c7afcd9f7f0ff9ecbd65'
paths = ['crates/gpui/src/scene.rs', 'crates/gpui/src/window/view_retention/tests.rs']
def original(path):
    return subprocess.check_output(['git', 'show', baseline + ':' + path], cwd=worktree, env=environment, text=True)

previous_scene = (old / 'baseline-workspace' / paths[0]).read_text()
begin = previous_scene.index('    pub(crate) fn diagnostic_record_owner(')
end = previous_scene.index('    pub fn finish(&mut self) {', begin)
getters = previous_scene[begin:end]
previous_tests = (old / 'baseline-workspace' / paths[1]).read_text()
baseline_tests = original(paths[1])
assert previous_tests.startswith(baseline_tests)
tail = previous_tests[len(baseline_tests):]
old_cold_regression = '\n' + Path('/workspace/scratch/gpui-in-place-ranges-loop/window-owner-regression.rs').read_text()
assert tail.startswith(old_cold_regression)
suffix = tail[len(old_cold_regression):]
for name in ['policy.json', 'policy.sha256', 'external-dependencies.json', 'native-runtime-identity.json', 'native-run', 'supervise.py', 'build_native.py', 'compiler-dependency-identities.json']:
    shutil.copy2(root / name, comparison / name)
for name in ['build_remaining.py', 'collect_identities.py', 'verify_inputs.py', 'measure.py', 'check_correctness.py', 'check_owner_regression.py', 'check_empty_owners.py', 'decide.py']:
    script = (old / name).read_text().replace('/workspace/zed-line-records', str(worktree)).replace('/workspace/zed-cached-line-records', str(worktree)).replace('a_cached_long_line_does_not_keep_one_wide_record_per_glyph', 'a_cold_long_line_does_not_keep_one_wide_record_per_glyph').replace('a cached line keeps one record for a glyph run', 'a cold line keeps one record for a glyph run').replace('native cachedlongline', 'native coldlongline')
    (comparison / name).write_text(script)
for lane in ['baseline', 'candidate']:
    workspace = comparison / (lane + '-workspace')
    shutil.copytree(old / 'baseline-workspace', workspace)
    for path in paths:
        source = original(path) if lane == 'baseline' else (worktree / path).read_text()
        if path.endswith('scene.rs'):
            if lane == 'baseline':
                source = source.replace('    fn unit_bounds() ->', (root / 'record-regressions.rs').read_text() + '    fn unit_bounds() ->')
            observer = getters
            if lane == 'candidate':
                observer = observer.replace('index.min(self.paint_operations.len())', 'self.paint_operations.iter().take(index).map(|operation| operation.glyph_indices().map_or(1, |(_, indices)| indices.len())).sum()')
            source = source.replace('    pub fn finish(&mut self) {', observer + '    pub fn finish(&mut self) {')
        else:
            if lane == 'baseline':
                source += '\n' + (root / 'window-owner-regression.rs').read_text()
            source += suffix
        (workspace / path).write_text(source)
    manifest = {str(p.relative_to(workspace)): hashlib.sha256(p.read_bytes()).hexdigest() for p in workspace.rglob('*') if p.is_file()}
    (comparison / (lane + '-source-inputs.json')).write_text(json.dumps({'baseline': baseline, 'private_named_observers_and_fixtures_only': True, 'files': manifest}, indent=2) + '\n')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=worktree, env=environment, text=True).strip()
tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=worktree, env=environment, text=True).strip()
receipt = {'source': head, 'tree': tree, 'baseline': baseline, 'files': {path: hashlib.sha256((worktree / path).read_bytes()).hexdigest() for path in paths}, 'scope': 'Publication state within glyph descriptors, exact original Scene/Window widths and zero fixed heap budget. Text_system/line andwindow/glyph_painting unchanged. Non-glyph replay body exact; uniform glyph ranges retain movement/remap/animation semantics, seal only source glyph boundaries. No postpaint scan. Shared normalizedoverlay metadata frozen beforepairs.'}
for directory in [root, comparison]:
    (directory / 'candidate-source-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
b = json.loads((comparison / 'baseline-source-inputs.json').read_text())['files']
c = json.loads((comparison / 'candidate-source-inputs.json').read_text())['files']
difference = [path for path in b if b[path] != c[path]]
assert difference == ['crates/gpui/src/scene.rs'] or sorted(difference) == ['crates/gpui/src/scene.rs']
(comparison / 'lane-source-difference-proof.json').write_text(json.dumps({'source': head, 'different_compiled_files': difference, 'all_other_shared_fixture_bytes_identical': True, 'typed_logical_overlay_getter': True, 'baseline_production_unchanged_except_shared_positive_tests_and_observers': True, 'no_compaction_shim': True}, indent=2) + '\n')
print(head, tree)
