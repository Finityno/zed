from pathlib import Path
import subprocess,os,hashlib,json,re
r=Path(__file__).parent;w=Path('/workspace/zed-record-publication');base='08d5555709d7afab3936c7afcd9f7f0ff9ecbd65';records=(r.parent/'record-regressions.rs').read_text();owner='\n'+(r.parent/'window-owner-regression.rs').read_text();proof=[]
for path in ['crates/gpui/src/scene.rs','crates/gpui/src/window/view_retention/tests.rs']:
 production=(w/path).read_text();compiled=(r/'candidate-workspace'/path).read_text();before=(r/'baseline-workspace'/path).read_text();original=subprocess.check_output(['git','show',base+':'+path],cwd=w,env=os.environ|{'GIT_NO_LAZY_FETCH':'1'},text=True)
 if path.endswith('scene.rs'):
  def strip_observer(source):
   start=source.index('    pub(crate) fn diagnostic_record_owner(');end=source.index('    pub fn finish(&mut self) {',start);return source[:start]+source[end:]
  assert strip_observer(compiled)==production
  assert strip_observer(before).replace(records,'',1)==original
  for source in [compiled,before]:assert source.count(records)==1
  names=[]
  for source in [compiled,before]:
   start=source.index('mod tests {');brace=source.index('{',start);depth=1;end=brace+1
   while depth:
    depth+=(source[end]=='{')-(source[end]=='}');end+=1
   names.append(re.findall(r'\bfn ([a-zA-Z_][a-zA-Z_0-9]*)\(',source[start:end]))
  assert names[0]==names[1]
  suffix=0
 else:
  assert compiled.startswith(production);suffix=len(compiled)-len(production)
  assert before.startswith(original+owner)
  assert before[len(original+owner):]==compiled[len(production):]
  assert production==original+owner
 proof.append({'path':path,'production_sha256':hashlib.sha256(production.encode()).hexdigest(),'exact_after_named_getters_stripped':True,'test_suffix_bytes':suffix})
rows=json.loads((r/'correctness-receipts.json').read_text());assert len(rows)==278 and all(x['exit_code']==0 for x in rows);suites=[]
for row in rows:
 if 'case' in row:continue
 log=Path(row['log']).read_text();assert hashlib.sha256(log.encode()).hexdigest()==row['log_sha256'];m=re.search(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',log);assert m and m[2]=='0';suites.append({'lane':row['lane'],'pattern':row['pattern'],'passed':int(m[1]),'ignored':int(m[3])})
zeros=[x for x in suites if x['passed']==0];v={'source':json.loads((r/'candidate-source-receipt.json').read_text())['source'],'files':proof,'baseline_production_exact_except_same_added_tests_and_named_getters':True,'shared_test_definition_order_matches':True,'common_suites':suites,'zero_test_filters_explicit':zeros};(r/'candidate-exact-production-proof.json').write_text(json.dumps(v,indent=2)+'\n')
for name,count in [('empty-owner-correctness-receipts.json',6),('window-record-owner-regression-receipts.json',2)]: assert len(json.loads((r/name).read_text()))==count
v={'common_native_passes':sum(x['passed'] for x in suites),'common_children':278,'matched_frame_audit_cases':121,'empty_release_children':6,'cold_owner_expected_red_green_children':2,'zero_filters_explicit':zeros,'earlier_failed_correctness_source_and_exact_logs_preserved':True};(r/'correctness-summary.json').write_text(json.dumps(v,indent=2)+'\n');print(json.dumps(v))
