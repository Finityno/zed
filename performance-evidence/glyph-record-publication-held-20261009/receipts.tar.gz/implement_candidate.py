from pathlib import Path
import hashlib,json,subprocess,os
root=Path(__file__).parent;worktree=Path('/workspace/zed-record-publication');previous=Path('/workspace/zed-in-place-ranges');baseline='08d5555709d7afab3936c7afcd9f7f0ff9ecbd65'
assert (worktree/'README.md').read_text().startswith('> [!IMPORTANT]\n> Remove this line to confirm you\'ve reviewed this PR before submitting.')
assert hashlib.sha256((root/'policy.json').read_bytes()).hexdigest()==(root/'policy.sha256').read_text().strip()
path=worktree/'crates/gpui/src/scene.rs';source=(previous/'crates/gpui/src/scene.rs').read_text()
assert hashlib.sha256(source.encode()).hexdigest()=='5bc12e6381a10a3ffce06892c335a66736f8142eb679c2e1d4cfe844834b8157'
source=source.replace('AtomicUsize','AtomicBool')
header='''    // A descriptor published to a caller must not absorb later glyphs.
    // Atomic storage keeps the immutable Scene interface Send + Sync.
    published_paint_prefix: AtomicBool,
''';assert source.count(header)==1;source=source.replace(header,'')
source=source.replace('        self.published_paint_prefix.store(0, Ordering::Relaxed);\n','')
old='''    pub fn len(&self) -> usize {
        let length = self.paint_operations.len();
        self.published_paint_prefix.store(length, Ordering::Relaxed);
        length
    }'''
new='''    pub fn len(&self) -> usize {
        if let Some(PaintOperation::MonochromeSprites(record) | PaintOperation::SubpixelSprites(record)) =
            self.paint_operations.last()
        {
            record.published.store(true, Ordering::Relaxed);
        }
        self.paint_operations.len()
    }''';assert source.count(old)==1;source=source.replace(old,new)
start=source.index('    #[inline]\n    fn append_glyph_record(');end=source.index('    /// The number of paint operations and of painted glyph sprites so far,',start)
source=source[:start]+'''    #[inline]
    fn append_glyph_record(&mut self, subpixel: bool, index: usize) {
        if let Some(last) = self.paint_operations.last_mut() {
            match last {
                PaintOperation::MonochromeSprites(record)
                    if !subpixel && record.indices.end == index
                        && !record.published.load(Ordering::Relaxed) =>
                {
                    record.indices.end = index + 1;
                    return;
                }
                PaintOperation::SubpixelSprites(record)
                    if subpixel && record.indices.end == index
                        && !record.published.load(Ordering::Relaxed) =>
                {
                    record.indices.end = index + 1;
                    return;
                }
                _ => {}
            }
        }
        self.paint_operations.push(PaintOperation::glyphs(subpixel, index..index + 1));
    }

'''+source[end:]
old='''            PaintOperation::MonochromeSprite(index) => {
                let sprite = &self.painted_monochrome_sprites[*index as usize];
                clipped(&sprite.bounds, &sprite.content_mask)
            }
            PaintOperation::SubpixelSprite(index) => {
                let sprite = &self.painted_subpixel_sprites[*index as usize];
                clipped(&sprite.bounds, &sprite.content_mask)
            }
''';assert source.count(old)==1;source=source.replace(old,'')
source=source.replace('PaintOperation::MonochromeSprites(indices) => self.painted_monochrome_sprites[indices.clone()]','PaintOperation::MonochromeSprites(record) => self.painted_monochrome_sprites[record.indices.clone()]')
source=source.replace('PaintOperation::SubpixelSprites(indices) => self.painted_subpixel_sprites[indices.clone()]','PaintOperation::SubpixelSprites(record) => self.painted_subpixel_sprites[record.indices.clone()]')
old='''            // Nested retained records shift by operation index. Each source
            // operation must keep its own destination operation boundary.
            self.len();
''';assert source.count(old)==1;source=source.replace(old,'')
start=source.index('                PaintOperation::Primitive(_)\n',source.index('    pub(crate) fn replay_inside('));end=source.index('                PaintOperation::MonochromeSprites(indices)\n',start);oldbranch=source[start:end]
body=oldbranch[oldbranch.index('                    if let Some(moved) = moved {'):]
source=source[:start]+'''                PaintOperation::Primitive(primitive) => {
                    let mut primitive = primitive.clone();
'''+body+source[end:]
start=source.index('                PaintOperation::MonochromeSprites(indices)\n',source.index('    pub(crate) fn replay_inside('));end=source.index('                PaintOperation::StartLayer(layer) => match moved {',start);branch=source[start:end]
branch=branch.replace('PaintOperation::MonochromeSprites(indices)','PaintOperation::MonochromeSprites(record)').replace('PaintOperation::SubpixelSprites(indices)','PaintOperation::SubpixelSprites(record)').replace('                    for index in indices.clone() {','''                    // Nested retained ranges shift by operation index, so
                    // separate source glyph records must not join on replay.
                    self.len();
                    for index in record.indices.clone() {''')
source=source[:start]+branch+source[end:]
old='''    MonochromeSprite(u32),
    SubpixelSprite(u32),
    MonochromeSprites(Range<usize>),
    SubpixelSprites(Range<usize>),''';new='''    MonochromeSprites(GlyphPaintRecord),
    SubpixelSprites(GlyphPaintRecord),''';assert source.count(old)==1;source=source.replace(old,new)
start=source.index('impl PaintOperation {');end=source.index('\n#[derive(Clone)]\n',start)
source=source[:start]+'''pub(crate) struct GlyphPaintRecord {
    indices: Range<usize>,
    // Publishing an index protects only the last extensible glyph record.
    // Atomic storage preserves the immutable Scene interface's Send + Sync.
    published: AtomicBool,
}

impl PaintOperation {
    fn glyph_indices(&self) -> Option<(bool, Range<usize>)> {
        match self {
            Self::MonochromeSprites(record) => Some((false, record.indices.clone())),
            Self::SubpixelSprites(record) => Some((true, record.indices.clone())),
            Self::Primitive(_) | Self::StartLayer(_) | Self::EndLayer => None,
        }
    }

    fn glyphs(subpixel: bool, indices: Range<usize>) -> Self {
        let record = GlyphPaintRecord { indices, published: AtomicBool::new(false) };
        if subpixel {
            Self::SubpixelSprites(record)
        } else {
            Self::MonochromeSprites(record)
        }
    }
}
''' +source[end:]
assert 'published_paint_prefix' not in source
assert 'PaintOperation::MonochromeSprite(' not in source and 'PaintOperation::SubpixelSprite(' not in source
path.write_text(source)
tests=worktree/'crates/gpui/src/window/view_retention/tests.rs';tests.write_text((previous/'crates/gpui/src/window/view_retention/tests.rs').read_text())
# The non-glyph movement/remap/animation body is byte-identical; only glyph
# descriptor shape changes. No source-loop seal remains on non-glyph replay.
base_source=subprocess.check_output(['git','show',baseline+':crates/gpui/src/scene.rs'],cwd=worktree,env=os.environ|{'GIT_NO_LAZY_FETCH':'1'},text=True)
a=base_source.index('                    if let Some(moved) = moved {',base_source.index('    pub(crate) fn replay_inside('));b=base_source.index('                PaintOperation::StartLayer(layer) =>',a);expected=base_source[a:b]
assert body==expected
(root/'non-glyph-replay-body-proof.json').write_text(json.dumps({'baseline':baseline,'non_glyph_transformation_remap_animation_and_insertion_body_exact':True,'body_sha256':hashlib.sha256(body.encode()).hexdigest(),'no_publication_call_in_non_glyph_replay':True,'new_uniform_glyph_descriptor_contains_atomic_flag':True,'no_scene_header_or_scalar_promotion':True},indent=2)+'\n')
