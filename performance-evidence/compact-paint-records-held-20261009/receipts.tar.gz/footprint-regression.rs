    #[test]
    fn indexed_glyph_records_do_not_reserve_full_glyph_payloads() {
        assert!(std::mem::size_of::<PaintOperation>() < std::mem::size_of::<Primitive>());
    }

