from pathlib import Path
import json,hashlib,tarfile,shutil,re,subprocess,os,collections
r=Path(__file__).parent;c=r/'comparison';w=Path('/workspace/zed-paint-records');d=json.loads((c/'decision.json').read_text());assert d['status']=='HELD_UNMERGED' and len(d['failures'])==6
public=w/'performance-evidence/compact-paint-records-held-20261009';public.mkdir(parents=True)
rows=json.loads((c/'correctness-receipts.json').read_text());count=0;zero=[]
for v in rows:
 if 'pattern' not in v:continue
 m=re.search(r'test result: ok\. (\d+) passed',Path(v['log']).read_text());assert m;count+=int(m.group(1))
 if m.group(1)=='0':zero.append({'lane':v['lane'],'pattern':v['pattern']})
(c/'correctness-summary.json').write_text(json.dumps({'common_children':len(rows),'native_common_test_passes':count,'paired_frame_audits':119,'before_after_footprint_expected_before_failure':True,'after_footprint_pass':True,'expected_red_test_skipped_in_both_common_suites':True,'zero_test_patterns_no_coverage_claim':zero,'all_common_correctness_pass':True},indent=2)+'\n')
files=[]
for p in r.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(r)
 if any(part=='__pycache__' or part.endswith('-artifacts') for part in rel.parts):
  if p.suffix!='.d':continue
 if p.name.endswith('.pyc') or p.name.endswith('.preserved.gz'):continue
 files.append((str(rel),p))
archive=public/'receipts.tar.gz';seen={};linked=0
with tarfile.open(archive,'w:gz',compresslevel=6) as t:
 for name,p in sorted(files):
  st=p.stat();raw=p.read_bytes();sha=hashlib.sha256(raw).hexdigest();key=(sha,st.st_size,st.st_mode,st.st_mtime_ns);info=t.gettarinfo(str(p),arcname=name)
  if key in seen:
   info.type=tarfile.LNKTYPE;info.linkname=seen[key];info.size=0;t.addfile(info);linked+=1
  else:
   seen[key]=name
   with p.open('rb') as f:t.addfile(info,f)
with tarfile.open(archive,'r:gz') as t:
 assert len(t.getmembers())==len(files)
 for name,p in files:assert hashlib.sha256(t.extractfile(name).read()).digest()==hashlib.sha256(p.read_bytes()).digest(),name
sha=hashlib.sha256(archive.read_bytes()).hexdigest();metadata={'archive_sha256':sha,'archive_bytes':archive.stat().st_size,'archive_members':len(files),'byte_exact_roundtrip':True,'identical_member_hardlinks':linked,'hardlink_note':'Tar links deduplicate members only when bytes, size, mode and nanosecond modification time match; all members resolve to original exact bytes. No raw sample/source removed.','held':True,'merged':False,'production_source':'f71a4eba34a6dc288e8180dc61945d8be4fcbb95','baseline':'08d5555709d7afab3936c7afcd9f7f0ff9ecbd65','never_resample_unchanged':True,'no_app_GPU_platform_or_shipped_allocator_gain':True};(r/'archive-verification.json').write_text(json.dumps(metadata,indent=2)+'\n');(public/'evidence.json').write_text(json.dumps(metadata,indent=2)+'\n')
for name in ['decision.json','summary.json','policy.json','policy.sha256','correctness-summary.json','footprint-regression-receipts.json','compiler-dependency-identities.json','external-dependencies.json','binary-identities.json','native-runtime-identity.json','candidate-source-receipt.json','lane-source-difference-proof.json']:shutil.copy2(c/name,public/name)
for name in ['diagnostic-method.json','diagnostic-decision.json','diagnostic-binary-identity.json']:shutil.copy2(r/name,public/name)
(public/'README.md').write_text(f'''# Held compact paint records

The candidate is unmerged. All 20 declared memory targets pass across 3,332
native children: paint records shrink from 184 to 168 bytes, with 8.6957% less
requested owner storage. Transcript fixtures retain 64 KiB less and use
1.017–1.191% less complete-component live requested heap. Colored fixtures
retain 384 KiB less and use 2.500–2.555% less live requested heap. All ordinary
CPU, elapsed, whole-child CPU, peak RSS, requested held/peak/total byte and
allocation-call controls pass. Six current RSS controls fail their frozen
baseline ranges, so do not merge, adopt, resample unchanged or weaken gates.

The failures are bare value-on-16-bare-nested (+564 KiB versus484 variation),
value-on-80-bare-flat (+692 versus516), color-redraw-off-32-32 (+1508 versus388),
and census resize-on-80-bare-nested (+1036 versus516), keep-256 (+268 versus260),
color-recolor-on-200-32 (+1656 versus196). Requested byte reductions do not
establish a process RSS reduction.

Twenty current-main complete-window owner attribution children precede the
prototype and frozen policy. Bare timing comprises 2,142 children in488.979
seconds, followed separately by1,190 census children in123.578 seconds.
All59 immutable original externs, original Taffy0.13, compiler/flags and
System allocator/runtime identities match across both lanes and before/after
phases. No timing overlaps builds, compression, hashing or other profiling.

Common correctness passes in274 children: {count} native test passes plus119
paired complete-frame primitive/hitbox/state-owner/count audits. The native
footprint contract fails on baseline and passes on the candidate; both common
suites explicitly skip that separately verified expected-red contract. The
new independent snapshot regression passes before/after: renderer-array
mutations do not alter stored quad/shadow/path/underline/image snapshots,
path vertices remain independently owned, and shadow blur extents retain their
clip rule. Zero-test filters are explicitly excluded from coverage claims.
The candidate's complete Scene suite also passes before the cohort.

This flattens the private record enum; public Primitive payloads, scalar
replay/move/rebase/animation behavior, buffer counts/capacities and rendering
APIs remain. No prior held glyph-span scanner, cache, new heap owner or unsafe
code is copied into this design. Source isf71a4eba34a6dc288e8180dc61945d8be4fcbb95
on owned baseline08d5555709d7afab3936c7afcd9f7f0ff9ecbd65. Consumer pins remain
rendering6b18c87dd5f2d1ccbee1ee641054295f2a78390b and
component031f54b627333272a8c157cbe4ca1cf591d16172. No consumer adoption is made.

Archive SHA256:{sha}. All{len(files)} raw/source/fixture/identity members resolve
to verified original bytes. Exact duplicate members share tar links only when
content and file metadata match. Large native/dependency artifacts are
identified by hashes and retained in the managed workspace. Original source
attribution and licenses remain intact.

Coverage is Linux GPUI fake platform/text and System requested counting.
No Fincode application, physical GPU, macOS/Windows or shipped allocator gain
is established. Next investigate the intermediate permutation buffer used
while copying sorted glyphs, with captured current-main scene evidence.
''')
p=w/'PERFORMANCE_GOAL.md';s=p.read_text();s+='''\n\nPrivate paint-record flattening at\n`f71a4eba34a6dc288e8180dc61945d8be4fcbb95` remains held and unmerged. Its\n3,332 native children meet all20 declared memory targets:8.6957% lower record\nowner storage,64 KiB lower held bytes in transcript fixtures and384 KiB in\ncolored fixtures, with1.017–1.191%/2.500–2.555% less completecomponent live\nrequested heap. All CPU/elapsed/wholechildCPU and requested held/peak/total\nbyte/call gates pass. Six current RSS fields exceed their frozen baseline\nranges. Preserve all adverse results and do not resample unchanged or weaken\ngates. Complete pairedframe/native snapshot/path/shadowclip correctness and\nbefore-red/after-green footprint tests pass. See\n`performance-evidence/compact-paint-records-held-20261009`. No adoption or\napp/GPU/nativeplatform/shippedallocator gain is claimed. Continue with measured\ncurrentmain scene-sort scratch ownership and intermediate permutation copies.\n''';p.write_text(s)
env=os.environ|{'GIT_NO_LAZY_FETCH':'1'};subprocess.run(['git','add','--sparse','PERFORMANCE_GOAL.md',str(public.relative_to(w))],cwd=w,env=env,check=True);subprocess.run(['git','commit','-m','Preserve held compact paint-record evidence [skip ci]'],cwd=w,env=env,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,env=env,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=w,env=env,text=True).strip();metadata.update({'held_head':head,'held_tree':tree});(r/'held-final-source-receipt.json').write_text(json.dumps(metadata,indent=2)+'\n')
paths=['crates/gpui/src/scene.rs','PERFORMANCE_GOAL.md']+[str(p.relative_to(w)) for p in public.iterdir() if p.is_file()];manifest=[]
for name in sorted(paths):
 p=w/name;blob=subprocess.check_output(['git','hash-object',name],cwd=w,env=env,text=True).strip();manifest.append({'path':name,'local':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'blob':blob})
(r/'publication-files.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(metadata,indent=2))
