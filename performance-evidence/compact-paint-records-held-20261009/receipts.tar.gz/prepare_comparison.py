from pathlib import Path
import json,hashlib,shutil,subprocess,os
r=Path(__file__).parent;c=r/'comparison';c.mkdir();prod=Path('/workspace/zed-paint-records');env=os.environ|{'GIT_NO_LAZY_FETCH':'1'}
for name in ['policy.json','policy.sha256','external-dependencies.json','native-runtime-identity.json','native-run','supervise.py','build_native.py']:shutil.copy2(r/name,c/name)
old=Path('/workspace/scratch/gpui-glyph-spans-loop')
for name in ['measure.py','check_correctness.py','verify_inputs.py','compiler-dependency-identities.json']:shutil.copy2(old/name,c/name)
scene_diag=(r/'baseline-workspace/crates/gpui/src/scene.rs').read_text();i=scene_diag.index('    pub(crate) fn diagnostic_paint_record_owner');j=scene_diag.index('    pub fn finish',i);observer=scene_diag[i:j]
base=subprocess.check_output(['git','show','08d5555709d7afab3936c7afcd9f7f0ff9ecbd65:crates/gpui/src/scene.rs'],cwd=prod,env=env,text=True)
for lane in ['baseline','candidate']:
 w=c/(lane+'-workspace');shutil.copytree(r/'baseline-workspace',w)
 s=base if lane=='baseline' else (prod/'crates/gpui/src/scene.rs').read_text()
 if lane=='baseline':s=s.replace('    fn unit_bounds() -> Bounds<ScaledPixels> {',(r/'footprint-regression.rs').read_text()+(r/'snapshot-regression.rs').read_text()+'    fn unit_bounds() -> Bounds<ScaledPixels> {')
 s=s.replace('    pub fn finish(&mut self) {',observer+'    pub fn finish(&mut self) {');(w/'crates/gpui/src/scene.rs').write_text(s)
 (c/(lane+'-source-inputs.json')).write_text(json.dumps({'baseline':'08d5555709d7afab3936c7afcd9f7f0ff9ecbd65','private_harness_only':True,'files':{str(p.relative_to(w)):hashlib.sha256(p.read_bytes()).hexdigest() for p in w.rglob('*') if p.is_file()}},indent=2)+'\n')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=prod,env=env,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=prod,env=env,text=True).strip();identity={'source':head,'tree':tree,'baseline':'08d5555709d7afab3936c7afcd9f7f0ff9ecbd65','files':{'crates/gpui/src/scene.rs':hashlib.sha256((prod/'crates/gpui/src/scene.rs').read_bytes()).hexdigest()},'scope':'FlattenPaintOperation only; no failed span code copied. Native payload-width/rest-snapshot regressions included.'};(r/'candidate-source-receipt.json').write_text(json.dumps(identity,indent=2)+'\n');(c/'candidate-source-receipt.json').write_text(json.dumps(identity,indent=2)+'\n')
b=json.loads((c/'baseline-source-inputs.json').read_text())['files'];d=json.loads((c/'candidate-source-inputs.json').read_text())['files'];diff=[k for k in b if b[k]!=d[k]];assert diff==['crates/gpui/src/scene.rs'];actual=(c/'candidate-workspace/crates/gpui/src/scene.rs').read_text().replace(observer,'');assert actual==(prod/'crates/gpui/src/scene.rs').read_text()
(c/'lane-source-difference-proof.json').write_text(json.dumps({'source_difference':diff,'all_private_helpers_fixtures_and_tests_identical':True,'candidate_exact_production_bytes_except_named_scene_owner_getters':True,'all59_original_externs_identical':True,'production_source':head},indent=2)+'\n')
p=c/'verify_inputs.py';s=p.read_text().replace('/workspace/zed-glyph-spans','/workspace/zed-paint-records');p.write_text(s)
p=c/'measure.py';s=p.read_text();s=s.replace("if line.startswith('NATIVE_RECEIPT ')","if 'PAINT_RECORD_OWNER ' in line:\n     owner=json.loads(line.split('PAINT_RECORD_OWNER ',1)[1]);row['record_owner']=owner;row['record_owner_bytes']=owner['rendered'][2]+owner['spare'][2]\n    if line.startswith('NATIVE_RECEIPT ')");p.write_text(s)
p=c/'check_correctness.py';s=p.read_text().replace("command=[binary,pattern,'--nocapture','--test-threads=1']","command=[binary,pattern,'--skip','indexed_glyph_records_do_not_reserve_full_glyph_payloads','--nocapture','--test-threads=1']");p.write_text(s)
for name in ['verify_inputs.py','measure.py','check_correctness.py']:compile((c/name).read_text(),str(c/name),'exec')
print(head,tree,'matched source prepared before all paired samples')
