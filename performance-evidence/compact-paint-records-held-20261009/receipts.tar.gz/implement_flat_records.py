from pathlib import Path
p=Path('/workspace/zed-paint-records/crates/gpui/src/scene.rs');s=p.read_text()
s=s.replace('''                PaintOperation::Primitive(_)
                | PaintOperation::StartLayer(_)
                | PaintOperation::EndLayer => {''','''                _ => {''',1)
start=s.index('        match &mut primitive {',s.index('        let order =',s.index('    pub fn insert_primitive(')));end=s.index('\n    }',start)
s=s[:start]+'''        let operation = match primitive {
            Primitive::Shadow(mut shadow) => {
                shadow.order = order;
                self.shadows.push(shadow);
                PaintOperation::Shadow(shadow)
            }
            Primitive::Quad(mut quad) => {
                quad.order = order;
                self.quads.push(quad);
                PaintOperation::Quad(quad)
            }
            Primitive::Path(mut path) => {
                path.order = order;
                path.id = PathId(self.paths.len());
                self.paths.push(path.clone());
                PaintOperation::Path(path)
            }
            Primitive::Underline(mut underline) => {
                underline.order = order;
                self.underlines.push(underline);
                PaintOperation::Underline(underline)
            }
            Primitive::MonochromeSprite(mut sprite) => {
                sprite.order = order;
                let index = self.painted_monochrome_sprites.len() as u32;
                self.painted_monochrome_sprites.push(sprite);
                self.paint_operations.push(PaintOperation::MonochromeSprite(index));
                return;
            }
            Primitive::SubpixelSprite(mut sprite) => {
                sprite.order = order;
                let index = self.painted_subpixel_sprites.len() as u32;
                self.painted_subpixel_sprites.push(sprite);
                self.paint_operations.push(PaintOperation::SubpixelSprite(index));
                return;
            }
            Primitive::PolychromeSprite(mut sprite) => {
                sprite.order = order;
                self.polychrome_sprites.push(sprite);
                PaintOperation::PolychromeSprite(sprite)
            }
            Primitive::Surface(mut surface) => {
                surface.order = order;
                self.surfaces.push(surface.clone());
                PaintOperation::Surface(surface)
            }
        };
        self.paint_operations.push(operation);'''+s[end:]
old='''            PaintOperation::Primitive(primitive) => {
                clipped(&primitive_extent(primitive), primitive.content_mask())
            }'''
new='''            PaintOperation::Shadow(shadow) => clipped(
                &shadow.bounds.dilate(shadow.blur_radius * 3.), &shadow.content_mask,
            ),
            PaintOperation::Quad(quad) => clipped(&quad.bounds, &quad.content_mask),
            PaintOperation::Path(path) => clipped(&path.bounds, &path.content_mask),
            PaintOperation::Underline(underline) => clipped(&underline.bounds, &underline.content_mask),
            PaintOperation::PolychromeSprite(sprite) => clipped(&sprite.bounds, &sprite.content_mask),
            PaintOperation::Surface(surface) => clipped(&surface.bounds, &surface.content_mask),'''
assert old in s;s=s.replace(old,new)
old='''                PaintOperation::Primitive(_)
                | PaintOperation::MonochromeSprite(_)
                | PaintOperation::SubpixelSprite(_) => {'''
new='''                PaintOperation::Shadow(_)
                | PaintOperation::Quad(_)
                | PaintOperation::Path(_)
                | PaintOperation::Underline(_)
                | PaintOperation::PolychromeSprite(_)
                | PaintOperation::Surface(_)
                | PaintOperation::MonochromeSprite(_)
                | PaintOperation::SubpixelSprite(_) => {'''
assert old in s;s=s.replace(old,new)
old='''                        PaintOperation::Primitive(primitive) => primitive.clone(),'''
new='''                        PaintOperation::Shadow(shadow) => Primitive::Shadow(*shadow),
                        PaintOperation::Quad(quad) => Primitive::Quad(*quad),
                        PaintOperation::Path(path) => Primitive::Path(path.clone()),
                        PaintOperation::Underline(underline) => Primitive::Underline(*underline),
                        PaintOperation::PolychromeSprite(sprite) => Primitive::PolychromeSprite(*sprite),
                        PaintOperation::Surface(surface) => Primitive::Surface(surface.clone()),'''
assert old in s;s=s.replace(old,new)
old='''pub(crate) enum PaintOperation {
    Primitive(Primitive),'''
new='''pub(crate) enum PaintOperation {
    // Glyph records below already name the painted arrays by index. Keeping
    // another Primitive enum here reserved its full glyph payload in every
    // record, including layer operations and the indexed glyphs themselves.
    Shadow(Shadow),
    Quad(Quad),
    Path(Path<ScaledPixels>),
    Underline(Underline),
    PolychromeSprite(PolychromeSprite),
    Surface(PaintSurface),'''
assert old in s;s=s.replace(old,new)
assert 'PaintOperation::Primitive' not in s
marker='''    fn unit_bounds() -> Bounds<ScaledPixels> {'''
test='''    #[test]
    fn indexed_glyph_records_do_not_reserve_full_glyph_payloads() {
        assert!(std::mem::size_of::<PaintOperation>() < std::mem::size_of::<Primitive>());
    }

'''
assert marker in s;s=s.replace(marker,test+marker);p.write_text(s)
Path('/workspace/scratch/gpui-paint-records-loop/footprint-regression.rs').write_text(test)
print('Flattened stored records; original generic scalar replay/move/rebase paths preserved. No batch scanner/newowner/unsafe code.')
