from pathlib import Path
p=Path('/workspace/zed-paint-records/crates/gpui/src/scene.rs');s=p.read_text();mark='    fn unit_bounds() -> Bounds<ScaledPixels> {'
test='''    #[test]
    fn replayed_records_keep_snapshots_and_owned_path_vertices() {
        let paint = |scene: &mut Scene| {
            let bounds = unit_bounds();
            let mask = ContentMask { bounds };
            scene.push_layer(bounds);
            scene.insert_primitive(opaque_quad());
            scene.insert_primitive(Shadow {
                order: 0, blur_radius: ScaledPixels(1.), bounds,
                corner_radii: Corners::default(), content_mask: mask, color: crate::white(),
                element_bounds: bounds, element_corner_radii: Corners::default(), inset: 0, pad: 0,
            });
            let mut path = Path::new(point(px(0.), px(0.)));
            path.line_to(point(px(4.), px(0.)));
            path.line_to(point(px(4.), px(4.)));
            let mut path = path.scale(1.);
            path.bounds = bounds;
            path.content_mask = mask;
            assert!(!path.vertices.is_empty());
            scene.insert_primitive(path);
            scene.insert_primitive(Underline {
                order: 0, pad: 0, bounds, content_mask: mask, color: crate::white(),
                thickness: ScaledPixels(1.), wavy: false.into(),
            });
            scene.insert_primitive(PolychromeSprite {
                order: 0, pad: 0, grayscale: false.into(), opacity: 0.5, bounds,
                content_mask: mask, corner_radii: Corners::default(), tile: shimmering_glyph(0).tile,
            });
            #[cfg(not(target_os = "macos"))]
            scene.insert_primitive(PaintSurface { order: 0, bounds, content_mask: mask });
            scene.insert_monochrome_sprite(shimmering_glyph(0));
            scene.pop_layer();
        };
        let mut source = Scene::default();
        paint(&mut source);
        assert!(!source.clipped_only_inside(0..source.len(), [0., 0., 10., 10.]));
        source.finish();
        // Presenting changes renderer arrays. Replay must still recover the
        // rest snapshot, including the separately owned path vertex buffer.
        source.quads[0].background = Background::from(crate::white());
        source.shadows[0].bounds.origin.x = ScaledPixels(100.);
        source.paths[0].vertices.clear();
        source.underlines[0].bounds.origin.y = ScaledPixels(100.);
        source.polychrome_sprites[0].opacity = 0.;
        let destination = || {
            let mut scene = Scene::default();
            scene.insert_primitive(opaque_quad());
            scene
        };
        let mut replayed = destination();
        replayed.replay(0..source.len(), &source);
        replayed.finish();
        let mut fresh = destination();
        paint(&mut fresh);
        fresh.finish();
        assert_eq!(format!("{:?}", replayed.quads), format!("{:?}", fresh.quads));
        assert_eq!(format!("{:?}", replayed.shadows), format!("{:?}", fresh.shadows));
        assert_eq!(format!("{:?}", replayed.paths), format!("{:?}", fresh.paths));
        assert_eq!(format!("{:?}", replayed.underlines), format!("{:?}", fresh.underlines));
        assert_eq!(format!("{:?}", replayed.polychrome_sprites), format!("{:?}", fresh.polychrome_sprites));
        assert_eq!(format!("{:?}", replayed.monochrome_sprites), format!("{:?}", fresh.monochrome_sprites));
        assert_eq!(format!("{:?}", replayed.surfaces), format!("{:?}", fresh.surfaces));
        assert_eq!(replayed.paint_operations.len(), fresh.paint_operations.len());
    }

'''
assert mark in s;s=s.replace(mark,test+mark);p.write_text(s);Path('/workspace/scratch/gpui-paint-records-loop/snapshot-regression.rs').write_text(test)
