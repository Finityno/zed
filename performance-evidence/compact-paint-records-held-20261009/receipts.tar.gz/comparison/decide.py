from pathlib import Path
import json,hashlib,statistics
r=Path(__file__).parent;p=json.loads((r/'policy.json').read_text());assert hashlib.sha256((r/'policy.json').read_bytes()).hexdigest()==(r/'policy.sha256').read_text().strip();summary=[];failures=[]
for kind,pairs in [('bare',p['timing_pairs']),('census',p['memory_pairs'])]:
 rows=json.loads((r/(kind+'-samples.json')).read_text());assert len(rows)==len(p['controls'])*pairs*2
 for case in p['controls']:
  lanes={lane:[v for v in rows if v['case']==case and v['lane']==lane] for lane in ['baseline','candidate']};assert all(len(v)==pairs and all(row['exit_code']==0 for row in v) for v in lanes.values())
  for pair in range(pairs):
   b=next(v for v in lanes['baseline'] if v['pair']==pair);c=next(v for v in lanes['candidate'] if v['pair']==pair)
   for field in ['signature','frame_hash','state_count','state_box_bytes','frames','nodes','node_high_water']:
    if field in b or field in c:assert b[field]==c[field],(kind,case,pair,field,b.get(field),c.get(field))
   if 'record_owner' in b or 'record_owner' in c:
    for owner in ['rendered','spare']:
     assert b['record_owner'][owner][:2]==c['record_owner'][owner][:2],(kind,case,owner,b['record_owner'][owner],c['record_owner'][owner])
    assert b['record_owner']['rendered'][3]==b['record_owner']['spare'][3]==184
    assert c['record_owner']['rendered'][3]==c['record_owner']['spare'][3]==168
  fields=['cpu_ns','elapsed_ns','child_cpu_ns','current_rss_kib','peak_rss_kib'] if kind=='bare' else ['held_bytes','peak_bytes','requested_bytes','allocation_calls','current_rss_kib','peak_rss_kib']
  if kind=='census' and case in p['primary']:fields+=['record_owner_bytes']
  entry={'kind':kind,'case':case,'fields':{}}
  for field in fields:
   base=[v[field] for v in lanes['baseline']];cand=[v[field] for v in lanes['candidate']];bm=statistics.median(base);cm=statistics.median(cand);br=max(base)-min(base);cr=max(cand)-min(cand);delta=cm-bm;gain=-delta/bm if bm else 0;target=None;absolute_target=None
   if kind=='census' and case in p['primary'] and field in ['held_bytes','record_owner_bytes']:
    target=p['primary_live_gain_fractions'][case] if field=='held_bytes' else p['primary_owner_gain_fraction'];absolute_target=0 if field=='held_bytes' else p['primary_owner_absolute_gains'][case];passed=gain>=target and -delta>max(br,cr) and -delta>=absolute_target;budget=None;gate='declared_memory_primary'
   else:
    budget=0 if field in ['held_bytes','peak_bytes','requested_bytes','allocation_calls'] else br;passed=delta<=budget;gate='zero_heap_churn_or_full_baseline_range_control'
   metric={'baseline_median':bm,'candidate_median':cm,'delta':delta,'fraction_gain':gain,'baseline_range':br,'candidate_range':cr,'budget':budget,'target_fraction':target,'absolute_gain_target':absolute_target,'gate':gate,'pass':passed};entry['fields'][field]=metric
   if not passed:failures.append({'kind':kind,'case':case,'field':field,**metric})
  summary.append(entry)
(r/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');decision={'qualified':not failures,'status':'PERFORMANCE_GATES_PASS_PENDING_OWNING_CHECKS_REVIEW' if not failures else 'HELD_UNMERGED','failures':failures,'controls':len(p['controls']),'native_children':len(p['controls'])*(p['timing_pairs']+p['memory_pairs'])*2,'primary':[v for v in summary if v['kind']=='census' and v['case'] in p['primary']],'policy_sha256':hashlib.sha256((r/'policy.json').read_bytes()).hexdigest(),'no_unchanged_resampling':True,'no_app_GPU_platform_gain':True,'memory_growth_budget':0};(r/'decision.json').write_text(json.dumps(decision,indent=2)+'\n');print(json.dumps({'qualified':not failures,'children':decision['native_children'],'failed_fields':len(failures),'failures':[(f['kind'],f['case'],f['field'],f['delta'],f['budget']) for f in failures],'primary_live':[(v['case'],v['fields']['held_bytes']['fraction_gain'],v['fields']['record_owner_bytes']['delta']) for v in decision['primary']]}))
