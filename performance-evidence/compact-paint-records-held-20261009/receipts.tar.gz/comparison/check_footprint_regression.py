from pathlib import Path
import subprocess,json,hashlib,os
r=Path(__file__).parent;out=r/'footprint-regression';out.mkdir();rows=[]
for lane in ['baseline','candidate']:
 binary=r/(lane+'-bare-artifacts/gpui-ada3fb4d7b1cfe56');log=out/(lane+'.log');command=[str(r/'native-run'),str(binary),'indexed_glyph_records_do_not_reserve_full_glyph_payloads','--nocapture','--test-threads=1']
 with log.open('w') as f:result=subprocess.run(command,env=os.environ,stdout=f,stderr=subprocess.STDOUT,timeout=90)
 expected=101 if lane=='baseline' else 0;assert result.returncode==expected,(lane,result.returncode,log.read_text());assert ('1 failed' if lane=='baseline' else '1 passed') in log.read_text()
 rows.append({'lane':lane,'command':command,'exit_code':result.returncode,'expected_exit_code':expected,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'passed_expected_behavior':True})
(r/'footprint-regression-receipts.json').write_text(json.dumps(rows,indent=2)+'\n');print('Native footprint contract fails before and passes after; no paired samples discarded.')
