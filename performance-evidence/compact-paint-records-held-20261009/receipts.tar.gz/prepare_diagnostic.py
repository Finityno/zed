from pathlib import Path
import json,hashlib,shutil,subprocess,os
r=Path(__file__).parent;w=r/'baseline-workspace';previous=Path('/workspace/scratch/gpui-glyph-spans-loop/baseline-workspace');shutil.copytree(previous,w)
p=w/'crates/gpui/src/scene.rs';s=p.read_text();mark='    pub fn finish(&mut self) {';assert s.count(mark)==1
insert='''    pub(crate) fn diagnostic_paint_record_owner(&self) -> [usize; 4] {
        [self.paint_operations.len(), self.paint_operations.capacity(),
         self.paint_operations.capacity() * std::mem::size_of::<PaintOperation>(),
         std::mem::size_of::<PaintOperation>()]
    }

    pub(crate) fn diagnostic_flat_record_width() -> usize {
        #[allow(dead_code)]
        enum RecordShape {
            Shadow(Shadow), Quad(Quad), Path(Path<ScaledPixels>), Underline(Underline),
            PolychromeSprite(PolychromeSprite), Surface(PaintSurface),
            MonochromeSprite(u32), SubpixelSprite(u32), StartLayer(Layer), EndLayer,
        }
        std::mem::size_of::<RecordShape>()
    }

''';p.write_text(s.replace(mark,insert+mark))
for name,handle,marker in [('transcript_profile.rs','window','    let node_high_water = '),('color_profile.rs','window','    let current_rss_kib = ')]:
 p=w/'crates/gpui/src/window/view_retention'/name;s=p.read_text();i=s.index(marker)
 observer='''    let (rendered_records, spare_records) = cx.update_window('''+handle+'''.into(), |_, window, _| (window.rendered_frame.scene.diagnostic_paint_record_owner(), window.next_frame.scene.diagnostic_paint_record_owner())).expect("scene owners");
    let flat_width = crate::scene::Scene::diagnostic_flat_record_width();
    println!("PAINT_RECORD_OWNER {}", serde_json::json!({"rendered":rendered_records,"spare":spare_records,"flat_width":flat_width}));
''';s=s[:i]+observer+s[i:];p.write_text(s)
files={str(p.relative_to(w)):hashlib.sha256(p.read_bytes()).hexdigest() for p in w.rglob('*') if p.is_file()};(r/'baseline-source-inputs.json').write_text(json.dumps({'baseline':'08d5555709d7afab3936c7afcd9f7f0ff9ecbd65','private_attribution_only':True,'files':files},indent=2)+'\n')
method={'baseline':'08d5555709d7afab3936c7afcd9f7f0ff9ecbd65','fincode_main':'2ecee972697eb4827f23da9517dc9f6b200048f4','fincode_pin':'6b18c87dd5f2d1ccbee1ee641054295f2a78390b','component_pin':'031f54b627333272a8c157cbe4ca1cf591d16172','production_candidate_exists':False,'purpose':'Measured complete native transcript paint-record requested owner attribution: exact Vec len/capacity/width in both rendered and spare frames, versus a local uninstantiated flat-record type shape. Reads occur after all timers/census snapshots and do not allocate on scene paths. No candidate/performance-gain claim.','owner_controls':'All59 original externs/runtime identical. Steady wholecomponent census held/peak/total/calls/nativeRSS and scene/frame/state counts preserved; new observation occurs after census and functional signatures. Before any production prototype, choose meaningful owner/completecomponent memory goals and freeze all strict controls.','cases':[f'{scenario}-{mode}-{count}' for scenario in ['scroll','stream','tick','redraw'] for mode in ['off','on'] for count in [200,512]]+['color-redraw-off-200-32','color-redraw-on-200-32','color-decorated-off-200-32','color-decorated-on-200-32'],'iterations':128,'allocator':'System requested counting only, never CPU gain evidence','no_app_GPU_platform_gain':True}
(r/'diagnostic-method.json').write_text(json.dumps(method,indent=2)+'\n');print('Private paint-record attribution added; production worktree remains unchanged.')
