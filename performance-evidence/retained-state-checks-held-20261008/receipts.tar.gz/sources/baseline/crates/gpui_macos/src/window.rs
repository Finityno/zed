use crate::{
    BoolExt, MacDisplay, MacPlatform, NSRange, NSStringExt, TISCopyCurrentKeyboardInputSource,
    TISGetInputSourceProperty, WindowFrameSource, events::platform_input_from_native,
    kTISPropertyInputSourceIsASCIICapable, kTISPropertyInputSourceType, kTISTypeKeyboardInputMode,
    ns_string, renderer,
};
#[cfg(any(test, feature = "test-support"))]
use anyhow::Result;
use block2::RcBlock;
use cocoa::{
    appkit::{
        NSApplication, NSBackingStoreBuffered, NSColor, NSControl as _, NSEvent,
        NSEventModifierFlags, NSEventType,
        NSFilenamesPboardType, NSMenu, NSMenuItem, NSPasteboard, NSRequestUserAttentionType,
        NSScreen, NSView, NSViewHeightSizable, NSViewWidthSizable, NSVisualEffectMaterial,
        NSVisualEffectState, NSVisualEffectView, NSWindow, NSWindowCollectionBehavior,
        NSWindowOcclusionState, NSWindowOrderingMode, NSWindowStyleMask, NSWindowTitleVisibility,
    },
    base::{id, nil},
    foundation::{
        NSArray, NSAutoreleasePool, NSData, NSDictionary, NSFastEnumeration, NSInteger, NSNotFound,
        NSOperatingSystemVersion, NSPoint, NSProcessInfo, NSRect, NSSize, NSString, NSUInteger,
        NSUserDefaults,
    },
};
use dispatch2::DispatchQueue;
use gpui::{
    AnyWindowHandle, BackgroundExecutor, Bounds, Capslock, CursorStyle, ExternalDragPayload,
    ExternalPaths, FileDropEvent, ForegroundExecutor, KeyDownEvent, Keymap, Keystroke, Modifiers,
    ModifiersChangedEvent, MouseButton, MouseDownEvent, MouseMoveEvent, MouseUpEvent,
    NativeMenuItem, Pixels,
    PlatformAtlas, PlatformDisplay, PlatformInput, PlatformInputHandler, PlatformWindow, Point,
    PresentOutcome, PresentReport, PromptButton, PromptLevel, RequestFrameOptions, Rgba,
    SharedString, Size, SystemWindowTab,
    WindowAppearance, WindowBackgroundAppearance, WindowBounds, WindowControlArea, WindowGlassStyle,
    WindowKind, WindowParams, WindowVisibility, point, px, size,
};
#[cfg(any(test, feature = "test-support"))]
use image::RgbaImage;

use core_foundation::base::{CFRelease, CFTypeRef};
use core_foundation_sys::base::CFEqual;
use core_foundation_sys::number::{CFBooleanGetValue, CFBooleanRef};
use core_graphics::display::{CGDirectDisplayID, CGRect};
use ctor::ctor;
use futures::channel::oneshot;
use gpui_util::ResultExt;
use objc::{
    class,
    declare::ClassDecl,
    msg_send,
    runtime::{BOOL, Class, NO, Object, Protocol, Sel, YES},
    sel, sel_impl,
};
use objc2::{
    AnyThread, MainThreadMarker,
    rc::Retained,
    runtime::{AnyObject as Objc2Object, ProtocolObject},
};
use objc2_app_kit::{
    NSAlert, NSAlertStyle, NSBeep, NSButton as Objc2NSButton, NSDraggingImageComponent,
    NSDraggingImageComponentIconKey, NSDraggingItem, NSPasteboardWriting, NSTrackingArea,
    NSTrackingAreaOptions, NSView as Objc2NSView, NSWindow as Objc2NSWindow,
    NSWindowButton as Objc2NSWindowButton, NSWorkspace,
};
use objc2_foundation::{NSPoint as Objc2NSPoint, NSRect as Objc2NSRect, NSURL};
use parking_lot::Mutex;
use raw_window_handle as rwh;
use smallvec::SmallVec;
use std::{
    cell::Cell,
    ffi::{CStr, CString, c_void},
    mem,
    ops::Range,
    os::unix::ffi::OsStrExt,
    path::PathBuf,
    ptr::{self, NonNull},
    rc::Rc,
    sync::{
        Arc, Once, Weak,
        atomic::{AtomicBool, Ordering},
    },
    time::{Duration, Instant},
};

const WINDOW_STATE_IVAR: &str = "windowState";
const OVERLAY_INPUT_IVAR: &str = "overlayInputActive";

static RESTORES_WORKSPACE_AT_LAUNCH_DEFAULT: Once = Once::new();

static mut WINDOW_CLASS: *const Class = ptr::null();
static mut PANEL_CLASS: *const Class = ptr::null();
static mut VIEW_CLASS: *const Class = ptr::null();
static mut OVERLAY_VIEW_CLASS: *const Class = ptr::null();
static mut BLURRED_VIEW_CLASS: *const Class = ptr::null();
static mut WINDOW_STATE_ARCHIVER_DELEGATE_CLASS: *const Class = ptr::null();
static mut WINDOW_STATE_UNARCHIVER_CLASS: *const Class = ptr::null();
static mut CONTEXT_MENU_TARGET_CLASS: *const Class = ptr::null();

const CONTEXT_MENU_SELECTION_IVAR: &str = "contextMenuSelection";

#[allow(non_upper_case_globals)]
const NSWindowStyleMaskNonactivatingPanel: NSWindowStyleMask =
    NSWindowStyleMask::from_bits_retain(1 << 7);
// WindowLevel const value ref: https://docs.rs/core-graphics2/0.4.1/src/core_graphics2/window_level.rs.html
#[allow(non_upper_case_globals)]
const NSNormalWindowLevel: NSInteger = 0;
#[allow(non_upper_case_globals)]
const NSFloatingWindowLevel: NSInteger = 3;
#[allow(non_upper_case_globals)]
const NSPopUpWindowLevel: NSInteger = 101;
#[allow(non_upper_case_globals)]
const NSWindowAnimationBehaviorUtilityWindow: NSInteger = 4;
#[allow(non_upper_case_globals)]
const NSViewLayerContentsRedrawDuringViewResize: NSInteger = 2;
// https://developer.apple.com/documentation/appkit/nsdragoperation
type NSDragOperation = NSUInteger;
#[allow(non_upper_case_globals)]
const NSDragOperationNone: NSDragOperation = 0;
#[allow(non_upper_case_globals)]
const NSDragOperationCopy: NSDragOperation = 1;
#[allow(non_upper_case_globals)]
const NSDragOperationMove: NSDragOperation = 16;
const NSDRAGGING_CONTEXT_OUTSIDE_APPLICATION: NSInteger = 0;
const NSDRAGGING_CONTEXT_WITHIN_APPLICATION: NSInteger = 1;

extern "C" fn overlay_hit_test(this: &Object, _: Sel, _: NSPoint) -> id {
    let active = unsafe {
        let raw: *mut c_void = *this.get_ivar(OVERLAY_INPUT_IVAR);
        &*(raw as *const AtomicBool)
    };
    if active.load(Ordering::Acquire) {
        this as *const Object as id
    } else {
        nil
    }
}

extern "C" fn handle_overlay_event(this: &Object, selector: Sel, native_event: id) {
    let window_state = unsafe { get_window_state(this) };
    let native_view = window_state.lock().native_view;
    unsafe {
        handle_view_event(native_view.as_ref(), selector, native_event);
    }
}

#[derive(PartialEq)]
pub enum UserTabbingPreference {
    Never,
    Always,
    InFullScreen,
}

#[ctor(unsafe)]
unsafe fn build_classes() {
    unsafe {
        WINDOW_CLASS = build_window_class("GPUIWindow", class!(NSWindow));
        PANEL_CLASS = build_window_class("GPUIPanel", class!(NSPanel));
        CONTEXT_MENU_TARGET_CLASS = match ClassDecl::new("GPUIContextMenuTarget", class!(NSObject))
        {
            Some(mut decl) => {
                decl.add_ivar::<*mut c_void>(CONTEXT_MENU_SELECTION_IVAR);
                decl.add_method(
                    sel!(handleGPUIContextMenuItem:),
                    handle_context_menu_item as extern "C" fn(&Object, Sel, id),
                );
                decl.register()
            }
            // Objective-C class names are process-global, so another loaded
            // image may have registered the name already; native context menus
            // then stay unavailable instead of panicking at startup.
            None => ptr::null(),
        };
        VIEW_CLASS = {
            let mut decl = ClassDecl::new("GPUIView", class!(NSView)).unwrap();
            decl.add_ivar::<*mut c_void>(WINDOW_STATE_IVAR);
            decl.add_method(sel!(dealloc), dealloc_view as extern "C" fn(&Object, Sel));

            decl.add_method(
                sel!(performKeyEquivalent:),
                handle_key_equivalent as extern "C" fn(&Object, Sel, id) -> BOOL,
            );
            decl.add_method(
                sel!(keyDown:),
                handle_key_down as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(keyUp:),
                handle_key_up as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(mouseDown:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(mouseUp:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(rightMouseDown:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(rightMouseUp:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(otherMouseDown:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(otherMouseUp:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(mouseMoved:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(resetCursorRects),
                reset_cursor_rects as extern "C" fn(&Object, Sel),
            );
            decl.add_method(
                sel!(pressureChangeWithEvent:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(mouseExited:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(magnifyWithEvent:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(mouseDragged:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(rightMouseDragged:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(otherMouseDragged:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(scrollWheel:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(swipeWithEvent:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );
            decl.add_method(
                sel!(flagsChanged:),
                handle_view_event as extern "C" fn(&Object, Sel, id),
            );

            decl.add_method(
                sel!(makeBackingLayer),
                make_backing_layer as extern "C" fn(&Object, Sel) -> id,
            );

            decl.add_protocol(Protocol::get("CALayerDelegate").unwrap());
            decl.add_method(
                sel!(viewDidChangeBackingProperties),
                view_did_change_backing_properties as extern "C" fn(&Object, Sel),
            );
            decl.add_method(
                sel!(setFrameSize:),
                set_frame_size as extern "C" fn(&Object, Sel, NSSize),
            );
            decl.add_method(
                sel!(displayLayer:),
                display_layer as extern "C" fn(&Object, Sel, id),
            );

            decl.add_protocol(Protocol::get("NSTextInputClient").unwrap());
            decl.add_method(
                sel!(validAttributesForMarkedText),
                valid_attributes_for_marked_text as extern "C" fn(&Object, Sel) -> id,
            );
            decl.add_method(
                sel!(hasMarkedText),
                has_marked_text as extern "C" fn(&Object, Sel) -> BOOL,
            );
            decl.add_method(
                sel!(markedRange),
                marked_range as extern "C" fn(&Object, Sel) -> NSRange,
            );
            decl.add_method(
                sel!(selectedRange),
                selected_range as extern "C" fn(&Object, Sel) -> NSRange,
            );
            decl.add_method(
                sel!(firstRectForCharacterRange:actualRange:),
                first_rect_for_character_range
                    as extern "C" fn(&Object, Sel, NSRange, id) -> NSRect,
            );
            decl.add_method(
                sel!(insertText:replacementRange:),
                insert_text as extern "C" fn(&Object, Sel, id, NSRange),
            );
            decl.add_method(
                sel!(setMarkedText:selectedRange:replacementRange:),
                set_marked_text as extern "C" fn(&Object, Sel, id, NSRange, NSRange),
            );
            decl.add_method(sel!(unmarkText), unmark_text as extern "C" fn(&Object, Sel));
            decl.add_method(
                sel!(attributedSubstringForProposedRange:actualRange:),
                attributed_substring_for_proposed_range
                    as extern "C" fn(&Object, Sel, NSRange, *mut c_void) -> id,
            );
            decl.add_method(
                sel!(viewDidChangeEffectiveAppearance),
                view_did_change_effective_appearance as extern "C" fn(&Object, Sel),
            );

            // Suppress beep on keystrokes with modifier keys.
            decl.add_method(
                sel!(doCommandBySelector:),
                do_command_by_selector as extern "C" fn(&Object, Sel, Sel),
            );

            decl.add_method(
                sel!(acceptsFirstMouse:),
                accepts_first_mouse as extern "C" fn(&Object, Sel, id) -> BOOL,
            );

            decl.add_method(
                sel!(_opaqueRectForWindowMoveWhenInTitlebar),
                opaque_rect_for_window_move_when_in_titlebar
                    as extern "C" fn(&Object, Sel) -> NSRect,
            );

            decl.add_method(
                sel!(characterIndexForPoint:),
                character_index_for_point as extern "C" fn(&Object, Sel, NSPoint) -> u64,
            );
            decl.register()
        };
        OVERLAY_VIEW_CLASS = {
            let mut decl = ClassDecl::new("GPUIOverlayView", class!(NSView)).unwrap();
            decl.add_ivar::<*mut c_void>(WINDOW_STATE_IVAR);
            decl.add_ivar::<*mut c_void>(OVERLAY_INPUT_IVAR);
            decl.add_method(
                sel!(dealloc),
                dealloc_overlay_view as extern "C" fn(&Object, Sel),
            );
            decl.add_method(
                sel!(hitTest:),
                overlay_hit_test as extern "C" fn(&Object, Sel, NSPoint) -> id,
            );
            // Same answer as the base view: while the overlay holds content
            // (a popover left open when the user switched apps) it is the
            // view AppKit asks, and NSView's default NO would activate the
            // window and swallow that first click instead of delivering it.
            decl.add_method(
                sel!(acceptsFirstMouse:),
                accepts_first_mouse as extern "C" fn(&Object, Sel, id) -> BOOL,
            );
            for selector in [
                sel!(mouseDown:),
                sel!(mouseUp:),
                sel!(rightMouseDown:),
                sel!(rightMouseUp:),
                sel!(otherMouseDown:),
                sel!(otherMouseUp:),
                sel!(mouseMoved:),
                sel!(mouseExited:),
                sel!(mouseDragged:),
                sel!(rightMouseDragged:),
                sel!(otherMouseDragged:),
                sel!(scrollWheel:),
                sel!(magnifyWithEvent:),
                sel!(swipeWithEvent:),
                sel!(pressureChangeWithEvent:),
            ] {
                decl.add_method(
                    selector,
                    handle_overlay_event as extern "C" fn(&Object, Sel, id),
                );
            }
            decl.register()
        };
        BLURRED_VIEW_CLASS = {
            let mut decl = ClassDecl::new("BlurredView", class!(NSVisualEffectView)).unwrap();
            decl.add_method(
                sel!(initWithFrame:),
                blurred_view_init_with_frame as extern "C" fn(&Object, Sel, NSRect) -> id,
            );
            decl.add_method(
                sel!(updateLayer),
                blurred_view_update_layer as extern "C" fn(&Object, Sel),
            );
            decl.register()
        };
        WINDOW_STATE_ARCHIVER_DELEGATE_CLASS = {
            let mut decl =
                ClassDecl::new("GPUIWindowStateArchiverDelegate", class!(NSObject)).unwrap();
            decl.add_method(
                sel!(archiver:willEncodeObject:),
                window_state_archiver_will_encode_object
                    as extern "C" fn(&Object, Sel, id, id) -> id,
            );
            decl.register()
        };
        WINDOW_STATE_UNARCHIVER_CLASS = {
            let mut decl =
                ClassDecl::new("GPUIWindowStateKeyedUnarchiver", class!(NSKeyedUnarchiver))
                    .unwrap();
            decl.add_method(
                sel!(_windowRestorationOptions),
                window_state_unarchiver_restoration_options as extern "C" fn(&Object, Sel) -> id,
            );
            decl.register()
        };
    }
}

// NSKeyedArchiverDelegate callback that skips objects which don't adopt `NSSecureCoding`
// (the window itself and its NSView hierarchy), so encoding the window's restorable state
// succeeds. AppKit still encodes the window frame and its persistent window-management
// identifier, which is what the Space restoration on relaunch keys off.
extern "C" fn window_state_archiver_will_encode_object(
    _this: &Object,
    _sel: Sel,
    _archiver: id,
    object: id,
) -> id {
    // SAFETY: `object` is whatever AppKit hands the delegate during archiving; we only send it
    // `isKindOfClass:` with valid class arguments, which is safe for any Objective-C object.
    unsafe {
        if object.is_null() {
            return object;
        }
        let is_view: BOOL = msg_send![object, isKindOfClass: class!(NSView)];
        let is_window: BOOL = msg_send![object, isKindOfClass: class!(NSWindow)];
        if is_view == YES || is_window == YES {
            nil
        } else {
            object
        }
    }
}

// Override of the private `_windowRestorationOptions` on our NSKeyedUnarchiver subclass.
// Returning a default-initialized `NSWindowRestorationOptions` tells AppKit to restore the
// window to its original Space. This is the macOS 15+ path (FB15644170: the
// `NSWindowRestoresWorkspaceAtLaunch` user default no longer works there).
extern "C" fn window_state_unarchiver_restoration_options(_this: &Object, _sel: Sel) -> id {
    if !is_macos_version_at_least(NSOperatingSystemVersion::new(15, 0, 0)) {
        return nil;
    }
    // SAFETY: we look the class up by name and only send it `alloc`/`init`/`autorelease`, all of
    // which have the standard `-> id` signature. Returning `nil` when the class is absent is valid.
    unsafe {
        match Class::get("NSWindowRestorationOptions") {
            Some(class) => {
                let options: id = msg_send![class, alloc];
                let options: id = msg_send![options, init];
                msg_send![options, autorelease]
            }
            None => nil,
        }
    }
}

pub(crate) fn convert_mouse_position(position: NSPoint, window_height: Pixels) -> Point<Pixels> {
    point(
        px(position.x as f32),
        // macOS screen coordinates are relative to bottom left
        window_height - px(position.y as f32),
    )
}

unsafe fn create_native_context_menu(
    items: &[NativeMenuItem],
    target: id,
    keymap: &Keymap,
    next_tag: &mut NSInteger,
) -> id {
    unsafe {
        let menu = NSMenu::new(nil);
        // The items are enabled explicitly below; the target deliberately does not
        // implement `validateMenuItem:`, so automatic enabling must stay off.
        let _: () = msg_send![menu, setAutoenablesItems: NO];
        for item in items {
            let ns_item = match item {
                NativeMenuItem::Separator => NSMenuItem::separatorItem(nil),
                NativeMenuItem::Submenu {
                    name,
                    items,
                    disabled,
                } => {
                    let ns_item = NSMenuItem::new(nil).autorelease();
                    let submenu = create_native_context_menu(items, target, keymap, next_tag);
                    ns_item.setSubmenu_(submenu);
                    let _: () = msg_send![submenu, release];
                    ns_item.setTitle_(ns_string(name));
                    ns_item.setEnabled_(if *disabled { NO } else { YES });
                    ns_item
                }
                NativeMenuItem::Entry(entry) => {
                    let keystrokes = entry.action.as_ref().and_then(|action| {
                        MacPlatform::keystrokes_for_menu_action(action.as_ref(), keymap)
                    });
                    let ns_item = MacPlatform::new_menu_item_with_key_equivalent(
                        &entry.name,
                        sel!(handleGPUIContextMenuItem:),
                        keystrokes,
                    );
                    if entry.checked {
                        ns_item.setState_(NSVisualEffectState::Active);
                    }
                    ns_item.setEnabled_(if entry.disabled { NO } else { YES });
                    let _: () = msg_send![ns_item, setTarget: target];
                    let _: () = msg_send![ns_item, setTag: *next_tag];
                    *next_tag += 1;
                    ns_item
                }
            };
            menu.addItem_(ns_item);
        }
        menu
    }
}

extern "C" fn handle_context_menu_item(this: &Object, _: Sel, item: id) {
    unsafe {
        let selection =
            *this.get_ivar::<*mut c_void>(CONTEXT_MENU_SELECTION_IVAR) as *mut Cell<isize>;
        if selection.is_null() {
            return;
        }
        let tag: NSInteger = msg_send![item, tag];
        (*selection).set(tag as isize);
    }
}

/// Stores the cursor style on the active GPUI window and invalidates its cursor rects.
///
/// # Safety
///
/// This function is not thread safe. Callers must ensure this is called on the AppKit main
/// thread because it reads the active AppKit window and updates GPUI window state associated
/// with Objective-C objects.
pub(crate) unsafe fn set_active_window_cursor_style(style: CursorStyle) {
    // SAFETY: The caller guarantees AppKit main-thread access. `is_gpui_window` ensures the
    // window has our WINDOW_STATE_IVAR before reading it.
    unsafe {
        let app = NSApplication::sharedApplication(nil);
        let key_window: id = msg_send![app, keyWindow];
        let main_window: id = msg_send![app, mainWindow];
        let active_window = if !key_window.is_null() && is_gpui_window(key_window) {
            Some(key_window)
        } else if !main_window.is_null() && is_gpui_window(main_window) {
            Some(main_window)
        } else {
            None
        };

        let Some(active_window) = active_window else {
            return;
        };

        let window_state = get_window_state(&*active_window);
        let mut window_state = window_state.lock();
        if window_state.cursor_style != style {
            window_state.cursor_style = style;
            let _: () = msg_send![
                window_state.native_window,
                invalidateCursorRectsForView: window_state.native_view.as_ptr()
            ];
        }
    }
}

unsafe fn build_window_class(name: &'static str, superclass: &Class) -> *const Class {
    unsafe {
        let mut decl = ClassDecl::new(name, superclass).unwrap();
        decl.add_ivar::<*mut c_void>(WINDOW_STATE_IVAR);
        decl.add_method(sel!(dealloc), dealloc_window as extern "C" fn(&Object, Sel));

        decl.add_method(
            sel!(canBecomeMainWindow),
            yes as extern "C" fn(&Object, Sel) -> BOOL,
        );
        decl.add_method(
            sel!(canBecomeKeyWindow),
            yes as extern "C" fn(&Object, Sel) -> BOOL,
        );
        decl.add_method(
            sel!(windowDidResize:),
            window_did_resize as extern "C" fn(&Object, Sel, id),
        );
        decl.add_method(
            sel!(windowDidChangeOcclusionState:),
            window_did_change_occlusion_state as extern "C" fn(&Object, Sel, id),
        );
        decl.add_method(
            sel!(windowWillEnterFullScreen:),
            window_will_enter_fullscreen as extern "C" fn(&Object, Sel, id),
        );
        decl.add_method(
            sel!(windowWillExitFullScreen:),
            window_will_exit_fullscreen as extern "C" fn(&Object, Sel, id),
        );
        decl.add_method(
            sel!(windowDidFailToExitFullScreen:),
            window_did_fail_to_exit_fullscreen as extern "C" fn(&Object, Sel, id),
        );
        decl.add_method(
            sel!(windowDidExitFullScreen:),
            window_did_exit_fullscreen as extern "C" fn(&Object, Sel, id),
        );
        decl.add_method(
            sel!(windowDidMove:),
            window_did_move as extern "C" fn(&Object, Sel, id),
        );
        decl.add_method(
            sel!(windowDidChangeScreen:),
            window_did_change_screen as extern "C" fn(&Object, Sel, id),
        );
        decl.add_method(
            sel!(windowDidBecomeKey:),
            window_did_change_key_status as extern "C" fn(&Object, Sel, id),
        );
        decl.add_method(
            sel!(windowDidResignKey:),
            window_did_change_key_status as extern "C" fn(&Object, Sel, id),
        );
        decl.add_method(
            sel!(windowShouldClose:),
            window_should_close as extern "C" fn(&Object, Sel, id) -> BOOL,
        );

        decl.add_method(sel!(close), close_window as extern "C" fn(&Object, Sel));

        decl.add_method(
            sel!(draggingEntered:),
            dragging_entered as extern "C" fn(&Object, Sel, id) -> NSDragOperation,
        );
        decl.add_method(
            sel!(draggingUpdated:),
            dragging_updated as extern "C" fn(&Object, Sel, id) -> NSDragOperation,
        );
        decl.add_method(
            sel!(draggingExited:),
            dragging_exited as extern "C" fn(&Object, Sel, id),
        );
        decl.add_method(
            sel!(performDragOperation:),
            perform_drag_operation as extern "C" fn(&Object, Sel, id) -> BOOL,
        );
        decl.add_method(
            sel!(concludeDragOperation:),
            conclude_drag_operation as extern "C" fn(&Object, Sel, id),
        );

        decl.add_protocol(Protocol::get("NSDraggingSource").unwrap());
        decl.add_method(
            sel!(draggingSession:sourceOperationMaskForDraggingContext:),
            dragging_session_source_operation_mask
                as extern "C" fn(&Object, Sel, id, NSInteger) -> NSDragOperation,
        );
        decl.add_method(
            sel!(draggingSession:endedAtPoint:operation:),
            dragging_session_ended as extern "C" fn(&Object, Sel, id, NSPoint, NSDragOperation),
        );

        decl.add_method(
            sel!(addTitlebarAccessoryViewController:),
            add_titlebar_accessory_view_controller as extern "C" fn(&Object, Sel, id),
        );

        decl.add_method(
            sel!(moveTabToNewWindow:),
            move_tab_to_new_window as extern "C" fn(&Object, Sel, id),
        );

        decl.add_method(
            sel!(mergeAllWindows:),
            merge_all_windows as extern "C" fn(&Object, Sel, id),
        );

        decl.add_method(
            sel!(selectNextTab:),
            select_next_tab as extern "C" fn(&Object, Sel, id),
        );

        decl.add_method(
            sel!(selectPreviousTab:),
            select_previous_tab as extern "C" fn(&Object, Sel, id),
        );

        decl.add_method(
            sel!(toggleTabBar:),
            toggle_tab_bar as extern "C" fn(&Object, Sel, id),
        );

        decl.register()
    }
}

#[derive(Clone, Copy)]
struct TrafficLightFrames {
    titlebar: Objc2NSRect,
    close: Objc2NSRect,
    minimize: Objc2NSRect,
    zoom: Objc2NSRect,
}

struct TrafficLightButtons {
    close: Retained<Objc2NSButton>,
    minimize: Retained<Objc2NSButton>,
    zoom: Retained<Objc2NSButton>,
}

// `NSApplicationPresentationOptions` bits (see `NSApplication.PresentationOptions`).
const NS_APPLICATION_PRESENTATION_AUTO_HIDE_DOCK: NSUInteger = 1 << 0;
const NS_APPLICATION_PRESENTATION_AUTO_HIDE_MENU_BAR: NSUInteger = 1 << 2;

// State captured when entering simple (borderless) fullscreen, used to restore
// the window on exit.
struct SimpleFullscreenState {
    frame: NSRect,
    bounds: Bounds<Pixels>,
    style_mask: NSWindowStyleMask,
}

enum SimpleFullscreenPlan {
    Enter { screen_frame: NSRect },
    Exit(SimpleFullscreenState),
}

struct SimpleFullscreenAppState {
    window_count: usize,
    saved_presentation_options: NSUInteger,
}

static SIMPLE_FULLSCREEN_APP_STATE: Mutex<Option<SimpleFullscreenAppState>> = Mutex::new(None);

unsafe fn push_simple_fullscreen_presentation_options() {
    let mut app_state = SIMPLE_FULLSCREEN_APP_STATE.lock();
    match app_state.as_mut() {
        Some(app_state) => app_state.window_count += 1,
        None => unsafe {
            let app = NSApplication::sharedApplication(nil);
            let saved_presentation_options: NSUInteger = msg_send![app, presentationOptions];
            let _: () = msg_send![
                app,
                setPresentationOptions: NS_APPLICATION_PRESENTATION_AUTO_HIDE_DOCK
                    | NS_APPLICATION_PRESENTATION_AUTO_HIDE_MENU_BAR
            ];
            *app_state = Some(SimpleFullscreenAppState {
                window_count: 1,
                saved_presentation_options,
            });
        },
    }
}

unsafe fn pop_simple_fullscreen_presentation_options() {
    let mut app_state = SIMPLE_FULLSCREEN_APP_STATE.lock();
    if let Some(state) = app_state.as_mut() {
        state.window_count = state.window_count.saturating_sub(1);
        if state.window_count == 0 {
            unsafe {
                let app = NSApplication::sharedApplication(nil);
                let _: () = msg_send![
                    app,
                    setPresentationOptions: state.saved_presentation_options
                ];
            }
            *app_state = None;
        }
    }
}

unsafe fn apply_simple_fullscreen_plan(
    native_window: id,
    native_view: id,
    plan: SimpleFullscreenPlan,
) {
    unsafe {
        match plan {
            SimpleFullscreenPlan::Exit(saved) => {
                pop_simple_fullscreen_presentation_options();
                native_window.setStyleMask_(saved.style_mask);
                native_window.setFrame_display_(saved.frame, YES);
            }
            SimpleFullscreenPlan::Enter { screen_frame } => {
                push_simple_fullscreen_presentation_options();
                native_window.setStyleMask_(NSWindowStyleMask::NSBorderlessWindowMask);
                native_window.setFrame_display_(screen_frame, YES);
            }
        }

        // Changing the style mask makes AppKit resign the window's key status and
        // first responder, so keyboard input stops reaching the editor. Re-make the
        // window key and restore the GPUI view as first responder.
        native_window.makeKeyAndOrderFront_(nil);
        native_window.makeFirstResponder_(native_view);
    }
}

struct MacWindowState {
    handle: AnyWindowHandle,
    foreground_executor: ForegroundExecutor,
    background_executor: BackgroundExecutor,
    native_window: id,
    native_view: NonNull<Object>,
    overlay_view: Option<NonNull<Object>>,
    overlay_input_active: Arc<AtomicBool>,
    blurred_view: Option<id>,
    // Requested glass backdrop tint; applied to `blurred_view` when it is an
    // `NSGlassEffectView`, remembered here so recreations reapply it.
    glass_tint: Option<Rgba>,
    // Requested glass backdrop style, remembered like `glass_tint`.
    glass_style: WindowGlassStyle,
    background_appearance: WindowBackgroundAppearance,
    cursor_style: CursorStyle,
    cursor_visible: Arc<AtomicBool>,
    frame_source: Option<WindowFrameSource>,
    renderer: renderer::Renderer,
    overlay_renderer: Option<renderer::Renderer>,
    /// The layered present's two halves; see `draw_layered`.
    base_scene: gpui::Scene,
    overlay_scene: gpui::Scene,
    renderer_context: renderer::Context,
    request_frame_callback: Option<Box<dyn FnMut(RequestFrameOptions)>>,
    event_callback: Option<Box<dyn FnMut(PlatformInput) -> gpui::DispatchEventResult>>,
    activate_callback: Option<Box<dyn FnMut(bool)>>,
    visibility_callback: Option<Box<dyn FnMut(WindowVisibility)>>,
    // `None` until a callback is registered, so notifications during
    // construction are not queued for delivery to a callback registered later.
    last_visibility: Option<WindowVisibility>,
    resize_callback: Option<Box<dyn FnMut(Size<Pixels>, f32)>>,
    moved_callback: Option<Box<dyn FnMut()>>,
    should_close_callback: Option<Box<dyn FnMut() -> bool>>,
    close_callback: Option<Box<dyn FnOnce()>>,
    appearance_changed_callback: Option<Box<dyn FnMut()>>,
    input_handler: Option<PlatformInputHandler>,
    last_key_equivalent: Option<KeyDownEvent>,
    last_left_mouse_down_event: Option<Retained<Objc2Object>>,
    synthetic_drag_counter: usize,
    traffic_light_position: Option<Point<Pixels>>,
    traffic_light_frames: Option<TrafficLightFrames>,
    pre_fullscreen_traffic_light_frames: Option<TrafficLightFrames>,
    transparent_titlebar: bool,
    previous_modifiers_changed_event: Option<PlatformInput>,
    keystroke_for_do_command: Option<Keystroke>,
    do_command_handled: Option<bool>,
    external_files_dragged: bool,
    // Whether the next left-mouse click is also the focusing click.
    first_mouse: bool,
    // When true, the whole content view is reported as app-owned titlebar content via
    // `_opaqueRectForWindowMoveWhenInTitlebar`, so AppKit does not drag the window from
    // the titlebar or delay titlebar clicks (a delay first observed on macOS 27). Such
    // windows draw their own titlebar and move the window via `start_window_move`.
    app_owns_titlebar_drag: bool,
    fullscreen_restore_bounds: Bounds<Pixels>,
    is_exiting_fullscreen: bool,
    simple_fullscreen_state: Option<SimpleFullscreenState>,
    move_tab_to_new_window_callback: Option<Box<dyn FnMut()>>,
    merge_all_windows_callback: Option<Box<dyn FnMut()>>,
    select_next_tab_callback: Option<Box<dyn FnMut()>>,
    select_previous_tab_callback: Option<Box<dyn FnMut()>>,
    toggle_tab_bar_callback: Option<Box<dyn FnMut()>>,
    /// Whether this window was given a tabbing identifier, and so may be a
    /// native tab. Kept per window because `allowsAutomaticWindowTabbing` is
    /// class-wide: configuring any window overwrites it, so it does not say
    /// whether this one can be a tab.
    native_tabbing: bool,
    activated_least_once: bool,
    closed: Arc<AtomicBool>,
    accesskit_adapter: Option<accesskit_macos::SubclassingAdapter>,
    // The parent window if this window is a sheet (Dialog kind)
    sheet_parent: Option<id>,
    /// The most recently presented native context menu. Held here — not
    /// released when its selection is reported — so a stray action message
    /// delivered after the tracking session still lands on live objects; the
    /// next presented menu (or the window state going away) drops this
    /// reference, and the invocation's own popup/report task holds the other,
    /// so nothing is freed while an invocation is still in flight.
    active_context_menu: Option<Arc<ActiveContextMenu>>,
    /// Distinguishes context-menu invocations, so a popup task queued behind a
    /// newer invocation can tell it was superseded and skip presenting.
    context_menu_generation: u64,
}

/// Everything a presented native context menu keeps alive: the `NSMenu`, its
/// `GPUIContextMenuTarget`, and the selection cell the target writes into.
///
/// Shared through an `Arc` rather than an `Rc` because one reference sits in
/// `MacWindowState`, which is `Send`: the last reference can be released from
/// whichever thread drops the window state, so the count must be atomic and
/// the AppKit teardown must hop to the main thread when it is not already
/// there.
struct ActiveContextMenu {
    generation: u64,
    menu: id,
    target: id,
    selection: *mut Cell<isize>,
}

/// The pointers an `ActiveContextMenu` owns, detached from it so the teardown
/// can be handed to the main queue whole when the last reference goes away on
/// another thread.
struct ContextMenuTeardown {
    menu: id,
    target: id,
    selection: *mut Cell<isize>,
}

impl ContextMenuTeardown {
    unsafe fn run(self) {
        unsafe {
            (*self.target).set_ivar(CONTEXT_MENU_SELECTION_IVAR, ptr::null_mut::<c_void>());
            let _: () = msg_send![self.menu, release];
            let _: () = msg_send![self.target, release];
            drop(Box::from_raw(self.selection));
        }
    }
}

impl Drop for ActiveContextMenu {
    fn drop(&mut self) {
        extern "C" fn teardown_on_main(context: *mut c_void) {
            unsafe {
                Box::from_raw(context as *mut ContextMenuTeardown).run();
            }
        }

        let teardown = ContextMenuTeardown {
            menu: self.menu,
            target: self.target,
            selection: self.selection,
        };
        let is_main_thread: BOOL = unsafe { msg_send![class!(NSThread), isMainThread] };
        if is_main_thread == YES {
            unsafe { teardown.run() }
        } else {
            unsafe {
                let context = Box::into_raw(Box::new(teardown)) as *mut c_void;
                DispatchQueue::main().exec_async_f(context, teardown_on_main);
            }
        }
    }
}

impl MacWindowState {
    fn set_presents_with_transaction(&mut self, enabled: bool) {
        self.renderer.set_presents_with_transaction(enabled);
        if let Some(renderer) = self.overlay_renderer.as_mut() {
            renderer.set_presents_with_transaction(enabled);
        }
    }

    fn move_traffic_light(&mut self) {
        if let Some(traffic_light_position) = self.traffic_light_position {
            if self.is_fullscreen() && !self.is_exiting_fullscreen {
                self.restore_traffic_light();
                return;
            }

            if self.traffic_light_frames.is_none() {
                self.traffic_light_frames = self.capture_traffic_light_frames();
            }

            let window_height = Pixels::from(self.native_window().frame().size.height);
            if self.traffic_light_frames.is_some() {
                // AppKit can recreate standard buttons, so fetch the live views for each layout pass.
                let Some(buttons) = self.traffic_light_buttons() else {
                    return;
                };
                let Some(titlebar_container) = Self::titlebar_container(&buttons.close) else {
                    return;
                };

                let close_frame = buttons.close.frame();
                let minimize_frame = buttons.minimize.frame();
                let button_width = Pixels::from(close_frame.size.width);
                let button_height = Pixels::from(close_frame.size.height);
                let button_padding = Pixels::from(
                    minimize_frame.origin.x - close_frame.origin.x - close_frame.size.width,
                );
                let container_height =
                    button_height + traffic_light_position.y + traffic_light_position.y;

                let mut titlebar_frame = titlebar_container.frame();
                titlebar_frame.size.height = container_height.to_f64();
                titlebar_frame.origin.y = (window_height - container_height).to_f64();

                let minimize_x = traffic_light_position.x + button_width + button_padding;
                let zoom_x = minimize_x + button_width + button_padding;

                titlebar_container.setFrame(titlebar_frame);
                buttons.close.setFrameOrigin(Objc2NSPoint::new(
                    traffic_light_position.x.to_f64(),
                    traffic_light_position.y.to_f64(),
                ));
                buttons.minimize.setFrameOrigin(Objc2NSPoint::new(
                    minimize_x.to_f64(),
                    traffic_light_position.y.to_f64(),
                ));
                buttons.zoom.setFrameOrigin(Objc2NSPoint::new(
                    zoom_x.to_f64(),
                    traffic_light_position.y.to_f64(),
                ));

                titlebar_container.updateTrackingAreas();
                buttons.close.updateTrackingAreas();
                buttons.minimize.updateTrackingAreas();
                buttons.zoom.updateTrackingAreas();
            }
        }
    }

    fn capture_traffic_light_frames(&self) -> Option<TrafficLightFrames> {
        let buttons = self.traffic_light_buttons()?;
        let titlebar_container = Self::titlebar_container(&buttons.close)?;

        Some(TrafficLightFrames {
            titlebar: titlebar_container.frame(),
            close: buttons.close.frame(),
            minimize: buttons.minimize.frame(),
            zoom: buttons.zoom.frame(),
        })
    }

    fn native_window(&self) -> &Objc2NSWindow {
        // SAFETY: `MacWindow::new` initializes `self.native_window` with the AppKit
        // window for this state. It is either `NSWindow` or `NSPanel`, so borrowing it
        // as `Objc2NSWindow` is valid here.
        unsafe { &*self.native_window.cast::<Objc2NSWindow>() }
    }

    fn traffic_light_buttons(&self) -> Option<TrafficLightButtons> {
        let window = self.native_window();
        Some(TrafficLightButtons {
            close: window.standardWindowButton(Objc2NSWindowButton::CloseButton)?,
            minimize: window.standardWindowButton(Objc2NSWindowButton::MiniaturizeButton)?,
            zoom: window.standardWindowButton(Objc2NSWindowButton::ZoomButton)?,
        })
    }

    fn titlebar_container(close_button: &Objc2NSButton) -> Option<Retained<Objc2NSView>> {
        // SAFETY: `close_button` comes from AppKit's `standardWindowButton(_:)`.
        // Although `superview` is unsafe, objc2 returns each result as `Retained<NSView>`.
        unsafe {
            let button_container = close_button.superview()?;
            button_container.superview()
        }
    }

    fn restore_traffic_light(&mut self) {
        if let Some(frames) = self.traffic_light_frames.take() {
            let Some(buttons) = self.traffic_light_buttons() else {
                return;
            };
            let Some(titlebar_container) = Self::titlebar_container(&buttons.close) else {
                return;
            };

            buttons.close.setFrame(frames.close);
            buttons.minimize.setFrame(frames.minimize);
            buttons.zoom.setFrame(frames.zoom);
            titlebar_container.setFrame(frames.titlebar);

            titlebar_container.updateTrackingAreas();
            buttons.close.updateTrackingAreas();
            buttons.minimize.updateTrackingAreas();
            buttons.zoom.updateTrackingAreas();
        }
    }

    /// A display-link tick already queued when the window went occluded can
    /// still draw once, rebuilding the intermediate textures that
    /// `windowDidChangeOcclusionState:` released, with no later transition to
    /// release them again. Dropping them after any draw made while not
    /// visible keeps an occluded window at zero; the frame's command buffer
    /// holds its own references until the GPU is done.
    fn release_intermediates_if_occluded(&mut self) {
        let visible = unsafe {
            self.native_window
                .occlusionState()
                .contains(NSWindowOcclusionState::NSWindowOcclusionStateVisible)
        };
        if visible {
            return;
        }
        self.renderer.release_intermediate_textures();
        if let Some(renderer) = self.overlay_renderer.as_mut() {
            renderer.release_intermediate_textures();
        }
    }

    fn start_display_link(&mut self) {
        self.stop_display_link();
        unsafe {
            if !self
                .native_window
                .occlusionState()
                .contains(NSWindowOcclusionState::NSWindowOcclusionStateVisible)
            {
                return;
            }
        }
        let Some(display_id) = display_id_for_screen(unsafe { self.native_window.screen() }) else {
            // AppKit can temporarily report no screen while displays are being reconfigured.
            return;
        };
        let data = self.native_view.as_ptr() as *mut c_void;
        self.frame_source
            .get_or_insert_with(|| WindowFrameSource::new(data, step))
            .start(display_id)
            .log_err();
    }

    fn stop_display_link(&mut self) {
        if let Some(frame_source) = self.frame_source.as_mut() {
            frame_source.stop();
        }
    }

    fn is_maximized(&self) -> bool {
        fn rect_to_size(rect: NSRect) -> Size<Pixels> {
            let NSSize { width, height } = rect.size;
            size(width.into(), height.into())
        }

        unsafe {
            let bounds = self.bounds();
            let screen_size = rect_to_size(self.native_window.screen().visibleFrame());
            bounds.size == screen_size
        }
    }

    fn is_fullscreen(&self) -> bool {
        unsafe {
            let style_mask = self.native_window.styleMask();
            style_mask.contains(NSWindowStyleMask::NSFullScreenWindowMask)
        }
    }

    fn toggle_simple_fullscreen(&mut self) -> Option<SimpleFullscreenPlan> {
        // If the window is in native fullscreen, simple fullscreen would conflict
        // with AppKit's own fullscreen handling, so ignore the request.
        if self.is_fullscreen() {
            return None;
        }

        if let Some(saved) = self.simple_fullscreen_state.take() {
            Some(SimpleFullscreenPlan::Exit(saved))
        } else {
            let screen = unsafe { self.native_window.screen() };
            if screen == nil {
                return None;
            }
            let screen_frame = unsafe { NSScreen::frame(screen) };
            let bounds = self.bounds();

            self.simple_fullscreen_state = Some(SimpleFullscreenState {
                frame: unsafe { NSWindow::frame(self.native_window) },
                bounds,
                style_mask: unsafe { self.native_window.styleMask() },
            });

            Some(SimpleFullscreenPlan::Enter { screen_frame })
        }
    }

    fn bounds(&self) -> Bounds<Pixels> {
        let mut window_frame = unsafe { NSWindow::frame(self.native_window) };
        let screen = unsafe { NSWindow::screen(self.native_window) };
        if screen == nil {
            return Bounds::new(point(px(0.), px(0.)), gpui::DEFAULT_WINDOW_SIZE);
        }
        let screen_frame = unsafe { NSScreen::frame(screen) };

        // Flip the y coordinate to be top-left origin
        window_frame.origin.y =
            screen_frame.size.height - window_frame.origin.y - window_frame.size.height;

        Bounds::new(
            point(
                px((window_frame.origin.x - screen_frame.origin.x) as f32),
                px((window_frame.origin.y + screen_frame.origin.y) as f32),
            ),
            size(
                px(window_frame.size.width as f32),
                px(window_frame.size.height as f32),
            ),
        )
    }

    fn content_size(&self) -> Size<Pixels> {
        let NSSize { width, height, .. } =
            unsafe { NSView::frame(self.native_window.contentView()) }.size;
        size(px(width as f32), px(height as f32))
    }

    fn scale_factor(&self) -> f32 {
        get_scale_factor(self.native_window)
    }

    fn window_bounds(&self) -> WindowBounds {
        if self.is_fullscreen() {
            WindowBounds::Fullscreen(self.fullscreen_restore_bounds)
        } else if let Some(state) = &self.simple_fullscreen_state {
            WindowBounds::Windowed(state.bounds)
        } else {
            WindowBounds::Windowed(self.bounds())
        }
    }
}

unsafe impl Send for MacWindowState {}

pub(crate) struct MacWindow(Arc<Mutex<MacWindowState>>, MainThreadMarker);

impl MacWindow {
    pub fn open(
        handle: AnyWindowHandle,
        WindowParams {
            bounds,
            titlebar,
            kind,
            is_movable,
            app_owns_titlebar_drag,
            is_resizable,
            is_minimizable,
            focus,
            show,
            display_id,
            window_min_size,
            tabbing_identifier,
            ..
        }: WindowParams,
        cursor_visible: Arc<AtomicBool>,
        foreground_executor: ForegroundExecutor,
        background_executor: BackgroundExecutor,
        renderer_context: renderer::Context,
        marker: MainThreadMarker,
    ) -> Self {
        unsafe {
            let pool = NSAutoreleasePool::new(nil);

            let allows_automatic_window_tabbing = tabbing_identifier.is_some();
            if allows_automatic_window_tabbing {
                let () = msg_send![class!(NSWindow), setAllowsAutomaticWindowTabbing: YES];
            } else {
                let () = msg_send![class!(NSWindow), setAllowsAutomaticWindowTabbing: NO];
            }

            let mut style_mask;
            if let Some(titlebar) = titlebar.as_ref() {
                style_mask =
                    NSWindowStyleMask::NSClosableWindowMask | NSWindowStyleMask::NSTitledWindowMask;

                if is_resizable {
                    style_mask |= NSWindowStyleMask::NSResizableWindowMask;
                }

                if is_minimizable {
                    style_mask |= NSWindowStyleMask::NSMiniaturizableWindowMask;
                }

                if titlebar.appears_transparent {
                    style_mask |= NSWindowStyleMask::NSFullSizeContentViewWindowMask;
                }
            } else {
                style_mask = NSWindowStyleMask::NSTitledWindowMask
                    | NSWindowStyleMask::NSFullSizeContentViewWindowMask;
            }

            let native_window: id = match kind {
                WindowKind::Normal => {
                    msg_send![WINDOW_CLASS, alloc]
                }
                // `AnchoredPopup` is rejected in `MacPlatform::open_window`, grouped here only
                // for exhaustiveness.
                WindowKind::PopUp | WindowKind::AnchoredPopup(_) => {
                    style_mask |= NSWindowStyleMaskNonactivatingPanel;
                    msg_send![PANEL_CLASS, alloc]
                }
                WindowKind::Floating | WindowKind::Dialog => {
                    msg_send![PANEL_CLASS, alloc]
                }
            };

            let display = display_id
                .and_then(MacDisplay::find_by_id)
                .unwrap_or_else(MacDisplay::primary);

            let mut target_screen = nil;
            let mut screen_frame = None;

            let screens = NSScreen::screens(nil);
            let count: u64 = cocoa::foundation::NSArray::count(screens);
            for i in 0..count {
                let screen = cocoa::foundation::NSArray::objectAtIndex(screens, i);
                let Some(display_id) = display_id_for_screen(screen) else {
                    continue;
                };
                let frame = NSScreen::frame(screen);
                if display_id == display.0 {
                    screen_frame = Some(frame);
                    target_screen = screen;
                }
            }

            let screen_frame = screen_frame.unwrap_or_else(|| {
                let screen = NSScreen::mainScreen(nil);
                target_screen = screen;
                NSScreen::frame(screen)
            });

            let window_rect = NSRect::new(
                NSPoint::new(
                    screen_frame.origin.x + bounds.origin.x.as_f32() as f64,
                    screen_frame.origin.y
                        + (display.bounds().size.height - bounds.origin.y).as_f32() as f64,
                ),
                NSSize::new(
                    bounds.size.width.as_f32() as f64,
                    bounds.size.height.as_f32() as f64,
                ),
            );

            let native_window = native_window.initWithContentRect_styleMask_backing_defer_screen_(
                window_rect,
                style_mask,
                NSBackingStoreBuffered,
                NO,
                target_screen,
            );
            assert!(!native_window.is_null());
            let () = msg_send![
                native_window,
                registerForDraggedTypes:
                    NSArray::arrayWithObject(nil, NSFilenamesPboardType)
            ];
            let () = msg_send![
                native_window,
                setReleasedWhenClosed: NO
            ];

            let content_view = native_window.contentView();
            let native_view: id = msg_send![VIEW_CLASS, alloc];
            let native_view = NSView::initWithFrame_(native_view, NSView::bounds(content_view));
            assert!(!native_view.is_null());

            let state = Arc::new(Mutex::new(MacWindowState {
                handle,
                foreground_executor,
                background_executor,
                native_window,
                native_view: NonNull::new_unchecked(native_view),
                overlay_view: None,
                overlay_input_active: Arc::new(AtomicBool::new(false)),
                blurred_view: None,
                glass_tint: None,
                glass_style: WindowGlassStyle::Regular,
                background_appearance: WindowBackgroundAppearance::Opaque,
                cursor_style: CursorStyle::Arrow,
                cursor_visible,
                frame_source: None,
                renderer: renderer::new_renderer(
                    renderer_context.clone(),
                    native_window as *mut _,
                    native_view as *mut _,
                    bounds.size.map(|pixels| pixels.as_f32()),
                    false,
                ),
                overlay_renderer: None,
                base_scene: gpui::Scene::default(),
                overlay_scene: gpui::Scene::default(),
                renderer_context,
                request_frame_callback: None,
                event_callback: None,
                activate_callback: None,
                visibility_callback: None,
                last_visibility: None,
                resize_callback: None,
                moved_callback: None,
                should_close_callback: None,
                close_callback: None,
                appearance_changed_callback: None,
                input_handler: None,
                last_key_equivalent: None,
                last_left_mouse_down_event: None,
                synthetic_drag_counter: 0,
                traffic_light_position: titlebar
                    .as_ref()
                    .and_then(|titlebar| titlebar.traffic_light_position),
                traffic_light_frames: None,
                pre_fullscreen_traffic_light_frames: None,
                transparent_titlebar: titlebar
                    .as_ref()
                    .is_none_or(|titlebar| titlebar.appears_transparent),
                previous_modifiers_changed_event: None,
                keystroke_for_do_command: None,
                do_command_handled: None,
                external_files_dragged: false,
                first_mouse: false,
                app_owns_titlebar_drag,
                fullscreen_restore_bounds: Bounds::default(),
                is_exiting_fullscreen: false,
                simple_fullscreen_state: None,
                move_tab_to_new_window_callback: None,
                merge_all_windows_callback: None,
                select_next_tab_callback: None,
                select_previous_tab_callback: None,
                toggle_tab_bar_callback: None,
                // Only these kinds are given the identifier below.
                native_tabbing: allows_automatic_window_tabbing
                    && matches!(kind, WindowKind::Normal | WindowKind::Floating),
                activated_least_once: false,
                closed: Arc::new(AtomicBool::new(false)),
                accesskit_adapter: None,
                sheet_parent: None,
                active_context_menu: None,
                context_menu_generation: 0,
            }));
            let mut window = Self(state, marker);

            (*native_window).set_ivar(
                WINDOW_STATE_IVAR,
                Arc::into_raw(window.0.clone()) as *const c_void,
            );
            native_window.setDelegate_(native_window);
            (*native_view).set_ivar(
                WINDOW_STATE_IVAR,
                Arc::into_raw(window.0.clone()) as *const c_void,
            );

            if let Some(title) = titlebar
                .as_ref()
                .and_then(|t| t.title.as_ref().map(AsRef::as_ref))
            {
                window.set_title(title);
            }

            native_window.setMovable_(is_movable as BOOL);

            if let Some(window_min_size) = window_min_size {
                native_window.setContentMinSize_(NSSize {
                    width: window_min_size.width.to_f64(),
                    height: window_min_size.height.to_f64(),
                });
            }

            if titlebar.is_none_or(|titlebar| titlebar.appears_transparent) {
                native_window.setTitlebarAppearsTransparent_(YES);
                native_window.setTitleVisibility_(NSWindowTitleVisibility::NSWindowTitleHidden);
            }

            native_view.setAutoresizingMask_(NSViewWidthSizable | NSViewHeightSizable);
            native_view.setWantsBestResolutionOpenGLSurface_(YES);

            // From winit crate: On Mojave, views automatically become layer-backed shortly after
            // being added to a native_window. Changing the layer-backedness of a view breaks the
            // association between the view and its associated OpenGL context. To work around this,
            // on we explicitly make the view layer-backed up front so that AppKit doesn't do it
            // itself and break the association with its context.
            native_view.setWantsLayer(YES);
            let _: () = msg_send![
            native_view,
            setLayerContentsRedrawPolicy: NSViewLayerContentsRedrawDuringViewResize
            ];

            content_view.addSubview_(native_view.autorelease());
            native_window.makeFirstResponder_(native_view);

            let app: id = NSApplication::sharedApplication(nil);
            let main_window: id = msg_send![app, mainWindow];
            let mut sheet_parent = None;

            // SAFETY: This is the live GPUIView (an NSView subclass) added to the
            // content view above, and window creation runs on the main thread.
            let tracking_view = &*native_view.cast::<Objc2NSView>();

            match kind {
                WindowKind::Normal | WindowKind::Floating => {
                    if kind == WindowKind::Floating {
                        // NSPanel defaults to hiding when the app deactivates. Clear that so
                        // floating windows stay visible above normal windows when focus moves to
                        // another app, matching the expected "always on top" behavior.
                        let _: () = msg_send![native_window, setFloatingPanel: YES];
                        let _: () = msg_send![native_window, setHidesOnDeactivate: NO];
                        // Let the window float keep above normal windows.
                        native_window.setLevel_(NSFloatingWindowLevel);
                        // "Always on top" has to hold across Spaces and over
                        // fullscreen apps too, or the panel is simply left
                        // behind on the Space it was opened on.
                        native_window.setCollectionBehavior_(
                            NSWindowCollectionBehavior::NSWindowCollectionBehaviorCanJoinAllSpaces
                                | NSWindowCollectionBehavior::NSWindowCollectionBehaviorFullScreenAuxiliary,
                        );
                        native_window.setAcceptsMouseMovedEvents_(YES);
                    } else {
                        native_window.setLevel_(NSNormalWindowLevel);
                        native_window.setAcceptsMouseMovedEvents_(NO);
                        add_mouse_tracking_area(tracking_view);
                    }

                    if let Some(tabbing_identifier) = tabbing_identifier {
                        let tabbing_id = ns_string(tabbing_identifier.as_str());
                        let _: () = msg_send![native_window, setTabbingIdentifier: tabbing_id];
                    } else {
                        let _: () = msg_send![native_window, setTabbingIdentifier:nil];
                    }
                }
                // `AnchoredPopup` is rejected in `MacPlatform::open_window`, grouped here only
                // for exhaustiveness.
                WindowKind::PopUp | WindowKind::AnchoredPopup(_) => {
                    add_mouse_tracking_area(tracking_view);

                    native_window.setLevel_(NSPopUpWindowLevel);
                    let _: () = msg_send![
                        native_window,
                        setAnimationBehavior: NSWindowAnimationBehaviorUtilityWindow
                    ];
                    native_window.setCollectionBehavior_(
                        NSWindowCollectionBehavior::NSWindowCollectionBehaviorCanJoinAllSpaces |
                        NSWindowCollectionBehavior::NSWindowCollectionBehaviorFullScreenAuxiliary
                    );
                }
                WindowKind::Dialog => {
                    if !main_window.is_null() {
                        let parent = {
                            let active_sheet: id = msg_send![main_window, attachedSheet];
                            if active_sheet.is_null() {
                                main_window
                            } else {
                                active_sheet
                            }
                        };
                        let _: () =
                            msg_send![parent, beginSheet: native_window completionHandler: nil];
                        sheet_parent = Some(parent);
                    }
                }
            }

            if allows_automatic_window_tabbing
                && !main_window.is_null()
                && main_window != native_window
            {
                let main_window_is_fullscreen = main_window
                    .styleMask()
                    .contains(NSWindowStyleMask::NSFullScreenWindowMask);
                let user_tabbing_preference = Self::get_user_tabbing_preference()
                    .unwrap_or(UserTabbingPreference::InFullScreen);
                let should_add_as_tab = user_tabbing_preference == UserTabbingPreference::Always
                    || user_tabbing_preference == UserTabbingPreference::InFullScreen
                        && main_window_is_fullscreen;

                if should_add_as_tab {
                    let main_window_can_tab: BOOL =
                        msg_send![main_window, respondsToSelector: sel!(addTabbedWindow:ordered:)];
                    let main_window_visible: BOOL = msg_send![main_window, isVisible];

                    if main_window_can_tab == YES && main_window_visible == YES {
                        let _: () = msg_send![main_window, addTabbedWindow: native_window ordered: NSWindowOrderingMode::NSWindowAbove];

                        // Ensure the window is visible immediately after adding the tab, since the tab bar is updated with a new entry at this point.
                        // Note: Calling orderFront here can break fullscreen mode (makes fullscreen windows exit fullscreen), so only do this if the main window is not fullscreen.
                        if !main_window_is_fullscreen {
                            let _: () = msg_send![native_window, orderFront: nil];
                        }
                    }
                }
            }

            if focus && show {
                native_window.makeKeyAndOrderFront_(nil);
            } else if show {
                native_window.orderFront_(nil);
            }

            // Set the initial position of the window to the specified origin.
            // Although we already specified the position using `initWithContentRect_styleMask_backing_defer_screen_`,
            // the window position might be incorrect if the main screen (the screen that contains the window that has focus)
            //  is different from the primary screen.
            NSWindow::setFrameTopLeftPoint_(native_window, window_rect.origin);
            {
                let mut window_state = window.0.lock();
                window_state.move_traffic_light();
                window_state.sheet_parent = sheet_parent;
            }

            pool.drain();

            window
        }
    }

    pub fn active_window() -> Option<AnyWindowHandle> {
        unsafe {
            let app = NSApplication::sharedApplication(nil);
            let main_window: id = msg_send![app, mainWindow];
            if main_window.is_null() {
                return None;
            }

            if msg_send![main_window, isKindOfClass: WINDOW_CLASS] {
                let handle = get_window_state(&*main_window).lock().handle;
                Some(handle)
            } else {
                None
            }
        }
    }

    pub fn ordered_windows() -> Vec<AnyWindowHandle> {
        unsafe {
            let app = NSApplication::sharedApplication(nil);
            let windows: id = msg_send![app, orderedWindows];
            let count: NSUInteger = msg_send![windows, count];

            let mut window_handles = Vec::new();
            for i in 0..count {
                let window: id = msg_send![windows, objectAtIndex:i];
                if msg_send![window, isKindOfClass: WINDOW_CLASS] {
                    let handle = get_window_state(&*window).lock().handle;
                    window_handles.push(handle);
                }
            }

            window_handles
        }
    }

    pub fn get_user_tabbing_preference() -> Option<UserTabbingPreference> {
        unsafe {
            let defaults: id = NSUserDefaults::standardUserDefaults();
            let domain = ns_string("NSGlobalDomain");
            let key = ns_string("AppleWindowTabbingMode");

            let dict: id = msg_send![defaults, persistentDomainForName: domain];
            let value: id = if !dict.is_null() {
                msg_send![dict, objectForKey: key]
            } else {
                nil
            };

            let value_str = if !value.is_null() {
                CStr::from_ptr(NSString::UTF8String(value)).to_string_lossy()
            } else {
                "".into()
            };

            match value_str.as_ref() {
                "manual" => Some(UserTabbingPreference::Never),
                "always" => Some(UserTabbingPreference::Always),
                _ => Some(UserTabbingPreference::InFullScreen),
            }
        }
    }
}

impl Drop for MacWindow {
    fn drop(&mut self) {
        let mut this = self.0.lock();
        // `accesskit_macos::SubclassingAdapter::for_window` strong-retains the
        // window's content view, and that content view keeps the `GPUIView` it
        // hosts alive. Together with the `Arc<Mutex<MacWindowState>>` parked in
        // both views' `windowState` ivar, that forms
        // `MacWindowState -> adapter -> content view -> GPUIView -> MacWindowState`,
        // a cycle the delegate/`frame_source` teardown below cannot break. Drop
        // the adapter here so the native view, its `CAMetalLayer` and the
        // renderer's command queue are actually released with the window.
        drop(this.accesskit_adapter.take());
        this.renderer.destroy();
        let window = this.native_window;
        let sheet_parent = this.sheet_parent.take();
        this.frame_source.take();
        unsafe {
            this.native_window.setDelegate_(nil);
        }
        this.input_handler.take();
        // A delivery task queued by `report_visibility` may still run after the
        // GPUI window is gone; without a callback it has nothing to notify.
        this.visibility_callback.take();
        // The accessibility adapter retains the window's content view, whose
        // GPUIView subview holds a raw `Arc` back to this state, so leaving
        // the adapter in place keeps the state — and with it the renderer,
        // its layer, drawables and atlas — alive after the window is gone.
        // Take it out here and release it once the window has closed. The
        // last mouse-down event and context menu are dropped the same way so
        // no other AppKit object retained by the state can close that loop.
        let accesskit_adapter = this.accesskit_adapter.take();
        let last_left_mouse_down_event = this.last_left_mouse_down_event.take();
        let active_context_menu = this.active_context_menu.take();
        this.foreground_executor
            .spawn(async move {
                unsafe {
                    if let Some(parent) = sheet_parent {
                        let _: () = msg_send![parent, endSheet: window];
                    }
                    window.close();
                    drop(accesskit_adapter);
                    drop(last_left_mouse_down_event);
                    drop(active_context_menu);
                    window.autorelease();
                }
            })
            .detach();
    }
}

/// Calls `f` if the window is not closed.
///
/// This should be used when spawning foreground tasks interacting with the
/// window, as some messages will end hard faulting if dispatched to no longer
/// valid window handles.
fn if_window_not_closed(closed: Arc<AtomicBool>, f: impl FnOnce()) {
    if !closed.load(Ordering::Acquire) {
        f();
    }
}

impl PlatformWindow for MacWindow {
    fn bounds(&self) -> Bounds<Pixels> {
        self.0.as_ref().lock().bounds()
    }

    fn window_bounds(&self) -> WindowBounds {
        self.0.as_ref().lock().window_bounds()
    }

    fn is_maximized(&self) -> bool {
        self.0.as_ref().lock().is_maximized()
    }

    fn content_size(&self) -> Size<Pixels> {
        self.0.as_ref().lock().content_size()
    }

    fn resize(&mut self, size: Size<Pixels>) {
        let this = self.0.lock();
        let window = this.native_window;
        let closed = this.closed.clone();
        this.foreground_executor
            .spawn(async move {
                if_window_not_closed(closed, || unsafe {
                    window.setContentSize_(NSSize {
                        width: size.width.as_f32() as f64,
                        height: size.height.as_f32() as f64,
                    });
                })
            })
            .detach();
    }

    fn merge_all_windows(&self) {
        let native_window = self.0.lock().native_window;
        extern "C" fn merge_windows_async(context: *mut std::ffi::c_void) {
            unsafe {
                let native_window = context as id;
                let _: () = msg_send![native_window, mergeAllWindows:nil];
            }
        }

        unsafe {
            DispatchQueue::main()
                .exec_async_f(native_window as *mut std::ffi::c_void, merge_windows_async);
        }
    }

    fn move_tab_to_new_window(&self) {
        let native_window = self.0.lock().native_window;
        extern "C" fn move_tab_async(context: *mut std::ffi::c_void) {
            unsafe {
                let native_window = context as id;
                let _: () = msg_send![native_window, moveTabToNewWindow:nil];
                let _: () = msg_send![native_window, makeKeyAndOrderFront: nil];
            }
        }

        unsafe {
            DispatchQueue::main()
                .exec_async_f(native_window as *mut std::ffi::c_void, move_tab_async);
        }
    }

    fn toggle_window_tab_overview(&self) {
        let native_window = self.0.lock().native_window;
        unsafe {
            let _: () = msg_send![native_window, toggleTabOverview:nil];
        }
    }

    fn set_tabbing_identifier(&self, tabbing_identifier: Option<String>) {
        let native_window = {
            let mut lock = self.0.lock();
            lock.native_tabbing = tabbing_identifier.is_some();
            lock.native_window
        };
        unsafe {
            let allows_automatic_window_tabbing = tabbing_identifier.is_some();
            if allows_automatic_window_tabbing {
                let () = msg_send![class!(NSWindow), setAllowsAutomaticWindowTabbing: YES];
            } else {
                let () = msg_send![class!(NSWindow), setAllowsAutomaticWindowTabbing: NO];
            }

            if let Some(tabbing_identifier) = tabbing_identifier {
                let tabbing_id = ns_string(tabbing_identifier.as_str());
                let _: () = msg_send![native_window, setTabbingIdentifier: tabbing_id];
            } else {
                let _: () = msg_send![native_window, setTabbingIdentifier:nil];
            }
        }
    }

    fn native_window_state(&self) -> Option<Vec<u8>> {
        let native_window = {
            let state = self.0.lock();
            if state.is_fullscreen() || state.simple_fullscreen_state.is_some() {
                return None;
            }
            state.native_window
        };
        // SAFETY: `native_window` is a live `NSWindow` retained by this window's state, and the
        // selectors below are AppKit/Foundation methods sent with their documented signatures. The
        // archived bytes are copied into an owned `Vec` before the objects we allocated are
        // released, so no pointer into Objective-C memory escapes this block.
        unsafe {
            let archiver: id = msg_send![class!(NSKeyedArchiver), alloc];
            let archiver: id = msg_send![archiver, initRequiringSecureCoding: YES];
            if archiver.is_null() {
                log::warn!("failed to create an archiver for the native window state");
                return None;
            }
            let delegate: id = msg_send![WINDOW_STATE_ARCHIVER_DELEGATE_CLASS, new];
            let _: () = msg_send![archiver, setDelegate: delegate];
            let _: () = msg_send![native_window, encodeRestorableStateWithCoder: archiver];
            let _: () = msg_send![archiver, finishEncoding];
            // The archiver holds a weak reference to its delegate; clear it before the delegate
            // is released below.
            let _: () = msg_send![archiver, setDelegate: nil];

            let data: id = msg_send![archiver, encodedData];
            let bytes = if data.is_null() {
                ptr::null()
            } else {
                data.bytes() as *const u8
            };
            let state = if bytes.is_null() {
                log::warn!("the archiver produced no data for the native window state");
                None
            } else {
                Some(std::slice::from_raw_parts(bytes, data.length() as usize).to_vec())
            };

            let _: () = msg_send![delegate, release];
            let _: () = msg_send![archiver, release];
            state
        }
    }

    fn restore_native_window_state(&self, state: &[u8]) {
        if state.is_empty() {
            return;
        }
        let native_window = self.0.lock().native_window;
        // SAFETY: `native_window` is a live `NSWindow` retained by this window's state. The NSData,
        // NSKeyedUnarchiver and `restoreStateWithCoder:` selectors are sent with their documented
        // signatures, and the `NSData` only borrows `state` for the duration of this synchronous
        // call (it is consumed before `state` could be freed).
        unsafe {
            let data = NSData::dataWithBytes_length_(
                nil,
                state.as_ptr() as *const c_void,
                state.len() as u64,
            );
            if data.is_null() {
                log::warn!(
                    "failed to wrap {} bytes of native window state",
                    state.len()
                );
                return;
            }

            // On macOS < 15 the `NSWindowRestoresWorkspaceAtLaunch` user default controls whether
            // the window is restored to its original Space. On macOS 15+ that default is broken
            // (FB15644170), and the `_windowRestorationOptions` override on our unarchiver subclass
            // handles it instead.
            if !is_macos_version_at_least(NSOperatingSystemVersion::new(15, 0, 0)) {
                RESTORES_WORKSPACE_AT_LAUNCH_DEFAULT.call_once(|| {
                    let defaults: id = NSUserDefaults::standardUserDefaults();
                    let key = ns_string("NSWindowRestoresWorkspaceAtLaunch");
                    let yes_value: id = msg_send![class!(NSNumber), numberWithBool: YES];
                    let dict: id = msg_send![
                        class!(NSDictionary),
                        dictionaryWithObject: yes_value
                        forKey: key
                    ];
                    let _: () = msg_send![defaults, registerDefaults: dict];
                });
            }

            let unarchiver: id = msg_send![WINDOW_STATE_UNARCHIVER_CLASS, alloc];
            let mut error: id = nil;
            let unarchiver: id =
                msg_send![unarchiver, initForReadingFromData: data error: &mut error];
            if unarchiver.is_null() {
                log::warn!(
                    "failed to unarchive the native window state: {}",
                    ns_error_description(error)
                );
                return;
            }
            let _: () = msg_send![native_window, restoreStateWithCoder: unarchiver];
            let error: id = msg_send![unarchiver, error];
            if !error.is_null() {
                log::warn!(
                    "failed to restore the native window state: {}",
                    ns_error_description(error)
                );
            }
            let _: () = msg_send![unarchiver, release];
        }
    }

    fn set_traffic_light_position(&self, position: Point<Pixels>) {
        let mut state = self.0.lock();
        state.traffic_light_position = Some(position);
        state.move_traffic_light();
    }

    fn scale_factor(&self) -> f32 {
        self.0.as_ref().lock().scale_factor()
    }

    fn appearance(&self) -> WindowAppearance {
        unsafe {
            let appearance: id = msg_send![self.0.lock().native_window, effectiveAppearance];
            crate::window_appearance::window_appearance_from_native(appearance)
        }
    }

    fn set_appearance_override(&self, appearance: Option<WindowAppearance>) {
        // `setAppearance:` synchronously notifies effective-appearance
        // observers (`view_did_change_effective_appearance`), which take this
        // window's state lock — holding it across the call deadlocks the main
        // thread on the first application.
        let native_window = self.0.lock().native_window;
        unsafe {
            let native_appearance: id = match appearance {
                Some(appearance) => {
                    crate::window_appearance::window_appearance_to_native(appearance)
                }
                None => nil,
            };
            let _: () = msg_send![native_window, setAppearance: native_appearance];
        }
    }

    fn display(&self) -> Option<Rc<dyn PlatformDisplay>> {
        unsafe {
            let screen = self.0.lock().native_window.screen();
            if screen.is_null() {
                return None;
            }
            let device_description: id = msg_send![screen, deviceDescription];
            let screen_number: id =
                NSDictionary::valueForKey_(device_description, ns_string("NSScreenNumber"));

            let screen_number: u32 = msg_send![screen_number, unsignedIntValue];

            Some(Rc::new(MacDisplay(screen_number)))
        }
    }

    fn mouse_position(&self) -> Point<Pixels> {
        let position = unsafe {
            self.0
                .lock()
                .native_window
                .mouseLocationOutsideOfEventStream()
        };
        convert_mouse_position(position, self.content_size().height)
    }

    fn modifiers(&self) -> Modifiers {
        unsafe {
            let modifiers: NSEventModifierFlags = msg_send![class!(NSEvent), modifierFlags];

            let control = modifiers.contains(NSEventModifierFlags::NSControlKeyMask);
            let alt = modifiers.contains(NSEventModifierFlags::NSAlternateKeyMask);
            let shift = modifiers.contains(NSEventModifierFlags::NSShiftKeyMask);
            let command = modifiers.contains(NSEventModifierFlags::NSCommandKeyMask);
            let function = modifiers.contains(NSEventModifierFlags::NSFunctionKeyMask);

            Modifiers {
                control,
                alt,
                shift,
                platform: command,
                function,
            }
        }
    }

    fn capslock(&self) -> Capslock {
        unsafe {
            let modifiers: NSEventModifierFlags = msg_send![class!(NSEvent), modifierFlags];

            Capslock {
                on: modifiers.contains(NSEventModifierFlags::NSAlphaShiftKeyMask),
            }
        }
    }

    fn set_input_handler(&mut self, input_handler: PlatformInputHandler) {
        self.0.as_ref().lock().input_handler = Some(input_handler);
    }

    fn take_input_handler(&mut self) -> Option<PlatformInputHandler> {
        self.0.as_ref().lock().input_handler.take()
    }

    fn prompt(
        &self,
        level: PromptLevel,
        msg: &str,
        detail: Option<&str>,
        answers: &[PromptButton],
    ) -> Option<oneshot::Receiver<usize>> {
        use objc2_foundation::{NSInteger, NSString};

        // NSAlert's first button keeps Return and Cancel keeps Escape, but the keyboard
        // focus (and therefore Space) defaults to Cancel, leaving the middle button of
        // prompts like "Save / Don't Save / Cancel" unreachable from the keyboard. Move
        // the initial focus onto the last non-cancel, non-default button instead.
        let initial_focus_ix = answers
            .iter()
            .enumerate()
            .rev()
            .find(|(_, label)| !label.is_cancel())
            .map(|(ix, _)| ix)
            .filter(|&ix| ix > 0);

        let alert = NSAlert::new(self.1);
        alert.setAlertStyle(match level {
            PromptLevel::Critical => NSAlertStyle::Critical,
            PromptLevel::Warning => NSAlertStyle::Warning,
            PromptLevel::Info => NSAlertStyle::Informational,
        });
        let message = NSString::from_str(msg);
        alert.setMessageText(message.as_ref());

        if let Some(detail) = detail {
            let detail_text = NSString::from_str(detail);
            alert.setInformativeText(detail_text.as_ref());
        }

        let mut initial_focus_button: Option<Retained<Objc2NSButton>> = None;
        for (ix, answer) in answers.iter().enumerate() {
            let title = NSString::from_str(answer.label());
            let button = alert.addButtonWithTitle(&title);
            button.setTag(ix as NSInteger);

            if answer.is_cancel() {
                if let Some(key) = core::char::from_u32(crate::events::ESCAPE_KEY as u32) {
                    let key = NSString::from_str(&key.to_string());
                    button.setKeyEquivalent(&key);
                }
            } else if Some(ix) == initial_focus_ix {
                initial_focus_button = Some(button);
            }
        }

        if let Some(button) = initial_focus_button {
            alert.window().setInitialFirstResponder(Some(&button));
        }

        let (done_tx, done_rx) = oneshot::channel();
        let done_tx = Cell::new(Some(done_tx));

        let block = RcBlock::new(move |answer: NSInteger| {
            if let Some(done_tx) = done_tx.take() {
                let _ = done_tx.send(answer.try_into().unwrap());
            }
        });

        let lock = self.0.lock();
        let native_window = lock.native_window;
        let closed = lock.closed.clone();
        let executor = lock.foreground_executor.clone();
        executor
            .spawn(async move {
                if !closed.load(Ordering::Acquire) {
                    // SAFETY: `native_window` is an Objective-C `NSWindow` pointer
                    // owned by the platform window; bridge it into objc2.
                    let sheet_window: &Objc2NSWindow =
                        unsafe { &*(native_window as *const Objc2NSWindow) };

                    alert.beginSheetModalForWindow_completionHandler(sheet_window, Some(&block));
                }
            })
            .detach();

        Some(done_rx)
    }

    fn activate(&self) {
        let lock = self.0.lock();
        let window = lock.native_window;
        let closed = lock.closed.clone();
        let executor = lock.foreground_executor.clone();
        executor
            .spawn(async move {
                if !closed.load(Ordering::Acquire) {
                    unsafe {
                        let _: () = msg_send![window, makeKeyAndOrderFront: nil];
                    }
                }
            })
            .detach();
    }

    fn request_attention(&self) {
        if self.is_active() {
            return;
        }

        let executor = self.0.lock().foreground_executor.clone();
        executor
            .spawn(async move {
                unsafe {
                    let app = NSApplication::sharedApplication(nil);
                    app.requestUserAttention_(NSRequestUserAttentionType::NSInformationalRequest);
                }
            })
            .detach();
    }

    fn is_active(&self) -> bool {
        unsafe { self.0.lock().native_window.isKeyWindow() == YES }
    }

    fn visibility(&self) -> WindowVisibility {
        visibility(&self.0.lock())
    }

    // is_hovered is unused on macOS. See Window::is_window_hovered.
    fn is_hovered(&self) -> bool {
        false
    }

    fn set_title(&mut self, title: &str) {
        unsafe {
            let app = NSApplication::sharedApplication(nil);
            let window = self.0.lock().native_window;
            let title = ns_string(title);
            let _: () = msg_send![app, changeWindowsItem:window title:title filename:false];
            let _: () = msg_send![window, setTitle: title];
            self.0.lock().move_traffic_light();
        }
    }

    fn get_title(&self) -> String {
        unsafe {
            let title: id = msg_send![self.0.lock().native_window, title];
            if title.is_null() {
                "".to_string()
            } else {
                title.to_str().to_string()
            }
        }
    }

    fn set_app_id(&mut self, _app_id: &str) {}

    fn set_background_appearance(&self, background_appearance: WindowBackgroundAppearance) {
        let mut this = self.0.as_ref().lock();
        let appearance_changed = this.background_appearance != background_appearance;
        this.background_appearance = background_appearance;

        // `MicaBackdrop` on macOS is a Finder-style backdrop: the WINDOW
        // stays opaque to the window server — whole-window compositing
        // (shadow, color handling) matches a normal opaque window exactly —
        // while the Metal layer goes transparent, so translucent regions
        // reveal a behind-window `NSVisualEffectView` beneath it (its
        // behind-window sampling works in opaque windows). `Blurred` keeps
        // the fully non-opaque window with the Liquid Glass material.
        let opaque_window = matches!(
            background_appearance,
            WindowBackgroundAppearance::Opaque
                | WindowBackgroundAppearance::MicaBackdrop
                | WindowBackgroundAppearance::MicaAltBackdrop
        );
        let transparent_layer = background_appearance != WindowBackgroundAppearance::Opaque;
        this.renderer.update_transparency(transparent_layer);

        unsafe {
            this.native_window.setOpaque_(opaque_window as BOOL);
            let background_color = if background_appearance == WindowBackgroundAppearance::Opaque
            {
                NSColor::colorWithSRGBRed_green_blue_alpha_(nil, 0f64, 0f64, 0f64, 1f64)
            } else if opaque_window {
                // Behind the backdrop view; an opaque window needs an opaque
                // fallback fill.
                msg_send![class!(NSColor), windowBackgroundColor]
            } else {
                // Not using `+[NSColor clearColor]` to avoid broken shadow.
                NSColor::colorWithSRGBRed_green_blue_alpha_(nil, 0f64, 0f64, 0f64, 0.0001)
            };
            this.native_window.setBackgroundColor_(background_color);

            let wants_backdrop_view = matches!(
                background_appearance,
                WindowBackgroundAppearance::Blurred
                    | WindowBackgroundAppearance::MicaBackdrop
                    | WindowBackgroundAppearance::MicaAltBackdrop
            );
            // Recreate on appearance changes so Blurred ↔ Mica switches
            // swap the backing view class (glass vs visual-effect).
            if appearance_changed || !wants_backdrop_view {
                if let Some(blur_view) = this.blurred_view {
                    NSView::removeFromSuperview(blur_view);
                    this.blurred_view = None;
                }
            }
            if wants_backdrop_view && this.blurred_view.is_none() {
                let content_view = this.native_window.contentView();
                let frame = NSView::bounds(content_view);
                // On macOS 26+ use the native Liquid Glass material
                // (`NSGlassEffectView`), which refracts the window's
                // backdrop with edge lensing and highlights instead of the
                // plain frosted blur of `NSVisualEffectView`. Fall back to
                // the blurred view when the class isn't available, and use
                // it always for the opaque-window Mica modes (the glass
                // view needs a non-opaque window to sample the desktop).
                let glass_class = if background_appearance == WindowBackgroundAppearance::Blurred {
                    Class::get("NSGlassEffectView")
                } else {
                    None
                };
                let blur_view: id = if let Some(glass_class) = glass_class {
                    let view: id = msg_send![glass_class, alloc];
                    NSView::initWithFrame_(view, frame)
                } else if opaque_window {
                    // Mica: a plain, natively-configured visual effect
                    // view with the real sidebar material. BlurredView's
                    // Selection material + stripped backdrop layers are
                    // tuned for the colorless non-opaque blur; what
                    // remains of them in an opaque window renders as a
                    // glowing wash instead of glass.
                    let view: id = msg_send![class!(NSVisualEffectView), alloc];
                    let view: id = NSView::initWithFrame_(view, frame);
                    NSVisualEffectView::setMaterial_(view, NSVisualEffectMaterial::Sidebar);
                    NSVisualEffectView::setState_(
                        view,
                        NSVisualEffectState::FollowsWindowActiveState,
                    );
                    view
                } else {
                    let view: id = msg_send![BLURRED_VIEW_CLASS, alloc];
                    NSView::initWithFrame_(view, frame)
                };
                blur_view.setAutoresizingMask_(NSViewWidthSizable | NSViewHeightSizable);
                apply_glass_style(blur_view, this.glass_style);
                apply_glass_tint(blur_view, this.glass_tint);

                let _: () = msg_send![
                    content_view,
                    addSubview: blur_view
                    positioned: NSWindowOrderingMode::NSWindowBelow
                    relativeTo: nil
                ];
                // Start in the state the key-status observer keeps it in
                // afterwards; a blur created for an inactive window otherwise
                // shows until the next key change. Only the blurred mode: the
                // observer hides that one alone, and a Mica backdrop follows
                // the window's active state through its own material state.
                if background_appearance == WindowBackgroundAppearance::Blurred {
                    let is_key = this.native_window.isKeyWindow() == YES;
                    let _: () = msg_send![blur_view, setHidden: (!is_key) as BOOL];
                }
                this.blurred_view = Some(blur_view.autorelease());
            }
        }
    }

    fn background_appearance(&self) -> WindowBackgroundAppearance {
        self.0.as_ref().lock().background_appearance
    }

    fn set_background_glass_tint(&self, tint: Option<Rgba>) {
        let blurred_view = {
            let mut this = self.0.as_ref().lock();
            this.glass_tint = tint;
            this.blurred_view
        };
        if let Some(blurred_view) = blurred_view {
            unsafe { apply_glass_tint(blurred_view, tint) };
        }
    }

    fn set_background_glass_style(&self, style: WindowGlassStyle) {
        let blurred_view = {
            let mut this = self.0.as_ref().lock();
            this.glass_style = style;
            this.blurred_view
        };
        if let Some(blurred_view) = blurred_view {
            unsafe { apply_glass_style(blurred_view, style) };
        }
    }

    fn is_subpixel_rendering_supported(&self) -> bool {
        false
    }

    fn set_edited(&mut self, edited: bool) {
        unsafe {
            let window = self.0.lock().native_window;
            msg_send![window, setDocumentEdited: edited as BOOL]
        }

        // Changing the document edited state resets the traffic light position,
        // so we have to move it again.
        self.0.lock().move_traffic_light();
    }

    fn set_document_path(&self, path: Option<&std::path::Path>) {
        unsafe {
            let window = self.0.lock().native_window;
            let filename = path.map_or(ns_string(""), |p| ns_string(&p.to_string_lossy()));
            let _: () = msg_send![window, setRepresentedFilename: filename];
        }

        // Changing the document path state resets the traffic light position,
        // so we have to move it again.
        self.0.lock().move_traffic_light();
    }

    fn show_character_palette(&self) {
        let this = self.0.lock();
        let window = this.native_window;
        this.foreground_executor
            .spawn(async move {
                unsafe {
                    let app = NSApplication::sharedApplication(nil);
                    let _: () = msg_send![app, orderFrontCharacterPalette: window];
                }
            })
            .detach();
    }

    fn can_show_native_context_menu(&self) -> bool {
        unsafe { !CONTEXT_MENU_TARGET_CLASS.is_null() }
    }

    fn show_native_context_menu(
        &self,
        menu: Vec<NativeMenuItem>,
        position: Point<Pixels>,
        keymap: &Keymap,
        on_select: Box<dyn FnOnce(Option<usize>)>,
    ) {
        let target_class = unsafe { CONTEXT_MENU_TARGET_CLASS };
        if target_class.is_null() {
            on_select(None);
            return;
        }
        let this = self.0.clone();
        let mut lock = self.0.lock();
        let native_view = lock.native_view.as_ptr();
        let content_height = lock.content_size().height;
        let executor = lock.foreground_executor.clone();

        unsafe {
            let selection = Box::into_raw(Box::new(Cell::new(-1isize)));
            let target: id = msg_send![target_class, alloc];
            let target: id = msg_send![target, init];
            (*target).set_ivar(CONTEXT_MENU_SELECTION_IVAR, selection as *mut c_void);

            let mut next_tag: NSInteger = 0;
            let ns_menu = create_native_context_menu(&menu, target, keymap, &mut next_tag);
            lock.context_menu_generation += 1;
            let generation = lock.context_menu_generation;
            // Deliberately an `Arc` of a non-`Send` type: see the struct's
            // doc — the count must be atomic because `MacWindowState` is
            // `Send`, while every AppKit call in the teardown hops to the
            // main thread itself.
            #[allow(clippy::arc_with_non_send_sync)]
            let invocation = Arc::new(ActiveContextMenu {
                generation,
                menu: ns_menu,
                target,
                selection,
            });
            // Replaces the previous invocation's slot. If that invocation is
            // still in flight its popup/report task holds the other reference,
            // so nothing is freed under it; once both are gone the menu closed
            // long ago and anything it could still be sent has been delivered.
            lock.active_context_menu = Some(Arc::clone(&invocation));
            drop(lock);

            let native_view: id = msg_send![native_view, retain];

            let ns_position = NSPoint::new(
                f64::from(position.x),
                f64::from(content_height - position.y),
            );
            // Popping up the menu runs a nested, modal event loop, so it must not
            // happen while a state lock is held or from inside the current event's
            // dispatch — defer it to the executor.
            let inner_executor = executor.clone();
            executor
                .spawn(async move {
                    // A later invocation queued before this one ran has already
                    // replaced it as the window's current menu; presenting a
                    // stale menu on top of (or instead of) the newer one would
                    // be wrong, so skip the popup and report a dismissal. Once
                    // the check passes no input event can supersede this
                    // invocation before the popup returns: the check and the
                    // popup share the main thread, and the tracking session
                    // consumes input. The popup's nested run loop does still
                    // service timers and other run-loop sources, so one of
                    // those can replace the window's slot mid-popup; that is
                    // harmless because this task owns its own reference to the
                    // invocation and reports through it, not through the slot.
                    let superseded = {
                        let state = this.lock();
                        state
                            .active_context_menu
                            .as_ref()
                            .map(|active| active.generation)
                            != Some(generation)
                    };
                    if superseded {
                        on_select(None);
                        let _: () = msg_send![native_view, release];
                        return;
                    }
                    let _: BOOL = msg_send![
                        invocation.menu,
                        popUpMenuPositioningItem: nil
                        atLocation: ns_position
                        inView: native_view
                    ];
                    // The chosen item's action message can be delivered through
                    // the main run loop after the tracking session ends, so read
                    // the selection on the next tick, not immediately. The task
                    // owns its invocation, so the read hits this menu's own
                    // still-live cell even if a newer menu has replaced it in
                    // the window state, and a completed selection is never
                    // converted into a dismissal by that replacement.
                    inner_executor
                        .spawn(async move {
                            let picked = (*invocation.selection).get();
                            on_select((picked >= 0).then_some(picked as usize));
                            let _: () = msg_send![native_view, release];
                        })
                        .detach();
                })
                .detach();
        }
    }

    fn minimize(&self) {
        let window = self.0.lock().native_window;
        unsafe {
            window.miniaturize_(nil);
        }
    }

    fn zoom(&self) {
        let this = self.0.lock();
        let window = this.native_window;
        let closed = this.closed.clone();
        this.foreground_executor
            .spawn(async move {
                if_window_not_closed(closed, || unsafe {
                    window.zoom_(nil);
                })
            })
            .detach();
    }

    fn toggle_fullscreen(&self) {
        let this = self.0.lock();
        let window = this.native_window;
        let closed = this.closed.clone();
        this.foreground_executor
            .spawn(async move {
                if_window_not_closed(closed, || unsafe {
                    window.toggleFullScreen_(nil);
                })
            })
            .detach();
    }

    fn toggle_simple_fullscreen(&self) {
        let state = self.0.clone();
        let (foreground_executor, closed) = {
            let this = self.0.lock();
            (this.foreground_executor.clone(), this.closed.clone())
        };
        foreground_executor
            .spawn(async move {
                if_window_not_closed(closed, move || {
                    let (native_window, native_view, plan) = {
                        let mut lock = state.lock();
                        (
                            lock.native_window,
                            lock.native_view.as_ptr() as id,
                            lock.toggle_simple_fullscreen(),
                        )
                    };
                    if let Some(plan) = plan {
                        unsafe { apply_simple_fullscreen_plan(native_window, native_view, plan) };
                    }
                })
            })
            .detach();
    }

    fn is_simple_fullscreen(&self) -> bool {
        self.0.lock().simple_fullscreen_state.is_some()
    }

    fn is_fullscreen(&self) -> bool {
        let this = self.0.lock();
        let window = this.native_window;

        unsafe {
            window
                .styleMask()
                .contains(NSWindowStyleMask::NSFullScreenWindowMask)
        }
    }

    fn on_request_frame(&self, callback: Box<dyn FnMut(RequestFrameOptions)>) {
        self.0.as_ref().lock().request_frame_callback = Some(callback);
    }

    fn on_input(&self, callback: Box<dyn FnMut(PlatformInput) -> gpui::DispatchEventResult>) {
        self.0.as_ref().lock().event_callback = Some(callback);
    }

    fn on_active_status_change(&self, callback: Box<dyn FnMut(bool)>) {
        self.0.as_ref().lock().activate_callback = Some(callback);
    }

    fn on_visibility_change(&self, callback: Box<dyn FnMut(WindowVisibility)>) {
        let mut state = self.0.lock();
        state.last_visibility = Some(visibility(&state));
        state.visibility_callback = Some(callback);
    }

    fn on_hover_status_change(&self, _: Box<dyn FnMut(bool)>) {}

    fn on_resize(&self, callback: Box<dyn FnMut(Size<Pixels>, f32)>) {
        self.0.as_ref().lock().resize_callback = Some(callback);
    }

    fn on_moved(&self, callback: Box<dyn FnMut()>) {
        self.0.as_ref().lock().moved_callback = Some(callback);
    }

    fn on_should_close(&self, callback: Box<dyn FnMut() -> bool>) {
        self.0.as_ref().lock().should_close_callback = Some(callback);
    }

    fn on_close(&self, callback: Box<dyn FnOnce()>) {
        self.0.as_ref().lock().close_callback = Some(callback);
    }

    fn on_hit_test_window_control(&self, _callback: Box<dyn FnMut() -> Option<WindowControlArea>>) {
    }

    fn on_appearance_changed(&self, callback: Box<dyn FnMut()>) {
        self.0.lock().appearance_changed_callback = Some(callback);
    }

    fn tabbed_windows(&self) -> Option<Vec<SystemWindowTab>> {
        unsafe {
            let windows: id = msg_send![self.0.lock().native_window, tabbedWindows];
            if windows.is_null() {
                return None;
            }

            let count: NSUInteger = msg_send![windows, count];
            let mut result = Vec::new();
            for i in 0..count {
                let window: id = msg_send![windows, objectAtIndex:i];
                if msg_send![window, isKindOfClass: WINDOW_CLASS] {
                    let handle = get_window_state(&*window).lock().handle;
                    let title: id = msg_send![window, title];
                    let title = SharedString::from(title.to_str().to_string());

                    result.push(SystemWindowTab::new(title, handle));
                }
            }

            Some(result)
        }
    }

    fn tab_bar_visible(&self) -> bool {
        unsafe {
            let tab_group: id = msg_send![self.0.lock().native_window, tabGroup];
            if tab_group.is_null() {
                false
            } else {
                let tab_bar_visible: BOOL = msg_send![tab_group, isTabBarVisible];
                tab_bar_visible == YES
            }
        }
    }

    fn on_move_tab_to_new_window(&self, callback: Box<dyn FnMut()>) {
        self.0.as_ref().lock().move_tab_to_new_window_callback = Some(callback);
    }

    fn on_merge_all_windows(&self, callback: Box<dyn FnMut()>) {
        self.0.as_ref().lock().merge_all_windows_callback = Some(callback);
    }

    fn on_select_next_tab(&self, callback: Box<dyn FnMut()>) {
        self.0.as_ref().lock().select_next_tab_callback = Some(callback);
    }

    fn on_select_previous_tab(&self, callback: Box<dyn FnMut()>) {
        self.0.as_ref().lock().select_previous_tab_callback = Some(callback);
    }

    fn on_toggle_tab_bar(&self, callback: Box<dyn FnMut()>) {
        self.0.as_ref().lock().toggle_tab_bar_callback = Some(callback);
    }

    fn draw(&self, scene: &gpui::Scene) {
        let mut this = self.0.lock();
        this.renderer.draw(scene);
        this.release_intermediates_if_occluded();
    }

    fn draw_layered(&self, scene: &gpui::Scene, overlay_start: usize) -> PresentReport {
        let mut this = self.0.lock();
        if this.overlay_renderer.is_none() {
            // Every present comes through here (gpui core never calls `draw`),
            // so the occluded-window release has to happen on this branch too
            // or a window without an overlay keeps the intermediates a stray
            // draw rebuilt while it was hidden.
            let report = this.renderer.draw(scene);
            this.release_intermediates_if_occluded();
            return report;
        }

        // Both planes must have capacity before either is presented. Once
        // drawing starts, only completion callbacks can change these counts,
        // and they only return capacity.
        if let Some(outcome) = this.renderer.submission_queue_full_outcome()
            .or_else(|| this.overlay_renderer.as_mut()
                .and_then(|renderer| renderer.submission_queue_full_outcome()))
        {
            this.release_intermediates_if_occluded();
            return PresentReport {
                outcome,
                breakdown: gpui::PresentBreakdown {
                    layers: 2,
                    ..Default::default()
                },
            };
        }
        let this = &mut *this;
        let split_start = Instant::now();
        let split = overlay_start.min(scene.len());
        // The two halves are kept across presents so their vectors hold
        // their capacity, instead of being allocated and freed per frame for
        // as long as the overlay exists.
        this.base_scene.clear();
        this.base_scene.replay(0..split, scene);
        this.base_scene.finish();

        this.overlay_scene.clear();
        this.overlay_scene.replay(split..scene.len(), scene);
        this.overlay_scene.finish();

        this.renderer.note_scene_tiles(&this.overlay_scene);
        let split_duration = split_start.elapsed();
        let mut report = this.renderer.draw(&this.base_scene);
        report.breakdown.encode += split_duration;
        if report.outcome != PresentOutcome::Presented {
            // Presenting the overlay over a base that did not land would put
            // the two planes on different frames. A deferred base is retried
            // and the retry presents both; a dropped one leaves both on the
            // frame before, as a window without an overlay is left. Input
            // keeps following the overlay that is still on screen.
            this.release_intermediates_if_occluded();
            return report;
        }
        this.overlay_input_active
            .store(!this.overlay_scene.is_empty(), Ordering::Release);
        // The overlay draws with the base renderer's drawable-sized
        // intermediates rather than a second set of its own.
        let intermediates = this.renderer.take_intermediates();
        let overlay_renderer = this
            .overlay_renderer
            .as_mut()
            .expect("overlay renderer checked above");
        overlay_renderer.lend_intermediates(intermediates);
        let overlay_report = overlay_renderer.draw(&this.overlay_scene);
        let intermediates = overlay_renderer.take_intermediates();
        this.renderer.lend_intermediates(intermediates);
        this.release_intermediates_if_occluded();

        report.breakdown.accumulate(overlay_report.breakdown);
        // The base layer holds the window's content, so the present's
        // outcome is the base's. An overlay layer whose drawable size is
        // still zero drops every frame, and reporting that as the frame's
        // outcome would count every frame as lost while the content was
        // reaching the screen. An overlay that defers after the base landed
        // is not retried: its plane keeps the previous frame until the window
        // next presents. It cannot defer while its layer waits for drawables
        // rather than timing out.
        report.breakdown.overlay_outcome = Some(overlay_report.outcome);
        report
    }

    fn enable_scene_overlay(&self) -> anyhow::Result<()> {
        let window_state = self.0.clone();
        let mut this = self.0.lock();
        if this.overlay_renderer.is_some() {
            // A native child view created after the overlay (e.g. a lazily
            // built WKWebView) lands above it in AppKit's subview order.
            // Re-adding the overlay on repeat calls restores it to the top.
            if let Some(overlay_view) = this.overlay_view {
                unsafe {
                    let native_view = this.native_view.as_ptr() as id;
                    let overlay_view = overlay_view.as_ptr() as id;
                    let _: id = msg_send![overlay_view, retain];
                    NSView::removeFromSuperview(overlay_view);
                    native_view.addSubview_(overlay_view);
                    let _: () = msg_send![overlay_view, release];
                }
            }
            return Ok(());
        }

        unsafe {
            let native_view = this.native_view.as_ptr() as id;
            let frame = NSView::bounds(native_view);
            let overlay_view: id = msg_send![OVERLAY_VIEW_CLASS, alloc];
            let overlay_view = NSView::initWithFrame_(overlay_view, frame);
            anyhow::ensure!(
                !overlay_view.is_null(),
                "failed to create GPUI overlay NSView"
            );
            (*overlay_view).set_ivar(
                WINDOW_STATE_IVAR,
                Arc::into_raw(window_state) as *const c_void,
            );
            (*overlay_view).set_ivar(
                OVERLAY_INPUT_IVAR,
                Arc::into_raw(this.overlay_input_active.clone()) as *const c_void,
            );

            let mut overlay_renderer =
                renderer::new_overlay_renderer(this.renderer_context.clone(), &this.renderer);
            let scale_factor = this.scale_factor();
            overlay_renderer
                .update_drawable_size(this.content_size().to_device_pixels(scale_factor));
            if let Some(layer) = overlay_renderer.layer() {
                let _: () = msg_send![layer, setContentsScale: scale_factor as f64];
            }

            overlay_view.setAutoresizingMask_(NSViewWidthSizable | NSViewHeightSizable);
            overlay_view.setWantsLayer(YES);
            let _: () = msg_send![overlay_view, setLayer: overlay_renderer.layer_ptr()];
            let _: () = msg_send![
                overlay_view,
                setLayerContentsRedrawPolicy: NSViewLayerContentsRedrawDuringViewResize
            ];

            // wry has already inserted WKWebView by the time this API is called.
            // Adding the overlay last places it above the WebView in AppKit's
            // back-to-front subview order.
            native_view.addSubview_(overlay_view.autorelease());
            this.overlay_view = NonNull::new(overlay_view);
            this.overlay_renderer = Some(overlay_renderer);
        }

        Ok(())
    }

    fn disable_scene_overlay(&self) {
        let mut this = self.0.lock();
        let Some(overlay_view) = this.overlay_view.take() else {
            return;
        };
        // The overlay must stop claiming input before the view goes: a hit
        // test racing the removal would otherwise route a click into a view
        // that is being torn down.
        this.overlay_input_active.store(false, Ordering::Release);
        // The superview held the only strong reference (the view was added
        // autoreleased), so removing it deallocates the view, which drops the
        // window-state and input-flag references its ivars carried.
        unsafe {
            NSView::removeFromSuperview(overlay_view.as_ptr() as id);
        }
        // Dropping the renderer releases the overlay's CAMetalLayer and its
        // drawables. Its borrowed intermediates were handed back to the base
        // renderer at the end of the last layered draw, so nothing is lost.
        this.overlay_renderer = None;
    }

    fn sprite_atlas(&self) -> Arc<dyn PlatformAtlas> {
        self.0.lock().renderer.sprite_atlas().clone()
    }

    fn gpu_specs(&self) -> Option<gpui::GpuSpecs> {
        None
    }

    fn update_ime_position(&self, _bounds: Bounds<Pixels>) {
        let executor = self.0.lock().foreground_executor.clone();
        executor
            .spawn(async move {
                unsafe {
                    let input_context: id =
                        msg_send![class!(NSTextInputContext), currentInputContext];
                    if input_context.is_null() {
                        return;
                    }
                    let _: () = msg_send![input_context, invalidateCharacterCoordinates];
                }
            })
            .detach()
    }

    fn titlebar_double_click(&self, is_resizable: bool, is_minimizable: bool) {
        let this = self.0.lock();
        if this.simple_fullscreen_state.is_some() {
            return;
        }
        let window = this.native_window;
        let closed = this.closed.clone();
        this.foreground_executor
            .spawn(async move {
                if_window_not_closed(closed, || {
                    unsafe {
                        let defaults: id = NSUserDefaults::standardUserDefaults();
                        let domain = ns_string("NSGlobalDomain");
                        let key = ns_string("AppleActionOnDoubleClick");

                        let dict: id = msg_send![defaults, persistentDomainForName: domain];
                        let action: id = if !dict.is_null() {
                            msg_send![dict, objectForKey: key]
                        } else {
                            nil
                        };

                        let action_str = if !action.is_null() {
                            CStr::from_ptr(NSString::UTF8String(action)).to_string_lossy()
                        } else {
                            "".into()
                        };

                        match action_str.as_ref() {
                            "None" => {
                                // "Do Nothing" selected, so do no action
                            }
                            "Minimize" => {
                                if is_minimizable {
                                    window.miniaturize_(nil);
                                }
                            }
                            "Maximize" => {
                                if is_resizable {
                                    window.zoom_(nil);
                                }
                            }
                            "Fill" => {
                                if is_resizable {
                                    // Unlike `zoom:`, AppKit's private Fill action honors the system's
                                    // "Tiled windows have margins" setting.
                                    let responds_to_zoom_fill: BOOL =
                                        msg_send![window, respondsToSelector: sel!(_zoomFill:)];
                                    if responds_to_zoom_fill == YES {
                                        let _: () = msg_send![window, _zoomFill: nil];
                                    } else {
                                        window.zoom_(nil);
                                    }
                                }
                            }
                            _ => {
                                if is_resizable {
                                    window.zoom_(nil);
                                }
                            }
                        }
                    }
                })
            })
            .detach();
    }

    fn start_window_move(&self) {
        let this = self.0.lock();
        if this.simple_fullscreen_state.is_some() {
            return;
        }
        let window = this.native_window;

        unsafe {
            let app = NSApplication::sharedApplication(nil);
            let event: id = msg_send![app, currentEvent];
            let _: () = msg_send![window, performWindowDragWithEvent: event];
        }
    }

    fn can_start_external_drag(&self) -> bool {
        true
    }

    fn start_external_drag(&self, payload: &ExternalDragPayload) -> bool {
        use objc2_foundation::{NSArray, NSPoint, NSRect, NSSize, NSString};

        let ExternalDragPayload::Files(paths) = payload;
        if paths.entries().is_empty() {
            log::warn!("start_external_drag declined: no paths");
            return false;
        }

        let (native_view, native_window, last_left_mouse_down_event) = {
            let state = self.0.lock();
            (
                state.native_view.as_ptr(),
                state.native_window,
                state.last_left_mouse_down_event.clone(),
            )
        };

        let Some(last_left_mouse_down_event) = last_left_mouse_down_event else {
            log::warn!("start_external_drag declined: no retained left mouse down event");
            return false;
        };

        // SAFETY: This method runs on the AppKit/foreground path during drag initiation. The
        // native view/window are retained by MacWindowState, copied out under a short lock above,
        // and all pointers passed to Objective-C remain valid for their respective calls.
        unsafe {
            let event: id = Retained::as_ptr(&last_left_mouse_down_event)
                .cast_mut()
                .cast();
            let dragging_items: id = msg_send![class!(NSMutableArray), array];
            // AppKit keeps this frame's distance from the event's location as the drag image's
            // offset from the cursor, so it has to stay anchored on `event`.
            let location: cocoa::foundation::NSPoint = msg_send![event, locationInWindow];
            let frame = NSRect::new(
                NSPoint::new(location.x - 16., location.y - 16.),
                NSSize::new(32., 32.),
            );

            for (path, is_directory) in paths.entries() {
                // Preserve non-UTF-8 paths
                let Ok(path_bytes) = CString::new(path.as_os_str().as_bytes()) else {
                    log::warn!("start_external_drag skipped path containing an interior nul byte");
                    continue;
                };

                let path_bytes = NonNull::new_unchecked(path_bytes.as_ptr().cast_mut());
                let url = NSURL::fileURLWithFileSystemRepresentation_isDirectory_relativeToURL(
                    path_bytes,
                    *is_directory,
                    None,
                );

                let pasteboard_writer = ProtocolObject::<dyn NSPasteboardWriting>::from_ref(&*url);
                let item = NSDraggingItem::initWithPasteboardWriter(
                    NSDraggingItem::alloc(),
                    pasteboard_writer,
                );

                // Resolve drag images lazily via `imageComponentsProvider` (Apple's
                // recommendation for large item counts), and by file *type* rather than
                // `iconForFile:`, which can synchronously hit LaunchServices, network
                // mounts, or iCloud for every selected path and beachball drag startup.
                // `iconForFileType:` is deprecated in favor of `iconForContentType:`,
                // but the replacement requires macOS 11 and we target 10.15.
                let file_type = if *is_directory {
                    "public.folder".to_string()
                } else {
                    path.extension()
                        .and_then(|extension| extension.to_str())
                        .map(|extension| extension.to_string())
                        .unwrap_or_else(|| "public.data".to_string())
                };
                let provider = RcBlock::new(move || {
                    let component = NSDraggingImageComponent::draggingImageComponentWithKey(
                        NSDraggingImageComponentIconKey,
                    );
                    let workspace = NSWorkspace::sharedWorkspace();
                    let file_type = NSString::from_str(&file_type);
                    // TODO: Replace with `iconForContentType` once Zed no longer supports MacOS 10.15
                    #[expect(deprecated, reason = "Support for MacOS 10.15")]
                    let icon = workspace.iconForFileType(&file_type);
                    component.setContents(Some(&icon));
                    // Component frames are relative to the item's dragging frame.
                    component.setFrame(NSRect::new(NSPoint::new(0., 0.), NSSize::new(32., 32.)));
                    let components = NSArray::from_slice(&[&*component]);
                    NonNull::new_unchecked(Retained::autorelease_return(components))
                });
                item.setDraggingFrame(frame);
                item.setImageComponentsProvider(Some(&provider));
                let _: () = msg_send![dragging_items, addObject: Retained::as_ptr(&item)];
            }

            let count: NSUInteger = msg_send![dragging_items, count];
            if count == 0 {
                log::warn!("start_external_drag declined: no dragging items");
                return false;
            }

            let session: id = msg_send![
                native_view,
                beginDraggingSessionWithItems: dragging_items
                event: event
                source: native_window
            ];

            let started = !session.is_null();
            if started {
                self.0.lock().synthetic_drag_counter += 1;
            }
            log::debug!(
                "start_external_drag completed: started={}, item_count={}",
                started,
                count
            );
            started
        }
    }

    fn play_system_bell(&self) {
        NSBeep()
    }

    #[cfg(any(test, feature = "test-support"))]
    fn render_to_image(&self, scene: &gpui::Scene) -> Result<RgbaImage> {
        let mut this = self.0.lock();
        this.renderer.render_to_image(scene)
    }

    fn a11y_init(&self, callbacks: gpui::A11yCallbacks) {
        let mut lock = self.0.lock();

        let activation_handler = A11yActivationHandler {
            callback: callbacks.activation,
        };
        let action_handler = A11yActionHandler(callbacks.action);

        let adapter = unsafe {
            accesskit_macos::SubclassingAdapter::for_window(
                lock.native_window as *mut c_void,
                activation_handler,
                action_handler,
            )
        };

        lock.accesskit_adapter = Some(adapter);
    }

    fn a11y_tree_update(&self, tree_update: accesskit::TreeUpdate) {
        let events = {
            let mut lock = self.0.lock();
            lock.accesskit_adapter
                .as_mut()
                .and_then(|adapter| adapter.update_if_active(|| tree_update))
        };
        if let Some(events) = events {
            events.raise();
        }
    }

    fn a11y_update_window_bounds(&self) {
        // macOS handles window bounds tracking automatically via NSAccessibility.
    }
}

struct A11yActivationHandler {
    callback: Box<dyn Fn() -> Option<accesskit::TreeUpdate> + Send + 'static>,
}

impl accesskit::ActivationHandler for A11yActivationHandler {
    fn request_initial_tree(&mut self) -> Option<accesskit::TreeUpdate> {
        (self.callback)()
    }
}

struct A11yActionHandler(Box<dyn Fn(accesskit::ActionRequest) + Send + 'static>);

impl accesskit::ActionHandler for A11yActionHandler {
    fn do_action(&mut self, request: accesskit::ActionRequest) {
        (self.0)(request);
    }
}

impl rwh::HasWindowHandle for MacWindow {
    fn window_handle(&self) -> Result<rwh::WindowHandle<'_>, rwh::HandleError> {
        // SAFETY: The AppKitWindowHandle is a wrapper around a pointer to an NSView
        unsafe {
            Ok(rwh::WindowHandle::borrow_raw(rwh::RawWindowHandle::AppKit(
                rwh::AppKitWindowHandle::new(self.0.lock().native_view.cast()),
            )))
        }
    }
}

impl rwh::HasDisplayHandle for MacWindow {
    fn display_handle(&self) -> Result<rwh::DisplayHandle<'_>, rwh::HandleError> {
        Ok(rwh::DisplayHandle::appkit())
    }
}

fn get_scale_factor(native_window: id) -> f32 {
    let factor = unsafe {
        let screen: id = msg_send![native_window, screen];
        if screen.is_null() {
            return 2.0;
        }
        NSScreen::backingScaleFactor(screen) as f32
    };

    // We are not certain what triggers this, but it seems that sometimes
    // this method would return 0 (https://github.com/zed-industries/zed/issues/6412)
    // It seems most likely that this would happen if the window has no screen
    // (if it is off-screen), though we'd expect to see viewDidChangeBackingProperties before
    // it was rendered for real.
    // Regardless, attempt to avoid the issue here.
    if factor == 0.0 { 2. } else { factor }
}

/// Returns whether `window` is one of GPUI's managed windows.
unsafe fn is_gpui_window(window: id) -> bool {
    unsafe {
        msg_send![window, isKindOfClass: WINDOW_CLASS]
            || msg_send![window, isKindOfClass: PANEL_CLASS]
    }
}

/// Applies `style` to a glass backdrop view. Only `NSGlassEffectView`
/// responds to `setStyle:`; the plain visual-effect fallbacks are left
/// untouched. Raw values: 0 = regular, 1 = clear (verified by reading the
/// property back).
unsafe fn apply_glass_style(view: id, style: WindowGlassStyle) {
    unsafe {
        let responds: BOOL = msg_send![view, respondsToSelector: sel!(setStyle:)];
        if responds == YES {
            let style_value: NSInteger = match style {
                WindowGlassStyle::Regular => 0,
                WindowGlassStyle::Clear => 1,
            };
            let _: () = msg_send![view, setStyle: style_value];
        }
    }
}

/// Applies `tint` to a glass backdrop view. Only `NSGlassEffectView` responds
/// to `setTintColor:`; the plain visual-effect fallbacks are left untouched.
/// `None` restores the untinted adaptive material.
unsafe fn apply_glass_tint(view: id, tint: Option<Rgba>) {
    unsafe {
        let responds: BOOL = msg_send![view, respondsToSelector: sel!(setTintColor:)];
        if responds == YES {
            let color: id = match tint {
                Some(tint) => NSColor::colorWithSRGBRed_green_blue_alpha_(
                    nil,
                    tint.r as f64,
                    tint.g as f64,
                    tint.b as f64,
                    tint.a as f64,
                ),
                None => nil,
            };
            let _: () = msg_send![view, setTintColor: color];
        }
    }
}

unsafe fn get_window_state(object: &Object) -> Arc<Mutex<MacWindowState>> {
    unsafe {
        let raw: *mut c_void = *object.get_ivar(WINDOW_STATE_IVAR);
        let rc1 = Arc::from_raw(raw as *mut Mutex<MacWindowState>);
        let rc2 = rc1.clone();
        mem::forget(rc1);
        rc2
    }
}

unsafe fn drop_window_state(object: &Object) {
    unsafe {
        let raw: *mut c_void = *object.get_ivar(WINDOW_STATE_IVAR);
        Arc::from_raw(raw as *mut Mutex<MacWindowState>);
    }
}

extern "C" fn yes(_: &Object, _: Sel) -> BOOL {
    YES
}

extern "C" fn dealloc_window(this: &Object, _: Sel) {
    unsafe {
        drop_window_state(this);
        let _: () = msg_send![super(this, class!(NSWindow)), dealloc];
    }
}

extern "C" fn dealloc_view(this: &Object, _: Sel) {
    unsafe {
        drop_window_state(this);
        let _: () = msg_send![super(this, class!(NSView)), dealloc];
    }
}

fn add_mouse_tracking_area(native_view: &Objc2NSView) {
    let options = NSTrackingAreaOptions::MouseEnteredAndExited
        | NSTrackingAreaOptions::MouseMoved
        // Track even when another application is active so visible
        // windows can respond to hover without being focused.
        | NSTrackingAreaOptions::ActiveAlways
        | NSTrackingAreaOptions::InVisibleRect;

    // SAFETY: NSView provides the tracking-event callbacks, and the owner is
    // the same view that retains the tracking area. No user info is supplied.
    let tracking_area = unsafe {
        NSTrackingArea::initWithRect_options_owner_userInfo(
            NSTrackingArea::alloc(),
            Objc2NSRect::ZERO,
            options,
            Some(native_view),
            None,
        )
    };
    native_view.addTrackingArea(&tracking_area);
}

extern "C" fn dealloc_overlay_view(this: &Object, _: Sel) {
    unsafe {
        drop_window_state(this);
        let raw: *mut c_void = *this.get_ivar(OVERLAY_INPUT_IVAR);
        drop(Arc::from_raw(raw as *const AtomicBool));
        let _: () = msg_send![super(this, class!(NSView)), dealloc];
    }
}

extern "C" fn reset_cursor_rects(this: &Object, _: Sel) {
    // SAFETY: AppKit invokes cursor-rect updates on the main thread for GPUIView instances,
    // whose WINDOW_STATE_IVAR is initialized when the view is created. The cursor registered
    // below is a valid NSCursor.
    unsafe {
        let _: () = msg_send![super(this, class!(NSView)), resetCursorRects];

        let window_state = get_window_state(this);
        let cursor_style = window_state.lock().cursor_style;

        let cursor: id = match cursor_style {
            CursorStyle::Arrow => msg_send![class!(NSCursor), arrowCursor],
            CursorStyle::IBeam => msg_send![class!(NSCursor), IBeamCursor],
            CursorStyle::Crosshair => msg_send![class!(NSCursor), crosshairCursor],
            CursorStyle::ClosedHand => msg_send![class!(NSCursor), closedHandCursor],
            CursorStyle::OpenHand => msg_send![class!(NSCursor), openHandCursor],
            CursorStyle::PointingHand => msg_send![class!(NSCursor), pointingHandCursor],
            CursorStyle::ResizeLeftRight => msg_send![class!(NSCursor), resizeLeftRightCursor],
            CursorStyle::ResizeUpDown => msg_send![class!(NSCursor), resizeUpDownCursor],
            CursorStyle::ResizeLeft => msg_send![class!(NSCursor), resizeLeftCursor],
            CursorStyle::ResizeRight => msg_send![class!(NSCursor), resizeRightCursor],
            CursorStyle::ResizeColumn => msg_send![class!(NSCursor), resizeLeftRightCursor],
            CursorStyle::ResizeRow => msg_send![class!(NSCursor), resizeUpDownCursor],
            CursorStyle::ResizeUp => msg_send![class!(NSCursor), resizeUpCursor],
            CursorStyle::ResizeDown => msg_send![class!(NSCursor), resizeDownCursor],

            // Undocumented, private class methods:
            // https://stackoverflow.com/questions/27242353/cocoa-predefined-resize-mouse-cursor
            CursorStyle::ResizeUpLeftDownRight => {
                msg_send![class!(NSCursor), _windowResizeNorthWestSouthEastCursor]
            }
            CursorStyle::ResizeUpRightDownLeft => {
                msg_send![class!(NSCursor), _windowResizeNorthEastSouthWestCursor]
            }

            CursorStyle::IBeamCursorForVerticalLayout => {
                msg_send![class!(NSCursor), IBeamCursorForVerticalLayout]
            }
            CursorStyle::OperationNotAllowed => {
                msg_send![class!(NSCursor), operationNotAllowedCursor]
            }
            CursorStyle::DragLink => msg_send![class!(NSCursor), dragLinkCursor],
            CursorStyle::DragCopy => msg_send![class!(NSCursor), dragCopyCursor],
            CursorStyle::ContextualMenu => msg_send![class!(NSCursor), contextualMenuCursor],
        };

        let bounds = NSView::bounds(this as *const Object as id);
        let _: () = msg_send![this, addCursorRect: bounds cursor: cursor];
    }
}

extern "C" fn handle_key_equivalent(this: &Object, _: Sel, native_event: id) -> BOOL {
    handle_key_event(this, native_event, true)
}

extern "C" fn handle_key_down(this: &Object, _: Sel, native_event: id) {
    handle_key_event(this, native_event, false);
}

extern "C" fn handle_key_up(this: &Object, _: Sel, native_event: id) {
    handle_key_event(this, native_event, false);
}

// Things to test if you're modifying this method:
//  U.S. layout:
//   - The IME consumes characters like 'j' and 'k', which makes paging through `less` in
//     the terminal behave incorrectly by default. This behavior should be patched by our
//     IME integration
//   - `alt-t` should open the tasks menu
//   - In vim mode, this keybinding should work:
//     ```
//        {
//          "context": "Editor && vim_mode == insert",
//          "bindings": {"j j": "vim::NormalBefore"}
//        }
//     ```
//     and typing 'j k' in insert mode with this keybinding should insert the two characters
//  Brazilian layout:
//   - `" space` should create an unmarked quote
//   - `" backspace` should delete the marked quote
//   - `" "`should create an unmarked quote and a second marked quote
//   - `" up` should insert a quote, unmark it, and move up one line
//   - `" cmd-down` should insert a quote, unmark it, and move to the end of the file
//   - `cmd-ctrl-space` and clicking on an emoji should type it
//  Czech (QWERTY) layout:
//   - in vim mode `option-4`  should go to end of line (same as $)
//  Japanese (Romaji) layout:
//   - type `a i left down up enter enter` should create an unmarked text "愛"
//   - In vim mode with `jj` bound to `vim::NormalBefore` in insert mode, typing 'j i' with
//     Japanese IME should produce "じ" (ji), not "jい"

/// Returns true if the current keyboard input source is a composition-based IME
/// (e.g. Japanese Hiragana, Korean, Chinese Pinyin) that produces non-ASCII output.
///
/// This checks two properties:
/// 1. The source type is `kTISTypeKeyboardInputMode` (an IME input mode, not a plain
///    keyboard layout). This excludes non-ASCII layouts like Armenian and Ukrainian
///    that map keys directly without composition.
/// 2. The source is not ASCII-capable, which excludes modes like Japanese Romaji that
///    produce ASCII characters and should allow multi-stroke keybindings like `jj`.
unsafe fn is_ime_input_source_active() -> bool {
    unsafe {
        let source = TISCopyCurrentKeyboardInputSource();
        if source.is_null() {
            return false;
        }

        let source_type =
            TISGetInputSourceProperty(source, kTISPropertyInputSourceType as *const c_void);
        let is_input_mode = !source_type.is_null()
            && CFEqual(
                source_type as CFTypeRef,
                kTISTypeKeyboardInputMode as CFTypeRef,
            ) != 0;

        let is_ascii = TISGetInputSourceProperty(
            source,
            kTISPropertyInputSourceIsASCIICapable as *const c_void,
        );
        let is_ascii_capable = !is_ascii.is_null() && CFBooleanGetValue(is_ascii as CFBooleanRef);

        CFRelease(source as CFTypeRef);

        is_input_mode && !is_ascii_capable
    }
}

extern "C" fn handle_key_event(this: &Object, native_event: id, key_equivalent: bool) -> BOOL {
    let window_state = unsafe { get_window_state(this) };
    let mut lock = window_state.as_ref().lock();

    let window_height = lock.content_size().height;
    let event = unsafe { platform_input_from_native(native_event, Some(window_height)) };

    let Some(event) = event else {
        return NO;
    };

    let run_callback = |event: PlatformInput| -> BOOL {
        let mut callback = window_state.as_ref().lock().event_callback.take();
        let handled: BOOL = if let Some(callback) = callback.as_mut() {
            !callback(event).propagate as BOOL
        } else {
            NO
        };
        window_state.as_ref().lock().event_callback = callback;
        handled
    };

    match event {
        PlatformInput::KeyDown(key_down_event) => {
            // For certain keystrokes, macOS will first dispatch a "key equivalent" event.
            // If that event isn't handled, it will then dispatch a "key down" event. GPUI
            // makes no distinction between these two types of events, so we need to ignore
            // the "key down" event if we've already just processed its "key equivalent" version.
            if key_equivalent {
                lock.last_key_equivalent = Some(key_down_event.clone());
            } else if lock.last_key_equivalent.take().as_ref() == Some(&key_down_event) {
                return NO;
            }

            drop(lock);

            let is_composing =
                with_input_handler(this, |input_handler| input_handler.marked_text_range())
                    .flatten()
                    .is_some();

            // If we're composing, send the key to the input handler first;
            // otherwise we only send to the input handler if we don't have a matching binding.
            // The input handler may call `do_command_by_selector` if it doesn't know how to handle
            // a key. If it does so, it will return YES so we won't send the key twice.
            // We also do this for non-printing keys (like arrow keys and escape) as the IME menu
            // may need them even if there is no marked text;
            // however we skip keys with control or the input handler adds control-characters to the buffer.
            // and keys with function, as the input handler swallows them.
            // and keys with platform (Cmd), so that Cmd+key events (e.g. Cmd+`) are not
            // consumed by the IME on non-QWERTY / dead-key layouts.
            // We also send printable keys to the IME first when an IME input source (e.g. Japanese,
            // Korean, Chinese) is active and the input handler accepts text input. This prevents
            // multi-stroke keybindings like `jj` from intercepting keys that the IME should compose
            // (e.g. typing 'ji' should produce 'じ', not 'jい'). If the IME doesn't handle the key,
            // it calls `doCommandBySelector:` which routes it back to keybinding matching.
            let is_ime_printable_key = !is_composing
                && key_down_event
                    .keystroke
                    .key_char
                    .as_ref()
                    .is_some_and(|key_char| key_char.chars().all(|c| !c.is_control()))
                && !key_down_event.keystroke.modifiers.control
                && !key_down_event.keystroke.modifiers.function
                && !key_down_event.keystroke.modifiers.platform
                && unsafe { is_ime_input_source_active() }
                && with_input_handler(this, |input_handler| {
                    input_handler.query_prefers_ime_for_printable_keys()
                })
                .unwrap_or(false);

            if is_composing
                || is_ime_printable_key
                || (key_down_event.keystroke.key_char.is_none()
                    && !key_down_event.keystroke.modifiers.control
                    && !key_down_event.keystroke.modifiers.function
                    && !key_down_event.keystroke.modifiers.platform)
            {
                {
                    let mut lock = window_state.as_ref().lock();
                    lock.keystroke_for_do_command = Some(key_down_event.keystroke.clone());
                    lock.do_command_handled.take();
                    drop(lock);
                }

                let handled: BOOL = unsafe {
                    let input_context: id = msg_send![this, inputContext];
                    msg_send![input_context, handleEvent: native_event]
                };
                window_state.as_ref().lock().keystroke_for_do_command.take();
                if let Some(handled) = window_state.as_ref().lock().do_command_handled.take() {
                    return handled as BOOL;
                } else if handled == YES {
                    return YES;
                }

                let handled = run_callback(PlatformInput::KeyDown(key_down_event));
                return handled;
            }

            let handled = run_callback(PlatformInput::KeyDown(key_down_event.clone()));
            if handled == YES {
                return YES;
            }

            if key_down_event.is_held
                && let Some(key_char) = key_down_event.keystroke.key_char.as_ref()
            {
                let handled = with_input_handler(this, |input_handler| {
                    if !input_handler.apple_press_and_hold_enabled() {
                        input_handler.replace_text_in_range(None, key_char);
                        return YES;
                    }
                    NO
                });
                if handled == Some(YES) {
                    return YES;
                }
            }

            // Don't send key equivalents to the input handler if there are key modifiers other
            // than Function key, or macOS shortcuts like cmd-` will stop working.
            if key_equivalent && key_down_event.keystroke.modifiers != Modifiers::function() {
                return NO;
            }

            unsafe {
                let input_context: id = msg_send![this, inputContext];
                msg_send![input_context, handleEvent: native_event]
            }
        }

        PlatformInput::KeyUp(_) => {
            drop(lock);
            run_callback(event)
        }

        _ => NO,
    }
}

extern "C" fn handle_view_event(this: &Object, _: Sel, native_event: id) {
    let window_state = unsafe { get_window_state(this) };
    let weak_window_state = Arc::downgrade(&window_state);
    let mut lock = window_state.as_ref().lock();
    let window_height = lock.content_size().height;
    let native_event_type = unsafe { native_event.eventType() };
    match native_event_type {
        NSEventType::NSLeftMouseDown => {
            // AppKit owns `native_event` for the callback; retain it so the drag session can still
            // be started later, once the pointer leaves the window.
            lock.last_left_mouse_down_event =
                unsafe { Retained::retain(native_event.cast::<Objc2Object>()) };
        }
        NSEventType::NSLeftMouseUp => {
            lock.last_left_mouse_down_event = None;
        }
        _ => {}
    }
    let event = unsafe { platform_input_from_native(native_event, Some(window_height)) };

    if let Some(mut event) = event {
        // AppKit unhides the cursor on the next mouse movement; mirror that here.
        if matches!(
            event,
            PlatformInput::MouseMove(_)
                | PlatformInput::MouseDown(_)
                | PlatformInput::MouseUp(_)
                | PlatformInput::MousePressure(_)
                | PlatformInput::MouseExited(_)
                | PlatformInput::ScrollWheel(_)
                | PlatformInput::Pinch(_)
        ) {
            lock.cursor_visible.store(true, Ordering::Relaxed);
        }

        match &mut event {
            PlatformInput::MouseDown(
                event @ MouseDownEvent {
                    button: MouseButton::Left,
                    modifiers: Modifiers { control: true, .. },
                    ..
                },
            ) => {
                // On mac, a ctrl-left click should be handled as a right click.
                *event = MouseDownEvent {
                    button: MouseButton::Right,
                    modifiers: Modifiers {
                        control: false,
                        ..event.modifiers
                    },
                    click_count: 1,
                    ..*event
                };
            }

            // Handles focusing click.
            PlatformInput::MouseDown(
                event @ MouseDownEvent {
                    button: MouseButton::Left,
                    ..
                },
            ) if (lock.first_mouse) => {
                *event = MouseDownEvent {
                    first_mouse: true,
                    ..*event
                };
                lock.first_mouse = false;
            }

            // Because we map a ctrl-left_down to a right_down -> right_up let's ignore
            // the ctrl-left_up to avoid having a mismatch in button down/up events if the
            // user is still holding ctrl when releasing the left mouse button
            PlatformInput::MouseUp(
                event @ MouseUpEvent {
                    button: MouseButton::Left,
                    modifiers: Modifiers { control: true, .. },
                    ..
                },
            ) => {
                *event = MouseUpEvent {
                    button: MouseButton::Right,
                    modifiers: Modifiers {
                        control: false,
                        ..event.modifiers
                    },
                    click_count: 1,
                    ..*event
                };
            }

            _ => {}
        };

        match &event {
            PlatformInput::MouseDown(_) => {
                drop(lock);
                unsafe {
                    let input_context: id = msg_send![this, inputContext];
                    msg_send![input_context, handleEvent: native_event]
                }
                lock = window_state.as_ref().lock();
            }
            PlatformInput::MouseMove(
                event @ MouseMoveEvent {
                    pressed_button: Some(_),
                    ..
                },
            ) => {
                // Synthetic drag is used for selecting long buffer contents while buffer is being scrolled.
                // External file drag and drop is able to emit its own synthetic mouse events which will conflict
                // with these ones.
                if !lock.external_files_dragged {
                    lock.synthetic_drag_counter += 1;
                    let executor = lock.foreground_executor.clone();
                    executor
                        .spawn(synthetic_drag(
                            weak_window_state,
                            lock.synthetic_drag_counter,
                            event.clone(),
                            lock.background_executor.clone(),
                        ))
                        .detach();
                }
            }

            PlatformInput::MouseUp(MouseUpEvent { .. }) => {
                lock.synthetic_drag_counter += 1;
            }

            PlatformInput::ModifiersChanged(ModifiersChangedEvent {
                modifiers,
                capslock,
            }) => {
                // Only raise modifiers changed event when they have actually changed
                if let Some(PlatformInput::ModifiersChanged(ModifiersChangedEvent {
                    modifiers: prev_modifiers,
                    capslock: prev_capslock,
                })) = &lock.previous_modifiers_changed_event
                    && prev_modifiers == modifiers
                    && prev_capslock == capslock
                {
                    return;
                }

                lock.previous_modifiers_changed_event = Some(event.clone());
            }

            _ => {}
        }

        if let Some(mut callback) = lock.event_callback.take() {
            drop(lock);
            callback(event);
            window_state.lock().event_callback = Some(callback);
        }
    }
}

fn visibility(state: &MacWindowState) -> WindowVisibility {
    let is_visible = unsafe {
        state
            .native_window
            .occlusionState()
            .contains(NSWindowOcclusionState::NSWindowOcclusionStateVisible)
    };
    if is_visible {
        WindowVisibility::Visible
    } else {
        WindowVisibility::Hidden
    }
}

fn report_visibility(window_state: &Arc<Mutex<MacWindowState>>) {
    let state = window_state.lock();
    if state.last_visibility.is_none() {
        return;
    }
    let executor = state.foreground_executor.clone();
    drop(state);

    // AppKit can notify while GPUI is updating a window. Deliver observers
    // after that update completes, as activation notifications do. The state
    // is read at delivery rather than captured here so a burst of
    // notifications collapses to the final value.
    executor
        .spawn({
            let window_state = window_state.clone();
            async move {
                let mut state = window_state.lock();
                let visibility = visibility(&state);
                if state.last_visibility == Some(visibility) {
                    return;
                }
                state.last_visibility = Some(visibility);
                if let Some(mut callback) = state.visibility_callback.take() {
                    drop(state);
                    callback(visibility);
                    window_state.lock().visibility_callback = Some(callback);
                }
            }
        })
        .detach();
}

extern "C" fn window_did_change_occlusion_state(this: &Object, _: Sel, _: id) {
    let window_state = unsafe { get_window_state(this) };
    let mut lock = window_state.lock();
    unsafe {
        if lock
            .native_window
            .occlusionState()
            .contains(NSWindowOcclusionState::NSWindowOcclusionStateVisible)
        {
            lock.move_traffic_light();
            lock.start_display_link();
        } else {
            lock.stop_display_link();
            // Nothing paints an occluded window, so its drawable-sized
            // intermediate textures can go; the first draw after it becomes
            // visible again recreates them. Its in-flight drawable counts
            // start afresh too, so one raised by a lost presented handler
            // does not outlive the stretch of presenting it happened in.
            lock.renderer.release_intermediate_textures();
            lock.renderer.forget_drawables_in_flight();
            if let Some(renderer) = lock.overlay_renderer.as_mut() {
                renderer.release_intermediate_textures();
                renderer.forget_drawables_in_flight();
            }
        }
    }
    drop(lock);
    // The only visibility source: AppKit posts this for covering, minimizing,
    // hiding, Space switches, and display sleep alike.
    report_visibility(&window_state);
}

extern "C" fn window_did_resize(this: &Object, _: Sel, _: id) {
    let window_state = unsafe { get_window_state(this) };
    window_state.as_ref().lock().move_traffic_light();
}

extern "C" fn window_will_enter_fullscreen(this: &Object, _: Sel, _: id) {
    let window_state = unsafe { get_window_state(this) };
    let mut lock = window_state.as_ref().lock();
    lock.fullscreen_restore_bounds = lock.bounds();
    lock.is_exiting_fullscreen = false;
    lock.pre_fullscreen_traffic_light_frames = lock.traffic_light_frames;
    lock.restore_traffic_light();

    let min_version = NSOperatingSystemVersion::new(15, 3, 0);

    if is_macos_version_at_least(min_version) {
        unsafe {
            lock.native_window.setTitlebarAppearsTransparent_(NO);
        }
    }
}

extern "C" fn window_will_exit_fullscreen(this: &Object, _: Sel, _: id) {
    let window_state = unsafe { get_window_state(this) };
    let mut lock = window_state.as_ref().lock();
    lock.is_exiting_fullscreen = true;

    let min_version = NSOperatingSystemVersion::new(15, 3, 0);

    if is_macos_version_at_least(min_version) && lock.transparent_titlebar {
        unsafe {
            lock.native_window.setTitlebarAppearsTransparent_(YES);
        }
    }

    lock.move_traffic_light();
}

extern "C" fn window_did_fail_to_exit_fullscreen(this: &Object, _: Sel, _: id) {
    let window_state = unsafe { get_window_state(this) };
    let mut lock = window_state.as_ref().lock();
    lock.is_exiting_fullscreen = false;
    lock.restore_traffic_light();
}

extern "C" fn window_did_exit_fullscreen(this: &Object, _: Sel, _: id) {
    // SAFETY: This method is registered only on GPUI window classes, which initialize
    // WINDOW_STATE_IVAR with an Arc<Mutex<MacWindowState>> during window creation.
    let window_state = unsafe { get_window_state(this) };
    let mut lock = window_state.as_ref().lock();
    lock.is_exiting_fullscreen = false;
    // Moving the buttons during the transition captures their fullscreen frames.
    // Keep using the native windowed frames when restoring them on the next entry.
    lock.traffic_light_frames = lock.pre_fullscreen_traffic_light_frames.take();
    lock.move_traffic_light();
}

pub(crate) fn is_macos_version_at_least(version: NSOperatingSystemVersion) -> bool {
    unsafe { NSProcessInfo::processInfo(nil).isOperatingSystemAtLeastVersion(version) }
}

fn ns_error_description(error: id) -> String {
    if error.is_null() {
        return "unknown error".to_owned();
    }
    unsafe {
        let description: id = msg_send![error, localizedDescription];
        description.to_str().to_owned()
    }
}

extern "C" fn window_did_move(this: &Object, _: Sel, _: id) {
    let window_state = unsafe { get_window_state(this) };
    let mut lock = window_state.as_ref().lock();
    if let Some(mut callback) = lock.moved_callback.take() {
        drop(lock);
        callback();
        window_state.lock().moved_callback = Some(callback);
    }
}

// Update the window scale factor and drawable size, and call the resize callback if any.
fn update_window_scale_factor(window_state: &Arc<Mutex<MacWindowState>>) {
    let mut lock = window_state.as_ref().lock();
    let scale_factor = lock.scale_factor();
    let size = lock.content_size();
    let drawable_size = size.to_device_pixels(scale_factor);
    if let Some(layer) = lock.renderer.layer() {
        unsafe {
            let _: () = msg_send![
                layer,
                setContentsScale: scale_factor as f64
            ];
        }
    }

    lock.renderer.update_drawable_size(drawable_size);
    if let Some(renderer) = lock.overlay_renderer.as_mut() {
        if let Some(layer) = renderer.layer() {
            unsafe {
                let _: () = msg_send![layer, setContentsScale: scale_factor as f64];
            }
        }
        renderer.update_drawable_size(drawable_size);
    }

    if let Some(mut callback) = lock.resize_callback.take() {
        let content_size = lock.content_size();
        let scale_factor = lock.scale_factor();
        drop(lock);
        callback(content_size, scale_factor);
        window_state.as_ref().lock().resize_callback = Some(callback);
    };
}

extern "C" fn window_did_change_screen(this: &Object, _: Sel, _: id) {
    let window_state = unsafe { get_window_state(this) };
    let mut lock = window_state.as_ref().lock();
    lock.start_display_link();
    drop(lock);
    update_window_scale_factor(&window_state);
}

extern "C" fn window_did_change_key_status(this: &Object, selector: Sel, _: id) {
    let window_state = unsafe { get_window_state(this) };
    let lock = window_state.lock();
    let is_active = unsafe { lock.native_window.isKeyWindow() == YES };

    // AppKit also unhides the cursor on activation changes, so mirror that here.
    lock.cursor_visible.store(true, Ordering::Relaxed);

    // When opening a pop-up while the application isn't active, Cocoa sends a spurious
    // `windowDidBecomeKey` message to the previous key window even though that window
    // isn't actually key. This causes a bug if the application is later activated while
    // the pop-up is still open, making it impossible to activate the previous key window
    // even if the pop-up gets closed. The only way to activate it again is to de-activate
    // the app and re-activate it, which is a pretty bad UX.
    // The following code detects the spurious event and invokes `resignKeyWindow`:
    // in theory, we're not supposed to invoke this method manually but it balances out
    // the spurious `becomeKeyWindow` event and helps us work around that bug.
    if selector == sel!(windowDidBecomeKey:) && !is_active {
        let native_window = lock.native_window;
        drop(lock);
        unsafe {
            let _: () = msg_send![native_window, resignKeyWindow];
        }
        return;
    }

    // In glass mode, render inactive windows opaque (drop the blur) to match
    // macOS and avoid the GPU cost of the effect on background windows. The
    // user-requested appearance stays in `background_appearance`; only the
    // effective rendering follows the active state.
    if lock.background_appearance == WindowBackgroundAppearance::Blurred {
        unsafe {
            // Keep the Metal layer transparent; only hide the blur on inactive
            // windows and fill the system window background color (adapts to
            // light/dark). The translucent content then shows over that solid
            // surface instead of being dimmed over the (now hidden) blur.
            // Active windows stay near-clear so the blur shows through.
            let background_color = if is_active {
                // Not using `+[NSColor clearColor]` to avoid broken shadow.
                NSColor::colorWithSRGBRed_green_blue_alpha_(nil, 0f64, 0f64, 0f64, 0.0001)
            } else {
                msg_send![class!(NSColor), textBackgroundColor]
            };
            lock.native_window.setBackgroundColor_(background_color);
            if let Some(blur_view) = lock.blurred_view {
                let _: () = msg_send![blur_view, setHidden: (!is_active) as BOOL];
            }
        }
    }

    let executor = lock.foreground_executor.clone();
    let native_window = lock.native_window;
    drop(lock);

    let a11y_events = {
        let mut lock = window_state.lock();
        lock.accesskit_adapter
            .as_mut()
            .and_then(|adapter| adapter.update_view_focus_state(is_active))
    };
    if let Some(events) = a11y_events {
        events.raise();
    }

    // When a window becomes active, trigger an immediate synchronous frame request to prevent
    // tab flicker when switching between windows in native tabs mode.
    //
    // This is only done on subsequent activations (not the first) to ensure the initial focus
    // path is properly established. Without this guard, the focus state would remain unset until
    // the first mouse click, causing keybindings to be non-functional.
    //
    // It is also only done for a window that shares a native tab group with another, or that can
    // be a native tab and was hidden. The frame presents inside a Core Animation transaction,
    // on the main thread, while AppKit's activation is still in progress, so a wait for a
    // drawable there (a compositor still holding the window's drawables from before it was
    // deactivated) stalls the activation for every app, not just this one. A visible window with
    // no sibling tab has no tab switch to hide, and its display link, which runs whenever the
    // window is visible, presents on the next refresh. A hidden window's display link is stopped,
    // so without this frame it would show its content from before it was hidden until the
    // occlusion change restarts the link and a refresh passes: this is the tab left in front
    // after closing the one above it, which AppKit may already have taken out of the group. A
    // window given no tabbing identifier is never a tab, so a hidden one (behind another app's
    // window and brought forward with Cmd-Tab) is left to its display link.
    if selector == sel!(windowDidBecomeKey:) && is_active {
        // Asked before the window-state lock is taken, so nothing AppKit does in answering can
        // find it held.
        let shares_a_tab_group = unsafe {
            let tabbed_windows: id = msg_send![native_window, tabbedWindows];
            !tabbed_windows.is_null() && {
                let count: NSUInteger = msg_send![tabbed_windows, count];
                count > 1
            }
        };
        let window_state = unsafe { get_window_state(this) };
        let mut lock = window_state.lock();

        if lock.activated_least_once {
            let display_link_running = lock
                .frame_source
                .as_ref()
                .is_some_and(WindowFrameSource::is_running);
            if (shares_a_tab_group || (lock.native_tabbing && !display_link_running))
                && let Some(mut callback) = lock.request_frame_callback.take()
            {
                lock.set_presents_with_transaction(true);
                lock.stop_display_link();
                drop(lock);
                callback(Default::default());

                let mut lock = window_state.lock();
                lock.request_frame_callback = Some(callback);
                lock.set_presents_with_transaction(false);
                lock.start_display_link();
            }
        } else {
            lock.activated_least_once = true;
        }
    }

    executor
        .spawn(async move {
            let mut lock = window_state.as_ref().lock();
            if is_active {
                lock.move_traffic_light();
            }

            if let Some(mut callback) = lock.activate_callback.take() {
                drop(lock);
                callback(is_active);
                window_state.lock().activate_callback = Some(callback);
            };
        })
        .detach();
}

extern "C" fn window_should_close(this: &Object, _: Sel, _: id) -> BOOL {
    let window_state = unsafe { get_window_state(this) };
    let mut lock = window_state.as_ref().lock();
    if let Some(mut callback) = lock.should_close_callback.take() {
        drop(lock);
        let should_close = callback();
        window_state.lock().should_close_callback = Some(callback);
        should_close as BOOL
    } else {
        YES
    }
}

extern "C" fn close_window(this: &Object, _: Sel) {
    unsafe {
        let (close_callback, simple_fullscreen_state) = {
            let window_state = get_window_state(this);
            let mut lock = window_state.as_ref().lock();
            lock.closed.store(true, Ordering::Release);
            (
                lock.close_callback.take(),
                lock.simple_fullscreen_state.take(),
            )
        };

        if simple_fullscreen_state.is_some() {
            pop_simple_fullscreen_presentation_options();
        }

        if let Some(callback) = close_callback {
            callback();
        }

        let _: () = msg_send![super(this, class!(NSWindow)), close];
    }
}

extern "C" fn make_backing_layer(this: &Object, _: Sel) -> id {
    let window_state = unsafe { get_window_state(this) };
    let window_state = window_state.as_ref().lock();
    window_state.renderer.layer_ptr() as id
}

extern "C" fn view_did_change_backing_properties(this: &Object, _: Sel) {
    let window_state = unsafe { get_window_state(this) };
    update_window_scale_factor(&window_state);
}

extern "C" fn set_frame_size(this: &Object, _: Sel, size: NSSize) {
    fn convert(value: NSSize) -> Size<Pixels> {
        Size {
            width: px(value.width as f32),
            height: px(value.height as f32),
        }
    }

    let window_state = unsafe { get_window_state(this) };
    let mut lock = window_state.as_ref().lock();

    let new_size = convert(size);
    let old_size = unsafe {
        let old_frame: NSRect = msg_send![this, frame];
        convert(old_frame.size)
    };

    if old_size == new_size {
        return;
    }

    unsafe {
        let _: () = msg_send![super(this, class!(NSView)), setFrameSize: size];
    }

    let scale_factor = lock.scale_factor();
    let drawable_size = new_size.to_device_pixels(scale_factor);
    lock.renderer.update_drawable_size(drawable_size);
    if let Some(renderer) = lock.overlay_renderer.as_mut() {
        renderer.update_drawable_size(drawable_size);
    }

    if let Some(mut callback) = lock.resize_callback.take() {
        let content_size = lock.content_size();
        let scale_factor = lock.scale_factor();
        drop(lock);
        callback(content_size, scale_factor);
        window_state.lock().resize_callback = Some(callback);
    };
}

extern "C" fn display_layer(this: &Object, _: Sel, _: id) {
    let window_state = unsafe { get_window_state(this) };
    let mut lock = window_state.lock();
    if let Some(mut callback) = lock.request_frame_callback.take() {
        // The frame presents inside the Core Animation transaction that
        // resizes the window, so it lands in step with the new window frame.
        // A present deferred here would be retried on the next display
        // refresh, outside the transaction, and show stretched until then.
        // That cannot happen while the layer's `nextDrawable` waits for a
        // drawable, where a nil drops the frame instead; an acquire that can
        // give up without one has to keep this present in the transaction.
        lock.set_presents_with_transaction(true);
        lock.stop_display_link();
        drop(lock);
        callback(Default::default());

        let mut lock = window_state.lock();
        lock.request_frame_callback = Some(callback);
        lock.set_presents_with_transaction(false);
        lock.start_display_link();
    }
}

extern "C" fn step(view: *mut c_void) {
    let view = view as id;
    let window_state = unsafe { get_window_state(&*view) };
    let mut lock = window_state.lock();

    if let Some(mut callback) = lock.request_frame_callback.take() {
        drop(lock);
        callback(Default::default());
        window_state.lock().request_frame_callback = Some(callback);
    }
}

extern "C" fn valid_attributes_for_marked_text(_: &Object, _: Sel) -> id {
    unsafe { msg_send![class!(NSArray), array] }
}

extern "C" fn has_marked_text(this: &Object, _: Sel) -> BOOL {
    let has_marked_text_result =
        with_input_handler(this, |input_handler| input_handler.marked_text_range()).flatten();

    has_marked_text_result.is_some() as BOOL
}

extern "C" fn marked_range(this: &Object, _: Sel) -> NSRange {
    let marked_range_result =
        with_input_handler(this, |input_handler| input_handler.marked_text_range()).flatten();

    marked_range_result.map_or(NSRange::invalid(), |range| range.into())
}

extern "C" fn selected_range(this: &Object, _: Sel) -> NSRange {
    let selected_range_result = with_input_handler(this, |input_handler| {
        input_handler.selected_text_range(false)
    })
    .flatten();

    selected_range_result.map_or(NSRange::invalid(), |selection| selection.range.into())
}

extern "C" fn first_rect_for_character_range(
    this: &Object,
    _: Sel,
    range: NSRange,
    _: id,
) -> NSRect {
    let frame = get_frame(this);
    with_input_handler(this, |input_handler| {
        input_handler.bounds_for_range(range.to_range()?)
    })
    .flatten()
    .map_or(
        NSRect::new(NSPoint::new(0., 0.), NSSize::new(0., 0.)),
        |bounds| {
            NSRect::new(
                NSPoint::new(
                    frame.origin.x + bounds.origin.x.as_f32() as f64,
                    frame.origin.y + frame.size.height
                        - bounds.origin.y.as_f32() as f64
                        - bounds.size.height.as_f32() as f64,
                ),
                NSSize::new(
                    bounds.size.width.as_f32() as f64,
                    bounds.size.height.as_f32() as f64,
                ),
            )
        },
    )
}

fn get_frame(this: &Object) -> NSRect {
    unsafe {
        let state = get_window_state(this);
        let lock = state.lock();
        let mut frame = NSWindow::frame(lock.native_window);
        let content_layout_rect: CGRect = msg_send![lock.native_window, contentLayoutRect];
        let style_mask: NSWindowStyleMask = msg_send![lock.native_window, styleMask];
        if !style_mask.contains(NSWindowStyleMask::NSFullSizeContentViewWindowMask) {
            frame.origin.y -= frame.size.height - content_layout_rect.size.height;
        }
        frame
    }
}

extern "C" fn insert_text(this: &Object, _: Sel, text: id, replacement_range: NSRange) {
    unsafe {
        let is_attributed_string: BOOL =
            msg_send![text, isKindOfClass: [class!(NSAttributedString)]];
        let text: id = if is_attributed_string == YES {
            msg_send![text, string]
        } else {
            text
        };

        let text = text.to_str();
        let replacement_range = replacement_range.to_range();
        with_input_handler(this, |input_handler| {
            input_handler.replace_text_in_range(replacement_range, text)
        });
    }
}

extern "C" fn set_marked_text(
    this: &Object,
    _: Sel,
    text: id,
    selected_range: NSRange,
    replacement_range: NSRange,
) {
    unsafe {
        let is_attributed_string: BOOL =
            msg_send![text, isKindOfClass: [class!(NSAttributedString)]];
        let text: id = if is_attributed_string == YES {
            msg_send![text, string]
        } else {
            text
        };
        let selected_range = selected_range.to_range();
        let replacement_range = replacement_range.to_range();
        let text = text.to_str();
        with_input_handler(this, |input_handler| {
            input_handler.replace_and_mark_text_in_range(replacement_range, text, selected_range)
        });
    }
}
extern "C" fn unmark_text(this: &Object, _: Sel) {
    with_input_handler(this, |input_handler| input_handler.unmark_text());
}

extern "C" fn attributed_substring_for_proposed_range(
    this: &Object,
    _: Sel,
    range: NSRange,
    actual_range: *mut c_void,
) -> id {
    with_input_handler(this, |input_handler| {
        let range = range.to_range()?;
        if range.is_empty() {
            return None;
        }
        let mut adjusted: Option<Range<usize>> = None;

        let selected_text = input_handler.text_for_range(range.clone(), &mut adjusted)?;
        if let Some(adjusted) = adjusted
            && adjusted != range
        {
            unsafe { (actual_range as *mut NSRange).write(NSRange::from(adjusted)) };
        }
        unsafe {
            let string: id = msg_send![class!(NSAttributedString), alloc];
            let string: id = msg_send![string, initWithString: ns_string(&selected_text)];
            Some(string)
        }
    })
    .flatten()
    .unwrap_or(nil)
}

// We ignore which selector it asks us to do because the user may have
// bound the shortcut to something else.
extern "C" fn do_command_by_selector(this: &Object, _: Sel, _: Sel) {
    let state = unsafe { get_window_state(this) };
    let mut lock = state.as_ref().lock();
    let keystroke = lock.keystroke_for_do_command.take();
    let mut event_callback = lock.event_callback.take();
    drop(lock);

    if let Some((keystroke, callback)) = keystroke.zip(event_callback.as_mut()) {
        let handled = (callback)(PlatformInput::KeyDown(KeyDownEvent {
            keystroke,
            is_held: false,
            prefer_character_input: false,
        }));
        state.as_ref().lock().do_command_handled = Some(!handled.propagate);
    }

    state.as_ref().lock().event_callback = event_callback;
}

extern "C" fn view_did_change_effective_appearance(this: &Object, _: Sel) {
    // The reentrancy hazard here (`setAppearance:` fires this observer
    // synchronously, so a programmatic appearance change made while GPUI holds
    // an `App` borrow would re-enter it) is handled upstream in
    // `gpui::Window`'s `on_appearance_changed` callback, which defers the
    // update onto the foreground executor.
    unsafe {
        let state = get_window_state(this);
        let appearance_changed_callback = {
            let mut lock = state.as_ref().lock();
            lock.appearance_changed_callback.take()
        };

        if let Some(mut callback) = appearance_changed_callback {
            callback();
            state.lock().appearance_changed_callback = Some(callback);
        }

        // AppKit can relayout the standard traffic light buttons as part of
        // applying a new appearance, so reapply GPUI's custom position.
        state.lock().move_traffic_light();
    }
}

extern "C" fn accepts_first_mouse(this: &Object, _: Sel, _: id) -> BOOL {
    let window_state = unsafe { get_window_state(this) };
    let mut lock = window_state.as_ref().lock();
    lock.first_mouse = true;
    YES
}

// Reports which region of the view AppKit should treat as app-owned titlebar content
// (rather than a system-owned window-move region). When `app_owns_titlebar_drag` is
// true, we claim the entire view so AppKit neither drags the window from the titlebar
// nor waits to disambiguate double-clicks before delivering titlebar clicks (the macOS
// 27 delay); such windows implement dragging themselves via [`Window::start_window_move`].
// Otherwise we return an empty rect so AppKit's native titlebar dragging keeps working.
// This is independent of `NSWindow.isMovable`, so the Window-menu tiling items stay
// enabled regardless.
extern "C" fn opaque_rect_for_window_move_when_in_titlebar(this: &Object, _: Sel) -> NSRect {
    let zero_rect = NSRect::new(NSPoint::new(0., 0.), NSSize::new(0., 0.));
    let window_state = unsafe { get_window_state(this) };
    let app_owns_titlebar_drag = window_state.as_ref().lock().app_owns_titlebar_drag;
    if app_owns_titlebar_drag {
        unsafe { msg_send![this, bounds] }
    } else {
        zero_rect
    }
}

extern "C" fn character_index_for_point(this: &Object, _: Sel, position: NSPoint) -> u64 {
    let position = screen_point_to_gpui_point(this, position);
    with_input_handler(this, |input_handler| {
        input_handler.character_index_for_point(position)
    })
    .flatten()
    .map(|index| index as u64)
    .unwrap_or(NSNotFound as u64)
}

fn screen_point_to_gpui_point(this: &Object, position: NSPoint) -> Point<Pixels> {
    let frame = get_frame(this);
    let window_x = position.x - frame.origin.x;
    let window_y = frame.size.height - (position.y - frame.origin.y);

    point(px(window_x as f32), px(window_y as f32))
}

fn is_drag_from_this_window(this: &Object, dragging_info: id) -> bool {
    let source: id = unsafe { msg_send![dragging_info, draggingSource] };
    std::ptr::eq(source as *const Object, this as *const Object)
}

extern "C" fn dragging_entered(this: &Object, _: Sel, dragging_info: id) -> NSDragOperation {
    let is_source_window = is_drag_from_this_window(this, dragging_info);
    let window_state = unsafe { get_window_state(this) };
    let position = drag_event_position(&window_state, dragging_info);
    let paths = external_paths_from_event(dragging_info);
    if let Some(event) = paths.map(|paths| FileDropEvent::Entered { position, paths })
        && send_file_drop_event(window_state, event)
    {
        if is_source_window {
            return NSDragOperationMove;
        }
        return NSDragOperationCopy;
    }
    NSDragOperationNone
}

extern "C" fn dragging_updated(this: &Object, _: Sel, dragging_info: id) -> NSDragOperation {
    let is_source_window = is_drag_from_this_window(this, dragging_info);
    let window_state = unsafe { get_window_state(this) };
    let position = drag_event_position(&window_state, dragging_info);
    if send_file_drop_event(window_state, FileDropEvent::Pending { position }) {
        if is_source_window {
            NSDragOperationMove
        } else {
            NSDragOperationCopy
        }
    } else {
        NSDragOperationNone
    }
}

extern "C" fn dragging_exited(this: &Object, _: Sel, _: id) {
    let window_state = unsafe { get_window_state(this) };
    send_file_drop_event(window_state, FileDropEvent::Exited);
}

extern "C" fn perform_drag_operation(this: &Object, _: Sel, dragging_info: id) -> BOOL {
    let window_state = unsafe { get_window_state(this) };
    let position = drag_event_position(&window_state, dragging_info);
    send_file_drop_event(window_state, FileDropEvent::Submit { position }).to_objc()
}

fn external_paths_from_event(dragging_info: *mut Object) -> Option<ExternalPaths> {
    let mut paths = SmallVec::new();
    let pasteboard: id = unsafe { msg_send![dragging_info, draggingPasteboard] };
    let filenames = unsafe { NSPasteboard::propertyListForType(pasteboard, NSFilenamesPboardType) };
    if filenames == nil {
        return None;
    }
    for file in unsafe { filenames.iter() } {
        let path = unsafe {
            let f = NSString::UTF8String(file);
            CStr::from_ptr(f).to_string_lossy().into_owned()
        };
        paths.push(PathBuf::from(path))
    }
    Some(ExternalPaths(paths))
}

extern "C" fn conclude_drag_operation(this: &Object, _: Sel, _: id) {
    let window_state = unsafe { get_window_state(this) };
    send_file_drop_event(window_state, FileDropEvent::Exited);
}

extern "C" fn dragging_session_source_operation_mask(
    _: &Object,
    _: Sel,
    _: id,
    context: NSInteger,
) -> NSDragOperation {
    let operation = match context {
        NSDRAGGING_CONTEXT_OUTSIDE_APPLICATION => NSDragOperationCopy,
        NSDRAGGING_CONTEXT_WITHIN_APPLICATION => NSDragOperationCopy | NSDragOperationMove,
        _ => NSDragOperationCopy | NSDragOperationMove,
    };
    log::debug!(
        "dragging_session_source_operation_mask: context={}, operation={}",
        context,
        operation
    );
    operation
}

extern "C" fn dragging_session_ended(
    this: &Object,
    _: Sel,
    _: id,
    _: NSPoint,
    operation: NSDragOperation,
) {
    log::debug!("dragging_session_ended operation={operation}");
    // SAFETY: AppKit invokes this selector on the GPUIWindow instance registered in build_classes,
    // which always has WINDOW_STATE_IVAR initialized to the owning MacWindowState.
    let window_state = unsafe { get_window_state(this) };
    {
        let mut lock = window_state.lock();
        lock.synthetic_drag_counter += 1;
        lock.last_left_mouse_down_event = None;
    }
    send_file_drop_event(window_state, FileDropEvent::Ended);
}

fn synthetic_drag_button_is_pressed(button: Option<MouseButton>, pressed: NSUInteger) -> bool {
    let bit = match button {
        Some(MouseButton::Left) => 0,
        Some(MouseButton::Right) => 1,
        Some(MouseButton::Middle) => 2,
        Some(MouseButton::Navigate(gpui::NavigationDirection::Back)) => 3,
        Some(MouseButton::Navigate(gpui::NavigationDirection::Forward)) => 4,
        None => return false,
    };
    pressed & (1 << bit) != 0
}

async fn synthetic_drag(
    window_state: Weak<Mutex<MacWindowState>>,
    drag_id: usize,
    event: MouseMoveEvent,
    executor: BackgroundExecutor,
) {
    loop {
        executor.timer(Duration::from_millis(16)).await;
        let Some(window_state) = window_state.upgrade() else {
            break;
        };
        let mut lock = window_state.lock();
        if lock.synthetic_drag_counter != drag_id {
            break;
        }
        // Native menu tracking can consume mouse-up, leaving stale drag events replaying.
        // Check whether the original mouse button is still physically pressed before replaying.
        let pressed: NSUInteger = unsafe { msg_send![class!(NSEvent), pressedMouseButtons] };
        if !synthetic_drag_button_is_pressed(event.pressed_button, pressed) {
            lock.synthetic_drag_counter += 1;
            break;
        }
        if let Some(mut callback) = lock.event_callback.take() {
            drop(lock);
            callback(PlatformInput::MouseMove(event.clone()));
            window_state.lock().event_callback = Some(callback);
        }
    }
}

/// Sends the specified FileDropEvent using `PlatformInput::FileDrop` to the window
/// state and updates the window state according to the event passed.
fn send_file_drop_event(
    window_state: Arc<Mutex<MacWindowState>>,
    file_drop_event: FileDropEvent,
) -> bool {
    let external_files_dragged = match file_drop_event {
        FileDropEvent::Entered { .. } => Some(true),
        FileDropEvent::Exited | FileDropEvent::Ended => Some(false),
        _ => None,
    };

    let mut lock = window_state.lock();
    if let Some(mut callback) = lock.event_callback.take() {
        drop(lock);
        callback(PlatformInput::FileDrop(file_drop_event));
        let mut lock = window_state.lock();
        lock.event_callback = Some(callback);
        if let Some(external_files_dragged) = external_files_dragged {
            lock.external_files_dragged = external_files_dragged;
        }
        true
    } else {
        false
    }
}

fn drag_event_position(window_state: &Mutex<MacWindowState>, dragging_info: id) -> Point<Pixels> {
    let drag_location: NSPoint = unsafe { msg_send![dragging_info, draggingLocation] };
    convert_mouse_position(drag_location, window_state.lock().content_size().height)
}

fn with_input_handler<F, R>(window: &Object, f: F) -> Option<R>
where
    F: FnOnce(&mut PlatformInputHandler) -> R,
{
    let window_state = unsafe { get_window_state(window) };
    let mut lock = window_state.as_ref().lock();
    if let Some(mut input_handler) = lock.input_handler.take() {
        drop(lock);
        let result = f(&mut input_handler);
        window_state.lock().input_handler = Some(input_handler);
        Some(result)
    } else {
        None
    }
}

fn display_id_for_screen(screen: id) -> Option<CGDirectDisplayID> {
    if screen.is_null() {
        return None;
    }

    unsafe {
        let device_description = NSScreen::deviceDescription(screen);
        let screen_number_key: id = ns_string("NSScreenNumber");
        let screen_number = device_description.objectForKey_(screen_number_key);
        let screen_number: NSUInteger = msg_send![screen_number, unsignedIntegerValue];
        Some(screen_number as CGDirectDisplayID)
    }
}

extern "C" fn blurred_view_init_with_frame(this: &Object, _: Sel, frame: NSRect) -> id {
    unsafe {
        let view = msg_send![super(this, class!(NSVisualEffectView)), initWithFrame: frame];
        // Use a colorless semantic material. The default value `AppearanceBased`, though not
        // manually set, is deprecated.
        NSVisualEffectView::setMaterial_(view, NSVisualEffectMaterial::Selection);
        NSVisualEffectView::setState_(view, NSVisualEffectState::Active);
        view
    }
}

extern "C" fn blurred_view_update_layer(this: &Object, _: Sel) {
    unsafe {
        let _: () = msg_send![super(this, class!(NSVisualEffectView)), updateLayer];
        let layer: id = msg_send![this, layer];
        if !layer.is_null() {
            remove_layer_background(layer);
        }
    }
}

unsafe fn remove_layer_background(layer: id) {
    unsafe {
        let _: () = msg_send![layer, setBackgroundColor:nil];

        let class_name: id = msg_send![layer, className];
        if class_name.isEqualToString("CAChameleonLayer") {
            // Remove the desktop tinting effect.
            let _: () = msg_send![layer, setHidden: YES];
            return;
        }

        let filters: id = msg_send![layer, filters];
        if !filters.is_null() {
            // Remove the increased saturation.
            // The effect of a `CAFilter` or `CIFilter` is determined by its name, and the
            // `description` reflects its name and some parameters. Currently `NSVisualEffectView`
            // uses a `CAFilter` named "colorSaturate". If one day they switch to `CIFilter`, the
            // `description` will still contain "Saturat" ("... inputSaturation = ...").
            let test_string: id = ns_string("Saturat");
            let count = NSArray::count(filters);
            for i in 0..count {
                let description: id = msg_send![filters.objectAtIndex(i), description];
                let hit: BOOL = msg_send![description, containsString: test_string];
                if hit == NO {
                    continue;
                }

                let all_indices = NSRange {
                    location: 0,
                    length: count,
                };
                let indices: id = msg_send![class!(NSMutableIndexSet), indexSet];
                let _: () = msg_send![indices, addIndexesInRange: all_indices];
                let _: () = msg_send![indices, removeIndex:i];
                let filtered: id = msg_send![filters, objectsAtIndexes: indices];
                let _: () = msg_send![layer, setFilters: filtered];
                break;
            }
        }

        let sublayers: id = msg_send![layer, sublayers];
        if !sublayers.is_null() {
            let count = NSArray::count(sublayers);
            for i in 0..count {
                let sublayer = sublayers.objectAtIndex(i);
                remove_layer_background(sublayer);
            }
        }
    }
}

extern "C" fn add_titlebar_accessory_view_controller(this: &Object, _: Sel, view_controller: id) {
    unsafe {
        let _: () = msg_send![super(this, class!(NSWindow)), addTitlebarAccessoryViewController: view_controller];

        // Hide the native tab bar and set its height to 0, since we render our own.
        let accessory_view: id = msg_send![view_controller, view];
        let _: () = msg_send![accessory_view, setHidden: YES];
        let mut frame: NSRect = msg_send![accessory_view, frame];
        frame.size.height = 0.0;
        let _: () = msg_send![accessory_view, setFrame: frame];
    }
}

extern "C" fn move_tab_to_new_window(this: &Object, _: Sel, _: id) {
    unsafe {
        let _: () = msg_send![super(this, class!(NSWindow)), moveTabToNewWindow:nil];

        let window_state = get_window_state(this);
        let mut lock = window_state.as_ref().lock();
        if let Some(mut callback) = lock.move_tab_to_new_window_callback.take() {
            drop(lock);
            callback();
            window_state.lock().move_tab_to_new_window_callback = Some(callback);
        }
    }
}

extern "C" fn merge_all_windows(this: &Object, _: Sel, _: id) {
    unsafe {
        let _: () = msg_send![super(this, class!(NSWindow)), mergeAllWindows:nil];

        let window_state = get_window_state(this);
        let mut lock = window_state.as_ref().lock();
        if let Some(mut callback) = lock.merge_all_windows_callback.take() {
            drop(lock);
            callback();
            window_state.lock().merge_all_windows_callback = Some(callback);
        }
    }
}

extern "C" fn select_next_tab(this: &Object, _sel: Sel, _id: id) {
    let window_state = unsafe { get_window_state(this) };
    let mut lock = window_state.as_ref().lock();
    if let Some(mut callback) = lock.select_next_tab_callback.take() {
        drop(lock);
        callback();
        window_state.lock().select_next_tab_callback = Some(callback);
    }
}

extern "C" fn select_previous_tab(this: &Object, _sel: Sel, _id: id) {
    let window_state = unsafe { get_window_state(this) };
    let mut lock = window_state.as_ref().lock();
    if let Some(mut callback) = lock.select_previous_tab_callback.take() {
        drop(lock);
        callback();
        window_state.lock().select_previous_tab_callback = Some(callback);
    }
}

extern "C" fn toggle_tab_bar(this: &Object, _sel: Sel, _id: id) {
    unsafe {
        let _: () = msg_send![super(this, class!(NSWindow)), toggleTabBar:nil];

        let window_state = get_window_state(this);
        let mut lock = window_state.as_ref().lock();
        lock.move_traffic_light();

        if let Some(mut callback) = lock.toggle_tab_bar_callback.take() {
            drop(lock);
            callback();
            window_state.lock().toggle_tab_bar_callback = Some(callback);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn display_id_for_screen_returns_none_for_null_screen() {
        assert_eq!(display_id_for_screen(nil), None);
    }
}
