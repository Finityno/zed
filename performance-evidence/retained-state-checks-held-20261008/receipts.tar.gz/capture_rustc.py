#!/usr/bin/env python3
import os,sys,json,pathlib
if '--crate-name' in sys.argv and sys.argv[sys.argv.index('--crate-name')+1] == 'gpui' and '--test' in sys.argv:
    name='baseline' if any('baseline-workspace' in arg for arg in sys.argv)  else 'candidate'
    path=pathlib.Path('/workspace/scratch/gpui-state-loop')/(name+'-rustc-command.json')
    selected=['CARGO_MANIFEST_DIR','CARGO_MANIFEST_PATH','CARGO_PKG_NAME','CARGO_PKG_VERSION','CARGO_PKG_AUTHORS','CARGO_PKG_DESCRIPTION','CARGO_PKG_HOMEPAGE','CARGO_PKG_LICENSE','CARGO_PKG_LICENSE_FILE','CARGO_PKG_README','CARGO_PKG_REPOSITORY','OUT_DIR']
    path.write_text(json.dumps({'cwd':os.getcwd(),'args':sys.argv[1:],'environment':{k:v for k,v in os.environ.items() if k in selected or k.startswith('CARGO_PKG_')}},indent=2)+'\n')
os.execv(sys.argv[1],sys.argv[1:])
