
#[cfg(target_os = "linux")]
#[path = "layout_owner_profile.rs"]
mod layout_owner_profile;

#[cfg(target_os = "linux")]
#[path = "transcript_profile.rs"]
mod transcript_profile;

#[path = "color_profile.rs"]
mod color_profile;

#[path = "records_profile.rs"]
mod records_profile;
