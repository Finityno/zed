from pathlib import Path
import gzip, hashlib, json, os, subprocess

root = Path(__file__).parent
snapshot = subprocess.check_output(['ps', '-eo', 'pid,stat,comm,args'], text=True)
for line in snapshot.splitlines()[1:]:
    values = line.split(None, 3)
    if len(values) != 4 or values[1].startswith('Z') or int(values[0]) == os.getpid():
        continue
    assert not values[2].startswith('gpui-')
    if values[2].startswith('python'):
        assert not any(name in values[3] for name in ['measure.py', 'measure_diagnostic.py'])
dependencies = json.loads((root / 'comparison/external-dependencies.json').read_text())
protected = {Path(item['path']).resolve() for item in dependencies}
directories = [Path('/workspace/scratch/gpui-nested-loop') / lane / 'target/debug/deps' for lane in ['baseline-workspace', 'candidate-workspace']]
configuration = json.loads(Path('/workspace/scratch/gpui-splice-state-loop/baseline-rustc-command.json').read_text())
assert all(str(directory) not in ' '.join(configuration['args']) for directory in directories)
for item in dependencies:
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256']
paths = sorted([path for directory in directories for path in directory.iterdir() if path.is_file() and not path.is_symlink() and path.suffix in ['.rlib', '.rmeta'] and path.resolve() not in protected], key=lambda path: path.stat().st_size, reverse=True)
rows = []
reclaimed = 0
receipt_path = root / 'completed-inactive-nested-cache-preservation.json'
assert not receipt_path.exists()
for path in paths:
    status = path.stat()
    output = path.with_name(path.name + '.preserved.gz')
    assert not output.exists()
    digest = hashlib.sha256()
    with path.open('rb') as data, output.open('wb') as stream:
        with gzip.GzipFile(fileobj=stream, mode='wb', compresslevel=6, mtime=status.st_mtime) as compressed:
            while chunk := data.read(1024 * 1024):
                digest.update(chunk)
                compressed.write(chunk)
    roundtrip = hashlib.sha256()
    count = 0
    with gzip.open(output, 'rb') as data:
        while chunk := data.read(1024 * 1024):
            roundtrip.update(chunk)
            count += len(chunk)
    assert roundtrip.hexdigest() == digest.hexdigest() and count == status.st_size
    row = {'path': str(path), 'sha256': digest.hexdigest(), 'bytes': count, 'mode': status.st_mode & 0o777, 'mtime_ns': status.st_mtime_ns, 'gzip': str(output), 'gzip_bytes': output.stat().st_size, 'gzip_sha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'roundtrip_verified': True}
    path.unlink()
    rows.append(row)
    reclaimed += row['bytes'] - row['gzip_bytes']
    receipt_path.write_text(json.dumps({'files': rows, 'reclaimed_bytes': reclaimed, 'only_own_completed_empty_nested_iteration_cache': True, 'native_library_search_roots_untouched': True, 'no_timing_or_profiling_active': True, 'concurrent_scoped_build_allowed': True, 'process_snapshot': snapshot, 'complete': False}, indent=2) + '\n')
    if reclaimed >= 600 * 1024 * 1024:
        break
for item in dependencies:
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256']
receipt = json.loads(receipt_path.read_text())
receipt.update({'complete': True, 'protected59_before_after_verified': True})
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print({'files': len(rows), 'reclaimed_bytes': reclaimed, 'protected59_before_after_verified': True})
