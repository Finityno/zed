from pathlib import Path
import json, hashlib, gzip, shutil, time, os
root = Path(__file__).parent
comparison = root / 'comparison'
assert json.loads((comparison / 'final-native-builds-receipt.json').read_text())['exit_code'] == 0
save = comparison / 'initial-supplement-compiled-fixtures'
save.mkdir()
for lane in ['baseline', 'candidate']:
    for kind in ['bare', 'census']:
        name = f'{lane}-{kind}'
        folder = comparison / (name + '-artifacts')
        binary = folder / 'gpui-ada3fb4d7b1cfe56'
        metadata = binary.stat(); digest = hashlib.sha256(binary.read_bytes()).hexdigest()
        target = binary.with_name(binary.name + '.preserved.gz')
        with binary.open('rb') as source, target.open('xb') as raw:
            with gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=1, mtime=0) as packed:
                shutil.copyfileobj(source, packed, 1024 * 1024)
        digest_after = hashlib.sha256()
        with gzip.open(target, 'rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''): digest_after.update(block)
        assert digest_after.hexdigest() == digest
        (folder / 'native-preservation.json').write_text(json.dumps({'path':str(binary),'sha256':digest,'bytes':metadata.st_size,'mode':metadata.st_mode,'mtime_ns':metadata.st_mtime_ns,'gzip_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'verified_roundtrip':True},indent=2)+'\n')
        binary.unlink()
        shutil.move(folder, save / folder.name)
for name in ['candidate-preflight-receipts.json','candidate-case-preflight-receipts.json','candidate-case-preflight','candidate-preflight-0.log','candidate-preflight-1.log','candidate-preflight-2.log','final-native-build-order.json','final-native-builds.log','final-native-builds-receipt.json','final-native-builds-detached-launch.json','final-native-builds-detached-launch.log']:
    path = comparison / name
    if path.exists(): shutil.move(path,save / name)
for lane in ['baseline','candidate']:
    shutil.copy2(comparison / (lane+'-source-inputs.json'),save / (lane+'-source-inputs.json'))
    for kind in ['bare','census']:
        for suffix in ['-build.log','-build-receipt.json']:
            path=comparison/(lane+'-'+kind+suffix);shutil.move(path,save / path.name)
    source = comparison / (lane+'-workspace/crates/gpui/src/window/view_retention/splice_profile.rs')
    shutil.copy2(source,save / (lane+'-splice_profile.rs'))
    source.write_text(source.read_text()+'\n'+(root/'shared-bounded-window-profile.rs').read_text())
    profile = comparison / (lane+'-workspace/crates/gpui/src/window/view_retention/dependency_profile.rs')
    shutil.copy2(profile,save / (lane+'-dependency_profile.rs'))
    text=profile.read_text()
    old='        println!("STATE_PROFILE {{\\"case\\":{case:?},'
    assert text.count(old)==1
    text=text.replace(old,'        let current_rss_kib = crate::perf_count::native_current_rss_kib();\n'+old)
    text=text.replace('STATE_PROFILE {{\\"case\\":{case:?},\\"iterations\\":{iterations},','STATE_PROFILE {{\\"case\\":{case:?},\\"iterations\\":{iterations},\\"current_rss_kib\\":{current_rss_kib},')
    profile.write_text(text)
    manifest=comparison/(lane+'-source-inputs.json');data=json.loads(manifest.read_text())
    for rel in ['crates/gpui/src/window/view_retention/splice_profile.rs','crates/gpui/src/window/view_retention/dependency_profile.rs']:
        data['files'][rel]=hashlib.sha256((comparison/(lane+'-workspace')/rel).read_bytes()).hexdigest()
    manifest.write_text(json.dumps(data,indent=2)+'\n')
(root/'shared-state-profile.rs').write_text((comparison/'baseline-workspace/crates/gpui/src/window/view_retention/dependency_profile.rs').read_text())
(root/'prepaired-fixture-contract-correction.json').write_text(json.dumps({'before_any_paired_sample':True,'production_source_unchanged':'9244e2fcd9611a5e8950f2fd3abed6dba65fcaa9','frozen_policy_unchanged':hashlib.sha256((comparison/'policy.json').read_bytes()).hexdigest(),'audit_finding':'Initial supplemental module lacked concrete Window resize/state-bump/off-keep case implementation, and initial state profile omitted current RSS. All four successful unpaired binaries and their complete receipts are preserved with gzip roundtrip hashes. Add a shared explicit complete-Window fixture for all twelve frozen cases and current RSS outside component timed/counting interval. These fixture changes require new binaries before first paired cohort; no experiment resampling or gate weakening.','preserved_at':str(save),'time_unix':time.time()},indent=2)+'\n')
preflight=comparison/'preflight.py';text=preflight.read_text();text+='''
for case in policy['complete_window_bare_controls']:
    command = [binary, 'profile_bounded_state_frames', '--ignored', '--nocapture', '--test-threads=1']
    log = out / ('window-' + case + '.log')
    with log.open('x') as stream:
        code = subprocess.run(command, env=os.environ | {'BOUNDED_WINDOW_CASE': case, 'BOUNDED_WINDOW_ITERATIONS': '2'}, stdout=stream, stderr=subprocess.STDOUT, timeout=60).returncode
    cases.append({'case': case, 'scope': 'window', 'command': command, 'exit_code': code, 'log': str(log), 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(), 'single_contract_only': True})
    (root / 'candidate-case-preflight-receipts.json').write_text(json.dumps(cases, indent=2) + '\\n')
    assert code == 0 and 'BOUNDED_WINDOW_PROFILE ' in log.read_text(), log.read_text()
print(json.dumps({'all54_candidate_contracts_pass': True, 'no_paired_metrics': True}))
''';preflight.write_text(text)
print('Final fixture contracts implemented before first paired samples; all previous compiled bins losslessly preserved')
