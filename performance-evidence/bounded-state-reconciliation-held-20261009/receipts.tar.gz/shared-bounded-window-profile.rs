#[test]
#[ignore]
fn profile_bounded_state_frames() {
    let case = std::env::var("BOUNDED_WINDOW_CASE").expect("case");
    let iterations: usize = std::env::var("BOUNDED_WINDOW_ITERATIONS")
        .expect("iterations").parse().expect("iteration count");
    assert!(iterations > 0 && iterations.is_multiple_of(2));
    let rows: usize = case.rsplit('-').next().expect("count").parse().expect("count");
    assert!([32, 256].contains(&rows));
    let retained = !case.starts_with("off-");
    let scenario = case.strip_prefix("off-").unwrap_or(&case).rsplit_once('-').expect("scenario").0;
    assert!(["keep", "resize", "state-bump", "remove"].contains(&scenario));
    let mut cx = TestAppContext::single();
    cx.update(|cx| cx.set_view_retention(retained));
    let leaves: Vec<_> = (0..rows).map(|_| cx.new(|_| RemovalRow {
        present: true, identity: 0, height: 10.,
        dependency: (scenario == "state-bump").then(DrawDependency::new),
    })).collect();
    let panel = cx.new(|_| RemovalPanel(leaves.clone()));
    let window = cx.add_window(|_, _| RemovalShell(panel.clone()));
    cx.simulate_window_resize(window.into(), size(px(900.), px(1100.)));
    let frame = |cx: &mut TestAppContext| {
        cx.update_window(window.into(), |_, window, cx| window.draw(cx).clear(cx)).expect("draw");
    };
    for _ in 0..4 { frame(&mut cx); }
    let audit_frames = std::env::var_os("LAYOUT_AUDIT_FRAMES").is_some();
    let mut audit = Vec::with_capacity(if audit_frames { iterations } else { 0 });
    let started = Instant::now();
    let cpu_started = thread_cpu_ns();
    for iteration in 0..iterations {
        if scenario == "resize" {
            cx.simulate_window_resize(window.into(), size(px(900. + (iteration % 2) as f32 * 100.), px(1100.)));
        } else if scenario == "keep" {
            window.update(&mut cx, |_, _, cx| cx.notify()).expect("notify window");
        } else {
            cx.update(|cx| {
                for leaf in &leaves {
                    leaf.update(cx, |leaf, cx| {
                        if scenario == "state-bump" {
                            leaf.dependency.as_ref().expect("dependency").changed(cx);
                        } else {
                            leaf.present = iteration % 2 == 0;
                        }
                        cx.notify();
                    });
                }
            });
        }
        frame(&mut cx);
        if audit_frames {
            audit.push(cx.update_window(window.into(), |_, window, _| describe_frame(window)).expect("frame audit"));
        }
        black_box(&cx);
    }
    let cpu_ns = thread_cpu_ns() - cpu_started;
    let elapsed_ns = started.elapsed().as_nanos();
    let (nodes, node_high_water, state_count, state_box_bytes, signature) = cx.update_window(window.into(), |_, window, _| {
        let states = window.rendered_frame.element_states.iter().filter(|((id, _), _)| {
            matches!(id.0.last(), Some(crate::ElementId::NamedInteger(name, _)) if name.as_ref() == "profile-state")
        });
        let (state_count, state_box_bytes) = states.fold((0, 0), |(count, bytes), (_, state)| {
            (count + 1, bytes + std::mem::size_of_val(state.inner.as_ref()))
        });
        let mut hasher = std::collections::hash_map::DefaultHasher::new();
        describe_frame(window).hash(&mut hasher);
        let engine = window.layout_engine.as_ref().expect("engine");
        (engine.layout_owner_node_counts(), engine.layout_owner_node_high_water(), state_count, state_box_bytes, hasher.finish())
    }).expect("output owners");
    if audit_frames {
        let mut hasher = std::collections::hash_map::DefaultHasher::new();
        audit.hash(&mut hasher);
        println!("FRAME_AUDIT {}", hasher.finish());
    }
    let current_rss_kib = crate::perf_count::native_current_rss_kib();
    println!("BOUNDED_WINDOW_PROFILE {{\"case\":{case:?},\"iterations\":{iterations},\"retained\":{retained},\"nodes\":{nodes},\"node_high_water\":{node_high_water},\"state_count\":{state_count},\"state_box_bytes\":{state_box_bytes},\"signature\":{signature},\"cpu_ns\":{cpu_ns},\"elapsed_ns\":{elapsed_ns},\"current_rss_kib\":{current_rss_kib}}}");
}
