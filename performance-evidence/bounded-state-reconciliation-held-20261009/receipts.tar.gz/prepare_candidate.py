from pathlib import Path
import hashlib, json, os, shutil, subprocess

root = Path(__file__).parent
workspace = Path('/workspace/zed-bounded-state-checks')
path = 'crates/gpui/src/window/view_retention/dependencies.rs'
base = '08d5555709d7afab3936c7afcd9f7f0ff9ecbd65'
environment = os.environ | {'GIT_NO_LAZY_FETCH': '1'}
assert hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest() == (root / 'policy.sha256').read_text().strip()
assert (workspace / 'README.md').read_text().splitlines()[:2] == ['> [!IMPORTANT]', '> Remove this line to confirm you\'ve reviewed this PR before submitting.']
original = (workspace / path).read_text()
held = Path('/workspace/zed-state-reconcile') / path
held_source = held.read_text()
def method(source, name):
    start = source.index('    pub(crate) fn ' + name + '(')
    brace = source.index('{', start)
    depth = 1
    end = brace + 1
    while depth:
        depth += (source[end] == '{') - (source[end] == '}')
        end += 1
    return source[start:end], source[brace + 1:end - 1]
small, small_body = method(original, 'dependencies_changed_except')
normal, normal_body = method(original, 'dependencies_changed')
held_method, held_body = method(held_source, 'dependencies_changed_except')
guard = '\n        if dependencies.states.len() >= 64 {\n            return self.dependencies_changed_except_large(dependencies, inside_notified, now, except);\n        }'
updated_method = small.replace(small_body, guard + small_body, 1)
helper = '\n\n    #[inline(never)]\n' + held_method.replace('pub(crate) fn dependencies_changed_except(', 'fn dependencies_changed_except_large(', 1)
updated = original.replace(small, updated_method + helper, 1)
tests = held_source[held_source.index('#[cfg(test)]\nmod state_check_tests {'):]
assert 'for count in [0_usize, 1, 8, 64]' in tests
tests = tests.replace('for count in [0_usize, 1, 8, 64]', 'for count in [0_usize, 1, 8, 63, 64, 65, 128, 256]', 1)
assert 'for marker_index in [None, Some(0), Some(count / 2), count.checked_sub(1)] {' in tests
updated += '\n' + tests
assert method(updated, 'dependencies_changed')[0] == normal
assert method(updated, 'dependencies_changed_except')[1] == guard + small_body
(root / 'shared-state-regressions.rs').write_text(tests)
(workspace / path).write_text(updated)
subprocess.run(['git', 'diff', '--check'], cwd=workspace, env=environment, check=True)
subprocess.run(['git', 'add', path], cwd=workspace, env=environment, check=True)
subprocess.run(['git', 'commit', '-m', 'Bound state exception reconciliation to large retained dependency lists [skip ci]'], cwd=workspace, env=environment, check=True)
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=workspace, env=environment, text=True).strip()
tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=workspace, env=environment, text=True).strip()
(root / 'candidate-source-receipt.json').write_text(json.dumps({'source': source, 'tree': tree, 'baseline': base, 'files': {path: hashlib.sha256(updated.encode()).hexdigest()}, 'normal_checker_byte_exact': True, 'small_state_body_byte_exact_after_guard': True, 'threshold64_frozen': True, 'large_state_kernel_inline_never': True, 'normal_checker_sha256': hashlib.sha256(normal.encode()).hexdigest(), 'original_small_body_sha256': hashlib.sha256(small_body.encode()).hexdigest(), 'owned_held_large_kernel_body_sha256': hashlib.sha256(held_body.encode()).hexdigest(), 'no_heap_header_persistent_storage': True}, indent=2) + '\n')
comparison = root / 'comparison'
comparison.mkdir()
old = Path('/workspace/scratch/gpui-compact-line-records-loop/comparison')
for lane in ['baseline', 'candidate']:
    destination = comparison / (lane + '-workspace')
    shutil.copytree(old / 'baseline-workspace', destination)
    shutil.rmtree(destination / 'crates/gpui')
    shutil.copytree(workspace / 'crates/gpui', destination / 'crates/gpui')
    if lane == 'baseline':
        (destination / path).write_text(original + '\n' + tests)
    # Both profiles add exactly the same complete-App fixture to the current
    # owned dependency profiler; there is no production-state adapter.
    profile_path = 'crates/gpui/src/window/view_retention/dependency_profile.rs'
    prior = Path('/workspace/scratch/gpui-state-reconcile-loop/baseline-workspace') / profile_path
    profile = prior.read_text()
    profile = profile[profile.index('fn change_code('):]
    count_start = profile.index('    let count = match case.as_str() {')
    count_end = profile.index('    let expected =', count_start)
    profile = profile[:count_start] + '''    let count = case.rsplit('-').next().and_then(|value| value.parse::<usize>().ok()).unwrap_or_else(|| match case.as_str() {
        "normal-empty" | "except-empty" => 0,
        "except-only" | "except-deadline" | "except-global" | "except-entity" => 1,
        _ => panic!("unknown state profile case"),
    });
''' + profile[count_end:]
    profile = profile.replace('"except-changed-8" | "except-absent-changed-8" | "normal-changed-64" => 3,', '_ if case.starts_with("except-changed-") || case.starts_with("except-absent-changed-") || case.starts_with("normal-changed-") => 3,', 1)
    profile = profile.replace('if matches!(case.as_str(), "except-changed-8" | "except-absent-changed-8" | "normal-changed-64") {', 'if case.starts_with("except-changed-") || case.starts_with("except-absent-changed-") || case.starts_with("normal-changed-") {', 1)
    profile = profile.replace('        let check = |cx: &App| {', '        assert_eq!(dependencies.states.len(), count);\n        let check = |cx: &App| {', 1)
    current = destination / profile_path
    current.write_text(current.read_text() + '\n' + profile)
    (root / 'shared-state-profile.rs').write_text(profile)
    files = {str(file.relative_to(destination)): hashlib.sha256(file.read_bytes()).hexdigest() for file in destination.rglob('*') if file.is_file()}
    (comparison / (lane + '-source-inputs.json')).write_text(json.dumps({'baseline': base, 'files': files, 'only_shared_state_tests_and_native_profile_added': True}, indent=2) + '\n')
for name in ['policy.json', 'policy.sha256', 'candidate-source-receipt.json']:
    shutil.copy2(root / name, comparison / name)
for name in ['external-dependencies.json', 'compiler-dependency-identities.json', 'native-runtime-identity.json', 'native-run', 'supervise.py']:
    shutil.copy2(old / name, comparison / name)
script = Path('/workspace/scratch/gpui-state-reconcile-loop/build_native.py').read_text()
(comparison / 'build_native.py').write_text(script)
baseline_files = json.loads((comparison / 'baseline-source-inputs.json').read_text())['files']
candidate_files = json.loads((comparison / 'candidate-source-inputs.json').read_text())['files']
assert set(baseline_files) == set(candidate_files)
different = [name for name in baseline_files if baseline_files[name] != candidate_files[name]]
assert different == [path], different
(root / 'source-equivalence.json').write_text(json.dumps({'source': source, 'baseline': base, 'different_compiled_files': different, 'same_full_current_owned_GPUI_source_except_candidate_method': True, 'all_added_fixtures_identical': True, 'normal_checker_byte_exact': True, 'small_body_byte_exact_after_threshold_guard': True, 'owned_large_kernel_body_unchanged_but_routed_only64plus_and_not_inlined': True, 'numerical_goals_frozen_before_source': True}, indent=2) + '\n')
handoff_path = Path('/workspace/scratch/gpui-fork-loop/handoff.json')
handoff = json.loads(handoff_path.read_text())
next_iteration = {'workspace': str(workspace), 'branch': 'perf/bounded-state-reconciliation-20261009', 'directory': str(root), 'baseline': base, 'policy_sha256': (root / 'policy.sha256').read_text().strip(), 'source': source, 'tree': tree, 'active_stage': 'Distinct outlined large-state64plus reconciliation prepared; normal and original small body byte exact, first candidate native build next; no paired samples yet.', 'active_session': None}
handoff.update({'workspace': str(workspace), 'branch': next_iteration['branch'], 'iteration_directory': str(root), 'active_workspace': str(workspace), 'active_branch': next_iteration['branch'], 'active_iteration': str(root), 'candidate_source': source, 'policy_sha256': next_iteration['policy_sha256'], 'next_iteration': next_iteration, 'active_session': None, 'active_supervisor_pid': None, 'phase': next_iteration['active_stage']})
handoff_path.write_text(json.dumps(handoff, indent=2) + '\n')
print({'source': source, 'tree': tree, 'different_compiled_files': different})
