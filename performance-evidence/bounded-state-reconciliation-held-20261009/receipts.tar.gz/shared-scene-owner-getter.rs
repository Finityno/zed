    pub(crate) fn diagnostic_record_owner(&self) -> serde_json::Value {
        serde_json::json!({"length":self.paint_operations.len(),"capacity":self.paint_operations.capacity(),"width":std::mem::size_of::<PaintOperation>(),"bytes":self.paint_operations.capacity()*std::mem::size_of::<PaintOperation>(),"scene_width":std::mem::size_of::<Scene>(),"window_width":std::mem::size_of::<crate::Window>()})
    }

    pub(crate) fn diagnostic_expanded_paint_index(&self, index: usize) -> usize { index.min(self.paint_operations.len()) }

    pub(crate) fn diagnostic_record_owner_tuple(&self) -> (usize, usize, usize, usize, usize, usize) {
        (self.paint_operations.len(), self.paint_operations.capacity(), std::mem::size_of::<PaintOperation>(), self.paint_operations.capacity()*std::mem::size_of::<PaintOperation>(), std::mem::size_of::<Scene>(), std::mem::size_of::<crate::Window>())
    }

