from pathlib import Path
import hashlib, json, os, subprocess

root = Path(__file__).parent
binary = root / 'baseline-census-artifacts/gpui-ada3fb4d7b1cfe56'
identity = {'path': str(binary), 'bytes': binary.stat().st_size, 'sha256': hashlib.sha256(binary.read_bytes()).hexdigest()}
dependencies = json.loads((root / 'external-dependencies.json').read_text())
assert len(dependencies) == 59
for dependency in dependencies:
    assert hashlib.sha256(Path(dependency['path']).read_bytes()).hexdigest() == dependency['sha256']
(root / 'attribution-binary-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
output = root / 'attribution-receipts'
output.mkdir()
rows = []
for retained in [False, True]:
    for count in [0, 32, 1024, 16384, 131072]:
        environment = dict(os.environ, EFFECT_OWNER_COUNT=str(count), EFFECT_OWNER_RETAINED='1' if retained else '0')
        command = [str(root / 'native-run'), 'taskset', '-c', '2', str(binary), 'profile_effect_owner', '--ignored', '--nocapture', '--test-threads=1']
        log = output / f'{count}-{int(retained)}.log'
        with log.open('w') as stream:
            result = subprocess.run(command, env=environment, stdout=stream, stderr=subprocess.STDOUT, timeout=30)
        row = {'count': count, 'retained': retained, 'command': command, 'exit_code': result.returncode, 'binary_sha256': identity['sha256'], 'log': str(log), 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
        for line in log.read_text().splitlines():
            if 'EFFECT_OWNER ' in line:
                row.update(json.loads(line.split('EFFECT_OWNER ', 1)[1]))
            if line.startswith('NATIVE_RECEIPT '):
                row.update(json.loads(line.split(' ', 1)[1]))
        rows.append(row)
        (root / 'attribution-samples.json').write_text(json.dumps(rows, indent=2) + '\n')
        assert row['exit_code'] == 0 and row.get('exact_callbacks') is True
        assert row['before_capacity'] == row['after_capacity'] and row['before_capacity'] >= count
print(json.dumps({'children': len(rows), 'exact_callbacks': True, 'owner': [{key: row[key] for key in ['count', 'retained', 'effect_size', 'owner_before_bytes', 'owner_after_bytes', 'held_bytes']} for row in rows]}))
