# Responsive large provider heap recordings

The profiler pointer-index goal is complete: repeated reuse preserves index
capacity, the exact-source component lowers CPU by more than 50%, and the
unchanged sampled 1,024-chat Codex/Claude replay passes the full original
transport/transcript/lifecycle oracle with two fresh heap captures. The
20% matched post-close app RSS goal remains open.

The original sampled large replay settled no panels before its 1,200-second
deadline, although cleanup passed. A zero-loss 20-second 99 Hz user CPU trace
attributed 92.07% self CPU to `_mi_prof_free`. The index never reused deleted
slots, so pointer churn built longer lookup chains and unnecessary capacity.
The repaired index searches beyond the first deleted slot for an existing key,
then reuses it. Live collision ownership, updates, probe bounds and refusal
after failed OS growth are retained. Three alternating 65,536-reuse component
pairs reduce median CPU from 717,228,139 to 417,047 ns and index storage from
786,432 to 12,288 bytes. Three real allocator profile contracts and strict
scoped Clippy pass.

## Native results

| Chats | Sampling | Elapsed | Sampled app CPU | Peak RSS | Closed-idle RSS | Live estimate before/after close |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| 4 | Disabled | 37.813 s | 11.66 s | 363 MB | 332 MB | — |
| 4 | 16 KiB | 37.977 s | 12.90 s | 390 MB | 380 MB | 26.8 / 14.5 MB |
| 32 | 16 KiB | 43.323 s | 23.04 s | 548 MB | 467 MB | 50.2 / 25.0 MB |
| 1,024 | 16 KiB | 501.313 s | 681.86 s | 3,339 MB | 3,184 MB | 407.8 / 90.2 MB |

All four cases pass 17,024 covered tool checks: exact output, tool identity and
status, sparse save, original-session reload, normal close, original child
cleanup and idle final collector. Recipes use 16 mixed 8 KiB tool payloads per
chat, 16 in flight, 1 ms pacing, 4,093-byte fragmented writes, distinct per-chat
fixtures, foreground heartbeat, fingerprint indexes, 30 seconds closed idle,
and the original 1,200-second/8 GiB guards. Half the large cohort uses Codex
app-server children, half Claude CLI children. No retries or payload padding.

The frozen ELF SHA is
`4d83ff07f36091e4481e264dd66f62606bd6765f2ccfecd9a280bb2931c41e06`;
all six actual heap phases match GNU identifier
`f84dd6877ee0a93d016052c381e729830c56e900`, period 16,384 bytes, and 100%
binary attribution. The combined capture branch is tree-identical to the
native-tested source; the combined change is squash-merged to main.

Sampling retains allocation-history buffers. Thus the sampled large closed
RSS is much larger than its estimated live ownership and cannot demonstrate
ordinary app memory savings. Its raw captures are 393,010,964 and 487,958,854
bytes. The bounded live views are 1,064,470 and 338,500 bytes, preserving every
positive live sample and all metadata. A fresh zero-loss CPU trace places
profiler free lookup at 3.14%; it includes a different phase, so that percentage
is diagnostic. Ordinary performance controls use sampling disabled.

## Priorities from actual ownership

1. Address physical retention after close with the original 20% app RSS and
   no-regression gates. The unsampled page census found about 977 MB total RSS
   after terminal pages reached zero: 453 MB in mimalloc-owned physical pages
   and 217 MB in the libc heap mapping. These labels and live weights do not
   prove every byte is reclaimable. Earlier one-shot native trim saved about
   163 MB but did not qualify the matched goal; terminal constructor candidates
   retain adverse CPU/timing evidence and remain held.
2. Qualify borrowed cached-part validation. The current diagnostic trace ranks
   memory comparison, SQLite index movement and record comparison among the
   largest remaining CPU sites. The candidate must preserve exact SQL types,
   nullable length, checksums/bytes, rewritten and corrupt rows, then improve
   repeated native validation CPU without higher app CPU/elapsed/closed RSS.
3. Examine terminal mirror creation at peak: the earlier physical census
   found about 1.19 GB of terminal pages and thousands of empty persistence
   mirrors. Preserve constructor failures, normalized/truncated output,
   status publication and sparse restoration in any lazy-creation design.
4. Rank retained Rust containers by lifecycle. The new large closed heap's
   first allocation sites include hash tables (15.5 MB), the GPUI effects queue
   (8.4 MB), observers (7.9 MB) and tool-analysis cache buckets (6.8 MB).
   Attribute their stacks and separate required session state from retained
   capacity before changing limits or observer lifetimes. Repeated cohorts
   within one app would test long-lived growth better than process restarts.

## Evidence and limits

[Machine-readable native and heap evidence](profiling/responsive-provider-heaps-20261007-evidence.json)
records source, frozen binary, archive hashes, measurements and failed outcomes.
Raw inputs, every-member-verified archives, profiles, perf recordings and
source/build/watchdog receipts remain under
`artifacts/profiling/linux-stress-20261006` in the owned workspace. All temporary
recordings and raw executables are restored and rehashed after each build.
Original deadline, linker/storage, analyzer and observer setup failures remain
separate from passing retries.

Validation runs directly in the connected OpenAI Linux executor, with external
process-group deadlines and selected build-first contracts. No validation
Actions, Namespace or devbox run is used. The GPUI harness exercises production
panels, transport, persistence and shutdown with controlled children and four
rendered panels. The complete Fincode entrypoint, real models/network behavior,
and native macOS/Windows execution remain outside this coverage.
