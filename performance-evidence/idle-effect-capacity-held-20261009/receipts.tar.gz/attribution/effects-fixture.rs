use super::*;
use std::{cell::Cell, rc::Rc};

#[test]
#[ignore]
fn profile_effect_owner() {
    let count: usize = std::env::var("EFFECT_OWNER_COUNT")
        .expect("EFFECT_OWNER_COUNT").parse().expect("effect count");
    let retained = std::env::var("EFFECT_OWNER_RETAINED").expect("EFFECT_OWNER_RETAINED") == "1";
    crate::perf_count::census::start();
    let mut cx = TestAppContext::single();
    cx.update(|cx| cx.set_view_retention(retained));
    let window = cx.add_window(|_, _| crate::Empty);
    for _ in 0..4 {
        cx.update_window(window.into(), |_, window, cx| window.draw(cx).clear(cx)).expect("warmup");
    }
    let progress = Rc::new(Cell::new((0usize, 0u64)));
    let (queued, queue_peak_capacity) = cx.update(|cx| {
        for index in 0..count {
            let progress = progress.clone();
            cx.defer(move |_| {
                let (completed, sum) = progress.get();
                assert_eq!(completed, index, "deferred callback order");
                progress.set((completed + 1, sum + index as u64));
            });
        }
        (cx.pending_effects.len(), cx.pending_effects.capacity())
    });
    assert_eq!(queued, count);
    assert_eq!(progress.get(), (count, (count as u64).saturating_mul(count.saturating_sub(1) as u64) / 2));
    assert_eq!(Rc::strong_count(&progress), 1, "all deferred closures released");
    let (drained, before_capacity) = cx.update(|cx| (cx.pending_effects.len(), cx.pending_effects.capacity()));
    assert_eq!(drained, 0);
    let (before_held, _, _, _) = crate::perf_count::census::snapshot();
    cx.executor().advance_clock(std::time::Duration::from_secs(3));
    cx.run_until_parked();
    let (after_len, after_capacity) = cx.update(|cx| (cx.pending_effects.len(), cx.pending_effects.capacity()));
    assert_eq!(after_len, 0);
    let (held_bytes, peak_bytes, requested_bytes, allocation_calls) = crate::perf_count::census::finish();
    let effect_size = std::mem::size_of::<Effect>();
    println!("EFFECT_OWNER {{\"count\":{count},\"retained\":{retained},\"queued\":{queued},\"queue_peak_capacity\":{queue_peak_capacity},\"before_capacity\":{before_capacity},\"after_capacity\":{after_capacity},\"effect_size\":{effect_size},\"owner_before_bytes\":{},\"owner_after_bytes\":{},\"before_held_bytes\":{before_held},\"held_bytes\":{held_bytes},\"peak_bytes\":{peak_bytes},\"requested_bytes\":{requested_bytes},\"allocation_calls\":{allocation_calls},\"exact_callbacks\":true}}", before_capacity * effect_size, after_capacity * effect_size);
}
