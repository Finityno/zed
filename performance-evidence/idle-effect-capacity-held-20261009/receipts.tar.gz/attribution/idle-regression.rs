
#[cfg(test)]
mod idle_effect_queue_tests {
    use super::*;

    struct DrawCount(Rc<Cell<usize>>);

    impl Render for DrawCount {
        fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl crate::IntoElement {
            self.0.set(self.0.get() + 1);
            crate::Empty
        }
    }

    fn enqueue(cx: &mut TestAppContext, count: usize) -> Rc<Cell<usize>> {
        let completed = Rc::new(Cell::new(0));
        cx.update(|cx| {
            for _ in 0..count {
                let completed = completed.clone();
                cx.defer(move |_| completed.set(completed.get() + 1));
            }
        });
        assert_eq!(completed.get(), count);
        assert_eq!(Rc::strong_count(&completed), 1);
        completed
    }

    fn capacity(cx: &mut TestAppContext) -> usize {
        cx.update(|cx| {
            assert!(cx.pending_effects.is_empty());
            cx.pending_effects.capacity()
        })
    }

    #[gpui::test]
    fn large_queue_releases_after_quiet_without_drawing(cx: &mut TestAppContext) {
        let draws = Rc::new(Cell::new(0));
        cx.add_window({
            let draws = draws.clone();
            move |_, _| DrawCount(draws)
        });
        enqueue(cx, 8193);
        assert!(capacity(cx) >= 8193);
        let before = draws.get();
        cx.executor().advance_clock(Duration::from_secs(31));
        cx.run_until_parked();
        assert!(capacity(cx) <= 256);
        assert_eq!(draws.get(), before, "reclaiming must not redraw a window");
    }

    #[gpui::test]
    fn effects_queued_during_a_flush_also_release(cx: &mut TestAppContext) {
        let completed = Rc::new(Cell::new(0));
        cx.update(|cx| {
            let completed = completed.clone();
            cx.defer(move |cx| {
                for _ in 0..8193 {
                    let completed = completed.clone();
                    cx.defer(move |_| completed.set(completed.get() + 1));
                }
            });
        });
        assert_eq!(completed.get(), 8193);
        assert_eq!(Rc::strong_count(&completed), 1);
        assert!(capacity(cx) >= 8193);
        cx.executor().advance_clock(Duration::from_secs(31));
        cx.run_until_parked();
        assert!(capacity(cx) <= 256);
    }

    #[gpui::test]
    fn another_large_burst_restarts_the_quiet_period(cx: &mut TestAppContext) {
        enqueue(cx, 8193);
        let high_water = capacity(cx);
        cx.executor().advance_clock(Duration::from_secs(20));
        enqueue(cx, 8193);
        cx.executor().advance_clock(Duration::from_secs(15));
        cx.run_until_parked();
        assert_eq!(capacity(cx), high_water);
        cx.executor().advance_clock(Duration::from_secs(16));
        cx.run_until_parked();
        assert!(capacity(cx) <= 256);
        enqueue(cx, 32);
        assert!(capacity(cx) >= 32);
    }

    #[gpui::test]
    fn small_background_updates_do_not_keep_a_large_buffer(cx: &mut TestAppContext) {
        enqueue(cx, 8193);
        cx.executor().advance_clock(Duration::from_secs(20));
        enqueue(cx, 32);
        cx.executor().advance_clock(Duration::from_secs(11));
        cx.run_until_parked();
        assert!(capacity(cx) <= 256);
    }

    #[gpui::test]
    fn ordinary_queue_capacity_is_preserved(cx: &mut TestAppContext) {
        enqueue(cx, 8192);
        let before = capacity(cx);
        cx.executor().advance_clock(Duration::from_secs(31));
        cx.run_until_parked();
        assert_eq!(capacity(cx), before);
    }

    #[gpui::test]
    fn notification_only_queue_also_releases(cx: &mut TestAppContext) {
        let entities: Vec<_> = (0..8193).map(|_| cx.new(|_| 0usize)).collect();
        cx.update(|cx| {
            for entity in &entities {
                cx.notify(entity.entity_id());
            }
        });
        assert!(capacity(cx) >= 8193);
        cx.executor().advance_clock(Duration::from_secs(31));
        cx.run_until_parked();
        assert!(capacity(cx) <= 256);
        for entity in &entities {
            assert_eq!(entity.read_with(cx, |value, _| *value), 0);
        }
    }

    #[test]
    fn an_armed_idle_task_does_not_keep_the_app_alive() {
        let mut cx = TestAppContext::single();
        let app = Rc::downgrade(&cx.app);
        let executor = cx.executor();
        enqueue(&mut cx, 8193);
        cx.run_until_parked();
        drop(cx);
        executor.advance_clock(Duration::from_secs(31));
        executor.run_until_parked();
        assert!(app.upgrade().is_none());
    }
}
