
#[cfg(test)]
mod idle_effect_refresh_tests {
    use super::*;

    #[gpui::test]
    fn refresh_only_queue_also_releases(cx: &mut TestAppContext) {
        cx.update(|cx| {
            for _ in 0..8193 {
                cx.refresh_windows();
            }
        });
        cx.update(|cx| assert!(cx.pending_effects.capacity() >= 8193));
        cx.executor().advance_clock(Duration::from_secs(31));
        cx.run_until_parked();
        cx.update(|cx| {
            assert!(cx.pending_effects.is_empty());
            assert!(cx.pending_effects.capacity() <= 256);
        });
    }
}
