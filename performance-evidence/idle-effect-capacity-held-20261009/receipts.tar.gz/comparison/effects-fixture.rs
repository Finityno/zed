use super::*;
use std::{cell::Cell, rc::Rc};

#[cfg(gpui_layout_sets_census)]
#[test]
#[ignore]
fn profile_effect_owner() {
    let count: usize = std::env::var("EFFECT_OWNER_COUNT")
        .expect("EFFECT_OWNER_COUNT").parse().expect("effect count");
    let retained = std::env::var("EFFECT_OWNER_RETAINED").expect("EFFECT_OWNER_RETAINED") == "1";
    crate::perf_count::census::start();
    let mut cx = TestAppContext::single();
    cx.update(|cx| cx.set_view_retention(retained));
    let window = cx.add_window(|_, _| crate::Empty);
    for _ in 0..4 {
        cx.update_window(window.into(), |_, window, cx| window.draw(cx).clear(cx)).expect("warmup");
    }
    let progress = Rc::new(Cell::new((0usize, 0u64)));
    let (queued, queue_peak_capacity) = cx.update(|cx| {
        for index in 0..count {
            let progress = progress.clone();
            cx.defer(move |_| {
                let (completed, sum) = progress.get();
                assert_eq!(completed, index, "deferred callback order");
                progress.set((completed + 1, sum + index as u64));
            });
        }
        (cx.pending_effects.len(), cx.pending_effects.capacity())
    });
    assert_eq!(queued, count);
    assert_eq!(progress.get(), (count, (count as u64).saturating_mul(count.saturating_sub(1) as u64) / 2));
    assert_eq!(Rc::strong_count(&progress), 1, "all deferred closures released");
    let (drained, before_capacity) = cx.update(|cx| (cx.pending_effects.len(), cx.pending_effects.capacity()));
    assert_eq!(drained, 0);
    let (before_held, _, _, _) = crate::perf_count::census::snapshot();
    cx.executor().advance_clock(std::time::Duration::from_secs(3));
    cx.run_until_parked();
    let (after_len, after_capacity) = cx.update(|cx| (cx.pending_effects.len(), cx.pending_effects.capacity()));
    assert_eq!(after_len, 0);
    let (held_bytes, peak_bytes, requested_bytes, allocation_calls) = crate::perf_count::census::finish();
    let effect_size = std::mem::size_of::<Effect>();
    println!("EFFECT_OWNER {{\"count\":{count},\"retained\":{retained},\"queued\":{queued},\"queue_peak_capacity\":{queue_peak_capacity},\"before_capacity\":{before_capacity},\"after_capacity\":{after_capacity},\"effect_size\":{effect_size},\"owner_before_bytes\":{},\"owner_after_bytes\":{},\"before_held_bytes\":{before_held},\"held_bytes\":{held_bytes},\"peak_bytes\":{peak_bytes},\"requested_bytes\":{requested_bytes},\"allocation_calls\":{allocation_calls},\"exact_callbacks\":true}}", before_capacity * effect_size, after_capacity * effect_size);
}

use std::{hash::{Hash, Hasher}, hint::black_box};

struct EffectProfileView(Rc<Cell<usize>>);

impl Render for EffectProfileView {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl crate::IntoElement {
        self.0.set(self.0.get() + 1);
        crate::Empty
    }
}

#[repr(C)]
struct EffectTimespec {
    seconds: std::os::raw::c_long,
    nanoseconds: std::os::raw::c_long,
}

unsafe extern "C" {
    fn clock_gettime(clock: std::os::raw::c_int, result: *mut EffectTimespec) -> std::os::raw::c_int;
    fn sysconf(name: std::os::raw::c_int) -> std::os::raw::c_long;
}

fn effect_thread_cpu_ns() -> u64 {
    let mut value = EffectTimespec { seconds: 0, nanoseconds: 0 };
    assert_eq!(unsafe { clock_gettime(3, &mut value) }, 0);
    value.seconds as u64 * 1_000_000_000 + value.nanoseconds as u64
}

fn current_rss_kib() -> usize {
    let page_size = unsafe { sysconf(30) };
    assert!(page_size > 0);
    let statm = std::fs::read_to_string("/proc/self/statm").expect("native statm");
    let pages: usize = statm.split_whitespace().nth(1).expect("resident pages").parse().expect("RSS");
    pages * page_size as usize / 1024
}

fn enqueue_effect_profile(cx: &mut TestAppContext, progress: &Rc<Cell<(usize, u64)>>, count: usize, reentrant: bool) {
    let first = progress.get().0;
    cx.update(|cx| {
        for index in 0..count {
            let progress = progress.clone();
            cx.defer(move |cx| {
                let (completed, sum) = progress.get();
                assert_eq!(completed, first + index, "callback order");
                progress.set((completed + 1, sum + completed as u64));
                if reentrant {
                    let progress = progress.clone();
                    cx.defer(move |_| {
                        let (completed, sum) = progress.get();
                        assert_eq!(completed, first + count + index, "nested callback order");
                        progress.set((completed + 1, sum + completed as u64));
                    });
                }
            });
        }
    });
    assert_eq!(progress.get().0, first + count * if reentrant { 2 } else { 1 });
    assert_eq!(Rc::strong_count(progress), 1);
}

fn effect_quiet(cx: &mut TestAppContext, seconds: u64, draws: &Rc<Cell<usize>>) {
    let before = draws.get();
    cx.executor().advance_clock(Duration::from_secs(seconds));
    cx.run_until_parked();
    assert_eq!(draws.get(), before, "timer must not redraw");
}

#[test]
#[ignore]
fn profile_effect_capacity() {
    let case = std::env::var("EFFECT_PROFILE_CASE").expect("EFFECT_PROFILE_CASE");
    let parts: Vec<_> = case.split('-').collect();
    assert_eq!(parts.len(), 4);
    let scenario = parts[1];
    let retained = parts[2] == "on";
    let count: usize = parts[3].parse().expect("effect count");
    #[cfg(gpui_layout_sets_census)]
    crate::perf_count::census::start();
    let mut cx = TestAppContext::single();
    cx.update(|cx| cx.set_view_retention(retained));
    let draws = Rc::new(Cell::new(0));
    let window = if scenario == "no_window" {
        None
    } else {
        Some(cx.add_window({
            let draws = draws.clone();
            move |_, _| EffectProfileView(draws)
        }))
    };
    if let Some(window) = window {
        for _ in 0..4 {
            cx.update_window(window.into(), |_, window, cx| window.draw(cx).clear(cx)).expect("warmup");
        }
        cx.update_window(window.into(), |_, window, _| window.reset_frame_work_stats(false)).expect("disable clocks");
    }
    let progress = Rc::new(Cell::new((0usize, 0u64)));
    let started = std::time::Instant::now();
    let cpu_started = effect_thread_cpu_ns();
    let cycles = if matches!(scenario, "short_refault" | "long_refault") { 4 } else { 1 };
    for _ in 0..cycles {
        enqueue_effect_profile(&mut cx, &progress, count, scenario == "reentrant");
        if scenario == "short_refault" {
            effect_quiet(&mut cx, 3, &draws);
        } else if scenario == "long_refault" {
            effect_quiet(&mut cx, 31, &draws);
        }
    }
    if scenario == "close_window" {
        let window = window.expect("window to close");
        cx.update_window(window.into(), |_, window, _| window.remove_window()).expect("close owned test window");
    }
    if matches!(scenario, "active" | "continuous") {
        for _ in 0..4 {
            effect_quiet(&mut cx, 10, &draws);
            enqueue_effect_profile(&mut cx, &progress, if scenario == "active" { count } else { 32 }, false);
        }
    }
    if scenario != "active" && scenario != "long_refault" {
        effect_quiet(&mut cx, 31, &draws);
    }
    black_box(&cx);
    let cpu_ns = effect_thread_cpu_ns() - cpu_started;
    let elapsed_ns = started.elapsed().as_nanos();
    #[cfg(gpui_layout_sets_census)]
    let (held_bytes, peak_bytes, requested_bytes, allocation_calls) = crate::perf_count::census::finish();
    #[cfg(not(gpui_layout_sets_census))]
    let (held_bytes, peak_bytes, requested_bytes, allocation_calls) = (-1, -1, 0, 0);
    let current_rss_kib = current_rss_kib();
    let (queue_len, queue_capacity, state_count, state_box_bytes, windows) = cx.update(|cx| {
        let state_count = cx.windows.values().filter_map(|window| window.as_deref()).map(|window| window.rendered_frame.element_states.len()).sum::<usize>();
        let state_box_bytes = cx.windows.values().filter_map(|window| window.as_deref()).flat_map(|window| window.rendered_frame.element_states.values()).map(|state| std::mem::size_of_val(state.inner.as_ref())).sum::<usize>();
        (cx.pending_effects.len(), cx.pending_effects.capacity(), state_count, state_box_bytes, cx.windows.len())
    });
    assert_eq!(queue_len, 0);
    let (completed, sum) = progress.get();
    assert_eq!(sum, (completed as u64).saturating_mul(completed.saturating_sub(1) as u64) / 2);
    assert_eq!(Rc::strong_count(&progress), 1);
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    (completed, sum, draws.get(), windows, queue_len, state_count, state_box_bytes).hash(&mut hasher);
    let signature = hasher.finish();
    let owner_bytes = queue_capacity * std::mem::size_of::<Effect>();
    println!("EFFECT_PROFILE {{\"case\":\"{case}\",\"cpu_ns\":{cpu_ns},\"elapsed_ns\":{elapsed_ns},\"signature\":{signature},\"state_count\":{state_count},\"state_box_bytes\":{state_box_bytes},\"held_bytes\":{held_bytes},\"peak_bytes\":{peak_bytes},\"requested_bytes\":{requested_bytes},\"allocation_calls\":{allocation_calls},\"current_rss_kib\":{current_rss_kib},\"queue_capacity\":{queue_capacity},\"owner_bytes\":{owner_bytes},\"completed_callbacks\":{completed},\"draws\":{}}}", draws.get());
}
