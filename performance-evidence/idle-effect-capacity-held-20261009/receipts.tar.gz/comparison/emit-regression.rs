
#[cfg(test)]
mod idle_effect_emit_tests {
    use super::*;

    struct Emitter;
    impl EventEmitter<usize> for Emitter {}

    #[gpui::test]
    fn emitted_events_also_release_their_queue(cx: &mut TestAppContext) {
        let emitter = cx.new(|_| Emitter);
        let completed = Rc::new(Cell::new(0));
        cx.update(|cx| {
            cx.subscribe(&emitter, {
                let completed = completed.clone();
                move |_, index: &usize, _| {
                    assert_eq!(completed.get(), *index);
                    completed.set(completed.get() + 1);
                }
            }).detach();
        });
        emitter.update(cx, |_, cx| {
            for index in 0..8193 {
                cx.emit(index);
            }
        });
        assert_eq!(completed.get(), 8193);
        cx.update(|cx| assert!(cx.pending_effects.capacity() >= 8193));
        cx.executor().advance_clock(Duration::from_secs(31));
        cx.run_until_parked();
        cx.update(|cx| {
            assert!(cx.pending_effects.is_empty());
            assert!(cx.pending_effects.capacity() <= 256);
        });
    }
}
