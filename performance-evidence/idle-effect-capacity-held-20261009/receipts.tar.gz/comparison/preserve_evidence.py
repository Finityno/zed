from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import platform
import subprocess
import tarfile

root = Path(__file__).parent
owner = root.parent
work = Path('/workspace/zed-effect-capacity')
output = work / 'performance-evidence/idle-effect-capacity-held-20261009'
output.mkdir(parents=True)
decision = json.loads((root / 'decision.json').read_text())
policy = json.loads((root / 'policy.json').read_text())
assert not decision['qualified'] and len(decision['failures']) == 35
for name, expected in json.loads((root / 'frozen-inputs.json').read_text()).items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
runtime = json.loads((root / 'runtime-identities.json').read_text())
assert runtime['uname'] == platform.uname()._asdict()
for collection in ['dynamic_libraries', 'compiler_shared_libraries']:
    for path, expected in runtime[collection].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected['sha256']
assert hashlib.sha256(Path(runtime['compiler']).read_bytes()).hexdigest() == runtime['compiler_sha256']
for dependency in json.loads((root / 'external-dependencies.json').read_text()):
    assert hashlib.sha256(Path(dependency['path']).read_bytes()).hexdigest() == dependency['sha256']
for lane in ['baseline', 'candidate']:
    identities = json.loads((root / (lane + '-source-inputs.json')).read_text())
    for path, expected in identities['files'].items():
        assert hashlib.sha256((root / (lane + '-workspace') / path).read_bytes()).hexdigest() == expected, path
    for kind, identity in json.loads((root / 'binary-identities.json').read_text())[lane].items():
        assert hashlib.sha256(Path(identity['path']).read_bytes()).hexdigest() == identity['sha256']
builds = json.loads((root / 'build-order-receipt.json').read_text())['receipts']
phases = json.loads((root / 'valid-cohort-order-receipt.json').read_text())['receipts']
assert len(builds) == 4 and len(phases) == 2
assert phases[0]['started_unix'] >= builds[-1]['started_unix'] + builds[-1]['elapsed_seconds']
assert phases[1]['started_unix'] >= phases[0]['started_unix'] + phases[0]['elapsed_seconds'] - 0.02
for kind, count in [('bare', 1350), ('census', 750)]:
    samples = json.loads((root / (kind + '-samples.json')).read_text())
    assert len(samples) == count
    for sample in samples:
        assert sample['exit_code'] == 0
        assert hashlib.sha256(Path(sample['log']).read_bytes()).hexdigest() == sample['log_sha256']
assert len(json.loads((root / 'contracts-summary.json').read_text())) == 32
assert len(json.loads((root / 'functional-preflight-summary.json').read_text())) == 68
(root / 'post-cohort-identities-verified.json').write_text(json.dumps({
    'all_frozen_inputs_unchanged': True, 'all_866_source_file_identities_unchanged': True,
    'all_four_binaries_and_59_externs_unchanged': True, 'compiler_runtime_libraries_unchanged': True,
    'same_uname_after_environment_attach': True, 'all_2100_sample_logs_verified': True}, indent=2) + '\n')
initial = root / 'production-only.diff'
(root / 'production-only-initial-prototype.diff').write_bytes(initial.read_bytes())
environment = dict(os.environ, GIT_NO_LAZY_FETCH='1')
diff = subprocess.check_output(['git', '-C', str(work), 'diff', policy['baseline'],
                                '06e96d96609b20bf9afec0e140678eb2e5617bdc'], env=environment)
(root / 'final-reviewed-source.diff').write_bytes(diff)
files = {}
for base, prefix in [(root, 'comparison'), (owner, 'attribution')]:
    for path in base.rglob('*'):
        relative = path.relative_to(base)
        if base == owner and relative.parts[0] == 'comparison':
            continue
        if any(part.endswith('-workspace') or part.endswith('-artifacts') for part in relative.parts):
            continue
        if path.is_file() and path.suffix in {'.py', '.json', '.jsonl', '.log', '.diff', '.rs', '.c', '.md', '.txt'}:
            files[prefix + '/' + str(relative)] = path
for name in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'LICENSE-APACHE', 'LICENSE-GPL']:
    files['native-root/' + name] = root / 'candidate-workspace' / name
for lane in ['baseline', 'candidate']:
    for name in ['app.rs', 'app/context.rs', 'gpui.rs', 'perf_count.rs']:
        files[lane + '/' + name] = root / (lane + '-workspace') / 'crates/gpui/src' / name
manifest = {name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
            for name, path in sorted(files.items())}
archive = output / 'receipts.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=6, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
    entries = [('manifest.json', (json.dumps(manifest, indent=2) + '\n').encode())]
    entries += [(name, path.read_bytes()) for name, path in sorted(files.items())]
    for name, data in entries:
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    for name, expected in manifest.items():
        data = tar.extractfile(name).read()
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
evidence = {
    'status': 'HELD/unmerged; no unchanged rerun or weaker gates', 'qualified': False,
    'baseline': policy['baseline'], 'source': '06e96d96609b20bf9afec0e140678eb2e5617bdc',
    'fincode_main_at_freeze': policy['fincode_main'], 'fincode_gpui': policy['fincode_pin'],
    'component_pin': policy['component_pin'], 'valid_children': 2100, 'workloads': 75,
    'failures': decision['failures'], 'all_primary_gain_fields_pass': True,
    'observed_primary_changes': {case: {kind: {metric: decision['summary'][kind][case][metric]
        for metric in (['current_rss_kib'] if kind == 'bare' else ['held_bytes', 'owner_bytes'])}
        for kind in ['bare', 'census']} for case in policy['primary_cases']},
    'important_gain_not_qualified': '67.35–80.54% less complete held requested heap,99.61–99.80% queue storage release,24.58–35.76% less native current RSS;35 frozen CPU/RSS/allocation controls fail. Four-cycle long-idle refilling uses9.75% more CPU; a single reclaim adds21allocation calls against8allowed.',
    'mechanism': 'All six effect-enqueue paths share a threshold flag; once after a large flush one weak-App task waits30s since the last large queue, keeps256effects and ends. Ordinary small updates do not extend the quiet period. Fixed App census increase40bytes is within64byte declared budget.',
    'correctness': '32 native contract invocations pass their declared results. Nine new lifecycle tests baseline2pass/7fail, candidate9pass in both bare/census lanes. Current App/Scene/window idle/retained-frame/wheel/dependency/panel/layout/atomic/read/nested checks pass.68four-lane functional children and all2100measured outputs preserve callback order/checksum/closure release and window/state signatures.',
    'environment_recovery': 'Cloud attachment removed supervising parents. Original1350-child bare process continued and exited0 at241.58s, before900s deadline, with every raw sample and final summary intact. Same kernel/host/source/compiler/runtime/binary/extern identities reverified. No duplicate/restarted samples;750census children follow sequentially under600s PGID deadline. Initial reattach helper rejected empty cmdline of already-exited zombie; corrected helper and original preserved.',
    'adverse_preparation': 'Original refresh API and AsyncApp result build failures retained; bootstrap-boundary native test failure and all four earlier native identities/binaries preserved. Only correctness setup helper changed, with original and corrected hashes. Every performance fixture and acceptance policy remains exactly frozen before production candidate.',
    'not_run': 'Strict owning Clippy, PR creation, merge and coherent application adoption withheld because performance gates fail.',
    'limits': policy['limits'], 'policy_sha256': hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest(),
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'archive_bytes': archive.stat().st_size,
    'members': len(manifest) + 1,
}
(output / 'evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')
(output / 'README.md').write_text('''# Held idle effects-queue capacity

One 2,100-child comparison across 75 complete App/Window workloads fails
35 frozen acceptance fields. All four memory targets pass: complete held
requested heap falls 67.35–80.54%, queue storage falls 99.61–99.80%, and
native current RSS falls 24.58–35.76%. This design remains unmerged because
CPU, RSS and allocation controls fail. Four-cycle long-idle refill CPU rises
9.75%; one reclaim adds 21 allocation calls against the frozen allowance of 8.
Do not rerun this design unchanged or weaken its gates.

Nine native lifecycle tests preserve callback order, no-redraw reclamation,
full quiet periods, reentrant/notify/refresh/event paths, ordinary capacity
and weak App lifetime. Both bare and counting lanes fail seven baseline tests
and pass all nine candidate tests. Existing retained frame, Scene, App, window
idle, wheel, dependency, panel, layout, atomic-claim, read and nested contracts
pass. All measured callback, closure-owner and window/state outputs match.

The archive preserves every raw sample, frozen policy, exact source/compiler/
runtime/common 59 extern/binary identity, original adverse build/test setup,
and the cloud-attachment interruption receipt. The original bare process
finished inside its original deadline; no samples were restarted or duplicated.
The subsequent census phase ran separately. Every archive member is hashed
and verified. Native executables and source snapshots remain in the durable
cloud evidence paths identified by their exact receipts.

These are Linux fake-platform complete-component observations with System,
not app, physical GPU, macOS/Windows or shipped-allocator gains. Virtual test
time drives the idle timers; CPU measures actual work, not a real 30-second
idle app recording. No PR, merge or consumer adoption is qualified. Continue
with a distinct observer allocation design and preserve independent work.
''')
(root / 'archive-verification.json').write_text(json.dumps({key: evidence[key] for key in
    ['archive_sha256', 'archive_bytes', 'members', 'valid_children', 'qualified']}, indent=2) + '\n')
print((root / 'archive-verification.json').read_text())
