from pathlib import Path
import json, math, statistics

root = Path(__file__).parent
policy = json.loads((root / 'policy.json').read_text())
results = {}
failures = []
for kind in ['bare', 'census']:
    samples = json.loads((root / (kind + '-samples.json')).read_text())
    expected = policy['timing_pairs'] if kind == 'bare' else policy['memory_pairs']
    assert len(samples) == len(policy['controls']) * expected * 2
    summaries = {}
    for case in policy['controls']:
        baseline = sorted([sample for sample in samples if sample['case'] == case and sample['lane'] == 'baseline'], key=lambda sample: sample['pair'])
        candidate = sorted([sample for sample in samples if sample['case'] == case and sample['lane'] == 'candidate'], key=lambda sample: sample['pair'])
        assert len(baseline) == len(candidate) == expected
        assert all(old['signature'] == new['signature'] and old['exit_code'] == new['exit_code'] == 0 for old, new in zip(baseline, candidate))
        assert all(old['state_count'] == new['state_count'] and old['state_box_bytes'] == new['state_box_bytes'] for old, new in zip(baseline, candidate))
        effect = case in policy['effect_cases']
        metrics = ['cpu_ns', 'elapsed_ns', 'child_cpu_ns', 'peak_rss_kib'] if kind == 'bare' else ['held_bytes', 'peak_bytes', 'requested_bytes', 'allocation_calls', 'peak_rss_kib']
        if effect:
            metrics += ['current_rss_kib'] if kind == 'bare' else ['owner_bytes']
        values = {}
        for metric in metrics + ['state_count', 'state_box_bytes']:
            old = [sample[metric] for sample in baseline]
            new = [sample[metric] for sample in candidate]
            old_median = statistics.median(old)
            new_median = statistics.median(new)
            old_range = max(old) - min(old)
            new_range = max(new) - min(new)
            allowed = 0
            if metric in ['cpu_ns', 'elapsed_ns', 'child_cpu_ns', 'peak_rss_kib', 'current_rss_kib']:
                allowed = old_range
            elif metric in ['held_bytes', 'peak_bytes', 'requested_bytes']:
                allowed = policy['fixed_app_budget']
            if kind == 'census' and effect:
                ordinary = '-empty-' in case or '-below-' in case
                if metric == 'held_bytes' and '-active-' in case:
                    allowed += policy['retained_task_budget']
                if metric in ['requested_bytes', 'allocation_calls'] and not ordinary:
                    cycles = policy['effect_cycles'][case]
                    allowed += cycles * policy['timer_requested_budget_per_cycle'] if metric == 'requested_bytes' else cycles * policy['timer_call_budget_per_cycle']
                    if '-long_refault-' in case:
                        count = int(case.rsplit('-', 1)[1])
                        allowed += 2 * count * policy['effect_size'] * (cycles - 1) if metric == 'requested_bytes' else math.ceil(math.log2(count / 256)) * (cycles - 1)
            passed = new_median - old_median <= allowed
            if not passed:
                failures.append([kind, case, metric, 'control', new_median - old_median, allowed])
            values[metric] = {'baseline_median': old_median, 'candidate_median': new_median, 'baseline_min': min(old), 'baseline_max': max(old), 'candidate_min': min(new), 'candidate_max': max(new), 'baseline_range': old_range, 'candidate_range': new_range, 'change_percent': (new_median / old_median - 1) * 100 if old_median else None, 'allowed_increase': allowed, 'pass': passed}
        if case in policy['primary_cases']:
            targets = [('held_bytes', 0.2), ('owner_bytes', 0.99)] if kind == 'census' else [('current_rss_kib', 0.1)]
            for metric, minimum in targets:
                value = values[metric]
                gain = value['baseline_median'] - value['candidate_median']
                if gain / value['baseline_median'] < minimum or gain <= max(value['baseline_range'], value['candidate_range']):
                    failures.append([kind, case, metric, 'primary gain', gain, value['baseline_range'], value['candidate_range'], minimum])
        summaries[case] = values
    results[kind] = summaries
decision = {'qualified': not failures, 'failures': failures, 'summary': results, 'cold_refill_tradeoff_explicit_before_candidate': True}
(root / 'decision.json').write_text(json.dumps(decision, indent=2) + '\n')
print(json.dumps({'qualified': decision['qualified'], 'failures': failures, 'primary': {case: {kind: results[kind][case] for kind in results} for case in policy['primary_cases']}}))
