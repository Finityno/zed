from pathlib import Path
import hashlib, json, os, shutil, subprocess

root = Path(__file__).parent
source = Path('/workspace/zed-effect-capacity')
baseline = '8ceb46cd79dc910bf709b561727bb42e7e9ae2da'
environment = dict(os.environ, GIT_NO_LAZY_FETCH='1')
candidate = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], env=environment, text=True).strip()
crates = json.loads((root.parent / 'baseline-source-inputs.json').read_text())['crates']
changed_path = 'crates/gpui/src/app.rs'
before = subprocess.check_output(['git', '-C', str(source), 'show', baseline + ':' + changed_path], env=environment)
before += (root / 'idle-regression.rs').read_bytes() + (root / 'refresh-regression.rs').read_bytes() + (root / 'emit-regression.rs').read_bytes()
for lane in ['baseline', 'candidate']:
    work = root / (lane + '-workspace')
    work.mkdir()
    for name in crates:
        shutil.copytree(source / 'crates' / name, work / 'crates' / name, symlinks=True)
    for name in ['Cargo.toml', 'Cargo.lock', 'AGENTS.md', 'README.md', 'rust-toolchain.toml', 'LICENSE-APACHE', 'LICENSE-GPL']:
        shutil.copy2(source / name, work / name)
    shutil.copytree(source / '.cargo', work / '.cargo', symlinks=True)
    for name in ['ibm-plex-sans', 'lilex']:
        shutil.copytree(source / 'assets/fonts' / name, work / 'assets/fonts' / name, symlinks=True)
    if lane == 'baseline':
        (work / changed_path).write_bytes(before)
        context_path = 'crates/gpui/src/app/context.rs'
        (work / context_path).write_bytes(subprocess.check_output(['git', '-C', str(source), 'show', baseline + ':' + context_path], env=environment))
    (work / 'crates/gpui/src/perf_count.rs').write_bytes((root / 'perf-count.rs').read_bytes())
    path = work / 'crates/gpui/src/gpui.rs'
    path.write_text(path.read_text() + '\n#[cfg(all(test, gpui_layout_sets_census))]\n#[path = "perf_count.rs"]\npub(crate) mod perf_count;\n')
    path = work / changed_path
    path.write_text(path.read_text() + '\n#[cfg(all(test, target_os = "linux"))]\n#[path = "app/effects_profile.rs"]\nmod effects_profile;\n')
    (work / 'crates/gpui/src/app/effects_profile.rs').write_bytes((root / 'effects-fixture.rs').read_bytes())
    (work / 'crates/gpui/src/window/view_retention/splice_profile.rs').write_bytes((root / 'comparison-fixture.rs').read_bytes())
    (work / 'crates/gpui/src/window/view_retention/transcript_profile.rs').write_bytes((root / 'transcript-fixture.rs').read_bytes())
    path = work / 'crates/gpui/src/window/view_retention/tests.rs'
    assert 'mod transcript_profile;' not in path.read_text()
    path.write_text(path.read_text() + '\n#[cfg(target_os = "linux")]\n#[path = "transcript_profile.rs"]\nmod transcript_profile;\n')
    files = {str(path.relative_to(work)): hashlib.sha256(path.read_bytes()).hexdigest() for path in work.rglob('*') if path.is_file()}
    (root / (lane + '-source-inputs.json')).write_text(json.dumps({'baseline': baseline, 'candidate': candidate, 'lane': lane, 'crates': crates, 'files': files, 'description': 'Current24actualownercrates/fullroot/lock/fonts/licenses. Identical75completeApp/Window fixtures, sharedcountingSystem andall8newidle regressions. Only effectsqueue productiondiff inApp differs.'}, indent=2) + '\n')
left = json.loads((root / 'baseline-source-inputs.json').read_text())['files']
right = json.loads((root / 'candidate-source-inputs.json').read_text())['files']
changed = [name for name in left if left[name] != right[name]]
assert sorted(changed) == ['crates/gpui/src/app.rs', 'crates/gpui/src/app/context.rs']
for name, expected in json.loads((root / 'pre-candidate-frozen-method.json').read_text()).items():
    actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
    if actual != expected:
        correction = json.loads((root / 'regression-setup-correction.json').read_text())
        assert name == 'idle-regression.rs' and expected == correction['original_sha256'] and actual == correction['corrected_sha256']
    else:
        assert actual == expected
(root / 'candidate-source.diff').write_bytes(subprocess.check_output(['git', '-C', str(source), 'diff', baseline, candidate], env=environment))
(root / 'comparison-source-receipt.json').write_text(json.dumps({'baseline': baseline, 'candidate': candidate, 'changed_source': changed, 'files_each': len(left), 'policy_sha256': hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest()}, indent=2) + '\n')
print(json.dumps({'baseline': baseline, 'candidate': candidate, 'changed': changed, 'files': len(left)}))
