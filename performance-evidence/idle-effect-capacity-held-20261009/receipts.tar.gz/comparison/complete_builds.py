from pathlib import Path
import json, subprocess

root = Path(__file__).parent
receipts = json.loads((root / 'build-order-receipt.json').read_text())['receipts']
assert len(receipts) == 2
for kind in ['bare', 'census']:
    command = ['python3', str(root / 'supervise.py'), '--seconds', '600', '--name', 'candidate-' + kind + '-supervised', '--cwd', str(root), '--', 'python3', str(root / 'build_native.py'), 'candidate', kind]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    receipt = json.loads((root / ('candidate-' + kind + '-supervised-receipt.json')).read_text())
    assert result.returncode == receipt['exit_code'] == 0 and not receipt['timed_out'], result.stdout
    assert receipt['started_unix'] >= receipts[-1]['started_unix'] + receipts[-1]['elapsed_seconds']
    receipts.append(receipt)
    (root / 'build-order-receipt.json').write_text(json.dumps({'sequential': True, 'receipts': receipts, 'rejected_candidate_compile_preserved': 'rejected-async-app-update-build', 'unchanged_successful_baselines_not_rebuilt': True}, indent=2) + '\n')
    print(json.dumps({'lane': 'candidate', 'kind': kind, 'completed': True, 'seconds': receipt['elapsed_seconds']}), flush=True)
