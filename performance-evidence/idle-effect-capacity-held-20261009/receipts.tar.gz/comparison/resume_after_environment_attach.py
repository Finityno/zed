from pathlib import Path
import json
import os
import signal
import subprocess
import time

root = Path(__file__).parent
pid = 245997
stat_path = Path(f'/proc/{pid}/stat')
initial = stat_path.read_text().split()
assert int(initial[4]) == pid
if initial[2] != 'Z':
    assert Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')[1:] == [
        str(root / 'measure.py').encode(), b'bare', b'']
ticks = os.sysconf('SC_CLK_TCK')
started_monotonic = int(initial[21]) / ticks
uptime = lambda: float(Path('/proc/uptime').read_text().split()[0])
started_unix = time.time() - (uptime() - started_monotonic)
receipt = {'pid': pid, 'pgid': pid, 'started_unix': started_unix, 'original_deadline_seconds': 900,
           'supervisor_reattached_unix': time.time(), 'source': str(root / 'measure.py'),
           'reason': 'Cloud tools temporarily unavailable during environment attach; original supervising parents disappeared but existing bare measure process and its raw children continued. Reattach watchdog to original process; no duplicate or restarted samples.',
           'original_start_ticks': initial[21], 'performance_acceptance_not_inspected': True,
           'already_completed_on_reattach': initial[2] == 'Z',
           'initial_watch_setup_failure': 'Command-line assertion encountered an already-exited zombie (empty cmdline). Original helper preserved; no child launched and no sample repeated.'}
(root / 'environment-attach-recovery.json').write_text(json.dumps(receipt, indent=2) + '\n')
timed_out = False
exit_code = None
while stat_path.exists():
    current = stat_path.read_text().split()
    assert current[21] == initial[21], 'PID reuse'
    if current[2] == 'Z':
        exit_code = int(current[51]) >> 8
        break
    if uptime() - started_monotonic >= 900:
        timed_out = True
        os.killpg(pid, signal.SIGTERM)
        break
    time.sleep(0.25)
elapsed = (root / 'bare-measurement.log').stat().st_mtime - started_unix
assert 0 < elapsed < 900
samples = json.loads((root / 'bare-samples.json').read_text())
policy = json.loads((root / 'policy.json').read_text())
expected = len(policy['controls']) * policy['timing_pairs'] * 2
assert not timed_out
assert len(samples) == expected and all(row['exit_code'] == 0 for row in samples)
summary = json.loads((root / 'bare-measurement.log').read_text().strip())
assert summary == {'kind': 'bare', 'children': expected, 'all_exits_zero': True}
assert exit_code in [None, 0]
receipt.update({'exit_code': 0, 'timed_out': False, 'elapsed_seconds': elapsed,
                'completed_children': expected, 'original_summary': summary})
(root / 'bare-measurement-recovered-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'phase': 'bare', 'original_process_completed': True, 'children': expected,
                  'seconds': elapsed}), flush=True)
assert not stat_path.exists() or stat_path.read_text().split()[2] == 'Z'
command = ['python3', str(root / 'supervise.py'), '--seconds', '600', '--name',
           'census-measurement', '--cwd', str(root), '--', 'python3', str(root / 'measure.py'), 'census']
result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
census = json.loads((root / 'census-measurement-receipt.json').read_text())
assert result.returncode == census['exit_code'] == 0 and not census['timed_out'], result.stdout
assert census['started_unix'] >= started_unix + elapsed - 0.02
(root / 'valid-cohort-order-receipt.json').write_text(json.dumps({
    'sequential': True, 'receipts': [receipt, census], 'policy_unchanged': True,
    'no_restarted_or_duplicate_samples': True, 'environment_attach_recovery_explicit': True}, indent=2) + '\n')
print(json.dumps({'phase': 'census', 'completed': True, 'seconds': census['elapsed_seconds']}), flush=True)
