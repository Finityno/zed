from pathlib import Path
import hashlib
import json
import os
import platform
import subprocess

root = Path(__file__).parent
runtime = json.loads(Path('/workspace/scratch/gpui-union-state-loop/runtime-identities.json').read_text())
runtime['compiler_vV'] = subprocess.check_output([runtime['compiler'], '-vV'], text=True)
assert hashlib.sha256(Path(runtime['compiler']).read_bytes()).hexdigest() == runtime['compiler_sha256']
for identities in ['dynamic_libraries', 'compiler_shared_libraries']:
    for path, expected in runtime[identities].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected['sha256']
runtime['LD_LIBRARY_PATH'] = os.environ.get('LD_LIBRARY_PATH', '')
runtime['uname'] = platform.uname()._asdict()
runtime['ldd'] = {}
binary = {}
for lane in ['baseline', 'candidate']:
    binary[lane] = {}
    runtime['ldd'][lane] = {}
    for kind in ['bare', 'census']:
        path = root / (lane + '-' + kind + '-artifacts/gpui-ada3fb4d7b1cfe56')
        binary[lane][kind] = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
        loaded = subprocess.check_output(['ldd', str(path)], text=True)
        assert 'not found' not in loaded
        for library in runtime['dynamic_libraries']:
            assert library in loaded
        runtime['ldd'][lane][kind] = loaded
dependencies = json.loads((root / 'external-dependencies.json').read_text())
for dependency in dependencies:
    assert hashlib.sha256(Path(dependency['path']).read_bytes()).hexdigest() == dependency['sha256']
assert len(dependencies) == 59
(root / 'binary-identities.json').write_text(json.dumps(binary, indent=2) + '\n')
(root / 'runtime-identities.json').write_text(json.dumps(runtime, indent=2) + '\n')
frozen = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in ['policy.json', 'measure.py', 'qualify.py', 'qualify_effects.py', 'run_measurements.py', 'native_run.c', 'native-run', 'binary-identities.json', 'external-dependencies.json', 'runtime-identities.json', 'baseline-source-inputs.json', 'candidate-source-inputs.json', 'idle-regression.rs', 'refresh-regression.rs', 'emit-regression.rs', 'regression-setup-correction.json']}
previous = json.loads((root / 'pre-candidate-frozen-method.json').read_text())
for name, expected in previous.items():
    actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
    if actual != expected:
        correction = json.loads((root / 'regression-setup-correction.json').read_text())
        assert name == 'idle-regression.rs' and expected == correction['original_sha256'] and actual == correction['corrected_sha256']
        assert correction['before_any_performance_sample']
    else:
        assert actual == expected
(root / 'frozen-inputs.json').write_text(json.dumps(frozen, indent=2) + '\n')
print(json.dumps({'lanes': 4, 'identical_externs': len(dependencies), 'runtime_hashes_verified': True, 'method_frozen_before_candidate_unchanged': True}))
