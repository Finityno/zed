from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path(__file__).parent
policy = json.loads((root / 'policy.json').read_text())
identities = json.loads((root / 'binary-identities.json').read_text())
output = root / 'functional-preflight'
output.mkdir()
rows = []
for case in policy['effect_cases']:
    signatures = set()
    for kind in ['bare', 'census']:
        for lane in ['baseline', 'candidate']:
            binary = Path(identities[lane][kind]['path'])
            assert hashlib.sha256(binary.read_bytes()).hexdigest() == identities[lane][kind]['sha256']
            name = case + '-' + lane + '-' + kind
            log_path = output / (name + '.log')
            command = [str(binary), 'profile_effect_capacity', '--ignored', '--nocapture', '--test-threads=1']
            environment = dict(os.environ, EFFECT_PROFILE_CASE=case)
            with log_path.open('w') as log:
                result = subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=60)
            log = log_path.read_text()
            assert result.returncode == 0 and 'test result: ok. 1 passed;' in log, log
            markers = [json.loads(line.split('EFFECT_PROFILE ', 1)[1])
                       for line in log.splitlines() if 'EFFECT_PROFILE ' in line]
            assert len(markers) == 1
            signature = markers[0]['signature']
            signatures.add(signature)
            rows.append({'case': case, 'lane': lane, 'kind': kind, 'exit_code': result.returncode,
                         'signature': signature, 'binary_sha256': identities[lane][kind]['sha256'],
                         'log': str(log_path), 'log_sha256': hashlib.sha256(log_path.read_bytes()).hexdigest()})
            (root / 'functional-preflight-summary.json').write_text(json.dumps(rows, indent=2) + '\n')
    assert len(signatures) == 1, case
print(json.dumps({'functional_children': len(rows), 'all_exits_zero': True,
                  'exact_signatures': True, 'no_performance_acceptance_evaluation': True}))
