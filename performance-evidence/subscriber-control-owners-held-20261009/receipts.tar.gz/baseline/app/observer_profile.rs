use super::*;
use std::{hash::{Hash, Hasher}, hint::black_box};

struct ObserverProfileGlobal;
impl Global for ObserverProfileGlobal {}

struct ObserverProfileView(Rc<Cell<usize>>);
impl Render for ObserverProfileView {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl crate::IntoElement {
        self.0.set(self.0.get() + 1);
        crate::Empty
    }
}

#[repr(C)]
struct ObserverTimespec {
    seconds: std::os::raw::c_long,
    nanoseconds: std::os::raw::c_long,
}
unsafe extern "C" {
    fn clock_gettime(clock: std::os::raw::c_int, result: *mut ObserverTimespec) -> std::os::raw::c_int;
    fn sysconf(name: std::os::raw::c_int) -> std::os::raw::c_long;
}
fn observer_thread_cpu_ns() -> u64 {
    let mut time = ObserverTimespec { seconds: 0, nanoseconds: 0 };
    assert_eq!(unsafe { clock_gettime(3, &mut time) }, 0);
    time.seconds as u64 * 1_000_000_000 + time.nanoseconds as u64
}
fn observer_current_rss_kib() -> usize {
    let fields = std::fs::read_to_string("/proc/self/statm").expect("native statm");
    let resident: usize = fields.split_whitespace().nth(1).expect("resident pages").parse().expect("page count");
    let page_size = unsafe { sysconf(30) };
    assert!(page_size > 0);
    resident * page_size as usize / 1024
}
fn notify_observer_profile(cx: &mut TestAppContext, emitter: &crate::Entity<usize>, global: bool) {
    if global {
        cx.update(|cx| cx.set_global(ObserverProfileGlobal));
    } else {
        cx.update(|cx| cx.notify(emitter.entity_id()));
    }
}

#[test]
#[ignore]
fn profile_observer_controls() {
    let case = std::env::var("OBSERVER_PROFILE_CASE").expect("OBSERVER_PROFILE_CASE");
    let parts: Vec<_> = case.split('-').collect();
    assert_eq!(parts.len(), 5);
    let global = parts[1] == "global";
    assert!(global || parts[1] == "entity");
    let churn = parts[2] == "churn";
    let close = parts[2] == "closed" || churn;
    assert!(close || parts[2] == "live");
    let retained = parts[3] == "on";
    let count: usize = parts[4].parse().expect("observer count");
    let iterations: usize = std::env::var("OBSERVER_PROFILE_ITERATIONS").unwrap_or_else(|_| "32".into()).parse().expect("iterations");
    #[cfg(gpui_layout_sets_census)]
    crate::perf_count::census::start();
    let mut cx = TestAppContext::single();
    cx.update(|cx| {
        cx.set_view_retention(retained);
        cx.set_global(ObserverProfileGlobal);
    });
    let draws = Rc::new(Cell::new(0));
    let window = cx.add_window({
        let draws = draws.clone();
        move |_, _| ObserverProfileView(draws)
    });
    for _ in 0..4 {
        cx.update_window(window.into(), |_, window, cx| window.draw(cx).clear(cx)).expect("warmup");
    }
    cx.update_window(window.into(), |_, window, _| window.reset_frame_work_stats(false)).expect("disable clocks");
    let emitter = cx.new(|_| 0usize);
    let progress = Rc::new(Cell::new(0usize));
    let mut subscriptions = Vec::with_capacity(count);
    let started = std::time::Instant::now();
    let cpu_started = observer_thread_cpu_ns();
    let cycles = if churn { 4 } else { 1 };
    for _ in 0..cycles {
    let first = progress.get();
    cx.update(|cx| {
        for index in 0..count {
            let progress = progress.clone();
            let callback = move || {
                assert_eq!(progress.get() % count, index, "observer callback order");
                progress.set(progress.get() + 1);
            };
            let subscription = if global {
                cx.observe_global::<ObserverProfileGlobal>(move |_| callback())
            } else {
                cx.observe(&emitter, move |_, _| callback())
            };
            subscriptions.push(subscription);
        }
    });
    for iteration in 0..iterations {
        notify_observer_profile(&mut cx, &emitter, global);
        assert_eq!(progress.get(), first + count * (iteration + 1));
    }
    if close {
        subscriptions.clear();
        cx.update(|_| {});
    }
    notify_observer_profile(&mut cx, &emitter, global);
    assert_eq!(progress.get(), first + count * (iterations + usize::from(!close)));
    assert_eq!(Rc::strong_count(&progress), if close { 1 } else { count + 1 });
    }
    black_box((&cx, &subscriptions, &emitter));
    let cpu_ns = observer_thread_cpu_ns() - cpu_started;
    let elapsed_ns = started.elapsed().as_nanos();
    #[cfg(gpui_layout_sets_census)]
    let (held_bytes, peak_bytes, requested_bytes, allocation_calls) = crate::perf_count::census::finish();
    #[cfg(not(gpui_layout_sets_census))]
    let (held_bytes, peak_bytes, requested_bytes, allocation_calls) = (-1, -1, 0, 0);
    let current_rss_kib = observer_current_rss_kib();
    let (queue_capacity, windows) = cx.update(|cx| {
        assert!(cx.pending_effects.is_empty());
        (cx.pending_effects.capacity(), cx.windows.len())
    });
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    (progress.get(), subscriptions.len(), Rc::strong_count(&progress), draws.get(), windows).hash(&mut hasher);
    let signature = hasher.finish();
    println!("OBSERVER_PROFILE {{\"case\":\"{case}\",\"cpu_ns\":{cpu_ns},\"elapsed_ns\":{elapsed_ns},\"signature\":{signature},\"state_count\":0,\"state_box_bytes\":0,\"held_bytes\":{held_bytes},\"peak_bytes\":{peak_bytes},\"requested_bytes\":{requested_bytes},\"allocation_calls\":{allocation_calls},\"current_rss_kib\":{current_rss_kib},\"queue_capacity\":{queue_capacity},\"completed_callbacks\":{},\"live_subscriptions\":{},\"draws\":{}}}", progress.get(), subscriptions.len(), draws.get());
}
