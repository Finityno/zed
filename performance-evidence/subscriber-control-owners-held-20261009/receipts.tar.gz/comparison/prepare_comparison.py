from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

root = Path(__file__).parent
source = Path('/workspace/zed-observer-controls')
baseline = '95114473898ea198175ab1d4fbb72d6e66de39ca'
environment = dict(os.environ, GIT_NO_LAZY_FETCH='1')
candidate = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], env=environment, text=True).strip()
crates = json.loads((root.parent / 'baseline-source-inputs.json').read_text())['crates']
changed_path = 'crates/gpui/src/subscription.rs'
before = subprocess.check_output(['git', '-C', str(source), 'show', baseline + ':' + changed_path], env=environment)
before += (root / 'control-regression.rs').read_bytes()
for lane in ['baseline', 'candidate']:
    work = root / (lane + '-workspace')
    work.mkdir()
    for name in crates:
        shutil.copytree(source / 'crates' / name, work / 'crates' / name, symlinks=True)
    for name in ['Cargo.toml', 'Cargo.lock', 'AGENTS.md', 'README.md', 'rust-toolchain.toml', 'LICENSE-APACHE', 'LICENSE-GPL']:
        shutil.copy2(source / name, work / name)
    shutil.copytree(source / '.cargo', work / '.cargo', symlinks=True)
    for name in ['ibm-plex-sans', 'lilex']:
        shutil.copytree(source / 'assets/fonts' / name, work / 'assets/fonts' / name, symlinks=True)
    if lane == 'baseline':
        (work / changed_path).write_bytes(before)
    (work / 'crates/gpui/src/perf_count.rs').write_bytes((root / 'perf-count.rs').read_bytes())
    path = work / 'crates/gpui/src/gpui.rs'
    path.write_text(path.read_text() + '\n#[cfg(all(test, gpui_layout_sets_census))]\n#[path = "perf_count.rs"]\npub(crate) mod perf_count;\n')
    path = work / 'crates/gpui/src/app.rs'
    path.write_text(path.read_text() + '\n#[cfg(all(test, target_os = "linux"))]\n#[path = "app/observer_profile.rs"]\nmod observer_profile;\n')
    (work / 'crates/gpui/src/app/observer_profile.rs').write_bytes((root / 'observer-fixture.rs').read_bytes())
    for src, dest in [('comparison-fixture.rs', 'splice_profile.rs'), ('transcript-fixture.rs', 'transcript_profile.rs')]:
        shutil.copy2(root / src, work / 'crates/gpui/src/window/view_retention' / dest)
    path = work / 'crates/gpui/src/window/view_retention/tests.rs'
    path.write_text(path.read_text() + '\n#[cfg(target_os = "linux")]\n#[path = "transcript_profile.rs"]\nmod transcript_profile;\n')
    files = {str(path.relative_to(work)): hashlib.sha256(path.read_bytes()).hexdigest() for path in work.rglob('*') if path.is_file()}
    (root / (lane + '-source-inputs.json')).write_text(json.dumps({
        'baseline': baseline, 'candidate': candidate, 'lane': lane, 'crates': crates, 'files': files,
        'description': 'Current24ownercrates/fullroot/lock/fonts/licenses. Identical72completeApp/Window fixtures, sharedcountingSystem and3newcontrol lifetime tests. OnlySubscriber control ownership differs.'}, indent=2) + '\n')
left = json.loads((root / 'baseline-source-inputs.json').read_text())['files']
right = json.loads((root / 'candidate-source-inputs.json').read_text())['files']
changed = [name for name in left if left[name] != right[name]]
assert changed == [changed_path]
for name, expected in json.loads((root / 'pre-candidate-frozen-method.json').read_text()).items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
(root / 'candidate-source.diff').write_bytes(subprocess.check_output(['git', '-C', str(source), 'diff', baseline, candidate], env=environment))
(root / 'comparison-source-receipt.json').write_text(json.dumps({
    'baseline': baseline, 'candidate': candidate, 'changed_source': changed, 'files_each': len(left),
    'policy_sha256': hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest()}, indent=2) + '\n')
print(json.dumps({'baseline': baseline, 'candidate': candidate, 'changed': changed, 'files': len(left)}))
