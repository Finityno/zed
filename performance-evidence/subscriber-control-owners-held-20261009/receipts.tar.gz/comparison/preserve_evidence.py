from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import platform
import tarfile

root = Path(__file__).parent
owner = root.parent
work = Path('/workspace/zed-observer-controls')
output = work / 'performance-evidence/subscriber-control-owners-held-20261009'
output.mkdir(parents=True)
decision = json.loads((root / 'decision.json').read_text())
policy = json.loads((root / 'policy.json').read_text())
assert not decision['qualified'] and len(decision['failures']) == 20
for name, expected in json.loads((root / 'frozen-inputs.json').read_text()).items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
runtime = json.loads((root / 'runtime-identities.json').read_text())
assert runtime['uname'] == platform.uname()._asdict()
for collection in ['dynamic_libraries', 'compiler_shared_libraries']:
    for path, expected in runtime[collection].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == expected['sha256']
assert hashlib.sha256(Path(runtime['compiler']).read_bytes()).hexdigest() == runtime['compiler_sha256']
for dependency in json.loads((root / 'external-dependencies.json').read_text()):
    assert hashlib.sha256(Path(dependency['path']).read_bytes()).hexdigest() == dependency['sha256']
for lane in ['baseline', 'candidate']:
    for path, expected in json.loads((root / (lane + '-source-inputs.json')).read_text())['files'].items():
        assert hashlib.sha256((root / (lane + '-workspace') / path).read_bytes()).hexdigest() == expected, path
    for identity in json.loads((root / 'binary-identities.json').read_text())[lane].values():
        assert hashlib.sha256(Path(identity['path']).read_bytes()).hexdigest() == identity['sha256']
builds = json.loads((root / 'build-order-receipt.json').read_text())['receipts']
phases = json.loads((root / 'valid-cohort-order-receipt.json').read_text())['receipts']
assert len(builds) == 4 and len(phases) == 2
assert phases[0]['started_unix'] >= builds[-1]['started_unix'] + builds[-1]['elapsed_seconds']
assert phases[1]['started_unix'] >= phases[0]['started_unix'] + phases[0]['elapsed_seconds']
for kind, count in [('bare', 1296), ('census', 720)]:
    samples = json.loads((root / (kind + '-samples.json')).read_text())
    assert len(samples) == count
    for sample in samples:
        assert sample['exit_code'] == 0
        assert hashlib.sha256(Path(sample['log']).read_bytes()).hexdigest() == sample['log_sha256']
assert len(json.loads((root / 'contracts-summary.json').read_text())) == 34
assert len(json.loads((root / 'functional-preflight-summary.json').read_text())) == 56
files = {}
for base, prefix in [(root, 'comparison'), (owner, 'attribution')]:
    for path in base.rglob('*'):
        relative = path.relative_to(base)
        if base == owner and relative.parts[0] == 'comparison':
            continue
        if any(part.endswith('-workspace') or part.endswith('-artifacts') for part in relative.parts):
            continue
        if path.is_file() and path.suffix in {'.py', '.json', '.log', '.diff', '.rs', '.c', '.md', '.txt'}:
            files[prefix + '/' + str(relative)] = path
for name in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'LICENSE-APACHE', 'LICENSE-GPL']:
    files['native-root/' + name] = root / 'candidate-workspace' / name
for lane in ['baseline', 'candidate']:
    for name in ['subscription.rs', 'app.rs', 'gpui.rs', 'perf_count.rs', 'app/observer_profile.rs']:
        files[lane + '/' + name] = root / (lane + '-workspace') / 'crates/gpui/src' / name
manifest = {name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
            for name, path in sorted(files.items())}
archive = output / 'receipts.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=6, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
    entries = [('manifest.json', (json.dumps(manifest, indent=2) + '\n').encode())]
    entries += [(name, path.read_bytes()) for name, path in sorted(files.items())]
    for name, data in entries:
        info = tarfile.TarInfo(name)
        info.size, info.mode = len(data), 0o644
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    for name, expected in manifest.items():
        data = tar.extractfile(name).read()
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
evidence = {
    'status': 'HELD/unmerged; no unchanged rerun or weaker gates', 'qualified': False,
    'baseline': policy['baseline'], 'source': 'db0c75766f22f43313731c42307b93a075742531',
    'fincode_main_at_freeze': policy['fincode_main'], 'fincode_gpui': policy['fincode_pin'],
    'component_pin': policy['component_pin'], 'valid_children': 2016, 'workloads': 72,
    'failures': decision['failures'], 'all_primary_memory_gain_fields_pass': True,
    'observed_primary_changes': {case: {metric: decision['summary']['census'][case][metric]
        for metric in ['allocation_calls', 'requested_bytes', 'held_bytes']} for case in policy['primary_cases']},
    'important_gain_not_qualified': '19.21–19.23% fewer completeApp allocationcalls,5.86–6.09% fewer requestedbytes,6.68–6.97% less heldheap;20 frozen transcriptCPU/elapsed/wholechild and censusnativeRSS controls fail. Eleven CPUfields and nineRSSfields. No normal requestedheap/churn field fails.',
    'mechanism': 'Subscriber activation and cancellation Cells share one Rc control owner; removes one allocation and8bytes from every subscriber node entry. Existing cancellation/activation order, callback ownership and removal semantics preserved. No new App fields, timers, GPU/renderer resources or caches.',
    'correctness': '34 native contract invocations pass. All7SubscriberSet callback/selfdrop/inertactivation/removal/replacement tests pass in4bare/census lanes. ExistingApp/Scene/windowidle/read/nested/retainedoracle16seeds50steps/wheel/dependency/panel/layout/atomic and independentcursorresize tests pass.56fourlane functional checks and2016pairwise callback/owner/window/state/scene/hitbox signatures match.',
    'protocol': 'Four sequential builds,1296alternatingbare children252.75s, then720separatecounting children33.89s. Identical59immutableexterns/Rust1.99/System/source/compiler/runtime/binary identities and frozenmethod reverified aftercohort. No restart or repeatedfailed samples.',
    'attribution': 'Existing owned sampled largeclosed heap ranks7.9MB observers; currentnative30realApp registration/notification/removal children preservecallbackcount/order/ownership. CountingCPU diagnostics are not gain evidence.',
    'not_run': 'Strict owning Clippy, PR creation, merge and coherent application adoption withheld because performance gates fail.',
    'limits': policy['limits'], 'policy_sha256': hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest(),
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'archive_bytes': archive.stat().st_size,
    'members': len(manifest) + 1,
}
(output / 'evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')
(output / 'README.md').write_text('''# Held shared subscription controls

One 2,016-child comparison across 72 complete App/Window workloads passes
all four observer memory targets but fails 20 frozen ordinary controls.
Complete-App allocation calls fall 19.21–19.23%, requested bytes fall
5.86–6.09% and held heap falls 6.68–6.97%. Eleven transcript CPU/elapsed/
whole-child fields and nine census native RSS fields fail. No normal requested
heap or allocation field fails. Do not rerun this design unchanged or weaken
its gates. No PR, merge or consumer adoption is qualified.

Activation and cancellation share one Rc control allocation; callbacks keep
the same lifetime and ordering. Seven cancellation/self-removal/inert/removal/
replacement tests pass in all four native lanes, together with the unchanged
App, Scene, idle-window, retained-frame, wheel, dependency, panel, layout,
atomic-claim, read and nested contracts and independent resize-hover checks.
All 56 functional preflight and 2,016 paired measured outputs match.

All raw samples, gates frozen before the production candidate, full source/
compiler/runtime/common 59 extern/binary identities and sequential process-group
receipts are archived and every member hash verified. Thirty current-main
complete-App observer attribution children are preserved. Native binaries and
source snapshots remain identified in the durable cloud receipts.

These are Linux fake-platform complete-component observations with System,
not app, physical GPU, macOS/Windows or shipped-allocator gains. Native timing
excludes setup and four warm-ups; requested-memory census includes them.
Independent work is preserved. Continue with a distinct paint-layer owner.
''')
(root / 'archive-verification.json').write_text(json.dumps({key: evidence[key] for key in
    ['archive_sha256', 'archive_bytes', 'members', 'valid_children', 'qualified']}, indent=2) + '\n')
print((root / 'archive-verification.json').read_text())
