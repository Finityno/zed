
#[cfg(test)]
mod control_lifetime_tests {
    use super::*;

    #[test]
    fn canceled_inert_subscription_cannot_be_reactivated() {
        let subscribers = SubscriberSet::new();
        let callback_owner = Rc::new(Cell::new(0usize));
        let (subscription, activate) = subscribers.insert(7usize, {
            let callback_owner = callback_owner.clone();
            move || callback_owner.set(callback_owner.get() + 1)
        });
        drop(subscription);
        assert_eq!(Rc::strong_count(&callback_owner), 1);
        activate();
        subscribers.retain(&7, |callback| {
            callback();
            true
        });
        assert_eq!(callback_owner.get(), 0);
    }

    #[test]
    fn inert_removal_releases_callback_while_control_handles_remain() {
        let subscribers = SubscriberSet::new();
        let callback_owner = Rc::new(Cell::new(0usize));
        let (subscription, activate) = subscribers.insert(7usize, {
            let callback_owner = callback_owner.clone();
            move || callback_owner.set(callback_owner.get() + 1)
        });
        assert_eq!(subscribers.remove(&7).into_iter().count(), 0);
        assert_eq!(Rc::strong_count(&callback_owner), 1);
        activate();
        drop(subscription);
        assert_eq!(callback_owner.get(), 0);
    }

    #[test]
    fn old_subscription_control_cannot_cancel_a_replacement() {
        let subscribers = SubscriberSet::new();
        let callback_owner = Rc::new(Cell::new(0usize));
        let make_callback = || {
            let callback_owner = callback_owner.clone();
            move || callback_owner.set(callback_owner.get() + 1)
        };
        let (old_subscription, old_activate) = subscribers.insert(7usize, make_callback());
        old_activate();
        drop(subscribers.remove(&7).into_iter().next());
        let (new_subscription, new_activate) = subscribers.insert(7usize, make_callback());
        new_activate();
        drop(old_subscription);
        subscribers.retain(&7, |callback| {
            callback();
            true
        });
        assert_eq!(callback_owner.get(), 1);
        drop(new_subscription);
        assert_eq!(Rc::strong_count(&callback_owner), 1);
    }
}
