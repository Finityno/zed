from pathlib import Path
import hashlib
import json
import shutil

root = Path(__file__).parent
source = Path('/workspace/zed-observer-controls')
work = root / 'baseline-workspace'
work.mkdir()
previous = Path('/workspace/scratch/gpui-effect-capacity-loop/comparison')
crates = json.loads((previous / 'baseline-source-inputs.json').read_text())['crates']
for crate in crates:
    shutil.copytree(source / 'crates' / crate, work / 'crates' / crate, symlinks=True)
for name in ['Cargo.toml', 'Cargo.lock', 'AGENTS.md', 'README.md', 'rust-toolchain.toml', 'LICENSE-APACHE', 'LICENSE-GPL']:
    shutil.copy2(source / name, work / name)
shutil.copytree(source / '.cargo', work / '.cargo', symlinks=True)
for name in ['ibm-plex-sans', 'lilex']:
    shutil.copytree(source / 'assets/fonts' / name, work / 'assets/fonts' / name, symlinks=True)
path = work / 'crates/gpui/src/gpui.rs'
path.write_text(path.read_text() + '\n#[cfg(all(test, gpui_layout_sets_census))]\n#[path = "perf_count.rs"]\npub(crate) mod perf_count;\n')
(work / 'crates/gpui/src/perf_count.rs').write_bytes((root / 'perf-count.rs').read_bytes())
path = work / 'crates/gpui/src/app.rs'
path.write_text(path.read_text() + '\n#[cfg(all(test, target_os = "linux"))]\n#[path = "app/observer_profile.rs"]\nmod observer_profile;\n')
(work / 'crates/gpui/src/app/observer_profile.rs').write_bytes((root / 'observer-fixture.rs').read_bytes())
for src, dest in [('comparison-fixture.rs', 'splice_profile.rs'), ('transcript-fixture.rs', 'transcript_profile.rs')]:
    shutil.copy2(previous / src, root / src)
    shutil.copy2(root / src, work / 'crates/gpui/src/window/view_retention' / dest)
path = work / 'crates/gpui/src/window/view_retention/tests.rs'
path.write_text(path.read_text() + '\n#[cfg(target_os = "linux")]\n#[path = "transcript_profile.rs"]\nmod transcript_profile;\n')
files = {str(path.relative_to(work)): hashlib.sha256(path.read_bytes()).hexdigest()
         for path in work.rglob('*') if path.is_file()}
(root / 'baseline-source-inputs.json').write_text(json.dumps({
    'baseline': '95114473898ea198175ab1d4fbb72d6e66de39ca', 'candidate': None,
    'lane': 'baseline', 'crates': crates, 'files': files,
    'description': 'Current24ownercrates/fullroot/lock/fonts/licenses; private real-App observer diagnostic, shared countingSystem and unchanged transcript/retained controls. No production modification.'}, indent=2) + '\n')
print(json.dumps({'baseline': '95114473898ea198175ab1d4fbb72d6e66de39ca', 'files': len(files), 'candidate': None}))
