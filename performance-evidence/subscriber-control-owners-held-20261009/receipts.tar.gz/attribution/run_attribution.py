from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path(__file__).parent
binary = root / 'baseline-census-artifacts/gpui-ada3fb4d7b1cfe56'
identity = {'path': str(binary), 'bytes': binary.stat().st_size,
            'sha256': hashlib.sha256(binary.read_bytes()).hexdigest()}
(root / 'attribution-binary-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
dependencies = json.loads((root / 'external-dependencies.json').read_text())
assert len(dependencies) == 59
for dependency in dependencies:
    assert hashlib.sha256(Path(dependency['path']).read_bytes()).hexdigest() == dependency['sha256']
cases = [f'observer-{kind}-live-{mode}-{count}' for kind in ['entity', 'global']
         for mode in ['off', 'on'] for count in [512, 8192]]
cases += [f'observer-{kind}-closed-on-8192' for kind in ['entity', 'global']]
output = root / 'attribution-receipts'
output.mkdir()
rows = []
for case in cases:
    for repeat in range(3):
        path = output / (case + '-' + str(repeat) + '.log')
        command = [str(root / 'native-run'), 'taskset', '-c', '2', str(binary),
                   'profile_observer_controls', '--ignored', '--nocapture', '--test-threads=1']
        environment = dict(os.environ, OBSERVER_PROFILE_CASE=case, OBSERVER_PROFILE_ITERATIONS='32')
        with path.open('w') as log:
            result = subprocess.run(command, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=60)
        log = path.read_text()
        row = {'case': case, 'repeat': repeat, 'command': command, 'exit_code': result.returncode,
               'binary_sha256': identity['sha256'], 'log': str(path),
               'log_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
        for line in log.splitlines():
            if 'OBSERVER_PROFILE ' in line:
                row.update(json.loads(line.split('OBSERVER_PROFILE ', 1)[1]))
            if line.startswith('NATIVE_RECEIPT '):
                row.update(json.loads(line.split(' ', 1)[1]))
        rows.append(row)
        (root / 'attribution-samples.json').write_text(json.dumps(rows, indent=2) + '\n')
        assert result.returncode == 0 and 'cpu_ns' in row, log
        assert row['live_subscriptions'] == (0 if '-closed-' in case else int(case.rsplit('-', 1)[1]))
print(json.dumps({'diagnostic_children': len(rows), 'all_exits_zero': True,
                  'complete_real_App_registration_notification_removal': True,
                  'counting_cpu_is_diagnostic_not_a_paired_gain': True}))
