use super::*;
use std::hint::black_box;

struct CacheRow { index: usize }
impl Render for CacheRow {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        let text = SharedString::from(format!("{} the quick brown fox", self.index));
        div().id(("cache-row", self.index)).w_full().h(px(24.)).child(text)
    }
}
struct CacheTranscript { rows: Vec<Entity<CacheRow>>, list_state: ListState, visible: bool }
impl Render for CacheTranscript {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        let rows = self.rows.clone();
        div().size_full().when(self.visible, |this| this.child(list(self.list_state.clone(), move |index, _, _| rows[index].clone().into_any_element()).size_full()))
    }
}

unsafe extern "C" { fn getpagesize() -> std::os::raw::c_int; }
fn current_rss_kib() -> usize {
    let text = std::fs::read_to_string("/proc/self/statm").expect("statm");
    let pages: usize = text.split_whitespace().nth(1).expect("rss pages").parse().expect("rss pages");
    pages * unsafe { getpagesize() } as usize / 1024
}

#[test]
#[ignore]
fn profile_line_cache_lifecycle() {
    let case = std::env::var("CACHE_PROFILE_CASE").expect("case");
    let parts: Vec<_> = case.split('-').collect();
    let scenario = parts[1];
    let retained = parts[2] == "on";
    let count: usize = parts[3].parse().expect("rows");
    let windows: usize = parts[4].parse().expect("windows");
    #[cfg(gpui_layout_sets_census)] crate::perf_count::census::start();
    let mut cx = super::super::super::layout_retention_tests::text_system_context(0);
    cx.update(|cx| cx.set_view_retention(retained));
    let views: Vec<_> = (0..windows).map(|_| {
        let view = cx.add_window(|_, cx| CacheTranscript { rows:(0..count).map(|index| cx.new(|_| CacheRow{index})).collect(),list_state:ListState::new(count,ListAlignment::Bottom,px(200.)),visible:true });
        cx.simulate_window_resize(view.into(),size(px(900.),px((count*24+100) as f32)));
        for _ in 0..4 { cx.update_window(view.into(),|_,window,cx| { window.refresh();window.draw(cx).clear(cx); }).expect("warm"); }
        cx.update_window(view.into(),|_,window,_| window.reset_frame_work_stats(false)).expect("disable clocks");
        view
    }).collect();
    let cycles = if scenario == "refault" {3} else {1};
    let start=Instant::now();let cpu_start=super::splice_profile::thread_cpu_ns();
    for cycle in 0..cycles {
        if scenario != "active" {
            for view in &views { view.update(&mut cx,|view,_,cx| { view.visible=false;cx.notify(); }).expect("hide"); }
            for _ in 0..4 { for view in &views { cx.update_window((*view).into(),|_,window,cx| { window.refresh();window.draw(cx).clear(cx); }).expect("empty"); } }
        }
        cx.executor().run_until_parked();cx.executor().advance_clock(Duration::from_secs(3));cx.executor().run_until_parked();
        if scenario == "resume" || scenario == "refault" && cycle+1<cycles {
            for view in &views { view.update(&mut cx,|view,_,cx| {view.visible=true;cx.notify();}).expect("show"); }
            for _ in 0..4 { for view in &views { cx.update_window((*view).into(),|_,window,cx| { window.refresh();window.draw(cx).clear(cx); }).expect("refill"); } }
        }
    }
    let cpu_ns=super::splice_profile::thread_cpu_ns()-cpu_start;let elapsed_ns=start.elapsed().as_nanos();
    let current_rss_kib=current_rss_kib();
    #[cfg(gpui_layout_sets_census)] let (held_bytes,peak_bytes,requested_bytes,allocation_calls)=crate::perf_count::census::snapshot();
    #[cfg(not(gpui_layout_sets_census))] let (held_bytes,peak_bytes,requested_bytes,allocation_calls)=(-1,-1,0,0);
    let mut signature=std::collections::hash_map::DefaultHasher::new();let mut state_count=0;let mut state_box_bytes=0;let mut owner_bytes=0isize;
    use std::hash::{Hash,Hasher};
    for view in &views {
        cx.update_window((*view).into(),|_,window,_| {
            describe_frame(window).hash(&mut signature);
            state_count+=window.rendered_frame.element_states.len();state_box_bytes+=window.rendered_frame.element_states.values().map(|state| std::mem::size_of_val(state.inner.as_ref())).sum::<usize>();
            owner_bytes+=crate::window::glyph_painting::line_cache_lifecycle_owner(window);
        }).expect("audit");
    }
    #[cfg(gpui_layout_sets_census)] crate::perf_count::census::finish();
    let signature=signature.finish();black_box(&cx);
    println!("CACHE_PROFILE {{\"case\":\"{case}\",\"cpu_ns\":{cpu_ns},\"elapsed_ns\":{elapsed_ns},\"signature\":{signature},\"state_count\":{state_count},\"state_box_bytes\":{state_box_bytes},\"held_bytes\":{held_bytes},\"peak_bytes\":{peak_bytes},\"requested_bytes\":{requested_bytes},\"allocation_calls\":{allocation_calls},\"owner_bytes\":{owner_bytes},\"current_rss_kib\":{current_rss_kib},\"app_size_bytes\":{},\"window_size_bytes\":{}}}",std::mem::size_of::<App>(),std::mem::size_of::<Window>());
}

#[cfg(test)]
mod idle_line_cache_contracts {
    use super::*;
    fn fixture(retained: bool, count: usize) -> (TestAppContext, WindowHandle<CacheTranscript>) {
        let mut cx = super::super::super::super::layout_retention_tests::text_system_context(0);
        cx.update(|cx| cx.set_view_retention(retained));
        let view = cx.add_window(|_, cx| CacheTranscript { rows: (0..count).map(|index| cx.new(|_| CacheRow { index })).collect(), list_state: ListState::new(count, ListAlignment::Bottom, px(200.)), visible: true });
        cx.simulate_window_resize(view.into(), size(px(900.), px((count * 24 + 100) as f32)));
        draw(&mut cx, view);
        (cx, view)
    }
    fn draw(cx: &mut TestAppContext, view: WindowHandle<CacheTranscript>) {
        for _ in 0..4 { cx.update_window(view.into(), |_, window, cx| {window.refresh(); window.draw(cx).clear(cx);}).expect("draw"); }
    }
    fn stats(cx: &mut TestAppContext, view: WindowHandle<CacheTranscript>) -> (usize, usize, usize, usize) {
        cx.update_window(view.into(), |_, window, _| crate::window::glyph_painting::line_cache_lifecycle_stats(window)).expect("stats")
    }
    fn frame(cx: &mut TestAppContext, view: WindowHandle<CacheTranscript>) -> Vec<String> {
        cx.update_window(view.into(), |_, window, _| describe_frame(window)).expect("frame")
    }
    fn idle(cx: &mut TestAppContext) {
        cx.executor().run_until_parked();cx.executor().advance_clock(Duration::from_secs(3));cx.executor().run_until_parked();
    }
    fn empty_maps_are_reclaimed(retained: bool) {
        let (mut cx, view) = fixture(retained, 1024);
        view.update(&mut cx, |view, _, cx| { view.visible = false; cx.notify(); }).expect("hide");
        draw(&mut cx, view);
        let before = stats(&mut cx, view);
        assert_eq!((before.0, before.1), (0, 0));
        assert!(before.2 > 224 && before.3 > 224, "fixture must grow both line tables: {before:?}");
        let expected = frame(&mut cx, view);
        idle(&mut cx);
        let after = stats(&mut cx, view);
        assert_eq!((after.0, after.1), (0, 0));
        assert!(after.2 <= 224 && after.3 <= 224, "empty line tables survived idle: {after:?}");
        assert_eq!(frame(&mut cx, view), expected, "idle cleanup must not draw or mutate the rendered frame");
        view.update(&mut cx, |view, _, cx| { view.visible = true; cx.notify(); }).expect("show");
        draw(&mut cx, view);
        assert!(!frame(&mut cx, view).is_empty());
    }
    #[test] fn empty_line_replay_maps_reclaimed_off() { empty_maps_are_reclaimed(false); }
    #[test] fn empty_line_replay_maps_reclaimed_on() { empty_maps_are_reclaimed(true); }
    #[test] fn live_line_replay_maps_and_sprites_survive_idle() {
        let (mut cx, view) = fixture(false, 1024);
        let before = stats(&mut cx, view);
        assert!(before.0 > 1000, "real paint must record live line sprites: {before:?}");
        let expected = frame(&mut cx, view);
        idle(&mut cx);
        assert_eq!(stats(&mut cx, view), before, "live scene keeps its capacity");
        assert_eq!(frame(&mut cx, view), expected);
        draw(&mut cx, view);
        assert_eq!(frame(&mut cx, view), expected, "cached sprites must still name the rendered frame");
    }
    #[test] fn recent_draw_defers_empty_line_replay_cleanup() {
        let (mut cx, view) = fixture(false, 1024);
        view.update(&mut cx, |view, _, cx| { view.visible = false; cx.notify(); }).expect("hide");draw(&mut cx, view);
        let expected = stats(&mut cx, view);
        cx.executor().run_until_parked();cx.executor().advance_clock(Duration::from_secs(1));
        draw(&mut cx, view);cx.executor().advance_clock(Duration::from_millis(1100));cx.executor().run_until_parked();
        assert_eq!(stats(&mut cx, view), expected, "recent draw keeps its quiet-period reserve");
    }
}
