from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).parent;old=Path('/workspace/scratch/gpui-line-color-loop/comparison')
for name in ['measure.py','qualify.py','run_measurements.py','capture_identities.py','check_contracts.py']:shutil.copy2(old/name,root/name)
p=root/'policy.json';policy=json.loads(p.read_text());policy['cold_memory_tradeoff']+=' 32row idle and live active cases allow zero added requested bytes/calls.';p.write_text(json.dumps(policy,indent=2)+'\n')
p=root/'measure.py';text=p.read_text().replace("pattern='profile_colored_transcript' if", "pattern='profile_line_cache_lifecycle' if case in policy['cache_cases'] else 'profile_colored_transcript' if").replace("COLOR_PROFILE_ITERATIONS=str(iterations))","COLOR_PROFILE_ITERATIONS=str(iterations),CACHE_PROFILE_CASE=case)").replace("'COLOR_PROFILE ']","'COLOR_PROFILE ','CACHE_PROFILE ']");p.write_text(text)
p=root/'qualify.py';text=p.read_text().replace("metrics=['cpu_ns'", "cache = case in policy['cache_cases']\n        windows = int(case.rsplit('-',1)[1]) if cache else 0\n        cycles = policy['cache_cycles'].get(case,0)\n        refills = policy['cache_refills'].get(case,0)\n        if cache:\n            assert all(old['app_size_bytes']==new['app_size_bytes'] and old['window_size_bytes']==new['window_size_bytes'] for old,new in zip(lanes['baseline'],lanes['candidate']))\n        metrics=['cpu_ns'")
text=text.replace("        values={}","        if cache: metrics += ['current_rss_kib'] if kind=='bare' else ['owner_bytes']\n        values={}")
text=text.replace("'child_cpu_ns','peak_rss_kib'] else 0", "'child_cpu_ns','peak_rss_kib','current_rss_kib'] else 0")
text=text.replace("            passed=new-old<=allowed", "            if cache:\n                if kind=='bare' and metric in ['cpu_ns','elapsed_ns','child_cpu_ns']:\n                    allowed=max(allowed,50000*windows*cycles)+(0.05*old if refills else 0)\n                if kind=='census' and metric in ['requested_bytes','allocation_calls'] and not '-32-' in case and not '-active-' in case:\n                    allowed=windows*(135712*cycles+2*1085472*refills) if metric=='requested_bytes' else windows*(2*cycles+6*refills)\n            passed=new-old<=allowed")
start=text.index("        if kind=='census' and case in policy['primary_cases']:");stop=text.index('        summary[case]=values',start)
text=text[:start]+'''        if case in policy['primary_cases']:
            targets=[('held_bytes',0.03),('owner_bytes',0.85)] if kind=='census' else [('current_rss_kib',0.02)]
            for metric,minimum in targets:
                value=values[metric];gain=value['baseline_median']-value['candidate_median']
                if gain/value['baseline_median']<minimum or gain<=max(value['baseline_range'],value['candidate_range']):failures.append([kind,case,metric,'primary gain',gain,value['baseline_range'],value['candidate_range'],minimum])
'''+text[stop:];p.write_text(text)
p=root/'check_contracts.py';text=p.read_text();start=text.index('contracts +=');stop=text.index('rows = []',start);text=text[:start]+text[stop:];p.write_text(text)
p=root/'run_measurements.py';p.write_text(p.read_text().replace("'/workspace/scratch/gpui-window-effects-loop/comparison'","'/workspace/scratch/gpui-line-color-loop/comparison'"))
p=root/'capture_identities.py';text=p.read_text();start=text.index('frozen = {name:');stop=text.index('previous = ',start)
names=['policy.json','measure.py','qualify.py','run_measurements.py','prepare_comparison.py','build_native.py','build_all.py','supervise.py','check_contracts.py','comparison-fixture.rs','transcript-fixture.rs','color-fixture.rs','cache-fixture.rs','perf-count.rs','cache-owner-helper.rs','native_run.c','native-run','external-dependencies.json']
text=text[:start]+"frozen = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in "+repr(names+['binary-identities.json','runtime-identities.json','baseline-source-inputs.json','candidate-source-inputs.json'])+"}\n"+text[stop:];p.write_text(text)
identities={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names};(root/'pre-candidate-frozen-method.json').write_text(json.dumps(identities,indent=2)+'\n')
print(json.dumps({'frozen_method':len(identities),'policy_sha256':identities['policy.json'],'gain_goal':'3%held/85%owner/2%nativeRSS, all four primary cases; explicit cleanup/refill budgets only'}))
