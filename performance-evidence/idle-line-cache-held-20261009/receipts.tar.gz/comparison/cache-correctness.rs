
#[cfg(test)]
mod idle_line_cache_contracts {
    use super::*;
    fn fixture(retained: bool, count: usize) -> (TestAppContext, WindowHandle<CacheTranscript>) {
        let mut cx = super::super::super::super::layout_retention_tests::text_system_context(0);
        cx.update(|cx| cx.set_view_retention(retained));
        let view = cx.add_window(|_, cx| CacheTranscript { rows: (0..count).map(|index| cx.new(|_| CacheRow { index })).collect(), list_state: ListState::new(count, ListAlignment::Bottom, px(200.)), visible: true });
        cx.simulate_window_resize(view.into(), size(px(900.), px((count * 24 + 100) as f32)));
        draw(&mut cx, view);
        (cx, view)
    }
    fn draw(cx: &mut TestAppContext, view: WindowHandle<CacheTranscript>) {
        for _ in 0..4 { cx.update_window(view.into(), |_, window, cx| {window.refresh(); window.draw(cx).clear(cx);}).expect("draw"); }
    }
    fn stats(cx: &mut TestAppContext, view: WindowHandle<CacheTranscript>) -> (usize, usize, usize, usize) {
        cx.update_window(view.into(), |_, window, _| crate::window::glyph_painting::line_cache_lifecycle_stats(window)).expect("stats")
    }
    fn frame(cx: &mut TestAppContext, view: WindowHandle<CacheTranscript>) -> Vec<String> {
        cx.update_window(view.into(), |_, window, _| describe_frame(window)).expect("frame")
    }
    fn idle(cx: &mut TestAppContext) {
        cx.executor().run_until_parked();cx.executor().advance_clock(Duration::from_secs(3));cx.executor().run_until_parked();
    }
    fn empty_maps_are_reclaimed(retained: bool) {
        let (mut cx, view) = fixture(retained, 1024);
        view.update(&mut cx, |view, _, cx| { view.visible = false; cx.notify(); }).expect("hide");
        draw(&mut cx, view);
        let before = stats(&mut cx, view);
        assert_eq!((before.0, before.1), (0, 0));
        assert!(before.2 > 224 && before.3 > 224, "fixture must grow both line tables: {before:?}");
        let expected = frame(&mut cx, view);
        idle(&mut cx);
        let after = stats(&mut cx, view);
        assert_eq!((after.0, after.1), (0, 0));
        assert!(after.2 <= 224 && after.3 <= 224, "empty line tables survived idle: {after:?}");
        assert_eq!(frame(&mut cx, view), expected, "idle cleanup must not draw or mutate the rendered frame");
        view.update(&mut cx, |view, _, cx| { view.visible = true; cx.notify(); }).expect("show");
        draw(&mut cx, view);
        assert!(!frame(&mut cx, view).is_empty());
    }
    #[test] fn empty_line_replay_maps_reclaimed_off() { empty_maps_are_reclaimed(false); }
    #[test] fn empty_line_replay_maps_reclaimed_on() { empty_maps_are_reclaimed(true); }
    #[test] fn live_line_replay_maps_and_sprites_survive_idle() {
        let (mut cx, view) = fixture(false, 1024);
        let before = stats(&mut cx, view);
        assert!(before.0 > 1000, "real paint must record live line sprites: {before:?}");
        let expected = frame(&mut cx, view);
        idle(&mut cx);
        assert_eq!(stats(&mut cx, view), before, "live scene keeps its capacity");
        assert_eq!(frame(&mut cx, view), expected);
        draw(&mut cx, view);
        assert_eq!(frame(&mut cx, view), expected, "cached sprites must still name the rendered frame");
    }
    #[test] fn recent_draw_defers_empty_line_replay_cleanup() {
        let (mut cx, view) = fixture(false, 1024);
        view.update(&mut cx, |view, _, cx| { view.visible = false; cx.notify(); }).expect("hide");draw(&mut cx, view);
        let expected = stats(&mut cx, view);
        cx.executor().run_until_parked();cx.executor().advance_clock(Duration::from_secs(1));
        draw(&mut cx, view);cx.executor().advance_clock(Duration::from_millis(1100));cx.executor().run_until_parked();
        assert_eq!(stats(&mut cx, view), expected, "recent draw keeps its quiet-period reserve");
    }
}
