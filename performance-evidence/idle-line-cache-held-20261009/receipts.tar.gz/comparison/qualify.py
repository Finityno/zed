from pathlib import Path
import json,statistics
root=Path(__file__).parent;policy=json.loads((root/'policy.json').read_text());results={};failures=[]
for kind in ['bare','census']:
    samples=json.loads((root/(kind+'-samples.json')).read_text());pairs=policy['timing_pairs'] if kind=='bare' else policy['memory_pairs']
    assert len(samples)==len(policy['controls'])*pairs*2
    summary={}
    for case in policy['controls']:
        lanes={lane:sorted([r for r in samples if r['case']==case and r['lane']==lane],key=lambda r:r['pair']) for lane in ['baseline','candidate']}
        assert all(len(rows)==pairs for rows in lanes.values())
        for before,after in zip(lanes['baseline'],lanes['candidate']):
            assert all(before[key]==after[key] for key in ['signature','state_count','state_box_bytes','exit_code']) and before['exit_code']==0
            if case in policy['color_cases']:assert before['replayed']==after['replayed']
        cache = case in policy['cache_cases']
        windows = int(case.rsplit('-',1)[1]) if cache else 0
        cycles = policy['cache_cycles'].get(case,0)
        refills = policy['cache_refills'].get(case,0)
        if cache:
            assert all(old['app_size_bytes']==new['app_size_bytes'] and old['window_size_bytes']==new['window_size_bytes'] for old,new in zip(lanes['baseline'],lanes['candidate']))
        metrics=['cpu_ns','elapsed_ns','child_cpu_ns','peak_rss_kib'] if kind=='bare' else ['held_bytes','peak_bytes','requested_bytes','allocation_calls','peak_rss_kib']
        if cache: metrics += ['current_rss_kib'] if kind=='bare' else ['owner_bytes']
        values={}
        for metric in metrics:
            before=[row[metric] for row in lanes['baseline']];after=[row[metric] for row in lanes['candidate']];old=statistics.median(before);new=statistics.median(after);old_range=max(before)-min(before);new_range=max(after)-min(after)
            allowed=old_range if metric in ['cpu_ns','elapsed_ns','child_cpu_ns','peak_rss_kib','current_rss_kib'] else 0
            if cache:
                if kind=='bare' and metric in ['cpu_ns','elapsed_ns','child_cpu_ns']:
                    allowed=max(allowed,50000*windows*cycles)+(0.05*old if refills else 0)
                if kind=='census' and metric in ['requested_bytes','allocation_calls'] and not '-32-' in case and not '-active-' in case:
                    allowed=windows*(135712*cycles+2*1085472*refills) if metric=='requested_bytes' else windows*(2*cycles+6*refills)
            passed=new-old<=allowed
            if not passed:failures.append([kind,case,metric,'control',new-old,allowed])
            values[metric]={'baseline_median':old,'candidate_median':new,'baseline_min':min(before),'baseline_max':max(before),'candidate_min':min(after),'candidate_max':max(after),'baseline_range':old_range,'candidate_range':new_range,'change_percent':(new/old-1)*100 if old else None,'allowed_increase':allowed,'pass':passed}
        if case in policy['primary_cases']:
            targets=[('held_bytes',0.03),('owner_bytes',0.85)] if kind=='census' else [('current_rss_kib',0.02)]
            for metric,minimum in targets:
                value=values[metric];gain=value['baseline_median']-value['candidate_median']
                if gain/value['baseline_median']<minimum or gain<=max(value['baseline_range'],value['candidate_range']):failures.append([kind,case,metric,'primary gain',gain,value['baseline_range'],value['candidate_range'],minimum])
        summary[case]=values
    results[kind]=summary
decision={'qualified':not failures,'failures':failures,'summary':results,'primary':{case:{kind:results[kind][case] for kind in results} for case in policy['primary_cases']}}
(root/'decision.json').write_text(json.dumps(decision,indent=2)+'\n');print(json.dumps({'qualified':decision['qualified'],'failures':failures,'primary':decision['primary']}))
