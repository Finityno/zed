
#[cfg(test)]
pub(crate) fn line_cache_lifecycle_owner(window: &mut Window) -> isize {
    #[cfg(gpui_layout_sets_census)]
    {
        let before = crate::perf_count::census::snapshot().0;
        drop(std::mem::take(&mut window.line_glyph_cache.previous));
        drop(std::mem::take(&mut window.line_glyph_cache.current));
        before - crate::perf_count::census::snapshot().0
    }
    #[cfg(not(gpui_layout_sets_census))]
    {
        std::hint::black_box(window);
        -1
    }
}

#[cfg(test)]
pub(crate) fn line_cache_lifecycle_stats(window: &Window) -> (usize, usize, usize, usize) {
    (window.line_glyph_cache.previous.len(), window.line_glyph_cache.current.len(), window.line_glyph_cache.previous.capacity(), window.line_glyph_cache.current.capacity())
}
