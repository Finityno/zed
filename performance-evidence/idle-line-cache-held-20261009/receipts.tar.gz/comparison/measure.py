from pathlib import Path
import os,json,subprocess,hashlib,sys
root=Path(__file__).parent
policy=json.loads((root/'policy.json').read_text());lanes=json.loads((root/'binary-identities.json').read_text());kind=sys.argv[1]
pairs=policy['timing_pairs'] if kind=='bare' else policy['memory_pairs'];iterations=policy['timing_iterations'] if kind=='bare' else policy['memory_iterations']
output=root/(kind+'-receipts');output.mkdir();policy_hash=hashlib.sha256((root/'policy.json').read_bytes()).hexdigest();rows=[]
for case in policy['controls']:
    for pair in range(pairs):
        for lane in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
            binary=lanes[lane][kind]['path'];assert hashlib.sha256(Path(binary).read_bytes()).hexdigest()==lanes[lane][kind]['sha256']
            pattern='profile_line_cache_lifecycle' if case in policy['cache_cases'] else 'profile_colored_transcript' if case in policy['color_cases'] else 'profile_transcript_paint' if case in policy['transcript_cases'] else 'profile_layout_key_sets'
            command=[str(root/'native-run'),'taskset','-c','2',binary,pattern,'--ignored','--nocapture','--test-threads=1']
            environment=dict(os.environ,LAYOUT_SETS_PROFILE_CASE=case,LAYOUT_SETS_PROFILE_ITERATIONS=str(iterations),TRANSCRIPT_PROFILE_CASE=case,TRANSCRIPT_PROFILE_ITERATIONS=str(iterations),COLOR_PROFILE_CASE=case,COLOR_PROFILE_ITERATIONS=str(iterations),CACHE_PROFILE_CASE=case)
            path=output/f'{case}-{pair:02}-{lane}.log'
            with path.open('w') as stream:result=subprocess.run(command,env=environment,stdout=stream,stderr=subprocess.STDOUT,timeout=70)
            receipt={'case':case,'pair':pair,'lane':lane,'kind':kind,'command':command,'exit_code':result.returncode,'log':str(path),'log_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'binary_sha256':lanes[lane][kind]['sha256'],'policy_sha256':policy_hash}
            for line in path.read_text().splitlines():
                for marker in ['LAYOUT_SETS_PROFILE ','TRANSCRIPT_PROFILE ','COLOR_PROFILE ','CACHE_PROFILE ']:
                    if marker in line:receipt.update(json.loads(line.split(marker,1)[1]))
                if line.startswith('NATIVE_RECEIPT '):receipt.update(json.loads(line.split(' ',1)[1]));receipt['child_cpu_ns']=(receipt['user_cpu_us']+receipt['system_cpu_us'])*1000
            rows.append(receipt);(root/(kind+'-samples.json')).write_text(json.dumps(rows,indent=2)+'\n')
            assert result.returncode==0 and 'cpu_ns' in receipt,path.read_text()
print(json.dumps({'kind':kind,'children':len(rows),'all_exits_zero':True}))
