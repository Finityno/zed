from pathlib import Path
import hashlib,json,os,shutil,subprocess
root=Path(__file__).parent;source=Path('/workspace/zed-line-cache-idle');baseline='b3136c6e2e6a8b2ac871ba1f59a0e2a6600db467';env=dict(os.environ,GIT_NO_LAZY_FETCH='1');candidate=subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],env=env,text=True).strip();crates=json.loads((root.parent/'baseline-source-inputs.json').read_text())['crates']
for lane in ['baseline','candidate']:
    work=root/(lane+'-workspace');work.mkdir()
    for name in crates:shutil.copytree(source/'crates'/name,work/'crates'/name,symlinks=True)
    for name in ['Cargo.toml','Cargo.lock','README.md','rust-toolchain.toml','LICENSE-APACHE','LICENSE-GPL']:shutil.copy2(source/name,work/name)
    shutil.copy2(root.parent/'AGENTS.current.md',work/'AGENTS.md');shutil.copytree(source/'.cargo',work/'.cargo',symlinks=True)
    for name in ['ibm-plex-sans','lilex']:shutil.copytree(source/'assets/fonts'/name,work/'assets/fonts'/name,symlinks=True)
    if lane=='baseline':
        for path in ['crates/gpui/src/window/glyph_painting.rs','crates/gpui/src/window.rs']:(work/path).write_bytes(subprocess.check_output(['git','-C',str(source),'show',baseline+':'+path],env=env))
    shutil.copy2(root/'perf-count.rs',work/'crates/gpui/src/perf_count.rs')
    p=work/'crates/gpui/src/gpui.rs';p.write_text(p.read_text()+'\n#[cfg(all(test, gpui_layout_sets_census))]\n#[path = "perf_count.rs"]\npub(crate) mod perf_count;\n')
    for src,dest in [('comparison-fixture.rs','splice_profile.rs'),('transcript-fixture.rs','transcript_profile.rs'),('color-fixture.rs','color_profile.rs'),('cache-fixture.rs','cache_profile.rs')]:shutil.copy2(root/src,work/'crates/gpui/src/window/view_retention'/dest)
    p=work/'crates/gpui/src/window/view_retention/tests.rs';p.write_text(p.read_text()+''.join('\n#[cfg(target_os = "linux")]\n#[path = "'+name+'_profile.rs"]\nmod '+name+'_profile;\n' for name in ['transcript','color','cache']))
    p=work/'crates/gpui/src/window/glyph_painting.rs';p.write_text(p.read_text()+(root/'cache-owner-helper.rs').read_text())
    files={str(p.relative_to(work)):hashlib.sha256(p.read_bytes()).hexdigest() for p in work.rglob('*') if p.is_file()};(root/(lane+'-source-inputs.json')).write_text(json.dumps({'baseline':baseline,'candidate':candidate,'lane':lane,'crates':crates,'files':files,'description':'Currentb31324crates/root/lock/licenses/fonts,111commoncomplete App/Window fixtures/System; idle line-cache cleanup only production difference.'},indent=2)+'\n')
left=json.loads((root/'baseline-source-inputs.json').read_text())['files'];right=json.loads((root/'candidate-source-inputs.json').read_text())['files'];changed=[p for p in left if left[p]!=right[p]];assert sorted(changed)==['crates/gpui/src/window.rs','crates/gpui/src/window/glyph_painting.rs'],changed
for name,expected in json.loads((root/'pre-candidate-frozen-method.json').read_text()).items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected,name
(root/'candidate-source.diff').write_bytes(subprocess.check_output(['git','-C',str(source),'diff',baseline,candidate],env=env));(root/'comparison-source-receipt.json').write_text(json.dumps({'baseline':baseline,'candidate':candidate,'changed':changed,'files':len(left),'policy_sha256':hashlib.sha256((root/'policy.json').read_bytes()).hexdigest()},indent=2)+'\n');print(json.dumps({'baseline':baseline,'candidate':candidate,'changed':changed,'files':len(left)}))
