from pathlib import Path
import gzip,hashlib,io,json,platform,tarfile
root=Path(__file__).parent;owner=root.parent;work=Path('/workspace/zed-line-cache-idle');output=work/'performance-evidence/idle-line-cache-held-20261009';output.mkdir(parents=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((root/'decision.json').read_text());policy=json.loads((root/'policy.json').read_text());assert not d['qualified'] and len(d['failures'])==35
for index in ['frozen-inputs.json','pre-candidate-frozen-method.json']:
    for name,expected in json.loads((root/index).read_text()).items():assert sha(owner/name if name=='source-review.json' else root/name)==expected,name
runtime=json.loads((root/'runtime-identities.json').read_text());assert runtime['uname']==platform.uname()._asdict()
for collection in ['dynamic_libraries','compiler_shared_libraries']:
    for path,expected in runtime[collection].items():assert sha(Path(path))==expected['sha256']
assert sha(Path(runtime['compiler']))==runtime['compiler_sha256']
for dep in json.loads((root/'external-dependencies.json').read_text()):assert sha(Path(dep['path']))==dep['sha256']
for lane in ['baseline','candidate']:
    for path,expected in json.loads((root/(lane+'-source-inputs.json')).read_text())['files'].items():assert sha(root/(lane+'-workspace')/path)==expected,path
    for identity in json.loads((root/'binary-identities.json').read_text())[lane].values():assert sha(Path(identity['path']))==identity['sha256']
builds=json.loads((root/'build-order-receipt.json').read_text())['receipts'];phases=json.loads((root/'valid-cohort-order-receipt.json').read_text())['receipts'];assert len(builds)==4 and len(phases)==2
assert phases[0]['started_unix']>=builds[-1]['started_unix']+builds[-1]['elapsed_seconds'];assert phases[1]['started_unix']>=phases[0]['started_unix']+phases[0]['elapsed_seconds']
for kind,count in [('bare',1998),('census',1110)]:
    samples=json.loads((root/(kind+'-samples.json')).read_text());assert len(samples)==count
    for row in samples:assert row['exit_code']==0 and sha(Path(row['log']))==row['log_sha256']
assert len(json.loads((root/'contracts-summary.json').read_text()))==46
assert len(json.loads((root/'functional-preflight-summary.json').read_text())['rows'])==212
layouts=json.loads((root/'fixed-owner-layout-verification.json').read_text());assert layouts['baseline']==layouts['candidate']=={'app':1896,'window':12944}
files={}
for base,prefix in [(root,'comparison'),(owner,'attribution')]:
    for path in base.rglob('*'):
        relative=path.relative_to(base)
        if base==owner and relative.parts[0]=='comparison':continue
        if any(part.endswith('-workspace') or part.endswith('-artifacts') for part in relative.parts):continue
        if relative.name in ['source-refresh.json','source-latest-refresh.json','remote-refresh.json','Cargo.fincode.current.toml','next-layout-cache-audit.json']:continue
        if path.is_file() and path.suffix in {'.py','.json','.log','.diff','.rs','.c','.md','.txt'}:files[prefix+'/'+str(relative)]=path
for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','LICENSE-APACHE','LICENSE-GPL']:files['native-root/'+name]=root/'candidate-workspace'/name
for lane in ['baseline','candidate']:
    for name in ['window.rs','window/glyph_painting.rs','gpui.rs','perf_count.rs','window/view_retention/splice_profile.rs','window/view_retention/transcript_profile.rs','window/view_retention/color_profile.rs','window/view_retention/cache_profile.rs']:files[lane+'/'+name]=root/(lane+'-workspace')/'crates/gpui/src'/name
files['owner-instrumented/glyph_painting.rs']=owner/'baseline-workspace/crates/gpui/src/window/glyph_painting.rs'
manifest={name:{'bytes':path.stat().st_size,'sha256':sha(path)} for name,path in sorted(files.items())};archive=output/'receipts.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=6,mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
    for name,data in [('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())]+[(name,path.read_bytes()) for name,path in sorted(files.items())]:
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    for name,expected in manifest.items():
        data=tar.extractfile(name).read();assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
source='dabb94e5272dcc474e0a918f8131f501d51f6a39'
evidence={'status':'HELD/unmerged; no unchanged rerun or weakened gates','qualified':False,'baseline':policy['baseline'],'source':source,'fincode_main_at_freeze':policy['fincode_main'],'fincode_gpui':policy['fincode_pin'],'component_pin':policy['component_pin'],'valid_children':3108,'workloads':111,'failures':d['failures'],'observed_primary':d['primary'],'all_primary_memory_gain_targets_pass':True,'important_gain_not_qualified':'All4large idle primaries: held requested heap3.36-4.42% lower; owner87.4974% lower; bare currentRSS2.84-4.39% lower; all gains exceed both full lane ranges.35 CPU/elapsed/whole-child, nativeRSS and refill peak-heap controls fail. No merge/adoption qualified.','mechanism':'Add existing idle callback call to shrink both line-replay tables at max(128,2*max(live lengths)). No fields/timer/task/draw or hot paint changes; live records/Arc identities/ranges remain. Source only2files/9lines. Existing sprite replay/cache bounding/atlas retirement and demand-driven frame changes preserved.','cold_costs':'Each large idle cycle allocates135712 requested bytes/two calls per window, inside frozen allowance; same32row and active cases have zero added calls/bytes. Cold resume/refault raises peak requested heap259944-262996B; four peak-heap controls fail. Preserve explicit predeclared cleanup/refill budgets, do not relax peak or RSS limits.','correctness':'46final native contract invocations,134passed plus2expected baseline-red empty-cache regressions. Realpaint/actualwindowquiet: baseline keeps1758/1792 and1776/1792 capacity; candidate shrinks both<=224 in bothretentionmodes. Live maps/sprites remain, recentdraw waits fullquietperiod.212fourlane functional children and3108paired scene/state/replay outputs equal. Scene25,text12incl1200frameatlasretirement, app/subscriber/read/nested/retained/wheel/panel/layout/cursor/frame-demand contracts preserve. App1896/Window12944 identical.','protocol':'Four sequential builds52.53/48.42/50.27/51.72s,1998barechildren676.148s,1110censuschildren226.055s. Same59immutableextern/compiler/System/root/lock/runtime identities verified before/after. All methods frozen before source, no repeated cohort. Currentmain refreshed before candidate from953d tob313 while preserving original owner diagnostics/initial freeze.','attribution':'12current953d controlled owners after text removal/four emptyframes/3s virtualidle. Empty replay table ownership33952/271392/1085472B per32/256/1024rows, fourlarge4,341,888B. Actual private table exclusion, not size estimate. Small32mapdrop RSS increases64KiB, adverse result preserved. Currentb313 maps/idle gap unchanged and its realnative regressions confirm retention before candidate.','coverage_limit':'Large stress viewport exposes1024rows before hiding, not typical viewport or wholeFincode gain. Bothretentionmodes,1/4windows,32/256controls,active/resume/3cycle refault; timers virtual. Complete App allocation from beforecreation includes4warmups; componenttime excludes setup and audit. NativeRSS before audit; census ownership probe clears maps after timing/snapshot. Native fakeplatform/text/renderer/System only, not physicalGPU/macOS/Windows/shippedallocator. Recolor notifies200rows individually and is a burst, not batchedtheme change.','adverse_setup':'All4builds and functional/correctness setup pass directly. Initial953d owner/source freeze preserved; no production candidate or paired samples before b313 refresh and added native correctness gates. Initialsource materialization/symlink copies from prior setup kept in owner tree. No performance resampling.','not_run':'Strict owningClippy/guards/PR/merge/consumeradoption withheld because frozen performance controls fail.','policy_sha256':sha(root/'policy.json'),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(manifest)+1}
(output/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(output/'README.md').write_text('''# Held idle line-replay table cleanup

All four large idle memory targets pass: 3.36-4.42% less requested live heap,
87.497% less empty-table ownership, and 2.84-4.39% less native current RSS.
Each gain exceeds both full lane ranges. The candidate remains unmerged:
35 CPU, elapsed, whole-child, RSS and cold-refill peak-heap controls fail.
Refill raises requested peak by 259,944-262,996 bytes. Do not resample this
source unchanged or weaken its frozen limits. No PR or adoption qualifies.

The existing idle callback shrinks both replay tables to at least 128 entries
or twice their largest live length. It preserves live line records and adds
no fields, timer, task, draw or hot-paint change. Native App and Window sizes
remain 1,896 and 12,944 bytes. Real empty-map idle regressions fail on baseline
and pass in both retention modes; live sprites and recent-draw quiet protection
pass. All 212 functional and 3,108 paired scene/state/replay outputs match.
Forty-six correctness invocations yield 134 passes plus two expected baseline
regressions. Existing atlas, retained, wheel, layout and frame-demand guards pass.

Twelve owner diagnostics attribute the current empty tables directly, including
the adverse small-owner RSS result. Current-main changes were preserved before
candidate creation. Both lanes use the same 59 immutable externs, compiler,
root and lockfile, with bare timing and counting allocator census run separately.
All raw data, exact source/runtime identities and cold allocation budgets are
retained. Each archive member is hash verified after sequential measurement.

These are complete native Linux App/Window fixtures using fake text, platform,
renderer and System. The 1,024-row exposed viewport is a high-water stress case;
results are not whole Fincode, physical GPU, macOS/Windows or shipped-allocator
percentages. Continue with the distinct retained layout-cache bottleneck.
''')
(root/'archive-verification.json').write_text(json.dumps({key:evidence[key] for key in ['archive_sha256','archive_bytes','members','valid_children','qualified']},indent=2)+'\n')
print((root/'archive-verification.json').read_text())
