from pathlib import Path
import json,hashlib,shutil
root=Path(__file__).parent;source=Path('/workspace/zed-line-cache-idle');work=root/'baseline-workspace';work.mkdir()
crates=json.loads(Path('/workspace/scratch/gpui-window-effects-loop/baseline-source-inputs.json').read_text())['crates']
for name in crates:shutil.copytree(source/'crates'/name,work/'crates'/name,symlinks=True)
for name in ['Cargo.toml','Cargo.lock','README.md','rust-toolchain.toml','LICENSE-APACHE','LICENSE-GPL']:shutil.copy2(source/name,work/name)
shutil.copy2(root/'AGENTS.current.md',work/'AGENTS.md');shutil.copytree(source/'.cargo',work/'.cargo',symlinks=True)
for name in ['ibm-plex-sans','lilex']:shutil.copytree(source/'assets/fonts'/name,work/'assets/fonts'/name,symlinks=True)
common=Path('/workspace/scratch/gpui-window-effects-loop/comparison')
shutil.copy2(common/'perf-count.rs',work/'crates/gpui/src/perf_count.rs')
p=work/'crates/gpui/src/gpui.rs';p.write_text(p.read_text()+'\n#[cfg(all(test, gpui_layout_sets_census))]\n#[path = "perf_count.rs"]\npub(crate) mod perf_count;\n')
shutil.copy2(common/'comparison-fixture.rs',work/'crates/gpui/src/window/view_retention/splice_profile.rs')
shutil.copy2(root/'owner-fixture.rs',work/'crates/gpui/src/window/view_retention/cache_owner_profile.rs')
p=work/'crates/gpui/src/window/view_retention/tests.rs';p.write_text(p.read_text()+'\n#[cfg(target_os = "linux")]\n#[path = "cache_owner_profile.rs"]\nmod cache_owner_profile;\n')
p=work/'crates/gpui/src/window/glyph_painting.rs';p.write_text(p.read_text()+'''
#[cfg(all(test, gpui_layout_sets_census))]
pub(crate) fn line_cache_owner_diagnostic(window: &mut Window) -> (usize,usize,usize,usize,isize) {
    let cache = &mut window.line_glyph_cache;
    let previous_len = cache.previous.len();
    let current_len = cache.current.len();
    assert_eq!((previous_len,current_len),(0,0), "all text removed across full frames");
    let previous_capacity = cache.previous.capacity();
    let current_capacity = cache.current.capacity();
    let before = crate::perf_count::census::snapshot().0;
    drop(std::mem::take(&mut cache.previous));
    drop(std::mem::take(&mut cache.current));
    let owner_bytes = before - crate::perf_count::census::snapshot().0;
    (previous_len,current_len,previous_capacity,current_capacity,owner_bytes)
}
''')
files={str(p.relative_to(work)):hashlib.sha256(p.read_bytes()).hexdigest() for p in work.rglob('*') if p.is_file()}
(root/'baseline-source-inputs.json').write_text(json.dumps({'baseline':'953d2ba3623b5a67fe3d922e36f43d9259bda019','candidate':None,'crates':crates,'files':files,'scope':'Exactcurrentnative App/Window owner diagnostics. Large viewport warmup then text removal/four empty frames/3s virtualquiet; measure empty cache map capacity and actual requested-owner bytes by private field-exclusion. No production change.'},indent=2)+'\n')
for name in ['build_native.py','supervise.py','native-run','native_run.c','external-dependencies.json']:shutil.copy2(common/name,root/name)
print(json.dumps({'baseline':'953d2ba3623b5a67fe3d922e36f43d9259bda019','files':len(files),'no_production_change':True}))
