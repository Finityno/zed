#[test]
#[ignore]
fn profile_line_cache_lifecycle() {
    let case = std::env::var("CACHE_PROFILE_CASE").expect("case");
    let parts: Vec<_> = case.split('-').collect();
    let scenario = parts[1];
    let retained = parts[2] == "on";
    let count: usize = parts[3].parse().expect("rows");
    let windows: usize = parts[4].parse().expect("windows");
    #[cfg(gpui_layout_sets_census)] crate::perf_count::census::start();
    let mut cx = super::super::super::layout_retention_tests::text_system_context(0);
    cx.update(|cx| cx.set_view_retention(retained));
    let views: Vec<_> = (0..windows).map(|_| {
        let view = cx.add_window(|_, cx| CacheTranscript { rows:(0..count).map(|index| cx.new(|_| CacheRow{index})).collect(),list_state:ListState::new(count,ListAlignment::Bottom,px(200.)),visible:true });
        cx.simulate_window_resize(view.into(),size(px(900.),px((count*24+100) as f32)));
        for _ in 0..4 { cx.update_window(view.into(),|_,window,cx| { window.refresh();window.draw(cx).clear(cx); }).expect("warm"); }
        cx.update_window(view.into(),|_,window,_| window.reset_frame_work_stats(false)).expect("disable clocks");
        view
    }).collect();
    let cycles = if scenario == "refault" {3} else {1};
    let start=Instant::now();let cpu_start=super::splice_profile::thread_cpu_ns();
    for cycle in 0..cycles {
        if scenario != "active" {
            for view in &views { view.update(&mut cx,|view,_,cx| { view.visible=false;cx.notify(); }).expect("hide"); }
            for _ in 0..4 { for view in &views { cx.update_window((*view).into(),|_,window,cx| { window.refresh();window.draw(cx).clear(cx); }).expect("empty"); } }
        }
        cx.executor().run_until_parked();cx.executor().advance_clock(Duration::from_secs(3));cx.executor().run_until_parked();
        if scenario == "resume" || scenario == "refault" && cycle+1<cycles {
            for view in &views { view.update(&mut cx,|view,_,cx| {view.visible=true;cx.notify();}).expect("show"); }
            for _ in 0..4 { for view in &views { cx.update_window((*view).into(),|_,window,cx| { window.refresh();window.draw(cx).clear(cx); }).expect("refill"); } }
        }
    }
    let cpu_ns=super::splice_profile::thread_cpu_ns()-cpu_start;let elapsed_ns=start.elapsed().as_nanos();
    let current_rss_kib=current_rss_kib();
    #[cfg(gpui_layout_sets_census)] let (held_bytes,peak_bytes,requested_bytes,allocation_calls)=crate::perf_count::census::snapshot();
    #[cfg(not(gpui_layout_sets_census))] let (held_bytes,peak_bytes,requested_bytes,allocation_calls)=(-1,-1,0,0);
    let mut signature=std::collections::hash_map::DefaultHasher::new();let mut state_count=0;let mut state_box_bytes=0;let mut owner_bytes=0isize;
    use std::hash::{Hash,Hasher};
    for view in &views {
        cx.update_window((*view).into(),|_,window,_| {
            describe_frame(window).hash(&mut signature);
            state_count+=window.rendered_frame.element_states.len();state_box_bytes+=window.rendered_frame.element_states.values().map(|state| std::mem::size_of_val(state.inner.as_ref())).sum::<usize>();
            owner_bytes+=crate::window::glyph_painting::line_cache_lifecycle_owner(window);
        }).expect("audit");
    }
    #[cfg(gpui_layout_sets_census)] crate::perf_count::census::finish();
    let signature=signature.finish();black_box(&cx);
    println!("CACHE_PROFILE {{\"case\":\"{case}\",\"cpu_ns\":{cpu_ns},\"elapsed_ns\":{elapsed_ns},\"signature\":{signature},\"state_count\":{state_count},\"state_box_bytes\":{state_box_bytes},\"held_bytes\":{held_bytes},\"peak_bytes\":{peak_bytes},\"requested_bytes\":{requested_bytes},\"allocation_calls\":{allocation_calls},\"owner_bytes\":{owner_bytes},\"current_rss_kib\":{current_rss_kib},\"app_size_bytes\":{},\"window_size_bytes\":{}}}",std::mem::size_of::<App>(),std::mem::size_of::<Window>());
}
