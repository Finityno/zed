use super::*;
use std::hint::black_box;

struct CacheRow { index: usize }
impl Render for CacheRow {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        let text = SharedString::from(format!("{} the quick brown fox", self.index));
        div().id(("cache-row", self.index)).w_full().h(px(24.)).child(text)
    }
}
struct CacheTranscript { rows: Vec<Entity<CacheRow>>, list_state: ListState, visible: bool }
impl Render for CacheTranscript {
    fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
        let rows = self.rows.clone();
        div().size_full().when(self.visible, |this| this.child(list(self.list_state.clone(), move |index, _, _| rows[index].clone().into_any_element()).size_full()))
    }
}

unsafe extern "C" { fn getpagesize() -> std::os::raw::c_int; }
fn current_rss_kib() -> usize {
    let text = std::fs::read_to_string("/proc/self/statm").expect("statm");
    let pages: usize = text.split_whitespace().nth(1).expect("rss pages").parse().expect("rss pages");
    pages * unsafe { getpagesize() } as usize / 1024
}

#[test]
#[ignore]
#[cfg(gpui_layout_sets_census)]
fn profile_idle_line_cache_owner() {
    let count: usize = std::env::var("LINE_CACHE_ROWS").expect("rows").parse().expect("rows");
    let windows: usize = std::env::var("LINE_CACHE_WINDOWS").expect("windows").parse().expect("windows");
    let retained = std::env::var("LINE_CACHE_RETAINED").expect("retained") == "on";
    assert!(count > 0 && windows > 0);
    crate::perf_count::census::start();
    let mut cx = super::super::super::layout_retention_tests::text_system_context(0);
    cx.update(|cx| cx.set_view_retention(retained));
    let views: Vec<_> = (0..windows).map(|_| {
        let window = cx.add_window(|_, cx| CacheTranscript {
            rows: (0..count).map(|index| cx.new(|_| CacheRow { index })).collect(),
            list_state: ListState::new(count, ListAlignment::Bottom, px(200.)),
            visible: true,
        });
        cx.simulate_window_resize(window.into(), size(px(900.), px((count * 24 + 100) as f32)));
        for _ in 0..4 {
            cx.update_window(window.into(), |_, window, cx| { window.refresh(); window.draw(cx).clear(cx); }).expect("warm draw");
        }
        window
    }).collect();
    for view in &views {
        view.update(&mut cx, |view, _, cx| { view.visible = false; cx.notify(); }).expect("hide text");
        for _ in 0..4 {
            cx.update_window((*view).into(), |_, window, cx| { window.refresh(); window.draw(cx).clear(cx); }).expect("empty draw");
        }
    }
    cx.executor().run_until_parked();
    cx.executor().advance_clock(Duration::from_secs(3));
    cx.executor().run_until_parked();
    let before = crate::perf_count::census::snapshot();
    let rss_before = current_rss_kib();
    let mut owners = Vec::new();
    for view in &views {
        owners.push(cx.update_window((*view).into(), |_, window, _| crate::window::glyph_painting::line_cache_owner_diagnostic(window)).expect("owner"));
    }
    let rss_after = current_rss_kib();
    let (held_bytes, peak_bytes, requested_bytes, allocation_calls) = crate::perf_count::census::finish();
    let owner_bytes: isize = owners.iter().map(|owner| owner.4).sum();
    black_box(&cx);
    println!("LINE_CACHE_OWNER {{\"rows\":{count},\"windows\":{windows},\"retained\":{retained},\"held_before\":{},\"held_after\":{held_bytes},\"peak_bytes\":{peak_bytes},\"requested_bytes\":{requested_bytes},\"allocation_calls\":{allocation_calls},\"owner_released_bytes\":{owner_bytes},\"rss_before_kib\":{rss_before},\"rss_after_kib\":{rss_after},\"owners\":{:?}}}", before.0, owners);
}
