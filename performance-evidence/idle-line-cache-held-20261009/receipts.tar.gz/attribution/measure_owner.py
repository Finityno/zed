from pathlib import Path
import ast,hashlib,json,os,subprocess
root=Path(__file__).parent;binary=root/'baseline-census-artifacts/gpui-ada3fb4d7b1cfe56';identity=hashlib.sha256(binary.read_bytes()).hexdigest();output=root/'owner-receipts';output.mkdir();rows=[]
for count in [32,256,1024]:
    for windows in [1,4]:
        for mode in ['off','on']:
            case=f'{count}-{windows}-{mode}';log=output/(case+'.log');command=[str(root/'native-run'),'taskset','-c','2',str(binary),'profile_idle_line_cache_owner','--ignored','--nocapture','--test-threads=1'];env=dict(os.environ,LINE_CACHE_ROWS=str(count),LINE_CACHE_WINDOWS=str(windows),LINE_CACHE_RETAINED=mode)
            with log.open('w') as stream:result=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=90)
            row={'case':case,'command':command,'binary_sha256':identity,'exit_code':result.returncode,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
            for line in log.read_text().splitlines():
                if 'LINE_CACHE_OWNER ' in line:
                    text=line.split('LINE_CACHE_OWNER ',1)[1];prefix,owners=text.split(',"owners":',1);row.update(json.loads(prefix+'}'));row['owners']=[list(owner) for owner in ast.literal_eval(owners[:-1])]
                if line.startswith('NATIVE_RECEIPT '):row['native']=json.loads(line.split(' ',1)[1])
            rows.append(row);(root/'owner-samples.json').write_text(json.dumps(rows,indent=2)+'\n');assert result.returncode==0 and 'owner_released_bytes' in row,log.read_text();assert all(owner[0]==owner[1]==0 for owner in row['owners'])
print(json.dumps({'children':len(rows),'all_exits_zero':True,'rows':[{key:row[key] for key in ['case','held_before','held_after','owner_released_bytes','rss_before_kib','rss_after_kib','owners']} for row in rows],'no_candidate_or_paired_gain':True,'coverage':'Tall stress viewports display32/256/1024rows then remove all text across4frames andidle3virtualseconds; direct private empty-map exclusion measures actual requested owner bytes, not production cleanup. Vec owner audit overhead retained in fullAppheld_after; scoped owner bytes exact. No nativeWindowManager/physicalGPU/app/System-to-shipped allocator gain.'}))
