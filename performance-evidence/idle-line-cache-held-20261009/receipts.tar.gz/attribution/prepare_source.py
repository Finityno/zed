from pathlib import Path
import json,hashlib,os,subprocess,shutil
root=Path(__file__).parent;data=json.loads((root/'source-refresh.json').read_text());repository=Path('/workspace/zed-perf');work=Path('/workspace/zed-line-cache-idle')
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_INDEX_FILE=str(root/'import-index'))
def git(*args,input=None):return subprocess.check_output(['git','-C',str(repository),*args],env=env,input=input).decode().strip()
git('read-tree','6b18c87dd5f2d1ccbee1ee641054295f2a78390b');files={}
for path,value in data.items():
    if not path.startswith('crates/'):continue
    assert value['encoding']=='utf-8';payload=value['content'].encode();sha=git('hash-object','-w','--stdin',input=payload);assert sha==value['sha'],path;git('update-index','--add','--cacheinfo','100644',sha,path);files[path]={'sha':sha,'sha256':hashlib.sha256(payload).hexdigest()}
assert git('write-tree')==data['commit']['tree']['sha']
(root/'current-commit.json').write_text(json.dumps(data['commit'],indent=2)+'\n')
subprocess.run(['python3','/workspace/scratch/gpui-empty-recording-adoption-loop/import_signed_commit.py',str(root/'current-commit.json'),str(repository)],check=True)
subprocess.run(['git','-C',str(repository),'worktree','add','--no-checkout','-b','perf/idle-line-cache-capacity-20261009',str(work),data['commit']['sha']],env=dict(os.environ,GIT_NO_LAZY_FETCH='1'),check=True)
subprocess.run(['git','-C',str(work),'sparse-checkout','init','--cone'],env=dict(os.environ,GIT_NO_LAZY_FETCH='1'),check=True)
crates=json.loads(Path('/workspace/scratch/gpui-window-effects-loop/baseline-source-inputs.json').read_text())['crates']
subprocess.run(['git','-C',str(work),'sparse-checkout','set',*['crates/'+name for name in crates],'.cargo','assets/fonts/ibm-plex-sans','assets/fonts/lilex'],env=dict(os.environ,GIT_NO_LAZY_FETCH='1'),check=True)
subprocess.run(['git','-C',str(work),'read-tree','-mu','HEAD'],env=dict(os.environ,GIT_NO_LAZY_FETCH='1'),check=True)
assert (work/'README.md').read_text().startswith('> [!IMPORTANT]\n> Remove this line to confirm')
shutil.copy2('/workspace/scratch/gpui-window-effects-loop/comparison/baseline-workspace/AGENTS.md',root/'AGENTS.current.md')
(root/'current-source-verification.json').write_text(json.dumps({'commit':data['commit']['sha'],'tree':data['commit']['tree']['sha'],'all_nine_blobs_verified':files,'whole_tree_verified':True},indent=2)+'\n')
(root/'PERFORMANCE_GOAL.current.md').write_text(data['goal'])
handoff_path=Path('/workspace/scratch/gpui-fork-loop/handoff.json');h=json.loads(handoff_path.read_text());h.update(active_workspace=str(work),active_branch='perf/idle-line-cache-capacity-20261009',active_iteration=str(root),active_comparison=None,phase='Current953d owner investigation: measure retained line-map capacities after text removal/idle, including requested live bytes and nativeRSS. No production candidate or build/profiling active.')
h['next_iteration']={'workspace':str(work),'branch':h['active_branch'],'directory':str(root),'baseline':data['commit']['sha'],'active_stage':h['phase'],'active_session':None,'source':None};h['next_steps']=['Prove new replay-map high-water retention in complete current-main native App/Window owners before selecting a memory design.','Preserve independent raster/image cache work and idle-windowPR49; do not overlap or duplicate work.','Freeze explicit meaningful whole-owner gain, cold-refill controls and ordinary CPU/heap/RSS controls before new candidate.'];handoff_path.write_text(json.dumps(h,indent=2)+'\n')
print(json.dumps({'baseline':data['commit']['sha'],'workspace':str(work),'whole_tree_verified':True}))
