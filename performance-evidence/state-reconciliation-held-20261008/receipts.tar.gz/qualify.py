from pathlib import Path
import json
import statistics

root = Path(__file__).parent
policy = json.loads((root / 'policy.json').read_text())
results = {}
failures = []
for kind in ['bare', 'census']:
    samples = json.loads((root / (kind + '-samples.json')).read_text())
    summaries = {}
    for case in policy['controls']:
        lanes = {lane: sorted([r for r in samples if r['case'] == case and r['lane'] == lane], key=lambda r: r['pair']) for lane in ['baseline', 'candidate']}
        baseline, candidate = lanes['baseline'], lanes['candidate']
        expected = policy['timing_pairs'] if kind == 'bare' else policy['memory_pairs']
        assert len(baseline) == len(candidate) == expected
        assert all(a['signature'] == b['signature'] and a['exit_code'] == b['exit_code'] == 0 for a, b in zip(baseline, candidate))
        metrics = ['cpu_ns', 'elapsed_ns', 'child_cpu_ns', 'peak_rss_kib'] if kind == 'bare' else ['held_bytes', 'peak_bytes', 'requested_bytes', 'allocation_calls', 'peak_rss_kib']
        summary = {}
        for metric in metrics:
            old = [r[metric] for r in baseline]
            new = [r[metric] for r in candidate]
            old_median = statistics.median(old)
            new_median = statistics.median(new)
            old_range = max(old) - min(old)
            new_range = max(new) - min(new)
            allowed = old_range if kind == 'bare' or metric == 'peak_rss_kib' else 0
            passed = new_median - old_median <= allowed
            if not passed:
                failures.append([kind, case, metric, 'control', new_median - old_median, allowed])
            summary[metric] = {'baseline_median': old_median, 'candidate_median': new_median, 'baseline_min': min(old), 'baseline_max': max(old), 'candidate_min': min(new), 'candidate_max': max(new), 'change_percent': (new_median / old_median - 1) * 100 if old_median else None, 'baseline_range': old_range, 'candidate_range': new_range, 'allowed_increase': allowed, 'pass': passed}
            if case in policy['primary_cases']:
                if kind == 'bare' and metric in ['cpu_ns', 'elapsed_ns']:
                    gain = old_median - new_median
                    if new_median > old_median * .8 or gain <= max(old_range, new_range):
                        failures.append([kind, case, metric, 'primary gain/variation', gain, old_range, new_range])
                if kind == 'census' and metric in ['peak_bytes', 'requested_bytes', 'allocation_calls']:
                    if old_median <= 0 or new_median != 0:
                        failures.append([kind, case, metric, 'primary allocation elimination', old_median, new_median])
                if kind == 'census' and metric == 'held_bytes' and new_median != 0:
                    failures.append([kind, case, metric, 'retained heap', new_median])
        summaries[case] = summary
    results[kind] = summaries
decision = {'qualified': not failures, 'failures': failures, 'summary': results}
(root / 'decision.json').write_text(json.dumps(decision, indent=2) + '\n')
print(json.dumps({'qualified': decision['qualified'], 'failures': failures, 'primary': {case: results['bare'][case] for case in policy['primary_cases']}}))
