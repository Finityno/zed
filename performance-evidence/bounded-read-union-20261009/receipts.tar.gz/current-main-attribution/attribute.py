from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path(__file__).parent
binary = root / 'baseline-attribution-artifacts/gpui-ada3fb4d7b1cfe56'
cases = json.loads(Path('/workspace/scratch/gpui-union-state-loop/policy.json').read_text())['controls']
output = root / 'attribution-receipts'
output.mkdir()
samples = []
for case in cases:
    command = [str(root / 'native-run'), 'taskset', '-c', '2', str(binary), 'profile_layout_key_sets', '--ignored', '--nocapture', '--test-threads=1']
    environment = dict(os.environ, LAYOUT_SETS_PROFILE_CASE=case, LAYOUT_SETS_PROFILE_ITERATIONS='8')
    path = output / (case + '.log')
    with path.open('w') as stream:
        result = subprocess.run(command, env=environment, stdout=stream, stderr=subprocess.STDOUT, timeout=60)
    sample = {'case': case, 'command': command, 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'exit_code': result.returncode, 'log_sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    for line in path.read_text().splitlines():
        for marker in ['READ_SHARING ', 'LAYOUT_SETS_PROFILE ', 'NATIVE_RECEIPT ']:
            if marker in line:
                sample.update(json.loads(line.split(marker, 1)[1]))
    samples.append(sample)
    (root / 'attribution-samples.json').write_text(json.dumps(samples, indent=2) + '\n')
    assert result.returncode == 0 and 'left_owner_reusable' in sample
    print(json.dumps({key: sample[key] for key in ['case', 'allocation_calls', 'requested_bytes', 'left_owner_reusable', 'right_owner_reusable', 'avoidable_requested_bytes', 'scan_comparisons', 'max_owner_len']}), flush=True)
