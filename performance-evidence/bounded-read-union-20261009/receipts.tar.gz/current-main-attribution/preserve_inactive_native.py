from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path(__file__).parent
processes = subprocess.check_output(['ps', '-eo', 'stat,comm'], text=True).splitlines()[1:]
assert not any(not line.split()[0].startswith('Z') and line.split()[1] in ['rustc', 'cargo', 'native-run', 'gpui-ada3fb4d7b1cfe56'] for line in processes)
targets = ['gpui-state-loop', 'gpui-splice-state-loop', 'gpui-union-state-loop', 'gpui-linear-reads-loop', 'gpui-state-prefix-loop']
rows = []
for name in targets:
    source = Path('/workspace/scratch') / name
    for path in sorted(source.glob('*-artifacts/gpui-ada3fb4d7b1cfe56')):
        output = root / 'preserved-inactive-native' / name / (path.parent.name + '.gz')
        output.parent.mkdir(parents=True, exist_ok=True)
        assert not output.exists()
        stat = path.stat()
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        with path.open('rb') as inp, output.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=1, mtime=0) as out:
            while block := inp.read(1024 * 1024):
                out.write(block)
        restored = hashlib.sha256()
        with gzip.open(output, 'rb') as stream:
            while block := stream.read(1024 * 1024):
                restored.update(block)
        assert restored.hexdigest() == digest
        rows.append({'original': str(path), 'archive': str(output), 'bytes': stat.st_size, 'sha256': digest, 'mode': stat.st_mode, 'mtime_ns': stat.st_mtime_ns, 'archive_bytes': output.stat().st_size, 'archive_sha256': hashlib.sha256(output.read_bytes()).hexdigest()})
        path.unlink()
        (root / 'inactive-native-preservation.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps({'files': len(rows), 'saved_bytes': sum(row['bytes'] - row['archive_bytes'] for row in rows), 'all_roundtrip_verified': True, 'scope': 'Inactive complete owned held/diagnostic native binaries only. Exact originals recoverable with mode/time/hash; never rerun failed designs unchanged. Original59externs/transitive target/runtime, user target/app, raw samples/source/licenses and active work remain untouched.'}))
