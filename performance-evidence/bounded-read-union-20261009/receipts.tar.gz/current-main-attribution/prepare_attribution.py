from pathlib import Path
import hashlib
import json
import shutil

root = Path(__file__).parent
source = Path('/workspace/zed-contained-reads')
workspace = root / 'baseline-workspace'
workspace.mkdir()
previous = Path('/workspace/scratch/gpui-union-state-loop')
inputs = json.loads(Path('/workspace/scratch/gpui-layout-sets-loop/source-inputs.json').read_text())['baseline']
crates = sorted({path.split('/')[1] for path in inputs if path.startswith('crates/')})
for name in crates:
    shutil.copytree(source / 'crates' / name, workspace / 'crates' / name)
for name in ['Cargo.toml', 'Cargo.lock', 'AGENTS.md', 'README.md', 'rust-toolchain.toml']:
    shutil.copy2(source / name, workspace / name)
shutil.copytree(source / '.cargo', workspace / '.cargo')
for name in ['ibm-plex-sans', 'lilex']:
    shutil.copytree(source / 'assets/fonts' / name, workspace / 'assets/fonts' / name)
for name in ['build_native.py', 'supervise.py', 'native-run', 'native_run.c', 'comparison-fixture.rs']:
    path = previous / name
    if not path.exists():
        path = Path('/workspace/scratch/gpui-layout-sets-loop') / name
    shutil.copy2(path, root / name)
path = workspace / 'crates/gpui/src/window/view_retention/dependencies.rs'
text = path.read_text()
needle = 'fn merge_reads<T: Ord + Copy>('
assert text.count(needle) == 1
text = text.replace(needle, '''#[cfg(gpui_union_attribution)]
thread_local! {
    pub(crate) static READ_SHARING: Cell<[u64; 8]> = const { Cell::new([0; 8]) };
}

#[cfg(gpui_union_attribution)]
fn covers_reads<T: Ord + Copy>(base: &[(T, u64)], additional: &[(T, u64)], floor: u64) -> bool {
    let mut additional = additional.iter();
    let mut next = additional.next();
    let mut previous = None;
    for (key, read_at) in base {
        if previous.is_some_and(|previous| previous >= *key) {
            return false;
        }
        previous = Some(*key);
        while let Some((additional_key, additional_read)) = next {
            READ_SHARING.with(|counts| { let mut values = counts.get(); values[6] += 1; counts.set(values); });
            match additional_key.cmp(key) {
                std::cmp::Ordering::Less => return false,
                std::cmp::Ordering::Equal => {
                    if (*additional_read).max(floor) < *read_at {
                        return false;
                    }
                    next = additional.next();
                }
                std::cmp::Ordering::Greater => break,
            }
        }
    }
    next.is_none()
}

''' + needle)
needle = ') -> Rc<[(T, u64)]> {\n'
assert text.count(needle) == 1
text = text.replace(needle, needle + '''    #[cfg(gpui_union_attribution)]
    READ_SHARING.with(|counts| { let mut values = counts.get(); values[0] += 1; counts.set(values); });
    #[cfg(gpui_union_attribution)]
    if !a.is_empty() && !b.is_empty() {
        let left = a_floor == 0 && covers_reads(a, b, b_floor);
        let right = !left && b_floor == 0 && covers_reads(b, a, a_floor);
        READ_SHARING.with(|counts| {
            let mut values = counts.get();
            values[1] += 1;
            values[2] += u64::from(left);
            values[3] += u64::from(right);
            values[4] += (a.len() + b.len()) as u64;
            if left || right {
                let owner_len = if left { a.len() } else { b.len() };
                values[5] += ((a.len() + b.len() + owner_len) * std::mem::size_of::<(T, u64)>() + 2 * std::mem::size_of::<usize>()) as u64;
                values[7] = values[7].max(owner_len as u64);
            }
            counts.set(values);
        });
    }
''')
path.write_text(text)
fixture = (root / 'comparison-fixture.rs').read_text()
needle = '    println!("LAYOUT_SETS_PROFILE '
fixture = fixture.replace(needle, '''    #[cfg(gpui_union_attribution)]
    crate::window::view_retention::dependencies::READ_SHARING.with(|counts| {
        let [calls, nonempty, left, right, read_items, avoidable_requested_bytes, scan_comparisons, max_owner_len] = counts.get();
        println!("READ_SHARING {{\\\"read_union_calls\\\":{calls},\\\"read_nonempty_pairs\\\":{nonempty},\\\"left_owner_reusable\\\":{left},\\\"right_owner_reusable\\\":{right},\\\"read_items\\\":{read_items},\\\"avoidable_requested_bytes\\\":{avoidable_requested_bytes},\\\"scan_comparisons\\\":{scan_comparisons},\\\"max_owner_len\\\":{max_owner_len}}}");
    });
''' + needle)
(workspace / 'crates/gpui/src/window/view_retention/splice_profile.rs').write_text(fixture)
identities = {str(path.relative_to(workspace)): hashlib.sha256(path.read_bytes()).hexdigest() for path in workspace.rglob('*') if path.is_file()}
(root / 'baseline-attribution-source-inputs.json').write_text(json.dumps({'baseline': '3466c9a24603307d53025e371f24569594f772ad', 'fincode_main': '3525187d7b68c663cbec1e62c65c017e90b21aa0', 'fincode_pin': 'b64fd9389c58a28048fa7c52d56447e73feffd89', 'component_pin': 'd8e4aa36aebaee078574ea83e9b630ca5b0e6a80', 'crates': crates, 'files': identities, 'description': 'Baseline-only nonallocating ownership/containment counters, original merge/sort still executes. Current owned main including independent PR40; no candidate or gain claims. Unique owner key order and earliest floor-lifted read constraints tested diagnostically.'}, indent=2) + '\n')
(root / 'diagnostic-dependencies.rs').write_bytes(path.read_bytes())
(root / 'diagnostic-fixture.rs').write_text(fixture)
print(json.dumps({'files': len(identities), 'crates': len(crates), 'production_changes': False}))
