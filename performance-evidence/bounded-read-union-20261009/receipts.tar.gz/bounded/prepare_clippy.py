from pathlib import Path
import hashlib
import json
import shutil
import tomllib

root = Path(__file__).parent
source = Path('/workspace/zed-bounded-reads')
workspace = root / 'clippy-workspace'
workspace.mkdir()
native = root / 'candidate-workspace'
crates = json.loads((root / 'candidate-source-inputs.json').read_text())['crates']
for name in crates:
    shutil.copytree(native / 'crates' / name, workspace / 'crates' / name)
for name in ['AGENTS.md', 'README.md', 'rust-toolchain.toml', 'clippy.toml']:
    shutil.copy2(source / name, workspace / name)
shutil.copytree(source / '.cargo', workspace / '.cargo')
for name in ['ibm-plex-sans', 'lilex']:
    shutil.copytree(source / 'assets/fonts' / name, workspace / 'assets/fonts' / name)
previous = Path('/workspace/scratch/gpui-union-state-loop')
shutil.copy2(previous / 'clippy-qualified-Cargo.toml', workspace / 'Cargo.toml')
shutil.copy2(previous / 'clippy-qualified-Cargo.lock', workspace / 'Cargo.lock')
for path in ['tooling/perf', 'tooling/corgi/patches']:
    shutil.copytree(source / path, workspace / path)
workspace.joinpath('script').mkdir()
for name in ['clippy', 'check-gpui-bench-feature-isolation', 'shfmt', 'cargo-cache']:
    path = source / 'script' / name
    if path.exists():
        shutil.copy2(path, workspace / 'script' / name)
old = tomllib.loads((workspace / 'Cargo.toml').read_text())
current = tomllib.loads((source / 'Cargo.toml').read_text())
assert all(current['workspace']['dependencies'].get(key) == value for key, value in old['workspace']['dependencies'].items())
assert old['workspace']['lints'] == current['workspace']['lints']
assert old['profile'] == current['profile']
assert len(old['workspace']['members']) == 26
provenance = {'baseline': '3466c9a24603307d53025e371f24569594f772ad', 'candidate': 'eff2bd53e09225062f725f3e84c564445b7444c0', 'scope': 'Actual current24 owning crate sources, current tooling/perf/corgi patches/scripts, same added native fixtures/tests,26-member scoped root. Exact relevant workspace dependencies/lints/profiles equal current main. Original native full root/lock unchanged and separately hashed.', 'files': {str(path.relative_to(workspace)): hashlib.sha256(path.read_bytes()).hexdigest() for path in workspace.rglob('*') if path.is_file()}, 'target': '/workspace/scratch/gpui-union-state-loop/owning-clippy-target', 'toolchain': '1.98.1', 'formatter': 'Skipped via GITHUB_ACTIONS=1 local script switch; no Actions dispatch.'}
(root / 'clippy-source-provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
print(json.dumps({'members': 26, 'current_profiles_dependencies_lints_identical': True, 'files': len(provenance['files'])}))
