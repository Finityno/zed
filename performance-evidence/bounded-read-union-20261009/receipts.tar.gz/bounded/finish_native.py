from pathlib import Path
import json
import subprocess

root = Path(__file__).parent
for lane in ['baseline', 'candidate']:
    subprocess.run(['python3', str(root / 'build_native.py'), lane, 'census'], check=True)
    print(json.dumps({'completed': lane + '-census-build'}), flush=True)
subprocess.run(['python3', str(root / 'capture_identities.py')], check=True)
subprocess.run(['python3', str(root / 'run_measurements.py')], check=True)
with (root / 'qualification.log').open('w') as stream:
    subprocess.run(['python3', str(root / 'qualify.py')], stdout=stream, stderr=subprocess.STDOUT, check=True)
decision = json.loads((root / 'decision.json').read_text())
policy = json.loads((root / 'policy.json').read_text())
print(json.dumps({'qualified': decision['qualified'], 'failures': decision['failures'], 'primary_cpu_percent': {case: decision['summary']['bare'][case]['cpu_ns']['change_percent'] for case in policy['primary_cases']}}), flush=True)
