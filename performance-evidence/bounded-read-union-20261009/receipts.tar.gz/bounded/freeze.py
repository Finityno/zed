from pathlib import Path
import hashlib
import json
import shutil

root = Path(__file__).parent
previous = Path('/workspace/scratch/gpui-linear-reads-loop')
policy = json.loads((previous / 'policy.json').read_text())
policy.update({
    'goal': 'Bound linear sorted merging to large dependency-read unions using an out-of-line kernel; preserve the original small-list algorithm and empty-input hot paths. Reduce complete changed-frame CPU without allocation/heap/RSS regression.',
    'baseline': '3466c9a24603307d53025e371f24569594f772ad',
    'basis': 'Owned complete-component baseline shows275530 copied entity/global read entries and about1944893 sort comparisons per8 changed256-row frames. Current main ownership attribution retains the exact275530 shape after independent allocation improvements. Unbounded inlined linear replacement12fdb142 qualifies11.42–13.13% targetCPU but9normalCPU/RSScontrols fail, held with all evidence. The new architecture keeps old small-array body and fast returns, moves linear code behind a64-read total threshold and #[inline(never)]. No repeated failed design.',
    'design_limits': 'After original empty-input sharing, dispatch only combined cardinality>=64 to a dedicated #[inline(never)] sorted merge. All small read merging is the literal original chain/map/sort/dedup algorithm. Preserve sorted duplicate keys, floor normalization and earliest versions. No state-checker/union change, field/cache/pool/new dependency.',
    'correctness': 'All219024 sorted multiset/floor combinations against old chain/sort/dedup; counted-key1024-read regression before-fail/after-pass; explicit63/64/65 threshold cases preserve old result. Native retained frame oracle, dependency changes, scrolling, panels, layout/atomic claims/nested contracts. Actual strict owningClippy and benchmark isolation before merge.',
    'limits': ['Linux native complete App/Window fake-platform component; no app/GPU/macOS/Windows/shipped-allocator gain.', 'Census before App/setup/4warmups, held live final snapshot; bare frame timer excludes setup and owner audit.', 'Same59 immutable exact externs, nativeRust1.99, separate System bare/counting census lanes. No profiling/build overlap; supervisor must complete phase before next.', 'Old linear candidate unmerged and never unchanged resampled. Invalid old overlapping cohort retained independently, never used for gate selection.'],
    'status': 'Frozen before candidate and paired measurement. Original meaningful5%CPU/elapsed gain targets and all20 heap/RSS/CPU controls retained; no weakening.',
})
(root / 'policy.json').write_text(json.dumps(policy, indent=2) + '\n')
for name in ['build_native.py', 'supervise.py', 'measure.py', 'qualify.py', 'run_measurements.py', 'native-run', 'native_run.c', 'comparison-fixture.rs', 'external-dependencies.json', 'capture_identities.py', 'check_contracts.py']:
    shutil.copy2(previous / name, root / name)
text = (root / 'run_measurements.py').read_text().replace("'prior_invalid_cohort': 'invalid-overlap-cohort/protocol-rejection.json'", "'previous_failed_design_preserved': '/workspace/scratch/gpui-linear-reads-loop'")
(root / 'run_measurements.py').write_text(text)
(root / 'pre-candidate-frozen-method.json').write_text(json.dumps({name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in ['policy.json', 'qualify.py', 'measure.py', 'run_measurements.py', 'native_run.c', 'native-run', 'comparison-fixture.rs', 'external-dependencies.json']}, indent=2) + '\n')
path = Path('/workspace/scratch/gpui-fork-loop/handoff.json')
handoff = json.loads(path.read_text())
handoff.update(active_workspace='/workspace/zed-bounded-reads', active_branch='perf/bounded-read-union-20261009', active_iteration=str(root), phase='Distinct bounded/out-of-line large-read union on current main3466c9a. Original small-list body/empty sharing unchanged;64-read threshold frozen. Four5%CPU/elapsed goals and20controls frozen before candidate. No build/profile active. Prior failed linear and low-coverage owner investigations fully retained.')
handoff['next_iteration'] = {'workspace': handoff['active_workspace'], 'branch': handoff['active_branch'], 'directory': str(root), 'baseline': policy['baseline'], 'policy_sha256': hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest(), 'phase': handoff['phase']}
path.write_text(json.dumps(handoff, indent=2) + '\n')
print(json.dumps({'policy_sha256': hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest(), 'children': 560, 'controls': 20}))
