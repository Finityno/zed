from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

root = Path(__file__).parent
worktree = Path('/workspace/zed-bounded-reads')
output = worktree / 'performance-evidence/bounded-read-union-20261009'
output.mkdir(parents=True)
decision = json.loads((root / 'decision.json').read_text())
assert decision['qualified'] and not decision['failures']
for name in ['strict-clippy', 'bench-isolation-guard']:
    receipt = json.loads((root / (name + '-receipt.json')).read_text())
    assert receipt['exit_code'] == 0 and not receipt['timed_out']
for name, expected in json.loads((root / 'frozen-inputs.json').read_text()).items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected
ordering = json.loads((root / 'valid-cohort-order-receipt.json').read_text())['receipts']
assert ordering[1]['started_unix'] >= ordering[0]['started_unix'] + ordering[0]['elapsed_seconds']
runtime = json.loads((root / 'runtime-identities.json').read_text())
sysroot = Path(runtime['compiler']).parent.parent / 'lib/rustlib/x86_64-unknown-linux-gnu/lib'
standard = {str(path): {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in sysroot.iterdir() if path.is_file() and path.suffix in {'.rlib', '.so'}}
(root / 'native-standard-library-identities.json').write_text(json.dumps(standard, indent=2) + '\n')
files = {}
for path in root.iterdir():
    if path.is_file() and path.suffix in {'.py', '.json', '.log', '.diff', '.rs', '.c'}:
        files['bounded/' + path.name] = path
for name in ['bare-receipts', 'census-receipts']:
    for path in (root / name).rglob('*'):
        if path.is_file():
            files['bounded/' + str(path.relative_to(root))] = path
for kind in ['bare', 'census']:
    samples = json.loads((root / (kind + '-samples.json')).read_text())
    assert len(samples) == (360 if kind == 'bare' else 200)
    for sample in samples:
        assert sample['exit_code'] == 0
        assert hashlib.sha256(Path(sample['log']).read_bytes()).hexdigest() == sample['log_sha256']
for name in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml', 'clippy.toml']:
    files['owning-clippy/' + name] = root / 'clippy-workspace' / name
for name in ['Cargo.toml', 'Cargo.lock', 'rust-toolchain.toml']:
    files['native-root/' + name] = root / 'candidate-workspace' / name
files['native-root/fixture.rs'] = root / 'comparison-fixture.rs'
attribution = Path('/workspace/scratch/gpui-contained-reads-loop')
for path in attribution.iterdir():
    if path.is_file() and path.suffix in {'.py', '.json', '.log', '.diff', '.rs'}:
        files['current-main-attribution/' + path.name] = path
for path in (attribution / 'attribution-receipts').rglob('*'):
    if path.is_file():
        files['current-main-attribution/' + str(path.relative_to(attribution))] = path
manifest = {name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for name, path in sorted(files.items())}
archive = output / 'receipts.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=6, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
    data = (json.dumps(manifest, indent=2) + '\n').encode()
    info = tarfile.TarInfo('manifest.json'); info.size = len(data); info.mode = 0o644
    tar.addfile(info, io.BytesIO(data))
    for name, path in sorted(files.items()):
        data = path.read_bytes(); info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    for name, expected in manifest.items():
        data = tar.extractfile(name).read()
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
policy = json.loads((root / 'policy.json').read_text())
primary = {case: {kind: {metric: decision['summary'][kind][case][metric] for metric in (['cpu_ns', 'elapsed_ns', 'child_cpu_ns', 'peak_rss_kib'] if kind == 'bare' else ['held_bytes', 'peak_bytes', 'requested_bytes', 'allocation_calls', 'peak_rss_kib'])} for kind in ['bare', 'census']} for case in policy['primary_cases']}
evidence = {
    'status': 'Qualified; final review and owned merge still required.', 'baseline': policy['baseline'], 'candidate_source': 'eff2bd53e09225062f725f3e84c564445b7444c0',
    'children': 560, 'cases': 20, 'policy_sha256': hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest(), 'qualified': True, 'failed_controls': [],
    'primary': primary, 'all_requested_heap_and_churn_medians_unchanged': True,
    'mechanism': 'After existing empty-input fast returns, only unions of64or more combined entity/global reads use a #[inline(never)] linear sorted merge. Exact original small-list chain/map/sort/dedup body preserved, proven by function-byte comparison. No field/cache/pool/state-checker change.',
    'correctness': '438048 sorted multiset/floor cases and12cases at63/64/65boundary agree with original algorithm; counted-key1024regression fails before/passes after; all11native contract invocations have expected exits, including retained oracle16seeds50steps, dependency changes, wheel scrolling, live-row panels, layout/atomic-claim and nested recording.',
    'direct_cloud_checks': 'Actual owning ./script/clippy1.98.1 release/alltargets/allfeatures/deny-warnings passes20.20sec; benchmark isolation passes. Scoped26members retain exact relevant current-root dependency/lint/profile declarations; all24 owning source crates/current tooling/patches/licenses supplied.',
    'sequential': 'Receipt timestamps prove native compilation completes before bare timing, and bare before allocation census. One valid cohort, no sampling retries or changed frozen gates.',
    'preserved_adverse_evidence': {'unbounded_linear_source': '12fdb142f4db5be22b8c5ffbcd0e871ef836011f', 'branch': 'perf/linear-read-union-20261008', 'public_head': 'b7c564ae0ab1399a514489a084fe8b2809a5f4d1', 'archive_sha256': '4bf7e3f18434d4b3e53ba2578bcc9f19ad6362e0ae896955b885dd9c040f856f', 'status': 'Held with9normalCPU/RSSfailures;560valid and560invalid-overlap children preserved. Not rerun unchanged. New bounded design has different dispatch/call architecture and current source base.'},
    'identities': 'NativeRust1.99/compiler/driver/LLVM/stdlibs plus identical common59 hashed externs and loaded runtime; separate source/output directories; bare System and separate counting System allocator. Every raw sample retained and archive-member hash verified.',
    'coverage_limits': ['Complete Linux native App/Window fake-platform component,256changed rows,32/256controls, not application/physicalGPU/macOS/Windows/shipped-allocator percentages.', 'Elapsed is component frame-loop latency, not display/GPU latency. No requested heap/allocation improvement or RSS gain established.', 'Census includes App/setup/4warmups/live final snapshot; bare timers exclude setup and postloop owner/hash audit.', 'Separate coherent component/Fincode adoption and integration qualification required; current threeconsumer pins remain b64fd938 with componentd8e4aa36.'],
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'archive_bytes': archive.stat().st_size, 'members': len(manifest) + 1,
}
(output / 'evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')
(output / 'README.md').write_text('''# Bounded sorted dependency-read merging

Large retained-frame unions repeatedly sort already ordered entity/global reads.
This candidate keeps the original small-list algorithm and empty-input sharing,
and dispatches only unions with64or more reads to an out-of-line linear merge.
Earliest floor-lifted versions, duplicate keys and ordering remain equivalent.
No cache, pool, field, state checker or renderer behavior changes.

One560-child alternating comparison across20complete native workloads qualifies.
Four256-row changed-component cases use9.41–11.96% less threadCPU and9.47–11.98%
less elapsed time, above both full lane ranges and the frozen5%target. All normal
CPU/elapsed/whole-child, requested heap/allocation and native RSS controls pass.
Every held/peak/requested-byte/allocation-call median remains identical; no memory
or RSS percentage gain is established. All raw samples and adverse source evidence
are preserved; none are dropped or retried until passing.

Native read/floor oracle coverage includes438048 combinations plus63/64/65boundary
cases. Counted-key regression fails before and passes after; retained frame oracle,
dependency updates, wheel scrolling, live-row panels, layout/atomic-claim and nested
recording contracts pass. Actual owning strictClippy and benchmark isolation pass.
The scoped lint root has26members with exact relevant current-root dependencies,
lints and profiles; native snapshots retain the full original root and lock.

The earlier unbounded inlined design remains held on its own evidence branch with
nine failed controls. Its invalid overlapping cohort is also preserved and unused
for qualification. This design changes the dispatch/call architecture; its single
valid cohort uses a repaired sequential runner with unchanged gain/control gates.

These are Linux complete App/Window fixture observations with a fake renderer and
System allocator. They establish no whole-app, physical GPU, macOS/Windows or shipped
allocator gain. Coherent owned component/Fincode adoption needs separate checks.
Archive receipts retain exact source/compiler/stdlibs/common extern/runtime/binary
identities, all20workloads, both measurement modes, direct native/lint results and
coverage limits. Every archive member is hash verified. Original copyrights,
licenses and source/package metadata are preserved; provenance uses plain revisions.
''')
(root / 'archive-verification.json').write_text(json.dumps({'archive_sha256': evidence['archive_sha256'], 'archive_bytes': evidence['archive_bytes'], 'members': evidence['members'], 'all_members_hash_verified': True, 'all560raw_samples_verified': True, 'sequential': True}, indent=2) + '\n')
print(json.dumps({key: evidence[key] for key in ['archive_sha256', 'archive_bytes', 'members', 'qualified']}))
