from pathlib import Path
import gzip
import hashlib
import json
import os

root = Path(__file__).parent
rows = json.loads(Path('/workspace/scratch/gpui-linear-reads-loop/inactive-cache-preservation.json').read_text())
restored = []
for row in rows:
    path = Path(row['original'])
    assert str(path).startswith('/workspace/scratch/gpui-union-state-loop/owning-clippy-target/release/deps/')
    if path.exists():
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
    else:
        with gzip.open(row['archive'], 'rb') as inp, path.open('wb') as out:
            while block := inp.read(1024 * 1024):
                out.write(block)
        assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
        os.chmod(path, row['mode'])
        os.utime(path, ns=(row['mtime_ns'], row['mtime_ns']))
    restored.append({'path': str(path), 'sha256': row['sha256'], 'restored_exact': True})
    (root / 'lint-cache-restoration.json').write_text(json.dumps(restored, indent=2) + '\n')
print(json.dumps({'exact_cache_artifacts_restored': len(restored), 'bytes': sum(row['bytes'] for row in rows)}))
