use std::{rc::Rc, cell::Cell};
fn merge_reads<T: Ord + Copy>(
    a: &Rc<[(T, u64)]>,
    a_floor: u64,
    b: &Rc<[(T, u64)]>,
    b_floor: u64,
) -> Rc<[(T, u64)]> {
    if b.is_empty() && a_floor == 0 {
        return a.clone();
    }
    if a.is_empty() && b_floor == 0 {
        return b.clone();
    }
    if a.len() + b.len() >= 64 {
        return merge_large_reads(a, a_floor, b, b_floor);
    }
    let mut merged: Vec<(T, u64)> = a
        .iter()
        .map(|(key, read_at)| (*key, (*read_at).max(a_floor)))
        .chain(b.iter().map(|(key, read_at)| (*key, (*read_at).max(b_floor))))
        .collect();
    earliest_reads(&mut merged);
    merged.into()
}

#[inline(never)]
fn merge_large_reads<T: Ord + Copy>(
    a: &Rc<[(T, u64)]>,
    a_floor: u64,
    b: &Rc<[(T, u64)]>,
    b_floor: u64,
) -> Rc<[(T, u64)]> {
    let mut merged = Vec::with_capacity(a.len() + b.len());
    let mut left = a.iter();
    let mut right = b.iter();
    let mut left_read = left.next();
    let mut right_read = right.next();
    while let (Some((left_key, left_at)), Some((right_key, right_at))) = (left_read, right_read) {
        match left_key.cmp(right_key) {
            std::cmp::Ordering::Less => {
                merged.push((*left_key, (*left_at).max(a_floor)));
                left_read = left.next();
            }
            std::cmp::Ordering::Greater => {
                merged.push((*right_key, (*right_at).max(b_floor)));
                right_read = right.next();
            }
            std::cmp::Ordering::Equal => {
                merged.push((*left_key, (*left_at).max(a_floor).min((*right_at).max(b_floor))));
                left_read = left.next();
                right_read = right.next();
            }
        }
    }
    merged.extend(left_read.into_iter().chain(left).map(|(key, read_at)| (*key, (*read_at).max(a_floor))));
    merged.extend(right_read.into_iter().chain(right).map(|(key, read_at)| (*key, (*read_at).max(b_floor))));
    merged.dedup_by(|current, previous| {
        if current.0 == previous.0 {
            previous.1 = previous.1.min(current.1);
            true
        } else {
            false
        }
    });
    merged.into()
}

/// Sorts reads by what was read and keeps the earliest read of each.
fn earliest_reads<T: Ord + Copy>(reads: &mut Vec<(T, u64)>) {
    reads.sort_unstable();
    reads.dedup_by_key(|(key, _)| *key);
}

/// The first read of each state, at the earliest version read, so that a
/// change in between still counts.
mod read_union_tests {
    use super::*;

    #[test]
    fn sorted_read_unions_preserve_earliest_floor_lifted_versions() {
        let choices = [(0, 2), (0, 8), (1, 5), (2, 1), (2, 9)];
        let mut inputs = vec![Vec::new()];
        let mut level = vec![Vec::new()];
        for _ in 0..3 {
            let mut next = Vec::new();
            for prefix in &level {
                for choice in choices {
                    let mut input = prefix.clone();
                    input.push(choice);
                    input.sort_by_key(|(key, _)| *key);
                    inputs.push(input.clone());
                    next.push(input);
                }
            }
            level = next;
        }
        for left in &inputs {
            for right in &inputs {
                for padding in [false, true] {
                    let mut left = left.clone();
                    let mut right = right.clone();
                    if padding {
                        left.extend((10..42).map(|key| (key, 5)));
                        right.extend((10..42).map(|key| (key, 7)));
                    }
                    let left: Rc<[(u32, u64)]> = left.into();
                    let right: Rc<[(u32, u64)]> = right.into();
                    for left_floor in [0, 3, 12] {
                        for right_floor in [0, 5, 10] {
                            let actual = merge_reads(&left, left_floor, &right, right_floor);
                            let expected = if right.is_empty() && left_floor == 0 {
                                assert!(Rc::ptr_eq(&actual, &left));
                                left.to_vec()
                            } else if left.is_empty() && right_floor == 0 {
                                assert!(Rc::ptr_eq(&actual, &right));
                                right.to_vec()
                            } else {
                                let mut reads: Vec<_> = left.iter().map(|(key, read)| (*key, (*read).max(left_floor)))
                                    .chain(right.iter().map(|(key, read)| (*key, (*read).max(right_floor))))
                                    .collect();
                                reads.sort_unstable();
                                reads.dedup_by_key(|(key, _)| *key);
                                reads
                            };
                            assert_eq!(actual.as_ref(), expected.as_slice(), "left={left:?} right={right:?} floors={left_floor}/{right_floor}");
                        }
                    }
                }
            }
        }
    }

    #[test]
    fn read_unions_preserve_versions_at_the_large_merge_boundary() {
        for total in [63, 64, 65] {
            let left: Rc<[(u32, u64)]> = (0..total / 2).map(|key| (key * 2, 3)).collect();
            let right: Rc<[(u32, u64)]> = (0..total - total / 2).map(|key| (key, 2)).collect();
            for left_floor in [0, 5] {
                for right_floor in [0, 7] {
                    let actual = merge_reads(&left, left_floor, &right, right_floor);
                    let mut expected: Vec<_> = left.iter().map(|(key, read)| (*key, (*read).max(left_floor)))
                        .chain(right.iter().map(|(key, read)| (*key, (*read).max(right_floor))))
                        .collect();
                    expected.sort_unstable();
                    expected.dedup_by_key(|(key, _)| *key);
                    assert_eq!(actual.as_ref(), expected.as_slice());
                }
            }
        }
    }

    #[test]
    fn large_read_unions_preserve_empty_sides_and_long_tails() {
        for (left_length, right_length) in [(0, 64), (64, 0), (1, 256), (256, 1), (7, 256), (256, 7)] {
            let left: Rc<[(u32, u64)]> = (0..left_length).map(|key| (key * 2, 3 + u64::from(key % 3))).collect();
            let right: Rc<[(u32, u64)]> = (0..right_length).map(|key| (key, 2 + u64::from(key % 5))).collect();
            for left_floor in [0, 5, 12] {
                for right_floor in [0, 7, 14] {
                    let actual = merge_reads(&left, left_floor, &right, right_floor);
                    let mut expected: Vec<_> = left.iter().map(|(key, read)| (*key, (*read).max(left_floor)))
                        .chain(right.iter().map(|(key, read)| (*key, (*read).max(right_floor))))
                        .collect();
                    expected.sort_unstable();
                    expected.dedup_by_key(|(key, _)| *key);
                    assert_eq!(actual.as_ref(), expected.as_slice(), "lengths={left_length}/{right_length} floors={left_floor}/{right_floor}");
                }
            }
        }
    }

    thread_local! {
        static COMPARISONS: Cell<usize> = const { Cell::new(0) };
    }

    #[derive(Clone, Copy, Eq, PartialEq)]
    struct CountedKey(u32);

    impl Ord for CountedKey {
        fn cmp(&self, other: &Self) -> std::cmp::Ordering {
            COMPARISONS.with(|count| count.set(count.get() + 1));
            self.0.cmp(&other.0)
        }
    }

    impl PartialOrd for CountedKey {
        fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
            Some(self.cmp(other))
        }
    }

    #[test]
    fn sorted_read_union_uses_linear_key_comparisons() {
        let left: Rc<[(CountedKey, u64)]> = (0..1024).map(|key| (CountedKey(key), 2)).collect();
        let right: Rc<[(CountedKey, u64)]> = (0..1024).map(|key| (CountedKey(key), 4)).collect();
        COMPARISONS.with(|count| count.set(0));
        let merged = merge_reads(&left, 3, &right, 5);
        let comparisons = COMPARISONS.with(Cell::get);
        assert_eq!(merged.len(), left.len());
        assert!(merged.iter().all(|(_, read)| *read == 3));
        assert!(comparisons <= left.len() + right.len(), "{comparisons} comparisons");
    }
}
