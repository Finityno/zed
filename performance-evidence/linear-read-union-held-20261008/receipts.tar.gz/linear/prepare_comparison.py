from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

root = Path(__file__).parent
source = Path('/workspace/zed-linear-reads')
baseline = '6e95c2810a67625903fb5ebfae4f11ddbe0fcabf'
environment = dict(os.environ, GIT_NO_LAZY_FETCH='1')
candidate = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], env=environment, text=True).strip()
inputs = json.loads(Path('/workspace/scratch/gpui-layout-sets-loop/source-inputs.json').read_text())['baseline']
crates = sorted({path.split('/')[1] for path in inputs if path.startswith('crates/')})
dependency_path = 'crates/gpui/src/window/view_retention/dependencies.rs'
original = subprocess.check_output(['git', '-C', str(source), 'show', baseline + ':' + dependency_path], env=environment).decode()
updated = (source / dependency_path).read_text()
start = original.index('fn merge_reads<T: Ord + Copy>(')
end = original.index('\n/// Sorts reads by', start)
candidate_start = updated.index('fn merge_reads<T: Ord + Copy>(')
candidate_end = updated.index('\n/// Sorts reads by', candidate_start)
baseline_with_tests = updated[:candidate_start] + original[start:end] + updated[candidate_end:]
fixture = (root / 'comparison-fixture.rs').read_bytes()
for lane in ['baseline', 'candidate']:
    workspace = root / (lane + '-workspace')
    workspace.mkdir()
    for name in crates:
        shutil.copytree(source / 'crates' / name, workspace / 'crates' / name)
    for name in ['Cargo.toml', 'Cargo.lock', 'AGENTS.md', 'README.md', 'rust-toolchain.toml']:
        shutil.copy2(source / name, workspace / name)
    shutil.copytree(source / '.cargo', workspace / '.cargo')
    for name in ['ibm-plex-sans', 'lilex']:
        shutil.copytree(source / 'assets/fonts' / name, workspace / 'assets/fonts' / name)
    (workspace / dependency_path).write_text(baseline_with_tests if lane == 'baseline' else updated)
    (workspace / 'crates/gpui/src/window/view_retention/splice_profile.rs').write_bytes(fixture)
    files = {str(path.relative_to(workspace)): hashlib.sha256(path.read_bytes()).hexdigest() for path in workspace.rglob('*') if path.is_file()}
    (root / (lane + '-source-inputs.json')).write_text(json.dumps({'baseline': baseline, 'candidate': candidate, 'lane': lane, 'files': files, 'crates': crates, 'description': 'Current24 owning crates/root/lock/.cargo/fonts/licenses, identical complete20-frame fixtures and regression tests. Only merge_reads production algorithm differs.'}, indent=2) + '\n')
old = json.loads((root / 'baseline-source-inputs.json').read_text())['files']
new = json.loads((root / 'candidate-source-inputs.json').read_text())['files']
changed = [path for path in old if old[path] != new[path]]
assert changed == [dependency_path]
(root / 'candidate-source.diff').write_bytes(subprocess.check_output(['git', '-C', str(source), 'diff', baseline, candidate], env=environment))
(root / 'comparison-source-receipt.json').write_text(json.dumps({'baseline': baseline, 'candidate': candidate, 'changed_source': changed, 'files_each': len(old), 'fixture_sha256': hashlib.sha256(fixture).hexdigest(), 'policy_sha256': hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest()}, indent=2) + '\n')
print(json.dumps({'baseline': baseline, 'candidate': candidate, 'files_each': len(old), 'changed': changed}))
