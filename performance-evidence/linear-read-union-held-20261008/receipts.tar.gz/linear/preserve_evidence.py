from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

root = Path(__file__).parent
worktree = Path('/workspace/zed-linear-reads')
output = worktree / 'performance-evidence/linear-read-union-held-20261008'
output.mkdir(parents=True)
files = {}
for path in root.iterdir():
    if path.is_file() and path.suffix in {'.py', '.json', '.log', '.diff', '.rs', '.c'}:
        files['linear/' + path.name] = path
for name in ['bare-receipts', 'census-receipts', 'invalid-overlap-cohort']:
    for path in (root / name).rglob('*'):
        if path.is_file():
            files['linear/' + str(path.relative_to(root))] = path
attribution = Path('/workspace/scratch/gpui-state-prefix-loop')
for path in attribution.iterdir():
    if path.is_file() and path.suffix in {'.py', '.json', '.log', '.diff', '.rs'}:
        files['attribution/' + path.name] = path
for name in ['attribution-receipts', 'attribution3-receipts', 'attribution4-receipts']:
    for path in (attribution / name).rglob('*'):
        if path.is_file():
            files['attribution/' + str(path.relative_to(attribution))] = path
for kind in ['bare', 'census']:
    for prefix in [Path(), Path('invalid-overlap-cohort')]:
        samples = json.loads((root / prefix / (kind + '-samples.json')).read_text())
        for sample in samples:
            path = root / prefix / Path(sample['log']).relative_to(root)
            assert hashlib.sha256(path.read_bytes()).hexdigest() == sample['log_sha256']
            assert sample['exit_code'] == 0
method = json.loads((root / 'frozen-inputs.json').read_text())
for name, expected in method.items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected
ordering = json.loads((root / 'valid-cohort-order-receipt.json').read_text())
first, second = ordering['receipts']
assert second['started_unix'] >= first['started_unix'] + first['elapsed_seconds']
manifest = {name: {'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for name, path in sorted(files.items())}
archive = output / 'receipts.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', compresslevel=6, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as tar:
    data = (json.dumps(manifest, indent=2) + '\n').encode()
    info = tarfile.TarInfo('manifest.json'); info.size = len(data); info.mode = 0o644
    tar.addfile(info, io.BytesIO(data))
    for name, path in sorted(files.items()):
        data = path.read_bytes(); info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    for name, expected in manifest.items():
        data = tar.extractfile(name).read()
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
decision = json.loads((root / 'decision.json').read_text())
evidence = {
    'status': 'HELD, unmerged. Never resample this design unchanged or weaken frozen gates.',
    'baseline': '6e95c2810a67625903fb5ebfae4f11ddbe0fcabf',
    'source': '12fdb142f4db5be22b8c5ffbcd0e871ef836011f',
    'policy_sha256': hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest(),
    'valid_children': 560, 'diagnostic_children': 60, 'invalid_preserved_children': 560,
    'qualified': False, 'failures': decision['failures'],
    'observed_primary_thread_cpu_reduction_percent': [-decision['summary']['bare'][case]['cpu_ns']['change_percent'] for case in json.loads((root / 'policy.json').read_text())['primary_cases']],
    'requested_heap_and_churn': 'Every held/peak/requested byte/allocation-call median is identical between lanes across all20 cases.',
    'correctness': 'All11 native contract invocations have expected exits;219024 floor/read multiset comparisons preserve the old result; counted-key regression fails before with25711 comparisons and passes after below2049; retained frame/oracle/scrolling/dependency/layout/nested contracts pass.',
    'not_run': 'Owning strictClippy and adoption are not run: the candidate fails performance gates and cannot be merged. No PR opened.',
    'protocol_rejection': 'An earlier CPU/census cohort overlapped12.0381524563 seconds. All560 raw children retained, no gain/gate selection from invalid data. Driver repaired before the first valid cohort, all source/method/gain/control gates unchanged. Completed receipts prove valid phases do not overlap. No valid failed cohort was resampled.',
    'coverage_limits': ['Linux native complete App/Window fake-platform component; no app/GPU/macOS/Windows/shipped-allocator percentage.', 'Census includes App/setup/4warmups/live retained output; timer excludes setup and owner/hash audit.', 'NativeRust1.99 exact59 immutable externs/shared runtime; diagnostic private counter/clock overhead included; unused renderer source is not GPU validation.', 'Independent main3466c9a and latest consumer changes are preserved; held source was tested on6e95.'],
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'archive_bytes': archive.stat().st_size, 'members': len(manifest) + 1,
}
(output / 'evidence.json').write_text(json.dumps(evidence, indent=2) + '\n')
(output / 'README.md').write_text('''# Held linear dependency-read merge

This candidate remains unmerged. Its first valid560-child cohort shows11.42–13.13%
less threadCPU/elapsed in four256-row changed-component workloads. Nine frozen
controls fail: seven normal retained CPU/elapsed/whole-child fields and two native
RSS fields. Every requested held/peak/churn byte and allocation-call median is
unchanged. Do not rerun this design unchanged or loosen acceptance gates.

The candidate merges sorted entity/global dependency reads in linear order instead
of sorting the concatenation. It preserves earliest floor-lifted versions, repeated
keys, deadlines and the existing zero-floor empty-input sharing. Source, compiler,
runtime, exact59 common externs, separate allocation/timing binaries, all20 workloads
and every raw result are recorded in the archive. The native read/floor oracle
checks219024 combinations; counted-key and retained-frame/dependency/scroll/layout
contracts pass. StrictClippy/adoption were not run because the performance gates fail.

The archive also preserves60 baseline diagnostic observations and560 invalid
children from an earlier12.038-second CPU/census overlap. No qualification uses
those invalid results. The repaired sequential supervisor retains unchanged source
and frozen gates; completed receipts prove both valid phases do not overlap.

These are Linux complete App/Window fixture results, with a fake renderer and System
allocator. They establish no whole-app, physical GPU, macOS/Windows or shipped
allocator gain. Source provenance is plain revisions in evidence.json. Original
source/package metadata and licenses remain preserved. The next design must be
distinct, with fresh ownership attribution and frozen controls.
''')
(root / 'archive-verification.json').write_text(json.dumps({'archive_sha256': evidence['archive_sha256'], 'archive_bytes': evidence['archive_bytes'], 'members': evidence['members'], 'all_members_hash_verified': True, 'all1120raw_children_verified': True, 'valid_cohort_sequential': True}, indent=2) + '\n')
print(json.dumps({key: evidence[key] for key in ['archive_sha256', 'archive_bytes', 'members', 'qualified']}))
