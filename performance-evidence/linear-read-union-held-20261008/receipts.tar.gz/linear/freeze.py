from pathlib import Path
import hashlib
import json
import shutil

root = Path(__file__).parent
previous = Path('/workspace/scratch/gpui-union-state-loop')
policy = json.loads((previous / 'policy.json').read_text())
policy.update({
    'goal': 'Replace copy-and-sort entity/global read union with a linear sorted merge. Reduce complete retained-frame CPU with unchanged requested allocation/live/peak heap and native RSS controls.',
    'baseline': '6e95c2810a67625903fb5ebfae4f11ddbe0fcabf',
    'fincode_pin': 'b64fd9389c58a28048fa7c52d56447e73feffd89',
    'component_pin': 'd8e4aa36aebaee078574ea83e9b630ca5b0e6a80',
    'primary_cases': ['remove-256', 'replace-256', 'grow-256', 'state-remove-256'],
    'primary_gain_gate': 'Every primary complete-frame median thread CPU and elapsed time is at least5% lower and the absolute reduction exceeds both full lane ranges. No CPU/gain inference from diagnostic Instant/counter observations.',
    'other_metrics_gate': 'All20 bare median thread CPU, elapsed, whole-child CPU and native RSS increases fit the complete baseline range. All census held/peak/total requested bytes and allocation calls must not increase; native RSS increases fit baseline full range. Paired frame/scene/hitbox hash, element-state count/bytes match.',
    'basis': 'Current owned full native App/Window baseline diagnostic captures275530 entity/global copied entries and1944893 sort comparisons in8 changed-row256 frames. Union spans place larger cost in sorted read merging than repeated nonempty state prefixes. Prefix investigation has no production candidate or paired result. Exact observations, private recipes and counter overhead preserved.',
    'design_limits': 'Only merge_reads implementation changes. Inputs already sorted by key; merge preserves earliest floor-lifted read including repeated keys. Existing zero-floor empty-input sharing unchanged. Reserve exactly a.len+b.len as previous exact-size collect. State union/checker/recording and all failed candidates untouched. No new dependency/cache/pool/field.',
    'correctness': 'Exhaustive sorted multiset/floor contract against existing chain-sort-dedup reference including duplicates and asymmetric/empty inputs. Test comparison census demonstrates linear mechanism before/after; native retained output oracle, dependency changes, scrolling, panel/live-row/layout/atomic-claim and recorder contracts. Actual owning strictClippy and benchmark isolation before merge.',
    'status': 'Frozen before candidate or paired measurement. No weakening gates or unchanged failed resampling.',
})
(root / 'policy.json').write_text(json.dumps(policy, indent=2) + '\n')
for name in ['build_native.py', 'supervise.py', 'measure.py', 'native-run', 'native_run.c', 'comparison-fixture.rs', 'external-dependencies.json']:
    source = previous / name
    if not source.exists():
        source = Path('/workspace/scratch/gpui-layout-sets-loop') / name
    shutil.copy2(source, root / name)
text = (previous / 'qualify.py').read_text()
start = text.index("  if case in policy['primary_cases'] and kind=='census':")
end = text.index('  summaries[case]=summary', start)
text = text[:start] + '''  if case in policy['primary_cases'] and kind=='bare':
   for metric in ['cpu_ns','elapsed_ns']:
    value=summary[metric];gain=value['baseline_median']-value['candidate_median']
    if gain/value['baseline_median']<0.05 or gain<=max(value['baseline_range'],value['candidate_range']):failures.append([kind,case,metric,'primary gain',gain,value['baseline_range'],value['candidate_range']])
''' + text[end:]
(root / 'qualify.py').write_text(text)
(root / 'pre-candidate-frozen-method.json').write_text(json.dumps({name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in ['policy.json', 'qualify.py', 'measure.py', 'native_run.c', 'native-run', 'comparison-fixture.rs', 'external-dependencies.json']}, indent=2) + '\n')
path = Path('/workspace/scratch/gpui-fork-loop/handoff.json')
handoff = json.loads(path.read_text())
handoff.update(active_workspace='/workspace/zed-linear-reads', active_branch='perf/linear-read-union-20261008', active_iteration=str(root), phase='Distinct linear sorted entity/global read merge. Four5%CPU/elapsed gain targets and20 memory/RSS/CPU controls frozen before candidate/paired samples. Cache preservation active; no build/profile overlaps.')
handoff['next_iteration'] = {'workspace': handoff['active_workspace'], 'branch': handoff['active_branch'], 'directory': str(root), 'baseline': policy['baseline'], 'policy_sha256': hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest(), 'phase': handoff['phase']}
path.write_text(json.dumps(handoff, indent=2) + '\n')
print(json.dumps({'policy_sha256': hashlib.sha256((root / 'policy.json').read_bytes()).hexdigest(), 'controls': len(policy['controls']), 'children': 2 * len(policy['controls']) * (policy['timing_pairs'] + policy['memory_pairs'])}))
