from pathlib import Path
import hashlib
import json
import shutil

root = Path(__file__).parent
source = Path('/workspace/zed-state-prefix')
workspace = root / 'attribution-workspace'
workspace.mkdir()
old = json.loads(Path('/workspace/scratch/gpui-layout-sets-loop/source-inputs.json').read_text())['baseline']
crates = sorted({path.split('/')[1] for path in old if path.startswith('crates/')})
for name in crates:
    shutil.copytree(source / 'crates' / name, workspace / 'crates' / name)
for name in ['Cargo.toml', 'Cargo.lock', 'AGENTS.md', 'README.md', 'rust-toolchain.toml']:
    shutil.copy2(source / name, workspace / name)
shutil.copytree(source / '.cargo', workspace / '.cargo')
for name in ['ibm-plex-sans', 'lilex']:
    shutil.copytree(source / 'assets/fonts' / name, workspace / 'assets/fonts' / name)
path = workspace / 'crates/gpui/src/window/view_retention/dependencies.rs'
text = path.read_text()
marker = 'impl RenderDependencies {\n'
assert text.count(marker) == 1
text = text.replace(marker, '''#[cfg(gpui_union_attribution)]
thread_local! {
    pub(crate) static UNION_COST: Cell<[u64; 8]> = const { Cell::new([0; 8]) };
}

''' + marker)
needle = '    pub(crate) fn union(&self, other: &Self) -> Self {\n'
assert text.count(needle) == 1
text = text.replace(needle, needle + '''        #[cfg(gpui_union_attribution)]
        UNION_COST.with(|counts| {
            let mut value = counts.get();
            value[0] += 1;
            value[6] += u64::from(other.states.is_empty());
            value[7] += u64::from(!self.states.is_empty() && !other.states.is_empty());
            if !other.states.is_empty() && other.states.len() <= self.states.len() {
                let prefix = self.states.iter().zip(other.states.iter()).all(|(left, right)| {
                    value[5] += 1;
                    left.0.same_state(&right.0)
                });
                if prefix {
                    value[1] += 1;
                    value[2] += other.states.len() as u64;
                    value[3] = value[3].max(other.states.len() as u64);
                }
            }
            counts.set(value);
        });
''')
needle = 'states.iter().any(|(version, _)| version.same_state(&state.0))'
assert text.count(needle) == 1
text = text.replace(needle, '''states.iter().any(|(version, _)| {
                #[cfg(gpui_union_attribution)]
                UNION_COST.with(|counts| {
                    let mut value = counts.get();
                    value[4] += 1;
                    counts.set(value);
                });
                version.same_state(&state.0)
            })''')
path.write_text(text)
fixture = Path('/workspace/scratch/gpui-union-state-loop/comparison-fixture.rs').read_text()
needle = '    println!("LAYOUT_SETS_PROFILE '
assert fixture.count(needle) == 1
fixture = fixture.replace(needle, '''    #[cfg(gpui_union_attribution)]
    crate::window::view_retention::dependencies::UNION_COST.with(|counts| {
        let [unions, prefixes, prefix_items, max_prefix, scan_comparisons, prefix_comparisons, right_empty, both_nonempty] = counts.get();
        println!("UNION_COST {{\\\"unions\\\":{unions},\\\"prefixes\\\":{prefixes},\\\"prefix_items\\\":{prefix_items},\\\"max_prefix\\\":{max_prefix},\\\"scan_comparisons\\\":{scan_comparisons},\\\"prefix_comparisons\\\":{prefix_comparisons},\\\"right_empty\\\":{right_empty},\\\"both_nonempty\\\":{both_nonempty}}}");
    });
''' + needle)
(workspace / 'crates/gpui/src/window/view_retention/splice_profile.rs').write_text(fixture)
path = workspace / 'crates/gpui/src/window/view_retention.rs'
text = path.read_text()
text += '\n#[cfg(test)]\nmod splice_profile;\n'
path.write_text(text)
identities = {str(path.relative_to(workspace)): hashlib.sha256(path.read_bytes()).hexdigest() for path in workspace.rglob('*') if path.is_file()}
(root / 'attribution-source-inputs.json').write_text(json.dumps({'current_main': '6e95c2810a67625903fb5ebfae4f11ddbe0fcabf', 'fincode_pin': 'b64fd9389c58a28048fa7c52d56447e73feffd89', 'component_pin': 'd8e4aa36aebaee078574ea83e9b630ca5b0e6a80', 'crates': crates, 'files': identities, 'scope': 'Diagnostic baseline complete App/Window fixture. Private count instrumentation only; no optimization or paired measurement. Original production union executes in full.'}, indent=2) + '\n')
for name in ['build_native.py', 'supervise.py', 'native-run', 'native_run.c']:
    original = Path('/workspace/scratch/gpui-union-state-loop') / name
    if not original.exists():
        original = Path('/workspace/scratch/gpui-layout-sets-loop') / name
    shutil.copy2(original, root / name)
print(json.dumps({'files': len(identities), 'crates': crates, 'source': str(workspace)}))
