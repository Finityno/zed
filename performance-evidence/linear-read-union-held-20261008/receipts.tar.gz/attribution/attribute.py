from pathlib import Path
import hashlib
import json
import os
import subprocess

root = Path(__file__).parent
binary = root / 'attribution-attribution2-artifacts/gpui-ada3fb4d7b1cfe56'
binary_hash = hashlib.sha256(binary.read_bytes()).hexdigest()
cases = json.loads(Path('/workspace/scratch/gpui-union-state-loop/policy.json').read_text())['controls']
output = root / 'attribution-receipts'
output.mkdir()
samples = []
for case in cases:
    command = [str(root / 'native-run'), 'taskset', '-c', '2', str(binary), 'profile_layout_key_sets', '--ignored', '--nocapture', '--test-threads=1']
    environment = dict(os.environ, LAYOUT_SETS_PROFILE_CASE=case, LAYOUT_SETS_PROFILE_ITERATIONS='8')
    log = output / (case + '.log')
    with log.open('w') as stream:
        result = subprocess.run(command, env=environment, stdout=stream, stderr=subprocess.STDOUT, timeout=60)
    sample = {'case': case, 'command': command, 'binary_sha256': binary_hash, 'exit_code': result.returncode, 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    for line in log.read_text().splitlines():
        for marker in ['UNION_COST ', 'LAYOUT_SETS_PROFILE ', 'NATIVE_RECEIPT ']:
            if marker in line:
                sample.update(json.loads(line.split(marker, 1)[1]))
    samples.append(sample)
    (root / 'attribution-samples.json').write_text(json.dumps(samples, indent=2) + '\n')
    assert result.returncode == 0 and 'prefixes' in sample
    print(json.dumps({key: sample[key] for key in ['case', 'unions', 'prefixes', 'prefix_items', 'max_prefix', 'scan_comparisons', 'prefix_comparisons']}), flush=True)
