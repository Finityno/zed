from pathlib import Path
import hashlib
import json

root = Path(__file__).parent
workspace = root / 'attribution-workspace'
path = workspace / 'crates/gpui/src/window/view_retention/dependencies.rs'
text = path.read_text()
marker = 'impl RenderDependencies {\n'
text = text.replace(marker, '''#[cfg(gpui_union_attribution)]
thread_local! {
    pub(crate) static MERGE_COST: Cell<[u64; 8]> = const { Cell::new([0; 8]) };
}

''' + marker)
needle = ') -> Rc<[(T, u64)]> {\n'
assert text.count(needle) == 1
text = text.replace(needle, needle + '''    #[cfg(gpui_union_attribution)]
    MERGE_COST.with(|counts| { let mut value = counts.get(); value[0] += 1; counts.set(value); });
''')
needle = '    let mut merged: Vec<(T, u64)> = a\n'
assert text.count(needle) == 1
text = text.replace(needle, '''    #[cfg(gpui_union_attribution)]
    let started = Instant::now();
    #[cfg(gpui_union_attribution)]
    MERGE_COST.with(|counts| {
        let mut value = counts.get();
        value[1] += 1;
        value[2] += (a.len() + b.len()) as u64;
        value[3] = value[3].max((a.len() + b.len()) as u64);
        value[6] += u64::from(a.is_empty() && b.is_empty());
        value[7] += u64::from(!a.is_empty() && !b.is_empty());
        counts.set(value);
    });
''' + needle)
needle = '    earliest_reads(&mut merged);\n    merged.into()\n'
assert text.count(needle) == 1
text = text.replace(needle, '''    #[cfg(not(gpui_union_attribution))]
    earliest_reads(&mut merged);
    #[cfg(gpui_union_attribution)]
    {
        merged.sort_unstable_by(|left, right| {
            MERGE_COST.with(|counts| { let mut value = counts.get(); value[5] += 1; counts.set(value); });
            left.cmp(right)
        });
        merged.dedup_by_key(|(key, _)| *key);
    }
    let result = merged.into();
    #[cfg(gpui_union_attribution)]
    MERGE_COST.with(|counts| { let mut value = counts.get(); value[4] += started.elapsed().as_nanos() as u64; counts.set(value); });
    result
''')
path.write_text(text)
path = workspace / 'crates/gpui/src/window/view_retention/splice_profile.rs'
text = path.read_text()
needle = '    println!("LAYOUT_SETS_PROFILE '
text = text.replace(needle, '''    #[cfg(gpui_union_attribution)]
    crate::window::view_retention::dependencies::MERGE_COST.with(|counts| {
        let [calls, slow_calls, copied_items, max_items, merge_ns, sort_comparisons, empty_slow, both_nonempty] = counts.get();
        println!("MERGE_COST {{\\\"merge_calls\\\":{calls},\\\"merge_slow_calls\\\":{slow_calls},\\\"merge_copied_items\\\":{copied_items},\\\"merge_max_items\\\":{max_items},\\\"merge_ns\\\":{merge_ns},\\\"merge_sort_comparisons\\\":{sort_comparisons},\\\"merge_empty_slow\\\":{empty_slow},\\\"merge_both_nonempty\\\":{both_nonempty}}}");
    });
''' + needle)
path.write_text(text)
inputs = json.loads((root / 'attribution3-source-inputs.json').read_text())
inputs['files'] = {str(path.relative_to(workspace)): hashlib.sha256(path.read_bytes()).hexdigest() for path in workspace.rglob('*') if path.is_file()}
inputs['scope'] = 'Private baseline complete component entity/global merge copy/sort counts and Instant spans. Original sort/dedup result retained. Setup/warmup and private counter/clock overhead included. No candidate or paired gain.'
(root / 'attribution4-source-inputs.json').write_text(json.dumps(inputs, indent=2) + '\n')
text = (root / 'attribute3.py').read_text().replace('attribution-attribution3-artifacts', 'attribution-attribution4-artifacts').replace('attribution3-receipts', 'attribution4-receipts').replace('attribution3-samples.json', 'attribution4-samples.json')
text = text.replace("['UNION_COST ', 'LAYOUT_SETS_PROFILE ', 'NATIVE_RECEIPT ']", "['UNION_COST ', 'MERGE_COST ', 'LAYOUT_SETS_PROFILE ', 'NATIVE_RECEIPT ']")
text = text.replace("'shared_nonempty']", "'shared_nonempty', 'merge_slow_calls', 'merge_copied_items', 'merge_sort_comparisons', 'merge_ns']")
(root / 'attribute4.py').write_text(text)
