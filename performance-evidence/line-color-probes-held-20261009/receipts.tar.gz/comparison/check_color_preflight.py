from pathlib import Path
import hashlib,json,os,subprocess
root=Path(__file__).parent;policy=json.loads((root/'policy.json').read_text());identities=json.loads((root/'binary-identities.json').read_text());out=root/'functional-preflight';out.mkdir();rows=[]
for case in policy['color_cases']:
    results=[]
    for kind in ['bare','census']:
        for lane in ['baseline','candidate']:
            binary=identities[lane][kind]['path'];log=out/f'{case}-{kind}-{lane}.log'
            command=[str(root/'native-run'),'taskset','-c','2',binary,'profile_colored_transcript','--ignored','--nocapture','--test-threads=1']
            with log.open('w') as stream:result=subprocess.run(command,env=dict(os.environ,COLOR_PROFILE_CASE=case,COLOR_PROFILE_ITERATIONS='2'),stdout=stream,stderr=subprocess.STDOUT,timeout=60)
            assert result.returncode==0,log.read_text()
            data=next(json.loads(line.split('COLOR_PROFILE ',1)[1]) for line in log.read_text().splitlines() if 'COLOR_PROFILE ' in line)
            signature={key:data[key] for key in ['signature','state_count','state_box_bytes','replayed']};results.append(signature)
            rows.append({'case':case,'lane':lane,'kind':kind,'log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'exit_code':result.returncode,'signature':signature,'binary_sha256':identities[lane][kind]['sha256']})
            (root/'functional-preflight-summary.json').write_text(json.dumps({'purpose':'Correctness only;2 iterations per distinct colored case and lane, no gain classification from these metrics','rows':rows},indent=2)+'\n')
    assert all(data==results[0] for data in results),case
print(json.dumps({'children':len(rows),'all_scene_state_replay_outputs_equal':True,'no_performance_gain_classification':True}))
