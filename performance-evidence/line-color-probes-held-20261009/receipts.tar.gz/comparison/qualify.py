from pathlib import Path
import json,statistics
root=Path(__file__).parent;policy=json.loads((root/'policy.json').read_text());results={};failures=[]
for kind in ['bare','census']:
    samples=json.loads((root/(kind+'-samples.json')).read_text());pairs=policy['timing_pairs'] if kind=='bare' else policy['memory_pairs']
    assert len(samples)==len(policy['controls'])*pairs*2
    summary={}
    for case in policy['controls']:
        lanes={lane:sorted([r for r in samples if r['case']==case and r['lane']==lane],key=lambda r:r['pair']) for lane in ['baseline','candidate']}
        assert all(len(rows)==pairs for rows in lanes.values())
        for before,after in zip(lanes['baseline'],lanes['candidate']):
            assert all(before[key]==after[key] for key in ['signature','state_count','state_box_bytes','exit_code']) and before['exit_code']==0
            if case in policy['color_cases']:assert before['replayed']==after['replayed']
        metrics=['cpu_ns','elapsed_ns','child_cpu_ns','peak_rss_kib'] if kind=='bare' else ['held_bytes','peak_bytes','requested_bytes','allocation_calls','peak_rss_kib']
        values={}
        for metric in metrics:
            before=[row[metric] for row in lanes['baseline']];after=[row[metric] for row in lanes['candidate']];old=statistics.median(before);new=statistics.median(after);old_range=max(before)-min(before);new_range=max(after)-min(after)
            allowed=old_range if metric in ['cpu_ns','elapsed_ns','child_cpu_ns','peak_rss_kib'] else 0
            passed=new-old<=allowed
            if not passed:failures.append([kind,case,metric,'control',new-old,allowed])
            values[metric]={'baseline_median':old,'candidate_median':new,'baseline_min':min(before),'baseline_max':max(before),'candidate_min':min(after),'candidate_max':max(after),'baseline_range':old_range,'candidate_range':new_range,'change_percent':(new/old-1)*100 if old else None,'allowed_increase':allowed,'pass':passed}
        if kind=='census' and case in policy['primary_cases']:
            for metric,minimum in [('allocation_calls',0.10),('requested_bytes',0.01)]:
                value=values[metric];gain=value['baseline_median']-value['candidate_median']
                if gain/value['baseline_median']<minimum or gain<=max(value['baseline_range'],value['candidate_range']):failures.append([kind,case,metric,'primary gain',gain,value['baseline_range'],value['candidate_range'],minimum])
        summary[case]=values
    results[kind]=summary
decision={'qualified':not failures,'failures':failures,'summary':results,'primary':{case:{kind:results[kind][case] for kind in results} for case in policy['primary_cases']}}
(root/'decision.json').write_text(json.dumps(decision,indent=2)+'\n');print(json.dumps({'qualified':decision['qualified'],'failures':failures,'primary':decision['primary']}))
