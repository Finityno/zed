
#[cfg(all(test, gpui_layout_sets_census))]
mod color_probe_allocation_tests {
    use super::*;
    #[test]
    fn comparing_a_highlighted_line_needs_no_color_allocation() {
        let mut cx = super::super::layout_retention_tests::text_system_context(0);
        let window = cx.add_window(|_, _| crate::Empty);
        let runs: Vec<_> = (0..32).map(|index| DecorationRun { len: 6, color: crate::hsla(index as f32 / 32., 0.5, 0.5, 1.), background_color: None, underline: None, strikethrough: None }).collect();
        let layout = LineGlyphsLayout::Shaped(Arc::new(LineLayout::default()));
        cx.update_window(window.into(), |_, window, _| {
            crate::perf_count::census::start();
            let key = window.line_glyphs_key(layout.clone(), Point::default(), crate::px(24.), TextAlign::Left, None, &runs).expect("plain glyphs");
            let (_, _, bytes, calls) = crate::perf_count::census::finish();
            assert_eq!((bytes, calls), (0, 0));
            assert_eq!(key.colors.len(), 32);
        }).expect("window");
    }
}
