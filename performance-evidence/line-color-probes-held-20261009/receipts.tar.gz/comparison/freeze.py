from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).parent;common=Path('/workspace/scratch/gpui-window-effects-loop/comparison')
for name in ['run_measurements.py','capture_identities.py','build_all.py','check_contracts.py']:shutil.copy2(common/name,root/name)
p=root/'run_measurements.py';p.write_text(p.read_text().replace("'/workspace/scratch/gpui-union-state-loop'","'/workspace/scratch/gpui-window-effects-loop/comparison'"))
p=root/'check_contracts.py';text=p.read_text().replace("    'scene::tests',","    'scene::tests',\n    'text_system::line::tests',\n    'glyph_painting::tests',")
text=text.replace("'window_effect_idle_tests'","'color_probe_allocation_tests'")
text=text.replace("((4, 4) if lane == 'baseline' else (8, 0))","((0, 1) if lane == 'baseline' else (1, 0))")
text=text.replace("contracts += [(lane, kind, 'color_probe_allocation_tests', 101 if lane == 'baseline' else 0) for kind in ['bare','census'] for lane in ['baseline','candidate']]","contracts += [(lane, 'census', 'color_probe_allocation_tests', 101 if lane == 'baseline' else 0) for lane in ['baseline','candidate']]")
p.write_text(text)
names=['policy.json','measure.py','qualify.py','run_measurements.py','prepare_comparison.py','build_native.py','build_all.py','supervise.py','check_contracts.py','probe-regression.rs','comparison-fixture.rs','transcript-fixture.rs','color-fixture.rs','perf-count.rs','native_run.c','native-run','external-dependencies.json']
identities={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in names}
(root/'pre-candidate-frozen-method.json').write_text(json.dumps(identities,indent=2)+'\n')
p=root/'capture_identities.py';text=p.read_text();start=text.index("frozen = {name:");stop=text.index("previous = ",start)
text=text[:start]+"frozen = {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in "+repr(names+['binary-identities.json','runtime-identities.json','baseline-source-inputs.json','candidate-source-inputs.json'])+"}\n"+text[stop:];p.write_text(text)
print(json.dumps({'frozen_before_candidate':len(identities),'policy_sha256':identities['policy.json']}))
