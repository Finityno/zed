
#[cfg(all(test, gpui_layout_sets_census))]
mod color_probe_allocation_tests {
    use super::*;
    use crate::{Context, IntoElement, ParentElement, Render, Styled};

    struct ColorProbeView {
        runs: Arc<Vec<DecorationRun>>,
        layout: Arc<LineLayout>,
    }

    impl Render for ColorProbeView {
        fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
            let runs = self.runs.clone();
            let layout = self.layout.clone();
            crate::div().size_full().child(crate::canvas(
                |_, _, _| (),
                move |_, _, window, _| {
                    crate::perf_count::census::start();
                    let key = window.line_glyphs_key(LineGlyphsLayout::Shaped(layout.clone()), Point::default(), crate::px(24.), TextAlign::Left, None, &runs).expect("plain glyphs");
                    let (_, _, bytes, calls) = crate::perf_count::census::finish();
                    println!("COLOR_PROBE_LAYOUT {{\"app\":{},\"window\":{},\"owned_key\":{}}}", std::mem::size_of::<crate::App>(), std::mem::size_of::<Window>(), std::mem::size_of::<LineGlyphsKey>());
                    assert_eq!((bytes, calls), (0, 0));
                    assert_eq!(key.colors.len(), 32);
                },
            ).size_full())
        }
    }

    #[test]
    fn comparing_a_highlighted_line_needs_no_color_allocation() {
        let mut cx = super::super::layout_retention_tests::text_system_context(0);
        let runs = Arc::new((0..32).map(|index| DecorationRun { len: 6, color: crate::hsla(index as f32 / 32., 0.5, 0.5, 1.), background_color: None, underline: None, strikethrough: None }).collect());
        cx.add_window(|_, _| ColorProbeView { runs, layout: Arc::new(LineLayout::default()) });
    }
}
