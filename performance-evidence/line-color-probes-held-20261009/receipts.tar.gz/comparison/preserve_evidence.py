from pathlib import Path
import gzip,hashlib,io,json,platform,tarfile
root=Path(__file__).parent;owner=root.parent;work=Path('/workspace/zed-line-colors');output=work/'performance-evidence/line-color-probes-held-20261009';output.mkdir(parents=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((root/'decision.json').read_text());policy=json.loads((root/'policy.json').read_text());assert not d['qualified'] and len(d['failures'])==8
for index in ['frozen-inputs.json','pre-candidate-frozen-method.json']:
    for name,expected in json.loads((root/index).read_text()).items():assert sha(owner/name if name=='source-review.json' else root/name)==expected,name
runtime=json.loads((root/'runtime-identities.json').read_text());assert runtime['uname']==platform.uname()._asdict()
for collection in ['dynamic_libraries','compiler_shared_libraries']:
    for path,expected in runtime[collection].items():assert sha(Path(path))==expected['sha256']
assert sha(Path(runtime['compiler']))==runtime['compiler_sha256']
for dep in json.loads((root/'external-dependencies.json').read_text()):assert sha(Path(dep['path']))==dep['sha256']
for lane in ['baseline','candidate']:
    for path,expected in json.loads((root/(lane+'-source-inputs.json')).read_text())['files'].items():assert sha(root/(lane+'-workspace')/path)==expected,path
    for identity in json.loads((root/'binary-identities.json').read_text())[lane].values():assert sha(Path(identity['path']))==identity['sha256']
builds=json.loads((root/'build-order-receipt.json').read_text())['receipts'];phases=json.loads((root/'valid-cohort-order-receipt.json').read_text())['receipts'];assert len(builds)==4 and len(phases)==2
assert phases[0]['started_unix']>=builds[-1]['started_unix']+builds[-1]['elapsed_seconds'];assert phases[1]['started_unix']>=phases[0]['started_unix']+phases[0]['elapsed_seconds']
for kind,count in [('bare',1674),('census',930)]:
    samples=json.loads((root/(kind+'-samples.json')).read_text());assert len(samples)==count
    for row in samples:assert row['exit_code']==0 and sha(Path(row['log']))==row['log_sha256']
assert len(json.loads((root/'contracts-summary.json').read_text()))==38
assert len(json.loads((root/'functional-preflight-summary.json').read_text())['rows'])==140
layouts=json.loads((root/'fixed-owner-layout-verification.json').read_text());assert layouts['baseline']==layouts['candidate']=={'app':1896,'window':12944,'owned_key':232}
files={}
for base,prefix in [(root,'comparison'),(owner,'attribution')]:
    for path in base.rglob('*'):
        relative=path.relative_to(base)
        if base==owner and relative.parts[0]=='comparison':continue
        if any(part.endswith('-workspace') or part.endswith('-artifacts') for part in relative.parts):continue
        if relative.name in ['source-refresh.json','remote-refresh.json','Cargo.fincode.current.toml']:continue
        if path.is_file() and path.suffix in {'.py','.json','.log','.diff','.rs','.c','.md','.txt'}:files[prefix+'/'+str(relative)]=path
for name in ['Cargo.toml','Cargo.lock','rust-toolchain.toml','LICENSE-APACHE','LICENSE-GPL']:files['native-root/'+name]=root/'candidate-workspace'/name
for lane in ['baseline','candidate']:
    for name in ['window/glyph_painting.rs','gpui.rs','perf_count.rs','window/view_retention/splice_profile.rs','window/view_retention/transcript_profile.rs','window/view_retention/color_profile.rs']:files[lane+'/'+name]=root/(lane+'-workspace')/'crates/gpui/src'/name
files['owner-instrumented/glyph_painting.rs']=owner/'baseline-workspace/crates/gpui/src/window/glyph_painting.rs'
manifest={name:{'bytes':path.stat().st_size,'sha256':sha(path)} for name,path in sorted(files.items())};archive=output/'receipts.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',compresslevel=6,mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w') as tar:
    for name,data in [('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())]+[(name,path.read_bytes()) for name,path in sorted(files.items())]:
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    for name,expected in manifest.items():
        data=tar.extractfile(name).read();assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
evidence={'status':'HELD/unmerged; never repeat unchanged or weaken gates','qualified':False,'baseline':policy['baseline'],'source':'892b5e219c424e298af28a52500a1a465e9c8f77','fincode_main_at_freeze':policy['fincode_main'],'fincode_gpui':policy['fincode_pin'],'component_pin':policy['component_pin'],'valid_children':2604,'workloads':93,'failures':d['failures'],'all_four_primary_churn_targets_pass':True,'observed_primary':d['primary'],'important_gain_not_qualified':'15.65-27.32% fewer complete App allocation calls,3.46-5.57% fewer requested bytes. Four primary held/peak medians unchanged; CPU below variation. Six retained highlighted stream/recolor CPU/elapsed/whole-child controls and two census RSS controls fail. No merge/adoption qualified.','mechanism':'Borrow DecorationRun colors for existing sprite-replay probe; keep owned SmallVec only when recording fresh sprites. No added App/Window/owned-key fields or GPU resources. Existing atlas safety and glyph-only rules unchanged. This differs from held earlier whole-cache designs: current main owns independent replay already.','correctness':'38 final native invocations pass expected baseline red/candidate green. Real canvas paint allocation test baseline960 requested bytes/two calls versus candidatezero; original invalid idle-phase failures never counted as red. App1896/Window12944/owned-key232 exactly equal.140colored four-lane functional children and all2604paired scene/state/replay outputs match; text,1200frame retirement guard, Scene/App/Subscriber/cursor/read/nested/retained/wheel/layout contracts preserved.','protocol':'Four final sequential native builds48.68/49.18/49.54/48.35s, then1674alternating bare children678.68s, then930counting children211.18s. Same59immutableexterns/compiler/System/root/lock/source/runtime/binary identities reverified after phases. No performance rerun. Frozen gain goals and timed fixtures unchanged throughout.','attribution':'16 current-main complete colored App/Window owner children:9/16run key allocatesonce per probe,32run twice,<=8runszero. Scoped3200/6400calls13.61/23.65%ofcomplete32iteration fixturecalls; typical retained unchanged views skip paint. Owned editor builds arbitrary consecutive highlight spans. No app ownership projection from these component counts.','adverse_setup':'Source materialization/sparse .cargo/symlink recopies preserved. First diagnostic parser rejected successful child because harness prefix preceded owner marker; exact original child was reparsed, never rerun. Private census regression initially lacked AppContext import, then incorrectly queried mask outside paint; all invalid source/binaries/contracts preserved. Corrected real-paint helper before any paired performance sample. Production892b5e2 and policy/timed fixtures unchanged; original and corrected helper hashes retained.','coverage_limit':'Recolor fixture notifies200rows individually, causing many more draws than a batched theme change; keep costs as notification-burst control. Four warmups and whole App creation included in census; native timing loop separate. All results Linux fake platform/text/renderer and System, not Fincode whole app, GPU, macOS/Windows or shipped allocator. Existing merged replay itself not qualified against previous main by this comparison.','not_run':'Owning strict Clippy, guards, PR, merge and coherent consumer adoption withheld because performance controls fail.','policy_sha256':sha(root/'policy.json'),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':len(manifest)+1}
(output/'evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
(output/'README.md').write_text('''# Held borrowed line-color probes

The frozen 2,604-child comparison across 93 complete App/Window workloads
meets all four churn targets: 15.65-27.32% fewer allocation calls and
3.46-5.57% fewer requested bytes in highlighted fast-mode redraws. Primary
held and peak heap stay unchanged; primary CPU differences are below variation.
Six retained highlighted streaming/recolor CPU, elapsed and whole-child fields,
and two census RSS fields fail. Preserve this design unmerged and never repeat
it unchanged or weaken the gates. No PR or adoption is qualified.

The probe borrows decoration colors, retaining owned colors only for fresh
sprite recording. This adds no cache fields or GPU resources and leaves atlas
retirement/generation, retained verification and glyph-only checks intact.
App, Window and owned-key sizes are identically 1,896, 12,944 and 232 bytes.
The real paint allocation regression fails before with 960 bytes/two calls and
passes after with zero. Thirty-eight final native correctness invocations pass,
and 140 functional plus all 2,604 paired scene/state/replay outputs match.

Sixteen current-main diagnostic children attribute key spills above eight runs.
All raw samples, setup failures, rejected helper sources and exact binary
identities are preserved. The invalid idle-phase regression was corrected into
a real paint callback before any paired performance sample; its failures are
not evidence of an allocation regression. The original successful diagnostic
child rejected by a parser was reparsed without repeating that child.

Both lanes share the same 59 immutable externs, compiler, dependency/root/lock
identities and System allocator. Four builds, bare timing and counting census
run sequentially with external deadlines; every archive member is hash verified.
Recolor controls issue individual row notifications and represent a burst,
not a batched theme change. Native Linux fake-platform results are not app,
physical GPU, macOS/Windows or shipped-allocator percentages. Continue with
the retained capacity of existing replay maps in idle windows as a distinct
memory owner; retain every adverse result from this design.
''')
(root/'archive-verification.json').write_text(json.dumps({key:evidence[key] for key in ['archive_sha256','archive_bytes','members','valid_children','qualified']},indent=2)+'\n')
print((root/'archive-verification.json').read_text())
