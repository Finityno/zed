from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).parent/'comparison';rejected=root/'rejected-probe-paint-phase';rejected.mkdir()
for name in ['probe-regression.rs','pre-candidate-frozen-method.json','frozen-inputs.json','binary-identities.json','runtime-identities.json','baseline-source-inputs.json','candidate-source-inputs.json','build-order-receipt.json','contracts-summary.json']:
    shutil.copy2(root/name,rejected/name)
for pattern in ['*-build.log','*-build-receipt.json','*-supervised*','contract-*']:
    for p in root.glob(pattern):shutil.copy2(p,rejected/p.name)
old=(root/'probe-regression.rs').read_text()
new='''
#[cfg(all(test, gpui_layout_sets_census))]
mod color_probe_allocation_tests {
    use super::*;
    use crate::{Context, IntoElement, ParentElement, Render, Styled};

    struct ColorProbeView {
        runs: Arc<Vec<DecorationRun>>,
        layout: Arc<LineLayout>,
    }

    impl Render for ColorProbeView {
        fn render(&mut self, _: &mut Window, _: &mut Context<Self>) -> impl IntoElement {
            let runs = self.runs.clone();
            let layout = self.layout.clone();
            crate::div().size_full().child(crate::canvas(
                |_, _, _| (),
                move |_, _, window, _| {
                    crate::perf_count::census::start();
                    let key = window.line_glyphs_key(LineGlyphsLayout::Shaped(layout.clone()), Point::default(), crate::px(24.), TextAlign::Left, None, &runs).expect("plain glyphs");
                    let (_, _, bytes, calls) = crate::perf_count::census::finish();
                    println!("COLOR_PROBE_LAYOUT {{\\"app\\":{},\\"window\\":{},\\"owned_key\\":{}}}", std::mem::size_of::<crate::App>(), std::mem::size_of::<Window>(), std::mem::size_of::<LineGlyphsKey>());
                    assert_eq!((bytes, calls), (0, 0));
                    assert_eq!(key.colors.len(), 32);
                },
            ).size_full())
        }
    }

    #[test]
    fn comparing_a_highlighted_line_needs_no_color_allocation() {
        let mut cx = super::super::layout_retention_tests::text_system_context(0);
        let runs = Arc::new((0..32).map(|index| DecorationRun { len: 6, color: crate::hsla(index as f32 / 32., 0.5, 0.5, 1.), background_color: None, underline: None, strikethrough: None }).collect());
        cx.add_window(|_, _| ColorProbeView { runs, layout: Arc::new(LineLayout::default()) });
    }
}
'''
(root/'probe-regression.rs').write_text(new)
for lane in ['baseline','candidate']:
    p=root/(lane+'-workspace/crates/gpui/src/window/glyph_painting.rs');shutil.copy2(p,rejected/(lane+'-glyph_painting.rs'));text=p.read_text();assert text.endswith(old);p.write_text(text[:-len(old)]+new)
    p=root/(lane+'-source-inputs.json');data=json.loads(p.read_text());data['files']['crates/gpui/src/window/glyph_painting.rs']=hashlib.sha256((root/(lane+'-workspace/crates/gpui/src/window/glyph_painting.rs')).read_bytes()).hexdigest();p.write_text(json.dumps(data,indent=2)+'\n')
for p in root.glob('*-artifacts'):p.rename(rejected/p.name)
p=root/'pre-candidate-frozen-method.json';data=json.loads(p.read_text());before=data['probe-regression.rs'];data['probe-regression.rs']=hashlib.sha256((root/'probe-regression.rs').read_bytes()).hexdigest();p.write_text(json.dumps(data,indent=2)+'\n')
(root/'probe-paint-phase-correction.json').write_text(json.dumps({'before':before,'after':data['probe-regression.rs'],'reason':'Native allocation regression attempted content-mask lookup outside paint; baseline and candidate both failed same invalid phase. Replaced private helper with real canvas paint callback. Added runtime owner-size output to confirm zero fixed-cache allowance.','production_unchanged':'892b5e219c424e298af28a52500a1a465e9c8f77','policy_and_all_timed_fixtures_unchanged':True,'paired_performance_children_before_correction':0,'invalid_contracts_not_successful_before_after_regression':True},indent=2)+'\n')
print(json.dumps({'private_helper_corrected_only':True,'prior_binaries_raw_preserved':4,'policy_unchanged':True,'paired_samples':0}))
