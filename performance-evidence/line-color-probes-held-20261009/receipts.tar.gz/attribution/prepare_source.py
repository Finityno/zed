from pathlib import Path
import json, hashlib, os, subprocess

root = Path(__file__).parent
data = json.loads((root / 'source-refresh.json').read_text())
repository = Path('/workspace/zed-perf')
environment = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_INDEX_FILE=str(root / 'import-index'))
def git(*args, input=None):
    return subprocess.check_output(['git', '-C', str(repository), *args], env=environment, input=input).decode().strip()
git('read-tree', 'df6e7d05b529313ad142f397a4e4ea428c2c01ae')
files = {}
for path, value in data.items():
    if not path.startswith('crates/'):
        continue
    assert value['encoding'] == 'utf-8'
    payload = value['content'].encode()
    sha = git('hash-object', '-w', '--stdin', input=payload)
    assert sha == value['sha'], path
    git('update-index', '--add', '--cacheinfo', '100644', sha, path)
    files[path] = {'sha': sha, 'sha256': hashlib.sha256(payload).hexdigest()}
assert git('write-tree') == data['commit']['tree']['sha']
(root / 'current-commit.json').write_text(json.dumps(data['commit'], indent=2) + '\n')
subprocess.run(['python3', '/workspace/scratch/gpui-empty-recording-adoption-loop/import_signed_commit.py', str(root/'current-commit.json'), str(repository)], check=True)
work = Path('/workspace/zed-line-colors')
if not work.exists():
    subprocess.run(['git', '-C', str(repository), 'worktree', 'add', '--no-checkout', '-b', 'perf/line-color-keys-20261009', str(work), data['commit']['sha']], env=dict(os.environ,GIT_NO_LAZY_FETCH='1'), check=True)
subprocess.run(['git', '-C', str(work), 'sparse-checkout', 'init', '--cone'], env=dict(os.environ,GIT_NO_LAZY_FETCH='1'), check=True)
crates = json.loads(Path('/workspace/scratch/gpui-window-effects-loop/baseline-source-inputs.json').read_text())['crates']
subprocess.run(['git', '-C', str(work), 'sparse-checkout', 'set', *['crates/'+name for name in crates], 'assets/fonts/ibm-plex-sans', 'assets/fonts/lilex'], env=dict(os.environ,GIT_NO_LAZY_FETCH='1'), check=True)
if not (work/'README.md').exists():
    subprocess.run(['git', '-C', str(work), 'read-tree', '-mu', 'HEAD'], env=dict(os.environ,GIT_NO_LAZY_FETCH='1'), check=True)
assert (work/'README.md').read_text().startswith('> [!IMPORTANT]\n> Remove this line to confirm')
(root/'current-source-verification.json').write_text(json.dumps({'commit':data['commit']['sha'],'tree':data['commit']['tree']['sha'],'all_eight_blobs_verified':files,'whole_tree_verified':True},indent=2)+'\n')
(root/'PERFORMANCE_GOAL.current.md').write_text(data['goal'])
(root/'Cargo.fincode.current.toml').write_text(data['manifest'])
handoff_path = Path('/workspace/scratch/gpui-fork-loop/handoff.json')
handoff = json.loads(handoff_path.read_text())
proof = json.loads(Path('/workspace/scratch/gpui-window-effects-loop/comparison/publication-verification.json').read_text())
handoff['held_window_idle_effects'] = dict(proof, workspace='/workspace/zed-idle-effects', branch='perf/window-idle-effects-20261009', directory='/workspace/scratch/gpui-window-effects-loop/comparison', children=2296, workloads=82, failed_fields=18, status='HELD/unmerged; no unchanged rerun or weakened gates. All evidence published, whole tree verified.')
handoff.update(active_workspace=str(work), active_branch='perf/line-color-keys-20261009', active_iteration=str(root), active_comparison=None, phase='Current-main line-key color churn owner investigation; no builds/profiling active. Independent merged transcript replay preserved.', current_zed_main=data['commit']['sha'], recent_owned_main=data['commit']['sha'], current_fincode_main='f0eb8eaaae85b9834bfe670a2b0b84e0b479b767', current_fincode_pins={'gpui':'95114473898ea198175ab1d4fbb72d6e66de39ca','gpui_platform':'95114473898ea198175ab1d4fbb72d6e66de39ca','sum_tree':'95114473898ea198175ab1d4fbb72d6e66de39ca','gpui-component':'3eafbc7543f04e2760644e068837d86a6dc1e030'})
handoff['next_iteration']={'workspace':str(work),'branch':'perf/line-color-keys-20261009','directory':str(root),'baseline':data['commit']['sha'],'active_stage':handoff['phase'],'active_session':None,'candidate':None}
handoff['next_steps']=['Attribute current-main replay key color spills using native complete highlighted transcript/App/Window owners before choosing source.','Freeze meaningful gain goals and broad controls before repeated alternating comparison.','Preserve independent adoption and all failed experiments; no duplicate build or overlapping profiling.']
handoff['independent_transcript_replay']={'pr':'https://github.com/Finityno/zed/pull/46','merged':data['commit']['sha'],'head':'646634a5615b19da5ea16c83af0b3a5d3d474ccb','scope':'Independent owner merge; author claims not newly qualified here; preserve source.'}
handoff_path.write_text(json.dumps(handoff,indent=2)+'\n')
print(json.dumps({'workspace':str(work),'baseline':data['commit']['sha'],'whole_tree_verified':True}))
