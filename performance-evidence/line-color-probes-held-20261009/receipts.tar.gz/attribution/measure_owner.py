from pathlib import Path
import hashlib,json,os,subprocess
root=Path(__file__).parent
cases=['color-redraw-off-200-4','color-redraw-off-200-8','color-redraw-off-200-9','color-redraw-off-200-16','color-redraw-off-200-32','color-rebuild-on-200-16','color-stream-on-200-16','color-redraw-on-200-16']
binary=root/'baseline-attribution-color-artifacts/gpui-ada3fb4d7b1cfe56'
identity=hashlib.sha256(binary.read_bytes()).hexdigest()
out=root/'owner-receipts';out.mkdir(exist_ok=True)
samples=[]
for case in cases:
    for sample in range(2):
        command=[str(root/'native-run'),'taskset','-c','2',str(binary),'profile_colored_transcript','--ignored','--nocapture','--test-threads=1']
        env=dict(os.environ,COLOR_PROFILE_CASE=case,COLOR_PROFILE_ITERATIONS='32')
        log=out/f'{case}-{sample}.log'
        if not log.exists():
            with log.open('w') as stream: result=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=60)
            assert result.returncode==0,log.read_text()
        row={'case':case,'sample':sample,'binary_sha256':identity,'command':command,'exit_code':0,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'log':str(log)}
        for line in log.read_text().splitlines():
            for marker,key in [('COLOR_PROFILE ','complete_app'),('COLOR_OWNER ','key_scope'),('NATIVE_RECEIPT ','native')]:
                if marker in line:row[key]=json.loads(line.split(marker,1)[1])
        samples.append(row)
        (root/'owner-samples.json').write_text(json.dumps(samples,indent=2)+'\n')
        assert all(k in row for k in ['complete_app','key_scope','native']) and row['native']['exit_code']==0,log.read_text()
print(json.dumps({'children':len(samples),'all_exits_zero':True,'cases':{case:[{'owner_calls':r['key_scope']['allocation_calls'],'owner_requested':r['key_scope']['requested_bytes'],'complete_calls':r['complete_app']['allocation_calls'],'complete_requested':r['complete_app']['requested_bytes'],'replayed':r['complete_app']['replayed']} for r in samples if r['case']==case] for case in cases}}))
