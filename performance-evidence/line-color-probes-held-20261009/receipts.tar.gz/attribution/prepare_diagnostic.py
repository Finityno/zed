from pathlib import Path
import json, hashlib, shutil, subprocess, os
root=Path(__file__).parent
source=Path('/workspace/zed-line-colors')
work=root/'baseline-workspace'
work.mkdir(exist_ok=True)
crates=json.loads(Path('/workspace/scratch/gpui-window-effects-loop/baseline-source-inputs.json').read_text())['crates']
for name in crates:shutil.copytree(source/'crates'/name,work/'crates'/name,symlinks=True,dirs_exist_ok=True)
for name in ['Cargo.toml','Cargo.lock','README.md','rust-toolchain.toml','LICENSE-APACHE','LICENSE-GPL']:shutil.copy2(source/name,work/name)
shutil.copy2('/workspace/scratch/gpui-window-effects-loop/comparison/baseline-workspace/AGENTS.md',work/'AGENTS.md')
shutil.copytree(source/'.cargo',work/'.cargo',symlinks=True,dirs_exist_ok=True)
for name in ['ibm-plex-sans','lilex']:shutil.copytree(source/'assets/fonts'/name,work/'assets/fonts'/name,symlinks=True,dirs_exist_ok=True)
common=Path('/workspace/scratch/gpui-window-effects-loop/comparison')
shutil.copy2(common/'perf-count.rs',work/'crates/gpui/src/perf_count.rs')
p=work/'crates/gpui/src/gpui.rs';p.write_text(p.read_text()+'\n#[cfg(all(test, gpui_layout_sets_census))]\n#[path = "perf_count.rs"]\npub(crate) mod perf_count;\n')
for src,dest in [('comparison-fixture.rs','splice_profile.rs'),('transcript-fixture.rs','transcript_profile.rs')]:shutil.copy2(common/src,work/'crates/gpui/src/window/view_retention'/dest)
shutil.copy2(root/'color-fixture.rs',work/'crates/gpui/src/window/view_retention/color_profile.rs')
p=work/'crates/gpui/src/window/view_retention/tests.rs';p.write_text(p.read_text()+'\n#[cfg(target_os = "linux")]\n#[path = "transcript_profile.rs"]\nmod transcript_profile;\n#[cfg(target_os = "linux")]\n#[path = "color_profile.rs"]\nmod color_profile;\n')
p=work/'crates/gpui/src/window/glyph_painting.rs';text=p.read_text()
text=text.replace('        let mut colors = SmallVec::new();','        #[cfg(gpui_line_color_attribution)]\n        let before = crate::perf_count::census::snapshot();\n        let mut colors = SmallVec::new();',1)
text=text.replace('        Some(LineGlyphsKey {','        #[cfg(gpui_line_color_attribution)]\n        color_attribution::record(before);\n        Some(LineGlyphsKey {',1)
text+='''
#[cfg(gpui_line_color_attribution)]
pub(crate) mod color_attribution {
    use std::sync::atomic::{AtomicUsize, Ordering::Relaxed};
    static BYTES: AtomicUsize=AtomicUsize::new(0);
    static CALLS: AtomicUsize=AtomicUsize::new(0);
    static KEYS: AtomicUsize=AtomicUsize::new(0);
    pub(crate) fn reset() { BYTES.store(0,Relaxed); CALLS.store(0,Relaxed); KEYS.store(0,Relaxed); }
    pub(crate) fn record(before: (isize,isize,usize,usize)) {
        let after=crate::perf_count::census::snapshot();
        BYTES.fetch_add(after.2-before.2,Relaxed); CALLS.fetch_add(after.3-before.3,Relaxed); KEYS.fetch_add(1,Relaxed);
    }
    pub(crate) fn report() { println!("COLOR_OWNER {{\\"keys\\":{},\\"requested_bytes\\":{},\\"allocation_calls\\":{}}}",KEYS.load(Relaxed),BYTES.load(Relaxed),CALLS.load(Relaxed)); }
}
'''
p.write_text(text)
files={str(p.relative_to(work)):hashlib.sha256(p.read_bytes()).hexdigest() for p in work.rglob('*') if p.is_file()}
(root/'baseline-source-inputs.json').write_text(json.dumps({'baseline':'6b18c87dd5f2d1ccbee1ee641054295f2a78390b','candidate':None,'crates':crates,'files':files,'scope':'Current main exact source plus private common owner fixtures/census; attribution cfg only diagnostic.'},indent=2)+'\n')
for name in ['build_native.py','supervise.py','native-run','native_run.c','external-dependencies.json']:
    shutil.copy2(common/name,root/name)
p=root/'build_native.py';text=p.read_text().replace("    args += ['--cfg', 'gpui_union_attribution']","    args += ['--cfg', 'gpui_line_color_attribution']");p.write_text(text)
print(json.dumps({'files':len(files),'baseline':'6b18c87dd5f2d1ccbee1ee641054295f2a78390b'}))
