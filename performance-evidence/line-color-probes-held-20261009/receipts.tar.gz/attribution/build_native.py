from pathlib import Path
import json, os, subprocess, sys, hashlib, time
root = Path(__file__).parent
lane, kind = sys.argv[1:]
configuration = json.loads(Path('/workspace/scratch/gpui-splice-state-loop/baseline-rustc-command.json').read_text())
args = configuration['args'].copy()
output = root / (lane + '-' + kind + '-artifacts')
output.mkdir()
args[args.index('--out-dir') + 1] = str(output)
if kind == 'census' or kind.startswith('attribution'):
    args += ['--cfg', 'gpui_layout_sets_census']
if kind.startswith('attribution'):
    args += ['--cfg', 'gpui_line_color_attribution']
workspace = root / (lane + '-workspace')
environment = dict(os.environ, **configuration['environment'])
environment['CARGO_MANIFEST_DIR'] = str(workspace / 'crates/gpui')
environment['CARGO_MANIFEST_PATH'] = str(workspace / 'crates/gpui/Cargo.toml')
log = root / (lane + '-' + kind + '-build.log')
started = time.time()
with log.open('w') as stream:
    result = subprocess.run(['timeout', '-k', '10', '600', *args], cwd=workspace, env=environment, stdout=stream, stderr=subprocess.STDOUT)
receipt = {'lane': lane, 'kind': kind, 'command': args, 'cwd': str(workspace), 'environment': {key: environment[key] for key in configuration['environment']}, 'exit_code': result.returncode, 'seconds': time.time() - started, 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(), 'dependency_artifacts': 'Exact same immutable dependency objects from completed baseline Cargo build; only out-dir, source cwd/Cargo package path and census cfg differ.'}
(root / (lane + '-' + kind + '-build-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: receipt[key] for key in ('lane', 'kind', 'exit_code', 'seconds', 'log_sha256')}), flush=True)
if result.returncode:
    print(log.read_text())
raise SystemExit(result.returncode)
