from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).parent
comparison=root/'comparison';comparison.mkdir()
common=Path('/workspace/scratch/gpui-window-effects-loop/comparison')
ordinary=json.loads((common/'policy.json').read_text())
colors=[f'color-redraw-off-32-{runs}' for runs in [4,8,9,16,32]]
colors += [f'color-redraw-{mode}-{rows}-{runs}' for mode in ['off','on'] for rows in [32,200] for runs in [16,32]]
colors += [f'color-{scenario}-{mode}-200-{runs}' for scenario in ['stream','scroll','recolor','resize','rebuild','decorated'] for mode in ['off','on'] for runs in [16,32]]
colors=list(dict.fromkeys(colors))
policy={'goal':'Borrow run colors while comparing unchanged glyph sprite replay; retain owned colors only for fresh recordings. No added fields/cache size/reserve/layout tuning. Allocation churn improvement in complete highlighted App/Window fast-mode redraw; retained mode and other workloads controls.',
    'baseline':'6b18c87dd5f2d1ccbee1ee641054295f2a78390b','fincode_main':'f0eb8eaaae85b9834bfe670a2b0b84e0b479b767','fincode_pin':'95114473898ea198175ab1d4fbb72d6e66de39ca','component_pin':'3eafbc7543f04e2760644e068837d86a6dc1e030',
    'primary_cases':[f'color-redraw-off-{rows}-{runs}' for rows in [32,200] for runs in [16,32]],
    'color_cases':colors,'transcript_cases':ordinary['transcript_cases'],'controls':ordinary['controls'][:58]+colors,
    'timing_pairs':9,'memory_pairs':5,'timing_iterations':256,'memory_iterations':128,
    'primary_gain_gate':'All four primary complete-App census allocation-call medians reduce at least10%, requested bytes at least1%; absolute gains must exceed BOTH full lane ranges. CPU gain optional, any claim must exceed both ranges and5%.',
    'cpu_controls':'All ordinary/primary median thread CPU, elapsed, whole-child CPU and native peak RSS increases fit full BASELINE range; census native peak RSS likewise. Bare timing separate from allocator census; no new resampling unchanged.',
    'memory_controls':'Zero added fixed fields or cache-capacity allowance. All held/peak/requested bytes/allocation-call median increases <=0, App/Window sizes and paired scene/states/replay output must match.',
    'coverage':'Native Linux complete App/Window fake text/platform/renderer and System. No whole-app, GPU, macOS/Windows or shipped allocator gain. Before/after starts at current independently merged replay; no qualification claim for original PR46.',
    'owner_basis':'16 current-main diagnostic children: 9/16run replay key allocates1,32run allocates2 each probe; scoped3200/6400 calls are13.61/23.65% of complete32iteration App fixture calls. Eight inline runs allocate0; retained unchanged views skip line paint. Owned editor line_render builds arbitrary consecutive highlight spans; prior owned transcript complete paint dominated53-73us.'}
(comparison/'policy.json').write_text(json.dumps(policy,indent=2)+'\n')
for name in ['comparison-fixture.rs','transcript-fixture.rs','perf-count.rs','build_native.py','supervise.py','native-run','native_run.c','external-dependencies.json']:shutil.copy2(common/name,comparison/name)
shutil.copy2(root/'color-fixture.rs',comparison/'color-fixture.rs')
print(json.dumps({'workloads':len(policy['controls']),'children':len(policy['controls'])*28,'primary':policy['primary_cases'],'policy_sha256':hashlib.sha256((comparison/'policy.json').read_bytes()).hexdigest()}))
